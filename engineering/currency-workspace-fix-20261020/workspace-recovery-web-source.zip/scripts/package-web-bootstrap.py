"""Wrap a completed Expo Web export with verified, resumable public-asset delivery."""
from pathlib import Path
import sys,re,hashlib,json,shutil
source=Path(sys.argv[1]).resolve();dest=Path(sys.argv[2]).resolve()
assert source.is_dir() and not dest.exists() and source!=dest
for file in source.rglob('*'):
 if not file.is_file() or file.suffix=='.map':continue
 rel=file.relative_to(source)
 assert not any(part in str(rel) for part in ['.env','.private.','.sql','.apk'])
 target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,target)
entries=list((dest/'_expo/static/js/web').glob('entry-*.js'));assert len(entries)==1
entry=entries[0];raw=entry.read_bytes();rel=entry.relative_to(dest).as_posix()
config={'url':'/'+rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
template=Path(__file__).with_name('web-bootstrap-loader.js').read_text(encoding='utf-8')
loader=template.replace('__ZETRA_BUNDLE_CONFIG__',json.dumps(config,separators=(',',':')))
assert '</script' not in loader.lower();count=0
for html in dest.rglob('*.html'):
 text=html.read_text(encoding='utf-8')
 pattern=r'<script src="'+re.escape('/'+rel)+r'" defer></script>'
 result,n=re.subn(pattern,lambda _:'<script data-zetra-delivery="verified-ranges">'+loader+'</script>',text)
 if not n:
  assert rel not in text;continue
 assert n==1
 html.write_text(result,encoding='utf-8');count+=1
assert count>0
print(json.dumps({'wrappedHTML':count,'bundle':config,'bundleUnchangedByPackaging':True,'publication':False}))
