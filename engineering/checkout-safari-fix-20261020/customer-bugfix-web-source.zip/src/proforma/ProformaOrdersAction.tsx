import React,{useCallback,useState} from 'react';
import {Pressable,Text,View,useWindowDimensions} from 'react-native';
import {useRouter,useFocusEffect} from 'expo-router';
import {useLanguage} from '../i18n/LanguageProvider';
import {Button} from '../ui/Button';
import {ordersText} from './ordersCopy';
import {proformaText} from './labels';
import {createDocumentService} from './documentsApi';
import {supabase} from '../supabase/supabaseClient';
import {makeId} from '../offline/salesQueue';
import {pendingCount} from './pendingCount';
/** History API remains the authority for permissions and records; no fabricated pending count. */
export function ProformaOrdersAction({organizationId,storeId}:{organizationId:string;storeId:string|null}){
 const router=useRouter(),{language}=useLanguage();const {width}=useWindowDimensions();
 const [count,setCount]=useState<number|null>(null);
 useFocusEffect(useCallback(()=>{const controller=new AbortController();setCount(null);if(organizationId&&storeId){const service=createDocumentService({organizationId,storeId},supabase,makeId);void pendingCount((signal,before)=>service.client.page(signal,before),controller.signal).then(value=>{if(!controller.signal.aborted)setCount(value)}).catch(()=>{})}return()=>controller.abort()},[organizationId,storeId]));
 return <Pressable
   accessibilityRole="button"
   accessibilityLabel={ordersText(language,'orders')}
   accessibilityState={{disabled:!storeId}}
   disabled={!storeId}
   onPress={()=>router.push({pathname:'/sales/proforma',params:{storeId:storeId!}} as any)}
   style={({pressed})=>({
     alignSelf:width>=900?'flex-start':'stretch',
     width:width>=900?280:'100%',
     minHeight:76,
     padding:16,
     borderWidth:1,
     borderColor:'#BFDBFE',
     borderRadius:16,
     backgroundColor:pressed?'#DBEAFE':'#EFF6FF',
     justifyContent:'center'
   })}>
   <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between'}}>
     <View style={{gap:5,flex:1}}>
       <Text style={{fontWeight:'800',fontSize:15,color:'#1E3A8A'}}>{ordersText(language,'orders')}</Text>
       <Text style={{fontSize:12,color:'#475569'}}>{proformaText(language,'pending')}</Text>
     </View>
     <Text style={{fontSize:26,fontWeight:'900',color:'#2563EB'}}>{count===null?'—':count}</Text>
   </View>
 </Pressable>;
}
