import React,{useCallback,useEffect,useState,useSyncExternalStore} from 'react';
import {Text} from 'react-native';
import {useOrg} from '../context/OrgContext';
import {useLanguage} from '../i18n/LanguageProvider';
import {referenceRateStore} from './rateStore';
import {currentValuation,displayDecimal} from './currentValuation';
import {formatExact,formatCurrencyExact} from './engine';

/** Explicit legacy-TZS display reader. Never used by payment inputs, route carts or posting payloads. */
export function formatPreferredLegacyMoney(amount:unknown,target:string|null,evidence:Parameters<typeof currentValuation>[2],now:Date,organizationId:string,locale='en'){
 const decimal=displayDecimal(amount);
 if(decimal===null)return 'Conversion unavailable';
 if(!target||target==='TZS')return formatCurrencyExact(decimal,'TZS',locale,0);
 const view=currentValuation({amount:decimal,currency:'TZS',organizationId,contextRevision:null,source:'TRANSACTION_RECORD'},target,evidence,now,organizationId);
 return view.status==='CONVERTED'?`${formatExact(view.displayAmount,locale)} ${view.displayCurrency}`:`Conversion unavailable · Original ${formatCurrencyExact(decimal,'TZS',locale,0)}`;
}
function usePreferredReference(){
 const {displayCurrency}=useLanguage();const state=useSyncExternalStore(referenceRateStore.subscribe,referenceRateStore.getSnapshot,referenceRateStore.getSnapshot),[tick,setTick]=useState(0);
 useEffect(()=>{if(!displayCurrency||displayCurrency==='TZS')return;void referenceRateStore.refresh();const timer=setInterval(()=>{setTick(v=>v+1);void referenceRateStore.refresh()},60000);return()=>clearInterval(timer)},[displayCurrency]);
 return {...state,tick};
}
export function usePreferredDisplayMoney(organizationId?:string,ready=true){
 const org=useOrg(),prefs=useLanguage(),rate=usePreferredReference();const id=organizationId??String(org.activeOrgId??'');
 return useCallback((amount:unknown,_options?:unknown)=>{
  if(!ready||org.loading||!id||id!==String(org.activeOrgId??'')||prefs.currencyOrganization!==id)return 'Conversion unavailable';
  return formatPreferredLegacyMoney(amount,prefs.displayCurrency,rate.evidence,new Date(),id,prefs.language);
 },[ready,org.loading,id,org.activeOrgId,prefs.currencyOrganization,prefs.displayCurrency,prefs.language,rate.evidence,rate.tick]);
}
export function usePreferredRateDescription(){
 const {displayCurrency,language,currencyPreferenceError,currencyOrganization}=useLanguage(),state=usePreferredReference();
 const result=displayCurrency&&displayCurrency!=='TZS'&&currencyOrganization?currentValuation({amount:'1',currency:'TZS',organizationId:currencyOrganization,contextRevision:null,source:'TRANSACTION_RECORD'},displayCurrency,state.evidence,new Date(),currencyOrganization):null;
 const reference=result?.status==='CONVERTED'?result.rate:null;
 return `${currencyPreferenceError?'Display preference could not be saved on this device. ':''}${displayCurrency&&displayCurrency!=='TZS'?`${language==='sw'?'Thamani kwa kiwango cha sasa':'Current-rate valuation'} · ${displayCurrency} · ${reference?`${reference.provider} · Effective ${reference.referenceDate} · Retrieved ${reference.retrievedAt} · Reference rate, not bank buy/sell rate`:'Conversion unavailable; verified fresh reference rate required'} · Original TZS records unchanged`:''}`;
}
export function PreferredRateNote({compact=false}:{compact?:boolean}={}){
 const full=usePreferredRateDescription();
 const description=compact?full.replace(/ · Retrieved .*? · Original TZS records unchanged/,'').replace('BOT_REFERENCE','BoT').replace('ECB_REFERENCE','ECB'):full;
 return description?<Text accessibilityLiveRegion="polite" style={{fontSize:11,lineHeight:16,color:'#64748b',flexShrink:1}}>{description}</Text>:null;
}
