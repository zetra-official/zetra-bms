// Exact Ionicons glyphs, subset for public login only. Business fonts are unchanged.
import React from 'react';
import {Text,Platform} from 'react-native';
import {useFonts} from 'expo-font';
const points={"cart-outline": 61955, "cube": 62104, "people": 62623, "bar-chart": 61807, "document-text": 62131, "settings": 62827, "hardware-chip-outline": 62309, "cloud-outline": 62045, "eye-outline": 62186, "eye-off-outline": 62184} as const;
const font={ZetraLoginIcons:require('../../../assets/fonts/login-icons.ttf')};
export function LoginIcon({name,size=24,color}:{name:keyof typeof points;size?:number;color:string}){
 const [loaded]=useFonts(font);
 return <Text accessible={false} style={{fontFamily:'ZetraLoginIcons',fontSize:size,lineHeight:size*1.2,color,width:size+2,textAlign:'center'}}>{(Platform.OS==='web'||loaded)?String.fromCodePoint(points[name]):' '}</Text>;
}
