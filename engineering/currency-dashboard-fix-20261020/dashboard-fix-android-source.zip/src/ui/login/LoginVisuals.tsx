import React,{useState} from 'react';
import {Image,Text,View,Pressable,Modal,Linking,ScrollView,useWindowDimensions} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {useLanguage} from '../../i18n/LanguageProvider';
import type {Language} from '../../i18n/catalog';

const copy={
 headline:['Professional business\nmanagement for','Usimamizi wa biashara\nwa kitaalamu kwa','Une gestion professionnelle\npour des','Gestão profissional\npara','إدارة أعمال احترافية\nمن أجل','Gestión empresarial\nprofesional para','专业的企业管理\n助力'],
 accent:['modern operations.','shughuli za kisasa.','opérations modernes.','operações modernas.','عمليات حديثة.','operaciones modernas.','现代化运营。'],
 intro:['Manage stores, products, sales, inventory, staff and finance from one powerful platform.','Simamia maduka, bidhaa, mauzo, stoo, wafanyakazi na fedha kwenye mfumo mmoja imara.','Gérez magasins, produits, ventes, stocks, personnel et finances sur une seule plateforme.','Gira lojas, produtos, vendas, inventário, equipa e finanças numa única plataforma.','أدر المتاجر والمنتجات والمبيعات والمخزون والموظفين والمالية من منصة واحدة قوية.','Gestiona tiendas, productos, ventas, inventario, personal y finanzas desde una sola plataforma.','在一个强大的平台上管理门店、产品、销售、库存、员工和财务。'],
 signIn:['Sign in to your account','Ingia kwenye akaunti yako','Connectez-vous à votre compte','Entre na sua conta','سجّل الدخول إلى حسابك','Inicia sesión en tu cuenta','登录您的账户'],
 access:['Access your business and keep it running smoothly from anywhere.','Fikia biashara yako na endelea kuiendesha vizuri ukiwa popote.','Accédez à votre entreprise et gérez-la facilement où que vous soyez.','Aceda ao seu negócio e mantenha-o a funcionar a partir de qualquer lugar.','ادخل إلى أعمالك وأدرها بسلاسة من أي مكان.','Accede a tu negocio y gestiónalo con facilidad desde cualquier lugar.','随时随地访问并顺畅管理您的业务。'],
 home:['Home','Mwanzo','Accueil','Início','الرئيسية','Inicio','首页'],
 features:['Features','Vipengele','Fonctionnalités','Funcionalidades','المزايا','Funciones','功能'],
 pricing:['Pricing','Bei','Tarifs','Preços','الأسعار','Precios','价格'],
 about:['About','Kuhusu','À propos','Sobre','من نحن','Acerca de','关于'],
 support:['Support','Msaada','Assistance','Apoio','الدعم','Soporte','支持'],
 close:['Close','Funga','Fermer','Fechar','إغلاق','Cerrar','关闭'],
 website:['Visit the official ZETRA website','Tembelea tovuti rasmi ya ZETRA','Visiter le site officiel de ZETRA','Visitar o site oficial da ZETRA','زيارة موقع ZETRA الرسمي','Visitar el sitio oficial de ZETRA','访问 ZETRA 官方网站'],
 plans:['For current plans, pricing and support, visit our official website.','Kwa mipango ya sasa, bei na msaada, tembelea tovuti yetu rasmi.','Pour les offres, les tarifs et l’assistance, consultez notre site officiel.','Para planos, preços e apoio atualizados, visite o nosso site oficial.','للاطلاع على الخطط والأسعار الحالية والحصول على الدعم، زر موقعنا الرسمي.','Para consultar planes, precios y soporte actuales, visita nuestro sitio oficial.','如需当前套餐、价格和支持，请访问我们的官方网站。'],
 illustrative:['Illustrative dashboard · Not live financial data','Dashboard ya mfano · Si taarifa hai za fedha','Tableau de bord illustratif · Données non réelles','Painel ilustrativo · Não são dados financeiros em tempo real','لوحة توضيحية · ليست بيانات مالية مباشرة','Panel ilustrativo · No son datos financieros en vivo','示意仪表盘 · 非实时财务数据'],
 or:['or','au','ou','ou','أو','o','或'],
} as const;
const languageIndex:Record<Language,number>={en:0,sw:1,fr:2,pt:3,ar:4,es:5,zh:6};
export function masterLoginText(language:Language,key:keyof typeof copy){return copy[key][languageIndex[language]]}
const featureNames={
 en:['Sales & POS','Inventory','Customers (CRM)','Finance','Products','Multi-Branch','AI Assistant','Cloud Ready'],
 sw:['Mauzo na POS','Stoo','Wateja (CRM)','Fedha','Bidhaa','Matawi Mengi','Msaidizi wa AI','Mtandaoni'],
 fr:['Ventes et caisse','Stocks','Clients (CRM)','Finances','Produits','Multi-agences','Assistant IA','Accès cloud'],
 pt:['Vendas e POS','Inventário','Clientes (CRM)','Finanças','Produtos','Várias filiais','Assistente de IA','Na nuvem'],
 ar:['المبيعات ونقاط البيع','المخزون','العملاء (CRM)','المالية','المنتجات','فروع متعددة','مساعد الذكاء الاصطناعي','الوصول السحابي'],
 es:['Ventas y TPV','Inventario','Clientes (CRM)','Finanzas','Productos','Varias sucursales','Asistente de IA','En la nube'],
 zh:['销售与收银','库存','客户 (CRM)','财务','产品','多门店','AI 助手','云端访问'],
} as const;
const featureDetails={
 en:['Fast & Reliable','Real-time Stock','Loyalty & Insights','Reports & Analytics','Easy Management','Scale Your Business','Smart Insights','Access Anywhere'],
 sw:['Haraka na Imara','Stoo kwa Wakati Halisi','Uaminifu na Uchambuzi','Ripoti na Uchambuzi','Usimamizi Rahisi','Kuza Biashara Yako','Uchambuzi Mahiri','Fikia Popote'],
 fr:['Rapide et fiable','Stocks en temps réel','Fidélité et analyses','Rapports et analyses','Gestion facile','Développez votre activité','Analyses intelligentes','Accès partout'],
 pt:['Rápido e fiável','Stock em tempo real','Fidelização e análises','Relatórios e análises','Gestão simples','Expanda o seu negócio','Análises inteligentes','Acesso em qualquer lugar'],
 ar:['سريع وموثوق','مخزون في الوقت الفعلي','الولاء والتحليلات','التقارير والتحليلات','إدارة سهلة','طوّر أعمالك','تحليلات ذكية','وصول من أي مكان'],
 es:['Rápido y fiable','Inventario en tiempo real','Fidelidad y análisis','Informes y análisis','Gestión sencilla','Haz crecer tu negocio','Análisis inteligente','Acceso desde cualquier lugar'],
 zh:['快速可靠','实时库存','忠诚度与洞察','报告与分析','便捷管理','拓展业务','智能洞察','随处访问'],
} as const;
const icons=['cart-outline','cube','people','bar-chart','document-text','settings','hardware-chip-outline','cloud-outline'] as const;
const accents=['#31E990','#E9AB5C','#2386FF','#2DBAF6','#AC63F0','#8C63E7','#24EBA4','#1A9DFF'];

/** Render only the approved source logo crop; none of its mock inputs/buttons are shown. */
export function LoginBrand({compact=false,width}:{compact?:boolean;width?:number}){
 const w=width??(compact?190:288),scale=w/292;
 return <View accessible accessibilityRole="image" accessibilityLabel="ZETRA BMS — Business Management System" style={{width:w,height:68*scale,overflow:'hidden',direction:'ltr'}}>
  <Image accessible={false} source={require('../../../assets/images/login-master-reference.jpg')} style={{position:'absolute',width:1280*scale,height:720*scale,left:-48*scale,top:-19*scale}}/>
 </View>;
}
export function LoginBackdrop({desktop}:{desktop:boolean}){
 const {width}=useWindowDimensions();
 return <View pointerEvents="none" accessible={false} style={{position:'absolute',top:0,left:0,right:0,bottom:0,backgroundColor:'#031323'}}>
  {desktop&&<Image accessible={false} source={require('../../../assets/images/login-master-artwork.png')} resizeMode="cover" style={{width:'100%',height:width*941/1672}}/>}
 </View>;
}
export function LoginMobileArtwork(){
 const {language}=useLanguage();return <View style={{width:'100%',height:168,marginBottom:14,overflow:'hidden',borderRadius:18,backgroundColor:'#031323'}}>
  <Image accessible accessibilityLabel={masterLoginText(language,'illustrative')} source={require('../../../assets/images/login-master-artwork.png')} resizeMode="cover" style={{width:'100%',height:'100%'}}/>
  <Text style={{position:'absolute',bottom:8,left:8,right:8,textAlign:'center',fontSize:10,color:'#DAE9F5',backgroundColor:'rgba(2,17,33,0.88)',padding:5,borderRadius:8}}>{masterLoginText(language,'illustrative')}</Text>
 </View>;
}
export function LoginHero(){
 const {language}=useLanguage(),{width}=useWindowDimensions(),rtl=language==='ar',font=width>=1400?36:32;
 return <View style={{width:'28.5%',minWidth:0,alignSelf:'flex-start',paddingTop:10,paddingBottom:12,direction:rtl?'rtl':'ltr'}}>
  <Text accessibilityRole="header" style={{fontSize:font,lineHeight:font+2,fontWeight:'800',color:'#F5F8FC',letterSpacing:-0.7}}>{masterLoginText(language,'headline')}{'\n'}<Text style={{color:'#39D99F'}}>{masterLoginText(language,'accent')}</Text></Text>
  <Text style={{color:'#C2CBDB',fontSize:14,lineHeight:23,marginTop:14,marginBottom:24}}>{masterLoginText(language,'intro')}</Text>
  <View style={{flexDirection:'row',flexWrap:'wrap',columnGap:12,rowGap:15}}>{featureNames[language].map((name,i)=><View key={icons[i]} style={{width:'47%',minHeight:52,flexDirection:'row',alignItems:'center',gap:10}}>
   <View style={{width:44,height:50,borderRadius:11,backgroundColor:'rgba(5,29,54,0.92)',borderWidth:1,borderColor:accents[i]+'55',alignItems:'center',justifyContent:'center',shadowColor:accents[i],shadowRadius:9,shadowOpacity:0.25,shadowOffset:{width:0,height:0}}}><Ionicons name={icons[i]} color={accents[i]} size={29}/></View>
   <View style={{flex:1,minWidth:0}}><Text style={{color:'#EEF4FC',fontWeight:'700',fontSize:12,lineHeight:17}}>{name}</Text><Text style={{color:'#B7C4D5',fontSize:10,lineHeight:15,marginTop:3}}>{featureDetails[language][i]}</Text></View>
  </View>)}</View>
  <Text style={{marginTop:16,color:'#BDCFDE',fontSize:10,lineHeight:15}}>{masterLoginText(language,'illustrative')}</Text>
 </View>;
}
/** Real informational navigation; pricing/support never fabricate plans or contact details. */
export function LoginNavigation(){
 const {language}=useLanguage(),[section,setSection]=useState<'features'|'pricing'|'about'|'support'|null>(null);const tx=(k:keyof typeof copy)=>masterLoginText(language,k);
 return <><View accessibilityRole="toolbar" style={{flex:1,flexDirection:'row',gap:24,alignItems:'center',justifyContent:'center'}}>{(['home','features','pricing','about','support'] as const).map(key=><Pressable key={key} accessibilityRole="button" onPress={()=>setSection(key==='home'?null:key)} style={{minHeight:44,justifyContent:'center',borderBottomWidth:key==='home'&&!section?2:0,borderColor:'#20DCA0'}}><Text style={{color:key==='home'&&!section?'#2BDB9F':'#DAE5F2',fontSize:12,fontWeight:'600'}}>{tx(key)}</Text></Pressable>)}</View>
  <Modal visible={section!==null} transparent animationType="fade" onRequestClose={()=>setSection(null)}><View style={{flex:1,backgroundColor:'rgba(0,8,20,0.8)',justifyContent:'center',padding:24}}><View accessibilityViewIsModal style={{width:'100%',maxWidth:480,alignSelf:'center',padding:24,gap:20,borderRadius:20,backgroundColor:'#0B233B',borderWidth:1,borderColor:'#31526F'}}><Text accessibilityRole="header" style={{color:'#FFF',fontSize:24,fontWeight:'700'}}>{section?tx(section):''}</Text><ScrollView style={{maxHeight:300}}><Text style={{color:'#C5D3E4',lineHeight:24,fontSize:15}}>{section==='features'?featureNames[language].join(' · '):section==='about'?'ZETRA TECHNOLOGIES LIMITED\n\n'+tx('intro'):tx('plans')}</Text></ScrollView><Pressable accessibilityRole="link" onPress={()=>void Linking.openURL('https://zetra.tz')} style={{minHeight:44,justifyContent:'center'}}><Text style={{color:'#42E2B0',fontWeight:'700'}}>{tx('website')} ↗</Text></Pressable><Pressable accessibilityRole="button" onPress={()=>setSection(null)} style={{minHeight:44,justifyContent:'center'}}><Text style={{color:'#FFF'}}>{tx('close')}</Text></Pressable></View></View></Modal>
 </>;
}

