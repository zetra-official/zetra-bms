import {ProformaConversionAction} from './ProformaConversionAction';
import React,{useEffect,useMemo,useRef,useState} from 'react';
import {ActivityIndicator,AppState,Modal,Pressable,ScrollView,Text,TextInput,View} from 'react-native';
import {useLanguage} from '../i18n/LanguageProvider';
import {supabase} from '../supabase/supabaseClient';
import {makeId} from '../offline/salesQueue';
import {Button} from '../ui/Button';
import {createDocumentService,type DocumentContext,type DocumentDetail,type DocumentInput} from './documentsApi';
import type {RpcPort} from './supabaseTransport';
import {proformaText} from './labels';
import {normalText} from './normalCopy';
import {displayDecimal} from './document';
import {ProformaExportButton} from './ProformaOrdersPanel';
import {readProformaCart,acknowledgeProformaCart} from './checkoutDraft';
import {InvoiceCurrencyModal} from './InvoiceCurrencyModal';
import {invoiceFxText} from './invoiceFxCopy';
import {AccountingCurrencySetup} from './AccountingCurrencySetup';
import {currencyUx} from './currencyUxCopy';
import type {PageRow} from './client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {consumeSavedCart,recordSavedCart} from './savedCart';
import {ordersText} from './ordersCopy';

export function ProformaDocuments({organizationId,storeId,startNew=false,draftId,onStartCheckout}:{organizationId:string;storeId:string;startNew?:boolean;draftId?:string;onStartCheckout?:()=>void}) {
 const {language}=useLanguage(),t=(k:Parameters<typeof proformaText>[1])=>proformaText(language,k),n=(k:Parameters<typeof normalText>[1])=>normalText(language,k);
 const service=useMemo(()=>createDocumentService({organizationId,storeId},supabase as unknown as RpcPort,makeId),[organizationId,storeId]);
 const [context,setContext]=useState<DocumentContext|null>(null),[history,setHistory]=useState<PageRow[]>([]),[historyFailed,setHistoryFailed]=useState(false),[cursor,setCursor]=useState<string|null>(null),[detail,setDetail]=useState<DocumentDetail|null>(null),[form,setForm]=useState<DocumentInput|null>(null),[editing,setEditing]=useState(false),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(false),[uncertain,setUncertain]=useState(false),[converter,setConverter]=useState(false),[checkoutSummary,setCheckoutSummary]=useState<{total:string;subtotal?:string;discountAmount?:string}|null>(null);
   const [orderTab,setOrderTab]=useState<'pending'|'draft'|'history'>('pending');
  const orderRows=history.filter(row=>
    orderTab==='pending'
      ? row.status==='PENDING'||row.status==='ACCEPTED'
      : orderTab==='draft'
        ? row.status==='DRAFT'
        : row.status==='CONVERTED'||row.status==='CANCELLED'||row.status==='EXPIRED'
  );
  const docId=useRef(makeId()),pending=useRef<null|(()=>Promise<DocumentDetail>)>(null),gate=useRef(false),epoch=useRef(0),mounted=useRef(true);
 const originatingCart=useRef<{actorId:string;source:string;draftId:string}|null>(null);
 const empty=(ctx:DocumentContext):DocumentInput=>({currency:ctx.currency??'',validDate:ctx.validDate,items:[],discountType:'fixed',discountValue:'0',customer:{name:'',phone:''},notes:'',terms:''});
 useEffect(()=>{mounted.current=true;const controller=new AbortController();const at=++epoch.current;setLoading(true);setError(false);
  void Promise.all([service.context('',undefined,controller.signal),service.client.page(controller.signal)]).then(async([initial,page])=>{if(controller.signal.aborted||at!==epoch.current)return;const staged=readProformaCart({organizationId,storeId,actorId:initial.actorId},draftId);const ctx=staged?await service.context('',staged.items.map(item=>item.product_id),controller.signal):initial;if(controller.signal.aborted||at!==epoch.current)return;setContext(ctx);setHistory(page.rows);setCursor(page.nextBefore);if(ctx.canCreate&&staged){if(staged.metadata?.sourceCart)originatingCart.current={actorId:ctx.actorId,source:staged.metadata.sourceCart,draftId:staged.id};const input=empty(ctx);if(staged){input.items=staged.items.map(item=>({productId:item.product_id,quantity:String(item.qty),unitPrice:String(item.unit_price)}));if(staged.metadata){if(staged.metadata.total)setCheckoutSummary({total:staged.metadata.total,subtotal:staged.metadata.subtotal,discountAmount:staged.metadata.discountAmount});input.customer={name:staged.metadata.customerName,phone:staged.metadata.customerPhone};input.notes=staged.metadata.notes;input.discountType=staged.metadata.discountType;input.discountValue=staged.metadata.discountValue}}setForm(input);setEditing(true);if(staged)acknowledgeProformaCart(staged.id)}}).catch(()=>{if(!controller.signal.aborted)setError(true)}).finally(()=>{if(!controller.signal.aborted)setLoading(false)});
  return()=>{mounted.current=false;epoch.current++;controller.abort()};
 },[service,draftId]);
 useEffect(()=>{const sub=AppState.addEventListener('change',state=>{if(state==='active'&&!gate.current)void service.context().then(ctx=>{if(mounted.current)setContext(old=>({...ctx,products:old?.products??ctx.products}))}).catch(()=>{})});return()=>sub.remove()},[service]);
 async function action(run:()=>Promise<void>){if(gate.current)return;gate.current=true;setBusy(true);setError(false);const at=epoch.current;try{await run()}catch{if(mounted.current&&at===epoch.current){setError(true);setUncertain(service.client.hasPending);if(!service.client.hasPending)pending.current=null}}finally{gate.current=false;if(mounted.current&&at===epoch.current)setBusy(false)}}
 async function refreshHistory(){try{const page=await service.client.page(new AbortController().signal);if(mounted.current){setHistory(page.rows);setCursor(page.nextBefore);setHistoryFailed(false)}}catch{if(mounted.current)setHistoryFailed(true)}}
 async function save(){if(!form)return;const input=JSON.parse(JSON.stringify(form)) as DocumentInput;pending.current??=()=>service.save(docId.current,detail?.revision.revision??null,input);await action(async()=>{const saved=await pending.current!();if(originatingCart.current){recordSavedCart({organizationId,storeId,...originatingCart.current,documentId:saved.document.id});originatingCart.current=null;try{await consumeSavedCart(AsyncStorage,{organizationId,storeId,actorId:context!.actorId})}catch{/* Saved receipt remains for the POS focus cleanup retry. Never resubmit the document. */}}if(!mounted.current)return;pending.current=null;setDetail(saved);setForm(saved.revision.editInput);setEditing(false);setUncertain(false);await refreshHistory()})}
 async function issue(){if(!detail)return;const selected=detail;pending.current??=()=>service.issue(selected);await action(async()=>{const saved=await pending.current!();if(!mounted.current)return;pending.current=null;setDetail(saved);setEditing(false);setUncertain(false);await refreshHistory();onStartCheckout?.()})}
 function change(update:Partial<DocumentInput>){if(!busy&&!uncertain&&form){if(update.items||update.discountType||update.discountValue!==undefined)setCheckoutSummary(null);setForm({...form,...update})}}
 function newDocument(){if(!context||busy||uncertain||!onStartCheckout)return;onStartCheckout()}

 async function open(id:string){await action(async()=>{const found=await service.client.detail(id,new AbortController().signal);if(!mounted.current)return;docId.current=id;setCheckoutSummary(null);setDetail(found);setForm(found.revision.editInput);setEditing(false);pending.current=null})}
 const field=(label:string,value:string,onChange:(v:string)=>void,numeric=false)=><View style={{gap:5}}><Text style={{color:'#475569',fontSize:13,fontWeight:'700'}}>{label}</Text><TextInput accessibilityLabel={label} value={value} editable={!busy&&!uncertain} onChangeText={onChange} keyboardType={numeric?'decimal-pad':'default'} style={{minHeight:46,borderWidth:1,borderColor:'#CBD5E1',borderRadius:12,padding:12,color:'#0F172A',backgroundColor:'#fff'}}/></View>;
 const money=(value:string,code:string)=>displayDecimal(value,language)+' '+code;
 const card={backgroundColor:'#FFFFFF',borderWidth:1,borderColor:'#DBE7EC',borderRadius:18,padding:16,gap:12} as const;
 const unsupported=!!form?.items.some(item=>{const product=context?.products.find(p=>p.productId===item.productId);return product?.precision||!product||product.unitPrice!==item.unitPrice});
   const checkoutReview=Boolean(startNew&&draftId&&checkoutSummary&&editing&&form&&!detail);
  return <ScrollView style={{flex:1,backgroundColor:'#FFFFFF'}} keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:16,gap:16,maxWidth:920,width:'100%',alignSelf:'center',direction:language==='ar'?'rtl':'ltr',paddingBottom:40}}>
  <Text style={{fontSize:25,fontWeight:'900',color:'#0F172A'}}>{t('invoice')}</Text>
  <Text style={{color:'#526777',lineHeight:21}}>{t('notProof')}</Text>
  {loading&&<ActivityIndicator/>}{error&&<Text accessibilityRole="alert" style={{color:'#A52B36',lineHeight:21}}>{uncertain?n('retry'):n('failed')}</Text>}
  {context&&<View style={{flexDirection:'row',flexWrap:'wrap',gap:10}}><Button title={t('orders')} disabled={busy||uncertain} onPress={()=>{setEditing(false);setDetail(null)}} variant="secondary"/>{context.canCreate&&<Button title={n('new')} disabled={busy||uncertain||!context.currency||!onStartCheckout} onPress={newDocument}/>}</View>}
  {context&&<AccountingCurrencySetup key={organizationId+storeId} organizationId={organizationId} role={context.role} current={context.currency} onConfirmed={async code=>{const ctx=await service.context();if(ctx.currency!==code)throw Error('CONFIRMED_CURRENCY_READBACK_FAILED');if(mounted.current){setContext(ctx);setForm(old=>old?{...old,currency:ctx.currency??''}:empty(ctx))}}}/>}
  {context&&!context.currency&&<Button title={currencyUx(language,'retry')} variant="secondary" disabled={busy} onPress={()=>void action(async()=>{const ctx=await service.context();if(mounted.current)setContext(ctx)})}/>}
  {detail&&!editing&&<Button title={currencyUx(language,'convert')} variant="secondary" onPress={()=>setConverter(true)}/>}
  {detail&&<InvoiceCurrencyModal visible={converter} onClose={()=>setConverter(false)} from={detail.revision.currency} total={detail.revision.total} canConfirm={context?.role==='owner'&&detail.canEdit&&!busy&&!uncertain} onConfirm={async(body,request)=>{const saved=await service.invoiceFx(detail,body as unknown as Record<string,unknown>,request);if(mounted.current){setDetail(saved);setForm(saved.revision.editInput);await refreshHistory()}}}/>}
  {startNew&&context&&!editing&&!detail&&<Text style={{color:'#475569',lineHeight:21}}>{n('checkoutRequired')}</Text>}
     {checkoutReview&&form&&context?.currency&&context.canCreate&&<View style={card}>
     <Text style={{fontSize:20,fontWeight:'800',color:'#0F172A'}}>{t('invoice')}</Text>
     {form.items.map(item=><View key={item.productId} style={{padding:10,backgroundColor:'#F6FAFC',borderRadius:10,gap:4}}>
       <Text style={{fontWeight:'700'}}>{context.products.find(p=>p.productId===item.productId)?.description??item.productId}</Text>
       <Text>{t('quantity')}: {item.quantity}</Text>
       <Text>{t('price')}: {money(item.unitPrice,form.currency)}</Text>
     </View>)}
     <Text>{t('customer')}: {form.customer.name} {form.customer.phone}</Text>
     <Text>{t('discount')}: {form.discountValue}{form.discountType==='percent'?'%':' '+form.currency}</Text>
     <Text>{t('notes')}: {form.notes}</Text>
     <Text style={{fontSize:23,fontWeight:'900',color:'#0F172A'}}>{t('total')}: {money(checkoutSummary!.total,form.currency)}</Text>
     {unsupported&&<Text style={{color:'#92400E'}}>{n('unsupported')}</Text>}
     <Button title={uncertain?t('retry'):n('save')}
       disabled={busy||(!uncertain&&(!context.currency||form.items.length===0||unsupported))}
       onPress={()=>void save()}/>
   </View>}
   {!checkoutReview&&context?.currency&&context.canCreate&&editing&&form&&<View style={card}>
   <Text style={{fontWeight:'800',color:'#0F172A'}}>{form.currency||'—'} · {context.timeZone}</Text><Text style={{color:'#526777',fontSize:12,lineHeight:19}}>{n('pricing')}</Text>
   {form.items.map((item,index)=><View key={item.productId} style={{...card,backgroundColor:'#F6FAFC'}}><Text style={{fontWeight:'700'}}>{context.products.find(p=>p.productId===item.productId)?.description??item.productId}</Text>{field(t('quantity'),item.quantity,value=>change({items:form.items.map((row,i)=>i===index?{...row,quantity:value}:row)}),true)}<Text>{t('price')}: {money(item.unitPrice,form.currency)}</Text><Button title={n('remove')} variant="secondary" disabled={busy||uncertain} onPress={()=>change({items:form.items.filter((_,i)=>i!==index)})}/></View>)}
   {checkoutSummary&&<View style={card}><Text style={{color:'#475569'}}>{n('checkoutSummary')}</Text><Text style={{color:'#0F172A',fontSize:22,fontWeight:'800'}}>{t('total')}: {money(checkoutSummary.total,form.currency)}</Text></View>}
   {unsupported&&<Text style={{color:'#92400E'}}>{n('unsupported')}</Text>}
   <View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}><Button title={form.currency||'—'} variant="secondary" disabled={busy||uncertain} onPress={()=>change({discountType:'fixed'})}/><Button title="%" variant="secondary" disabled={busy||uncertain} onPress={()=>change({discountType:'percent'})}/><Text>{t('discount')}: {form.discountType==='percent'?'%':form.currency}</Text></View>
   {field(t('discount'),form.discountValue,value=>change({discountValue:value}),true)}
   {field(n('date'),form.validDate,value=>change({validDate:value}))}
   <Text style={{fontWeight:'700'}}>{t('customer')}</Text><View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}><Button title={n('manual')} variant="secondary" disabled={busy||uncertain} onPress={()=>change({customer:{name:'',phone:''}})}/>{context.customers.slice(0,15).map(customer=><Button key={customer.id} title={customer.name||customer.phone} variant="secondary" disabled={busy||uncertain} onPress={()=>change({customer:{id:customer.id,name:customer.name,phone:customer.phone}})}/>)}</View>
   {!form.customer.id?<>{field(n('name'),form.customer.name??'',value=>change({customer:{...form.customer,name:value}}))}{field(n('phone'),form.customer.phone??'',value=>change({customer:{...form.customer,phone:value}}))}</>:<Text>{form.customer.name} · {form.customer.phone}</Text>}
   {field(t('notes'),form.notes,value=>change({notes:value}))}{field(t('terms'),form.terms,value=>change({terms:value}))}
   <Text>{n('calculated')}</Text><Button title={uncertain?t('retry'):n('save')} disabled={busy||(!uncertain&&(!context.currency||form.items.length===0||unsupported))} onPress={()=>void save()}/>
  </View>}
  {detail&&!editing&&<View style={card}><Text accessibilityLiveRegion="polite" style={{color:"#047857",fontWeight:"800"}}>{ordersText(language,"saved")}</Text>{onStartCheckout&&<Button title={ordersText(language,"returnPOS")} variant="secondary" onPress={onStartCheckout}/>}<Text style={{fontSize:21,fontWeight:'800'}}>{detail.revision.reference}</Text><Text>{t((detail.document.status??detail.revision.status).toLowerCase() as 'draft'|'pending'|'accepted'|'converted'|'expired'|'cancelled')} · {t('revision')} {detail.revision.revision}</Text><Text>{detail.revision.customer?.name} {detail.revision.customer?.phone}</Text>{detail.revision.items.map(item=><Text key={item.productId}>{item.description} · {item.quantity} × {money(item.unitPrice,detail.revision.currency)}</Text>)}<Text>{t('discount')}: {money(detail.revision.discount,detail.revision.currency)}</Text><Text style={{fontSize:22,fontWeight:'900'}}>{t('total')}: {money(detail.revision.total,detail.revision.currency)}</Text><Text>{t('validity')}: {new Intl.DateTimeFormat(language,{dateStyle:'medium',timeStyle:'short',timeZone:detail.revision.timeZone}).format(new Date(detail.revision.validUntil))}</Text><Text>{detail.revision.notes}</Text>
   {detail.canEdit&&<><Button title={n('edit')} disabled={busy||uncertain} onPress={()=>void action(async()=>{const ctx=await service.context('',detail.revision.items.map(item=>item.productId));if(mounted.current){setContext(ctx);setEditing(true);setForm(detail.revision.editInput)}})} variant="secondary"/><Button title={uncertain?t('retry'):n('issue')} disabled={busy} onPress={()=>void issue()}/></>}
   {detail.revision.invoiceFx&&<View style={card}><Text style={{color:'#0F172A',fontWeight:'800'}}>{invoiceFxText(language,'preview')}: {money(detail.revision.invoiceFx.convertedTotal,detail.revision.invoiceFx.to)}</Text><Text style={{color:'#475569',lineHeight:21}}>{invoiceFxText(language,'manual')}</Text><Text style={{color:'#475569'}}>1 {detail.revision.currency} = {detail.revision.invoiceFx.rate} {detail.revision.invoiceFx.to} · {detail.revision.invoiceFx.source} · {detail.revision.invoiceFx.confirmedAt}</Text></View>}
   {!uncertain&&<ProformaExportButton revision={detail.revision}/>}<ProformaConversionAction organizationId={organizationId} storeId={storeId} documentId={detail.document.id} revision={detail.revision.revision}/>
  </View>}
  {historyFailed&&<View><Text accessibilityRole="alert">{t('loadFailed')}</Text><Button title={t('retry')} disabled={busy||uncertain} onPress={()=>void refreshHistory()}/></View>}
     {!editing&&!detail&&context&&<View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>
     {(['pending','draft','history'] as const).map(tab=>
       <Pressable key={tab} accessibilityRole="button"
         accessibilityState={{selected:orderTab===tab}}
         onPress={()=>setOrderTab(tab)}
         style={{paddingVertical:12,paddingHorizontal:18,borderRadius:12,
           backgroundColor:orderTab===tab?'#2563EB':'#F1F5F9',
           borderWidth:1,borderColor:orderTab===tab?'#2563EB':'#CBD5E1'}}>
         <Text style={{fontWeight:'800',color:orderTab===tab?'#FFFFFF':'#334155'}}>
           {tab==='pending'?t('pending'):tab==='draft'?t('draft'):t('converted')}
         </Text>
       </Pressable>
     )}
   </View>}
   {!editing&&!detail&&<View style={{gap:10}}>{history.length===0&&!loading?<Text>{t('empty')}</Text>:orderRows.map(row=><Button key={row.id} title={`${row.reference}${((row as PageRow & {customer?:{name?:string}}).customer?.name?.trim())?` · ${(row as PageRow & {customer?:{name?:string}}).customer!.name}`:""} · ${money(row.total,row.currency)} · ${t(row.status.toLowerCase() as 'draft'|'pending'|'accepted'|'converted'|'expired'|'cancelled')}`} variant="secondary" disabled={busy||uncertain} onPress={()=>void open(row.id)}/>)}{cursor&&<Button title={n('more')} disabled={busy||uncertain} variant="secondary" onPress={()=>void action(async()=>{const page=await service.client.page(new AbortController().signal,cursor);if(mounted.current){setHistory(rows=>[...rows,...page.rows]);setCursor(page.nextBefore)}})}/>}</View>}
 </ScrollView>;
}
