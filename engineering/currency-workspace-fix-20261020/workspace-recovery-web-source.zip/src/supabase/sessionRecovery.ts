import type {Session} from '@supabase/supabase-js';

/** Only an authoritative rejected refresh permits removing a stored session. */
export function isRejectedRefresh(error: unknown): boolean {
  const value = error as {code?: string; message?: string} | null;
  if (['refresh_token_not_found', 'refresh_token_already_used', 'session_not_found', 'session_expired'].includes(value?.code ?? '')) return true;
  return /^Invalid Refresh Token: (Refresh Token Not Found|Already Used|No Valid Session Found)$/i.test(value?.message ?? '');
}

export async function connectionDeadline<T>(work: PromiseLike<T>, milliseconds: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([Promise.resolve(work), new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error('WORKSPACE_CONNECTION_TIMEOUT')), milliseconds);
    })]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

type SessionResponse = {data: {session: Session | null}; error: unknown};
type SessionReader = {getSession: () => Promise<SessionResponse>; refreshSession: () => Promise<SessionResponse>};
export type SessionRead = {status: 'authenticated' | 'signed_out' | 'retry'; session: Session | null; error: unknown};

/** A transport failure is unknown auth state, never proof of sign-out. No storage mutation. */
export async function readSessionForBootstrap(auth: SessionReader, timeout = 5000, now = Date.now()): Promise<SessionRead> {
  try {
    let result = await connectionDeadline(auth.getSession(), timeout);
    if (result.error && /jwt\s*expired/i.test(String((result.error as {message?:string}).message??''))) result=await connectionDeadline(auth.refreshSession(),timeout);
    if (result.error) return {status: isRejectedRefresh(result.error) ? 'signed_out' : 'retry', session: null, error: result.error};
    if (!result.data.session) return {status: 'signed_out', session: null, error: null};
    if (result.data.session.expires_at && result.data.session.expires_at * 1000 <= now + 5000) {
      result = await connectionDeadline(auth.refreshSession(), timeout);
      if (result.error) return {status: isRejectedRefresh(result.error) ? 'signed_out' : 'retry', session: null, error: result.error};
      if (!result.data.session || (result.data.session.expires_at && result.data.session.expires_at * 1000 <= now)) return {status: 'retry', session: null, error: new Error('SESSION_REFRESH_INCOMPLETE')};
    }
    return {status: 'authenticated', session: result.data.session, error: null};
  } catch (error) {
    return {status: isRejectedRefresh(error) ? 'signed_out' : 'retry', session: null, error};
  }
}
