// Native keeps Expo's existing implementation. Web resolves the .web file.
export { Ionicons as default } from '@expo/vector-icons';
