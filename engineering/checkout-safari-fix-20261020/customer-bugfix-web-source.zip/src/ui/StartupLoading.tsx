import React from 'react';
import {ActivityIndicator,Pressable,Text,View} from 'react-native';
import {useLanguage} from '../i18n/LanguageProvider';
const text={
 en:['Loading your workspace…','Your connection is taking longer than expected. Your session is preserved.','Retry connection','Open sign in'],
 sw:['Inapakia sehemu yako ya kazi…','Muunganisho unachukua muda mrefu kuliko kawaida. Session yako imehifadhiwa.','Jaribu muunganisho tena','Fungua kuingia'],
 fr:['Chargement de votre espace…','La connexion prend plus de temps que prévu. Votre session est conservée.','Réessayer la connexion','Ouvrir la connexion'],
 pt:['A carregar o seu espaço…','A ligação está a demorar mais do que o esperado. A sua sessão foi preservada.','Tentar ligação novamente','Abrir início de sessão'],
 ar:['جارٍ تحميل مساحة العمل…','يستغرق الاتصال وقتًا أطول من المتوقع. تم الاحتفاظ بجلستك.','إعادة محاولة الاتصال','فتح تسجيل الدخول'],
 es:['Cargando tu espacio…','La conexión tarda más de lo esperado. Tu sesión se conserva.','Reintentar conexión','Abrir inicio de sesión'],
 zh:['正在加载工作空间…','连接耗时超出预期。您的会话已保留。','重试连接','打开登录'],
} as const;
export function StartupLoading({delayed,onRetry,onLogin}:{delayed:boolean;onRetry:()=>void;onLogin:()=>void}){
 const {language}=useLanguage(),t=text[language];return <View style={{flex:1,backgroundColor:'#071523',padding:28,justifyContent:'center',alignItems:'center',gap:20}}>
 {!delayed&&<ActivityIndicator color="#32D5A1"/>}<Text accessibilityRole="alert" style={{color:'#E5F1FC',textAlign:'center',maxWidth:420,fontSize:16,lineHeight:26}}>{t[delayed?1:0]}</Text>
 {delayed&&<><Pressable accessibilityRole="button" onPress={onRetry} style={{minHeight:48,padding:14,borderRadius:12,backgroundColor:'#20D39B'}}><Text style={{color:'#04251C',fontWeight:'700'}}>{t[2]}</Text></Pressable><Pressable accessibilityRole="button" onPress={onLogin} style={{minHeight:44,padding:12}}><Text style={{color:'#9DDCFF'}}>{t[3]}</Text></Pressable></>}
 </View>;
}
