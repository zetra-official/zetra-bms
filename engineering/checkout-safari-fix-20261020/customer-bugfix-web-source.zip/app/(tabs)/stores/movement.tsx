import {useDocumentText} from "@/src/i18n/useDocumentText";
import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
﻿import {useCommonText} from "@/src/i18n/useCommonText";
// app/(tabs)/stores/movement.tsx
import { useNetInfo } from "@react-native-community/netinfo";
import { useLocalSearchParams,
  useRouter } from "expo-router";
import React,
  { useCallback,
  useEffect,
  useMemo,
  useRef,
  useState } from "react";
import {
  Alert,
  Keyboard,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  Text,
  TextInput,
  View
} from "react-native";
import * as Clipboard from "expo-clipboard";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useOrg } from "../../../src/context/OrgContext";
import { supabase } from "../../../src/supabase/supabaseClient";
import { Button } from "../../../src/ui/Button";
import { Card } from "../../../src/ui/Card";
import { Screen } from "../../../src/ui/Screen";
import { theme } from "../../../src/ui/theme";

type InventoryRow = {
  product_id: string;
  product_name: string;
  sku: string | null;
  unit: string | null;
  category: string | null;
  qty: number;
};

type SelectedItem = {
  product_id: string;
  qty: string; // typed by user
};

type ReceiptItem = {
  product_id: string;
  product_name: string;
  sku: string | null;
  qty: number;
};

type Receipt = {
  createdAt: string; // ISO
  organizationName: string;
  fromStoreName: string;
  toStoreName: string;

  actorEmail: string | null; // prefer showing this
  actorName: string; // display name / fallback
  actorRole: string;

  items: ReceiptItem[];
  totalItems: number;
  totalQty: number;
  movementIds: string[];
  reportReceiptId?: string | null;
};

function norm(s: any) {
  return String(s ?? "").trim();
}

function cleanQtyText(raw: string) {
  return String(raw ?? "")
    .trim()
    .replace(",", ".")
    .replace(/[^0-9.]/g, "")
    .replace(/(\..*)\./g, "$1");
}

function parsePositiveQty(s: string) {
  const cleaned = cleanQtyText(s);
  const n = Number(cleaned);
  if (!Number.isFinite(n)) return 0;
  return n > 0 ? Number(n.toFixed(3)) : 0;
}

function fmtEAT(iso: string) {
  try {
    return new Date(iso).toLocaleString("en-GB", {
      timeZone: "Africa/Nairobi",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
function escHtml(v: any) {
  return String(v ?? "—")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
export default function StoreMovementScreen() {
 const {documentText, documentLocale} = useDocumentText();
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const params = useLocalSearchParams<{
    fromStoreId?: string;
    fromStoreName?: string;
  }>();

  const netInfo = useNetInfo();

  const {
    activeOrgId,
    activeOrgName,
    activeRole,
    activeStoreId,
    activeStoreName,
    activeStoreType,
    stores,
  } = useOrg();

  // Stable online/offline
  const rawIsOnline =
    Platform.OS === "web"
      ? typeof navigator !== "undefined"
        ? navigator.onLine !== false
        : true
      : !!(netInfo.isConnected && netInfo.isInternetReachable !== false);
  const [stableIsOnline, setStableIsOnline] = useState<boolean>(rawIsOnline);
  const netDebounceRef = useRef<any>(null);

  useEffect(() => {
    if (netDebounceRef.current) clearTimeout(netDebounceRef.current);
    netDebounceRef.current = setTimeout(() => {
      setStableIsOnline(rawIsOnline);
    }, 700);
    return () => {
      if (netDebounceRef.current) clearTimeout(netDebounceRef.current);
    };
  }, [rawIsOnline]);

  const isOffline = !stableIsOnline;

  const isDesktopWeb =
    Platform.OS === "web" &&
    typeof window !== "undefined" &&
    window.innerWidth >= 900;

  const fromStoreId = useMemo(() => {
    return norm(params.fromStoreId) || norm(activeStoreId) || "";
  }, [params.fromStoreId, activeStoreId]);

  const fromStoreName = useMemo(() => {
    return norm(params.fromStoreName) || norm(activeStoreName) || "—";
  }, [params.fromStoreName, activeStoreName]);

  const withinOrgStores = useMemo(() => {
    const all = (stores ?? []) as any[];
    if (!activeOrgId) return all;
    return all.filter((s) => String(s.organization_id) === String(activeOrgId));
  }, [stores, activeOrgId]);

  const storeOrgMismatch = useMemo(() => {
    if (!fromStoreId || !activeOrgId) return false;
    const s = withinOrgStores.find((x: any) => String(x.store_id) === String(fromStoreId));
    if (!s) return false;
    return String(s.organization_id) !== String(activeOrgId);
  }, [fromStoreId, activeOrgId, withinOrgStores]);

 const isCapitalRecoveryStore = activeStoreType === "CAPITAL_RECOVERY";

  const isOwnerAdmin = useMemo(
    () => (["owner", "admin"] as const).includes((activeRole ?? "staff") as any),
    [activeRole]
  );

  // Staff movement flag
  const [staffMovementAllowed, setStaffMovementAllowed] = useState<boolean>(false);
  const [flagLoading, setFlagLoading] = useState(false);

  const loadMovementFlagForFromStore = useCallback(async () => {
    if (!fromStoreId || isCapitalRecoveryStore) {
      setStaffMovementAllowed(false);
      return;
    }

    setFlagLoading(true);
    try {
      const { data, error: e } = await supabase
        .from("stores")
        .select("id, staff_can_manage_movement")
        .eq("id", fromStoreId)
        .maybeSingle();

      if (e) throw e;

      const allowed = !!(data as any)?.staff_can_manage_movement;
      setStaffMovementAllowed(allowed);
    } catch {
      try {
        const { data: d2, error: e2 } = await supabase
          .from("stores")
          .select("id, allow_staff_movement")
          .eq("id", fromStoreId)
          .maybeSingle();

        if (e2) throw e2;

        const allowed2 = !!(d2 as any)?.allow_staff_movement;
        setStaffMovementAllowed(allowed2);
      } catch {
        setStaffMovementAllowed(false);
      }
    } finally {
      setFlagLoading(false);
    }
  }, [fromStoreId, isCapitalRecoveryStore]);

  useEffect(() => {
    void loadMovementFlagForFromStore();
  }, [loadMovementFlagForFromStore]);

const canMove = useMemo(() => {
    if (isCapitalRecoveryStore) return false;
    if (isOwnerAdmin) return true;
    return !!staffMovementAllowed;
  }, [isCapitalRecoveryStore, isOwnerAdmin, staffMovementAllowed]);

  // TO store selection
  const [toStoreId, setToStoreId] = useState<string>("");
  const [transferStores, setTransferStores] = useState<any[]>([]);

const loadTransferStores = useCallback(async () => {
  if (!fromStoreId || isCapitalRecoveryStore) {
    setTransferStores([]);
    return;
  }

  try {
    const { data, error: e } = await supabase.rpc(
      "get_stock_transfer_destinations_v1",
      {
        p_from_store_id: fromStoreId,
      }
    );

    if (e) throw e;

    const next = ((data ?? []) as any[]).map((s) => ({
      ...s,
      store_id: String(s.store_id ?? ""),
      store_name: String(s.store_name ?? "Store"),
    }));

    setTransferStores(next);
  } catch (err: any) {
    setTransferStores([]);

    Alert.alert(
      uiText("Failed to load stores"),
      err?.message ?? uiText("Imeshindikana kupata destination stores.")
    );
  }
}, [fromStoreId, isCapitalRecoveryStore]);

  useEffect(() => {
    void loadTransferStores();
  }, [loadTransferStores]);

const toStoreName = useMemo(() => {
  if (!toStoreId) return "—";

  const s = transferStores.find(
    (x: any) => String(x.store_id) === String(toStoreId)
  );

  return s?.store_name ?? "—";
}, [toStoreId, transferStores]);

  // Inventory
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<InventoryRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [q, setQ] = useState("");

  // Inline qty selection map
  const [selectedMap, setSelectedMap] = useState<Record<string, SelectedItem>>({});

  const selectedList = useMemo(() => {
    const items = Object.values(selectedMap)
      .map((it) => {
        const r = rows.find((x) => String(x.product_id) === String(it.product_id));
        return {
          product_id: String(it.product_id),
          qty: String(it.qty ?? ""),
          product_name: r?.product_name ?? "Product",
          sku: r?.sku ?? null,
          available: Number(r?.qty ?? 0),
        };
      })
      .filter((x) => parsePositiveQty(x.qty) > 0)
      .sort((a, b) => String(a.product_name).localeCompare(String(b.product_name)));
    return items;
  }, [selectedMap, rows]);

  const selectedCount = selectedList.length;

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return rows;

    return rows.filter((r) => {
      const hay = `${r.product_name ?? ""} ${r.sku ?? ""} ${r.unit ?? ""} ${r.category ?? ""}`.toLowerCase();
      return hay.includes(needle);
    });
  }, [rows, q]);

  const loadInventory = useCallback(async () => {
    setError(null);

   if (!fromStoreId) {
  setError("No FROM store selected (Active Store).");
  return;
}

if (isCapitalRecoveryStore) {
  setRows([]);
  setSelectedMap({});
  setError("Stock Movement haitumiki kwa Capital Recovery store.");
  return;
}

if (storeOrgMismatch) {
  setError("FROM store haifanani na Organization. Tafadhali chagua store tena.");
  return;
}

if (isOffline) {
  setError("Offline: huwezi kufetch inventory. Washa mtandao kisha jaribu tena.");
  return;
} 
    setLoading(true);
    try {
      const { data, error: e } = await supabase.rpc("get_store_inventory_v2", {
        p_store_id: fromStoreId,
      });
      if (e) throw e;

      const next = (data ?? []) as InventoryRow[];
      setRows(next);

      // keep qtys only for existing products
      setSelectedMap((prev) => {
        const keep: Record<string, SelectedItem> = {};
        for (const [pid, it] of Object.entries(prev)) {
          const ok = next.some((x) => String(x.product_id) === String(pid));
          if (ok) keep[pid] = it;
        }
        return keep;
      });
    } catch (err: any) {
      setError(err?.message ?? "Failed to load inventory");
    } finally {
      setLoading(false);
    }
  }, [fromStoreId, isCapitalRecoveryStore, storeOrgMismatch, isOffline]);

  useEffect(() => {
   if (!fromStoreId) return;
if (isCapitalRecoveryStore) return;
if (isOffline) return;
void loadInventory();
  }, [fromStoreId, isCapitalRecoveryStore, isOffline, loadInventory]);

  const pickToStore = useCallback(
    (id: string) => {
      if (!id) return;
      if (String(id) === String(fromStoreId)) {
        Alert.alert(uiText("Not allowed"), uiText("TO store haiwezi kuwa sawa na FROM store."));
        return;
      }
      setToStoreId(id);
    },
    [fromStoreId]
  );

  const clearAllSelected = useCallback(() => {
    setSelectedMap({});
  }, []);

  // Inline qty handler
  const setInlineQty = useCallback((productId: string, qty: string) => {
  const pid = String(productId);
  const raw = cleanQtyText(qty);

  setSelectedMap((prev) => {
    const next = { ...prev };

    if (!raw.trim()) {
      delete next[pid];
      return next;
    }

    next[pid] = { product_id: pid, qty: raw };
    return next;
  });
}, []);

  // Actor display + email
  const [actorName, setActorName] = useState<string>("—");
  const [actorEmail, setActorEmail] = useState<string | null>(null);

  const loadActorIdentity = useCallback(async () => {
    try {
      const { data: userRes, error: ue } = await supabase.auth.getUser();
      if (ue) throw ue;

      const user = userRes?.user;
      const uid = user?.id;

      const email = norm(user?.email);
      setActorEmail(email || null);

      if (!uid) {
        setActorName("—");
        return;
      }

      // 1) profiles.display_name
      try {
        const { data, error: e } = await supabase
          .from("profiles")
          .select("display_name")
          .eq("id", uid)
          .maybeSingle();

        if (!e) {
          const dn = norm((data as any)?.display_name);
          if (dn) {
            setActorName(dn);
            return;
          }
        }
      } catch {
        // ignore
      }

      // 2) user_metadata full_name
      const metaName = norm((user as any)?.user_metadata?.full_name);
      if (metaName) {
        setActorName(metaName);
        return;
      }

      // 3) fallback to email prefix
      if (email && email.includes("@")) {
        setActorName(email.split("@")[0]);
        return;
      }

      setActorName("—");
    } catch {
      setActorName("—");
      setActorEmail(null);
    }
  }, []);

  useEffect(() => {
    void loadActorIdentity();
  }, [loadActorIdentity]);

  // Receipt modal state
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<Receipt | null>(null);
  const [showAllMovementIds, setShowAllMovementIds] = useState(false);

  const buildReceiptText = useCallback((r: Receipt) => {
    const lines: string[] = [];

    lines.push(uiText("ZETRA BMS • Stock Transfer Receipt"));
    lines.push("----------------------------------");
    lines.push(uiText("Date/Time (EAT): {p0}", {p0: (fmtEAT(r.createdAt))}));
    lines.push(uiText("Organization: {p0}", {p0: (r.organizationName)}));
    lines.push(uiText("From: {p0}", {p0: (r.fromStoreName)}));
    lines.push(uiText("To: {p0}", {p0: (r.toStoreName)}));

    const processedBy = r.actorEmail ? r.actorEmail : r.actorName;
    lines.push(uiText("Processed by: {p0} ({p1})", {p0: (processedBy), p1: (r.actorRole)}));
    lines.push("");

    if (r.reportReceiptId) {
      lines.push(uiText("Receipt ID: {p0}", {p0: (r.reportReceiptId)}));
      lines.push("");
    }

    lines.push(uiText("Items: {p0} | Total Qty: {p1}", {p0: (r.totalItems), p1: (r.totalQty)}));
    lines.push("");
    lines.push("Items:");
    for (const it of r.items) {
      const sku = it.sku ? ` • SKU ${it.sku}` : "";
      lines.push(uiText("- {p0}{p1} • Qty {p2}", {p0: (it.product_name), p1: (sku), p2: (it.qty)}));
    }

    lines.push("");
    lines.push(uiText("Movement IDs:"));
    for (const id of r.movementIds) {
      lines.push(id);
    }

    return lines.join("\n");
  }, []);

  const onShareReceipt = useCallback(async () => {
    if (!lastReceipt) return;
    const text = buildReceiptText(lastReceipt);
    try {
      await Share.share({ message: text });
    } catch {
      // ignore
    }
  }, [lastReceipt, buildReceiptText]);

  const onCopyReceipt = useCallback(async () => {
    if (!lastReceipt) return;
    const text = buildReceiptText(lastReceipt);
    try {
      await Clipboard.setStringAsync(text);
      Alert.alert(uiText("Copied ✅"), uiText("Receipt ime-copy (unaweza ku-paste WhatsApp/Email)."));
    } catch {
      Alert.alert(uiText("Failed"), uiText("Imeshindikana ku-copy receipt."));
    }
  }, [lastReceipt, buildReceiptText]);
const onShareReceiptPdf = useCallback(async () => {
  if (!lastReceipt) return;

  const itemsHtml = lastReceipt.items
    .map(
      (it) => `
        <tr>
          <td>
            <strong>${escHtml(it.product_name)}</strong>
            ${it.sku ? `<br/><span>SKU: ${escHtml(it.sku)}</span>` : ""}
          </td>
          <td><strong>${escHtml(it.qty)}</strong></td>
        </tr>
      `
    )
    .join("");

  const movementHtml = lastReceipt.movementIds
    .map((id) => `<div class="id">${escHtml(id)}</div>`)
    .join("");

  const html = `
    <html lang="${documentLocale().language}" dir="${documentLocale().direction}">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
          @page { size: A4; margin: 14mm; }

          html, body {
            margin: 0;
            padding: 0;
            background: #ffffff;
            color: #0F172A;
            font-family: Arial, sans-serif;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }

          .page {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
          }

          .top {
            border-bottom: 2px solid #16A34A;
            padding-bottom: 14px;
            margin-bottom: 18px;
          }

          h1 {
            color: #16A34A;
            margin: 0;
            font-size: 28px;
          }

          .subtitle {
            margin-top: 8px;
            color: #475569;
            font-weight: 800;
          }

          .line {
            margin-top: 10px;
            font-weight: 800;
            color: #475569;
            line-height: 1.45;
          }

          .value {
            color: #2563EB;
            font-weight: 900;
          }

          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 18px;
            table-layout: fixed;
          }

          th {
            background: #F1F5F9;
            text-align: left;
            padding: 10px;
            color: #0F172A;
            font-size: 12px;
          }

          td {
            border-bottom: 1px solid #E5E7EB;
            padding: 10px;
            vertical-align: top;
            font-weight: 800;
            color: #0F172A;
            word-break: break-word;
          }

          td:nth-child(2), th:nth-child(2) {
            width: 90px;
            text-align: center;
          }

          span {
            color: #64748B;
            font-size: 12px;
          }

          .box {
            margin-top: 18px;
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            padding: 12px;
            background: #F8FAFC;
          }

          .box-title {
            color: #0F172A;
            font-weight: 900;
            margin-bottom: 8px;
          }

          .id {
            color: #2563EB;
            font-weight: 900;
            margin-top: 6px;
            word-break: break-word;
          }

          .footer {
            margin-top: 24px;
            color: #64748B;
            font-size: 12px;
            border-top: 1px solid #E5E7EB;
            padding-top: 12px;
          }
        </style>
      </head>

      <body>
        <div class="page">
          <div class="top">
            <h1>${documentText("Movement Success ✅")}</h1>
            <div class="subtitle">${documentText("ZETRA BMS • Stock Transfer Receipt")}</div>
          </div>

          <div class="line">${documentText("Date/Time (EAT):")} <span class="value">${escHtml(fmtEAT(lastReceipt.createdAt))}</span></div>
          <div class="line">${documentText("Organization:")} <span class="value">${escHtml(lastReceipt.organizationName)}</span></div>
          <div class="line">${documentText("FROM:")} <span class="value">${escHtml(lastReceipt.fromStoreName)}</span> ${documentText("→ TO:")} <span class="value">${escHtml(lastReceipt.toStoreName)}</span></div>
          <div class="line">${documentText("Processed by:")} <span class="value">${escHtml(lastReceipt.actorEmail || lastReceipt.actorName)}</span> (${escHtml(lastReceipt.actorRole)})</div>
          <div class="line">${documentText("Receipt ID:")} <span class="value">${escHtml(lastReceipt.reportReceiptId || "—")}</span></div>

          <table>
            <thead>
              <tr>
                <th>${documentText("Item")}</th>
                <th>${documentText("Qty")}</th>
              </tr>
            </thead>
            <tbody>${itemsHtml}</tbody>
          </table>

          <div class="box">
            <div class="box-title">${documentText("Items (")}${escHtml(lastReceipt.totalItems)}${documentText(") • Total Qty")} ${escHtml(lastReceipt.totalQty)}</div>
          </div>

          <div class="box">
            <div class="box-title">${documentText("Movement IDs")}</div>
            ${movementHtml || `<div class="id">—</div>`}
          </div>

          <div class="footer">${documentText("Generated by ZETRA BMS.")}</div>
        </div>
      </body>
    </html>
  `;

  try {
    const file = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(file.uri, {
      mimeType: "application/pdf",
      dialogTitle: "Share Stock Transfer Receipt PDF",
    });
  } catch (e: any) {
    Alert.alert(uiText("PDF failed"), e?.message ?? uiText("Failed to create PDF receipt."));
  }
}, [lastReceipt]);
  const submit = useCallback(async () => {
    Keyboard.dismiss();

    if (isOffline) {
      Alert.alert(uiText("Offline"), uiText("Huwezi kufanya movement bila mtandao."));
      return;
    }

   if (!activeOrgId) {
  Alert.alert(uiText("Missing"), uiText("No active Organization."));
  return;
}

if (isCapitalRecoveryStore) {
  Alert.alert(uiText("Not Available"), uiText("Stock Movement haitumiki kwa Capital Recovery store."));
  return;
}

    if (!fromStoreId) {
      Alert.alert(uiText("Missing"), uiText("Chagua FROM store (Active Store) kwanza."));
      return;
    }

    if (storeOrgMismatch) {
      Alert.alert(uiText("Mismatch"), uiText("FROM store haifanani na Organization. Tafadhali chagua store tena."));
      return;
    }

    if (!toStoreId) {
      Alert.alert(uiText("Missing"), uiText("Chagua TO store."));
      return;
    }

    if (String(toStoreId) === String(fromStoreId)) {
      Alert.alert(uiText("Invalid"), uiText("TO store haiwezi kuwa sawa na FROM store."));
      return;
    }

    if (!canMove) {
      Alert.alert(
        uiText("No Access"),
        uiText("Huruhusiwi kufanya Stock Movement. Muombe Owner/Admin kuwasha ruhusa kwa store hii.")
      );
      return;
    }

    if (selectedCount === 0) {
      Alert.alert(uiText("Missing"), uiText("Weka qty angalau item 1 (kwenye list)."));
      return;
    }

    // Validate qty + availability
    const toMove: Array<{
      product_id: string;
      product_name: string;
      sku: string | null;
      qty: number;
      available: number;
    }> = [];

    for (const it of selectedList) {
      const qtyNum = parsePositiveQty(it.qty);
      const available = Number(it.available ?? 0);

      if (!qtyNum) {
        Alert.alert(uiText("Invalid qty"), uiText("Weka quantity sahihi kwa: {p0} (>= 1).", {p0: (it.product_name)}));
        return;
      }
      if (qtyNum > available) {
        Alert.alert(
          uiText("Not enough stock"),
          uiText("{p0}: Stock haitoshi. Available: {p1} | Unajaribu: {p2}", {p0: (it.product_name), p1: (available), p2: (qtyNum)})
        );
        return;
      }

      toMove.push({
        product_id: String(it.product_id),
        product_name: String(it.product_name),
        sku: it.sku ?? null,
        qty: qtyNum,
        available,
      });
    }

    setLoading(true);
    try {
      // ✅ SINGLE CALL (Batch)
      const payloadItems = toMove.map((x) => ({
        product_id: x.product_id,
        qty: x.qty,
        product_name: x.product_name,
        sku: x.sku,
      }));

      const { data: batchData, error: be } = await supabase.rpc("transfer_stock_batch_v1", {
        p_from_store_id: fromStoreId,
        p_to_store_id: toStoreId,
        p_items: payloadItems,
        p_note: null,
      });

      if (be) throw be;

      // Supabase may return array with one row
      const row = Array.isArray(batchData) ? (batchData[0] ?? null) : batchData;

      const movementIds: string[] = Array.isArray(row?.movement_ids)
        ? (row.movement_ids as any[]).map((x) => norm(x)).filter(Boolean)
        : [];

      if (movementIds.length === 0) {
        // still allow receipt from local items, but show warning
        // (should not happen if DB ok)
      }

      // Build receipt model (client)
      const createdAt = new Date().toISOString();
      const actorRole = String(activeRole ?? "—");
      const orgName = String(activeOrgName ?? "—");

      const totalQty = toMove.reduce((sum, x) => sum + (Number(x.qty) || 0), 0);
      const items: ReceiptItem[] = toMove.map((x) => ({
        product_id: x.product_id,
        product_name: x.product_name,
        sku: x.sku ?? null,
        qty: x.qty,
      }));

      // Save report to DB (optional): create_transfer_receipt_v1
      let reportReceiptId: string | null = null;
      try {
        const { data: rid, error: re } = await supabase.rpc("create_transfer_receipt_v1", {
          p_org_id: activeOrgId,
          p_from_store_id: fromStoreId,
          p_to_store_id: toStoreId,
          p_items: items.map((x) => ({
            product_id: x.product_id,
            product_name: x.product_name,
            sku: x.sku,
            qty: x.qty,
          })),
          p_movement_ids: movementIds,
          p_note: null,
        });

        if (!re) {
          reportReceiptId = norm(rid) || null;
        }
      } catch {
        reportReceiptId = null;
      }

      const receipt: Receipt = {
        createdAt,
        organizationName: orgName,
        fromStoreName: fromStoreName || "—",
        toStoreName: toStoreName || "—",
        actorEmail: actorEmail || null,
        actorName: actorName || "—",
        actorRole,
        items,
        totalItems: items.length,
        totalQty,
        movementIds,
        reportReceiptId,
      };

      setLastReceipt(receipt);
      setShowAllMovementIds(false);
      setReceiptModalOpen(true);

      // refresh UI
      clearAllSelected();
      await loadInventory();
    } catch (err: any) {
      Alert.alert(uiText("Failed"), err?.message ?? uiText("Movement failed."));
    } finally {
      setLoading(false);
    }
  }, [
    isOffline,
    activeOrgId,
    activeOrgName,
    activeRole,
    isCapitalRecoveryStore,
    actorName,
    actorEmail,
    fromStoreId,
    fromStoreName,
    toStoreId,
    toStoreName,
    canMove,
    storeOrgMismatch,
    selectedCount,
    selectedList,
    clearAllSelected,
    loadInventory,
  ]);

const toStores = useMemo(() => {
  return transferStores.filter(
    (s: any) => String(s.store_id) !== String(fromStoreId)
  );
}, [transferStores, fromStoreId]);

  const processedByLabel = useMemo(() => {
    const em = norm(actorEmail);
    if (em) return em;
    const dn = norm(actorName);
    return dn || "—";
  }, [actorEmail, actorName]);

  return (
    <Screen scroll>
{/* Receipt Modal */}
<Modal
  visible={receiptModalOpen}
  transparent
  animationType="fade"
  statusBarTranslucent
  hardwareAccelerated
  onRequestClose={() => setReceiptModalOpen(false)}
>
  <Pressable
    onPress={() => setReceiptModalOpen(false)}
    style={{
      flex: 1,
      backgroundColor: "rgba(15,23,42,0.35)",
      padding: 18,
      justifyContent: "center",
      alignItems: "center",
    }}
  >
    <Pressable
      onPress={() => {}}
      onPressIn={() => {}}
      style={{
        width: "100%",
        maxWidth: 520,
        alignSelf: "stretch",
        borderRadius: 28,
        backgroundColor: "#FFFFFF",
        borderWidth: 1,
        borderColor: "rgba(15,23,42,0.10)",
        padding: 18,
        maxHeight: "85%",
        minHeight: 240,
        elevation: 30,
        zIndex: 999,
      }}
    >
      <ScrollView
        style={{ flexGrow: 0 }}
        contentContainerStyle={{ paddingBottom: 14 }}
        showsVerticalScrollIndicator
        keyboardShouldPersistTaps="handled"
      >
        <Text style={{ color: "#16A34A", fontWeight: "900", fontSize: 22 }}>
          {uiText("Movement Success ✅")}</Text>

        {lastReceipt ? (
          <>
            <Text style={{ color: "#475569", fontWeight: "800", marginTop: 14 }}>
              {uiText("Date/Time (EAT):")}{" "}
              <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                {fmtEAT(lastReceipt.createdAt)}
              </Text>
            </Text>

            <Text style={{ color: "#475569", fontWeight: "800", marginTop: 8 }}>
              {uiText("FROM:")}{" "}
              <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                {lastReceipt.fromStoreName}
              </Text>
              {"  "}→{"  "}
              {uiText("TO:")}{" "}
              <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                {lastReceipt.toStoreName}
              </Text>
            </Text>

            <Text style={{ color: "#475569", fontWeight: "800", marginTop: 8 }}>
              {uiText("Processed by:")}{" "}
              <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                {lastReceipt.actorEmail ? lastReceipt.actorEmail : lastReceipt.actorName}
              </Text>{" "}
              <Text style={{ color: "#0F172A", fontWeight: "900" }}>
                ({lastReceipt.actorRole})
              </Text>
            </Text>

            {lastReceipt.reportReceiptId ? (
              <Text style={{ color: "#475569", fontWeight: "800", marginTop: 10 }}>
                {uiText("Receipt ID:")}{" "}
                <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                  {lastReceipt.reportReceiptId}
                </Text>
              </Text>
            ) : (
              <Text style={{ color: "#64748B", fontWeight: "800", marginTop: 10 }}>
                {uiText("(Report save haikupatikana — movement bado imefanikiwa)")}</Text>
            )}

            <View
              style={{
                marginTop: 14,
                gap: 8,
                borderWidth: 1,
                borderColor: "rgba(15,23,42,0.08)",
                backgroundColor: "#F8FAFC",
                borderRadius: 16,
                padding: 12,
              }}
            >
              <Text style={{ color: "#0F172A", fontWeight: "900", fontSize: 15 }}>
                {uiText("Items ({p0}) • Total Qty {p1}", {p0: lastReceipt.totalItems, p1: lastReceipt.totalQty})}
              </Text>

              {lastReceipt.items.map((it) => (
                <Text key={it.product_id} style={{ color: "#2563EB", fontWeight: "900" }}>
                  • {it.product_name} — {it.qty}
                </Text>
              ))}
            </View>

            <View
              style={{
                marginTop: 14,
                gap: 8,
                borderWidth: 1,
                borderColor: "rgba(15,23,42,0.08)",
                backgroundColor: "#F8FAFC",
                borderRadius: 16,
                padding: 12,
              }}
            >
              <Text style={{ color: "#0F172A", fontWeight: "900", fontSize: 15 }}>
                {uiText("Movement IDs")}</Text>

              {(showAllMovementIds
                ? lastReceipt.movementIds
                : lastReceipt.movementIds.slice(0, 3)
              ).map((id, idx) => (
                <Text key={`${id}-${idx}`} style={{ color: "#2563EB", fontWeight: "900" }}>
                  {id}
                </Text>
              ))}

              {lastReceipt.movementIds.length > 3 ? (
                <Pressable
                  onPress={() => setShowAllMovementIds((v) => !v)}
                  style={{
                    marginTop: 6,
                    alignSelf: "flex-start",
                    paddingHorizontal: 12,
                    paddingVertical: 9,
                    borderRadius: 14,
                    borderWidth: 1,
                    borderColor: "rgba(37,99,235,0.28)",
                    backgroundColor: "#EFF6FF",
                  }}
                >
                  <Text style={{ color: "#2563EB", fontWeight: "900" }}>
                    {showAllMovementIds ? uiText("Hide IDs") : uiText("Show all ({p0})", {p0: (lastReceipt.movementIds.length)})}
                  </Text>
                </Pressable>
              ) : null}
            </View>
<View style={{ flexDirection: "row", gap: 10, marginTop: 16 }}>
  <View style={{ flex: 1 }}>
    <Button
      title={uiText("Share Text")}
      onPress={onShareReceipt}
      disabled={loading}
      variant="secondary"
    />
  </View>

  <View style={{ flex: 1 }}>
    <Button
      title={uiText("Share PDF")}
      onPress={onShareReceiptPdf}
      disabled={loading}
      variant="primary"
    />
  </View>
</View>

<View style={{ marginTop: 10 }}>
  <Button
    title={uiText("Copy Text")}
    onPress={onCopyReceipt}
    disabled={loading}
    variant="secondary"
  />
</View>

<View style={{ marginTop: 10 }}>
  <Button
    title={uiText("Close")}
    onPress={() => setReceiptModalOpen(false)}
    disabled={loading}
    variant="secondary"
  />
</View>
          </>
        ) : (
          <Text style={{ color: "#475569", fontWeight: "800", marginTop: 8 }}>
            {uiText("No receipt loaded.")}</Text>
        )}
      </ScrollView>
    </Pressable>
  </Pressable>
</Modal>

      {isOffline ? (
        <View
          style={{
            borderWidth: 1,
            borderColor: "rgba(245,158,11,0.45)",
            backgroundColor: "rgba(245,158,11,0.10)",
            paddingVertical: 10,
            paddingHorizontal: 12,
            borderRadius: theme.radius.lg,
            marginBottom: 8,
          }}
        >
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
            {uiText("OFFLINE • Movement imezimwa (washa data/Wi-Fi)")}</Text>
        </View>
      ) : null}

      <Text style={{ fontSize: isDesktopWeb ? 20 : 26, fontWeight: "900", color: theme.colors.text }}>
  {isCapitalRecoveryStore ? uiText("Movement Disabled") : uiText("Stock Movement")}
</Text>

      {/* Last Receipt Summary Card */}
      {lastReceipt ? (
        <Card
          style={{
            borderColor: "rgba(52,211,153,0.45)",
            backgroundColor: "rgba(52,211,153,0.08)",
            gap: 8,
          }}
        >
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Last Receipt")}</Text>

          <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
            {fmtEAT(lastReceipt.createdAt)} •{" "}
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
              {lastReceipt.actorEmail ? lastReceipt.actorEmail : lastReceipt.actorName}
            </Text>{" "}
            <Text style={{ color: theme.colors.faint, fontWeight: "900" }}>
              ({lastReceipt.actorRole})
            </Text>
          </Text>

          <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
            {uiText("FROM:")}<Text style={{ color: theme.colors.text }}>{lastReceipt.fromStoreName}</Text>
            {"   "}→{"   "}
            {uiText("TO:")}<Text style={{ color: theme.colors.text }}>{lastReceipt.toStoreName}</Text>
          </Text>

          {lastReceipt.reportReceiptId ? (
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {uiText("Receipt ID:")}{" "}
              <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
                {lastReceipt.reportReceiptId}
              </Text>
            </Text>
          ) : null}

          <Text style={{ color: theme.colors.muted, fontWeight: "900", marginTop: 4 }}>
            {uiText("Items ({p0}) • Total Qty {p1}", {p0: lastReceipt.totalItems, p1: lastReceipt.totalQty})}
          </Text>

          <View style={{ flexDirection: "row", gap: 10, marginTop: 10 }}>
            <View style={{ flex: 1 }}>
              <Button
  title={uiText("Open Receipt")}
  onPress={() => setReceiptModalOpen(true)}
  disabled={loading || !lastReceipt}
  variant="primary"
/>
            </View>
            <View style={{ flex: 1 }}>
              <Button
                title={uiText("Clear")}
                onPress={() => setLastReceipt(null)}
                disabled={loading}
                variant="secondary"
              />
            </View>
          </View>
        </Card>
      ) : null}

      {/* Receipt History = CARD ONLY */}
      <Card style={{ gap: isDesktopWeb ? 5 : 10, padding: isDesktopWeb ? 10 : undefined }}>
        <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: isDesktopWeb ? 14 : 16 }}>
          {uiText("Receipt History")}</Text>

        <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
          {uiText("Fungua history ya transfer receipts na utafute kwa tarehe (search by date).")}</Text>

        <View style={{ marginTop: 4 }}>
          <Button
            title={uiText("Open Receipt History")}
         onPress={() => {
  if (!activeOrgId) {
    Alert.alert(uiText("Missing"), uiText("No active Organization."));
    return;
  }
  if (isCapitalRecoveryStore) {
    Alert.alert(uiText("Not Available"), uiText("Receipt History ya stock movement haitumiki kwa Capital Recovery store."));
    return;
  }
  router.push({
    pathname: "/(tabs)/stores/receipt-history",
    params: {
      orgId: activeOrgId,
      orgName: activeOrgName ?? "",
      actorEmail: processedByLabel,
    },
  } as any);
}}
disabled={!activeOrgId || isCapitalRecoveryStore}
variant="primary"
/>
        </View>
      </Card>

      {/* Header card */}
      <Card style={{ gap: isDesktopWeb ? 5 : 10, padding: isDesktopWeb ? 10 : undefined }}>
        <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("Organization")}</Text>
        <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: isDesktopWeb ? 15 : 18 }}>
          {activeOrgName ?? "—"}
        </Text>

        <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 2 }}>{uiText("Role")}</Text>
        <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
          {activeRole ?? "—"}
        </Text>

      <Text style={{ color: theme.colors.muted, fontWeight: "900", marginTop: isDesktopWeb ? 1 : 2, fontSize: isDesktopWeb ? 11 : undefined, letterSpacing: isDesktopWeb ? 0.7 : undefined }}>{uiText("FROM")}</Text>
<Text style={{ color: theme.colors.text, fontWeight: "900" }}>
  {fromStoreName || "—"}
</Text>

<Text style={{ color: theme.colors.muted, fontWeight: "900", marginTop: isDesktopWeb ? 1 : 2, fontSize: isDesktopWeb ? 11 : undefined, letterSpacing: isDesktopWeb ? 0.7 : undefined }}>{uiText("TO")}</Text>
<Text style={{ color: theme.colors.text, fontWeight: "900" }}>
  {toStoreName || "—"}
</Text>

{isCapitalRecoveryStore ? (
  <View
    style={{
      marginTop: 6,
      borderWidth: 1,
      borderColor: theme.colors.emeraldBorder,
      borderRadius: isDesktopWeb ? 12 : theme.radius.xl,
      backgroundColor: theme.colors.emeraldSoft,
      padding: isDesktopWeb ? 10 : 14,
    }}
  >
    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
      {uiText("Capital Recovery store haitumii Stock Movement.")}</Text>
    <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 8 }}>
      {uiText("Tumia Products + Capital Recovery Workspace. Movement ya stock imezimwa kabisa kwenye mode hii.")}</Text>
  </View>
) : null}

<View
  style={{
    marginTop: 6,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: isDesktopWeb ? 12 : theme.radius.xl,
    backgroundColor: theme.colors.card,
    padding: isDesktopWeb ? 10 : 14,
  }}
>
          <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Permission")}</Text>
          <Text style={{ color: theme.colors.text, fontWeight: "900", marginTop: 6 }}>
  {isCapitalRecoveryStore
    ? uiText("Disabled for Capital Recovery")
    : isOwnerAdmin
      ? uiText("Owner/Admin: allowed")
      : flagLoading
        ? uiText("Checking staff permission...")
        : staffMovementAllowed
          ? uiText("Staff: allowed (switch ON)")
          : uiText("Staff: NOT allowed (switch OFF)")}
</Text>

          {!isOwnerAdmin && !flagLoading && !staffMovementAllowed ? (
            <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 8 }}>
              {uiText("Muombe Owner/Admin aende Stores → store yako → awashe “Allow staff stock movement”.")}</Text>
          ) : null}
        </View>

        <View style={{ flexDirection: "row", gap: isDesktopWeb ? 8 : 10, marginTop: isDesktopWeb ? 3 : 6 }}>
          <View style={{ flex: 1 }}>
          <Button
  title={loading ? uiText("Loading...") : uiText("Refresh Inventory")}
  onPress={loadInventory}
  disabled={loading || isOffline || !fromStoreId || isCapitalRecoveryStore}
  variant="primary"
/>
          </View>
          <View style={{ flex: 1 }}>
            <Button title={uiText("Back")} onPress={() => router.back()} disabled={loading} variant="secondary" />
          </View>
        </View>
      </Card>

      {!!error && (
        <Card
          style={{
            borderColor: theme.colors.dangerBorder,
            backgroundColor: theme.colors.dangerSoft,
          }}
        >
          <Text style={{ color: theme.colors.danger, fontWeight: "900" }}>{systemText(error)}</Text>
        </Card>
      )}

     {/* TO Store picker */}
<Card style={{ gap: isDesktopWeb ? 7 : 10, padding: isDesktopWeb ? 12 : undefined }}>
  <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: isDesktopWeb ? 14 : 16 }}>
    {isCapitalRecoveryStore ? uiText("TO Store Disabled") : uiText("Choose TO store")}
  </Text>

  {isCapitalRecoveryStore ? (
    <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
      {uiText("Capital Recovery store haitumii stock transfer, hivyo TO store selection imezimwa.")}</Text>
  ) : toStores.length === 0 ? (
    <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
      {uiText("Hakuna store nyingine ndani ya org hii.")}</Text>
  ) : (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
      {toStores.map((s: any) => {
        const id = String(s.store_id);
        const active = String(toStoreId) === id;
        return (
          <Pressable
            key={id}
            onPress={() => pickToStore(id)}
            style={{
              borderWidth: 1,
              borderColor: active ? theme.colors.emerald : theme.colors.border,
              backgroundColor: active ? theme.colors.emeraldSoft : theme.colors.surface2,
              borderRadius: isDesktopWeb ? 12 : theme.radius.xl,
              paddingVertical: isDesktopWeb ? 8 : 10,
              paddingHorizontal: isDesktopWeb ? 10 : 12,
              minWidth: isDesktopWeb ? 190 : 180,
            }}
          >
            <Text style={{ color: isDesktopWeb && active ? theme.colors.emerald : theme.colors.text, fontWeight: "900" }}>{s.store_name}</Text>
            <Text style={{ color: active ? theme.colors.emerald : theme.colors.muted, fontWeight: "900", marginTop: isDesktopWeb ? 3 : 6 }}>
              {active ? uiText("Selected ✓") : uiText("Tap to select")}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  )}
</Card>

      {/* Move summary + button */}
      <Card style={{ gap: isDesktopWeb ? 6 : 10, padding: isDesktopWeb ? 10 : undefined }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: isDesktopWeb ? 14 : 16 }}>
            {uiText("Ready to Move")}</Text>

          <Pressable
            onPress={clearAllSelected}
            disabled={loading || selectedCount === 0}
            style={{
              opacity: loading || selectedCount === 0 ? 0.5 : 1,
              paddingHorizontal: isDesktopWeb ? 9 : 10,
              paddingVertical: isDesktopWeb ? 6 : 8,
              borderRadius: theme.radius.lg,
              borderWidth: 1,
              borderColor: theme.colors.border,
              backgroundColor: theme.colors.surface2,
            }}
          >
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Clear")}</Text>
          </Pressable>
        </View>

        <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
  {uiText("Selected items:")}{" "}
  <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{selectedCount}</Text>
</Text>

<Button
  title={
    isCapitalRecoveryStore
      ? uiText("Movement Disabled")
      : loading
        ? uiText("Processing...")
        : uiText("Move Stock ({p0})", {p0: (selectedCount)})
  }
  onPress={submit}
  disabled={loading || isOffline || !canMove || selectedCount === 0 || isCapitalRecoveryStore}
  variant="primary"
/>

        {!isOwnerAdmin && !flagLoading && !staffMovementAllowed ? (
          <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
            {uiText("Staff: Movement imezimwa kwa store hii. Owner/Admin anaweza kuwasha.")}</Text>
        ) : null}
      </Card>

      {/* Product picker */}
      <Card style={{ gap: isDesktopWeb ? 6 : 10, padding: isDesktopWeb ? 10 : undefined }}>
        <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: isDesktopWeb ? 14 : 16 }}>
          {isCapitalRecoveryStore ? uiText("Inventory Picker Disabled") : uiText("Choose products (FROM inventory)")}
        </Text>

        {isCapitalRecoveryStore ? (
          <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
            {uiText("Capital Recovery store haitumii inventory picker. Tumia Products + Capital Recovery Workspace.")}</Text>
        ) : (
          <>
            <TextInput
              value={q}
              onChangeText={setQ}
              placeholder={uiText("Tafuta product / SKU / category...")}
              placeholderTextColor="rgba(255,255,255,0.35)"
              returnKeyType="search"
              onSubmitEditing={Keyboard.dismiss}
              style={{
                borderWidth: 1,
                borderColor: theme.colors.border,
                borderRadius: theme.radius.lg,
                backgroundColor: "rgba(255,255,255,0.05)",
                paddingHorizontal: 14,
                paddingVertical: isDesktopWeb ? 8 : 12,
                color: theme.colors.text,
                fontWeight: "800",
              }}
            />

            {filtered.length === 0 ? (
              <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                {uiText("Hakuna items. Bonyeza “Refresh Inventory”.")}</Text>
            ) : isDesktopWeb ? (
              <View
                style={{
                  borderWidth: 1,
                  borderColor: theme.colors.border,
                  borderRadius: 10,
                  overflow: "hidden",
                  backgroundColor: theme.colors.card,
                }}
              >
                {/* DESKTOP TABLE HEADER */}
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    minHeight: 38,
                    paddingHorizontal: 12,
                    backgroundColor: theme.colors.surface2,
                    borderBottomWidth: 1,
                    borderBottomColor: theme.colors.border,


                  }}
                >
                  <Text
                    style={{
                      width: 44,
                      color: theme.colors.muted,
                      fontWeight: "900",
                      fontSize: 11,
                    }}
                  >
                    #
                  </Text>

                  <Text
                    style={{
                      flex: 1,
                      color: "#10B981",
                      fontWeight: "900",
                      fontSize: 11,
                      letterSpacing: 0.3,
                    }}
                  >
                    {uiText("PRODUCT")}</Text>

                  <Text
                    style={{
                      width: 180,
                      color: "#8B5CF6",
                      fontWeight: "900",
                      fontSize: 11,
                      letterSpacing: 0.3,
                    }}
                  >
                    {uiText("CATEGORY")}</Text>

                  <Text
                    style={{
                      width: 170,
                      color: "#0EA5E9",
                      fontWeight: "900",
                      fontSize: 11,
                      letterSpacing: 0.3,
                    }}
                  >
                    SKU
                  </Text>

                  <Text
                    style={{
                      width: 110,
                      color: "#F59E0B",
                      fontWeight: "900",
                      fontSize: 11,
                      letterSpacing: 0.3,
                      textAlign: "center",
                    }}
                  >
                    {uiText("IN STOCK")}</Text>

                  <Text
                    style={{
                      width: 150,
                      color: "#2563EB",
                      fontWeight: "900",
                      fontSize: 11,
                      letterSpacing: 0.3,
                      textAlign: "center",
                    }}
                  >
                    {uiText("QTY TO MOVE")}</Text>
                </View>

                {/* DESKTOP TABLE ROWS */}
                {/* DESKTOP SCROLLABLE PRODUCT ROWS */}
                <ScrollView
                  nestedScrollEnabled
                  showsVerticalScrollIndicator
                  keyboardShouldPersistTaps="always"
                  style={{
                    maxHeight: 520,
                    minHeight: 0,
                  }}
                  contentContainerStyle={{
                    flexGrow: 0,
                  }}
                >                {filtered.map((r, index) => {
                  const pid = String(r.product_id);
                  const currentQty = selectedMap[pid]?.qty ?? "";
                  const isSelected = parsePositiveQty(currentQty) > 0;

                  return (
                    <View
                      key={pid}
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        minHeight: 54,
                        paddingHorizontal: 12,
                        borderBottomWidth:
                          index < filtered.length - 1 ? 1 : 0,
                        borderBottomColor: theme.colors.border,
                        backgroundColor: isSelected
                          ? "rgba(52,211,153,0.08)"
                          : theme.colors.card,
                      }}
                    >
                      {/* ROW NUMBER */}
                      <Text
                        style={{
                          width: 44,
                          color: theme.colors.faint,
                          fontWeight: "800",
                          fontSize: 12,
                        }}
                      >
                        {String(index + 1).padStart(2, "0")}
                      </Text>

                      {/* PRODUCT */}
                      <View
                        style={{
                          flex: 1,
                          paddingRight: 18,
                          minWidth: 0,
                        }}
                      >
                        <Text
                          numberOfLines={1}
                          style={{
                            color: theme.colors.text,
                            fontWeight: "900",
                            fontSize: 13,
                          }}
                        >
                          {r.product_name}
                        </Text>

                        {isSelected ? (
                          <Text
                            style={{
                              color: theme.colors.emerald,
                              fontWeight: "900",
                              fontSize: 10,
                              marginTop: 3,
                            }}
                          >
                            {uiText("✓ Selected")}</Text>
                        ) : null}
                      </View>

                      {/* CATEGORY */}
                      <Text
                        numberOfLines={1}
                        style={{
                          width: 180,
                          paddingRight: 14,
                          color: "#7C3AED",
                          fontWeight: "800",
                          fontSize: 12,
                        }}
                      >
                        {r.category ?? "—"}
                      </Text>

                      {/* SKU */}
                      <Text
                        numberOfLines={1}
                        style={{
                          width: 170,
                          paddingRight: 14,
                          color: "#0284C7",
                          fontWeight: "800",
                          fontSize: 12,
                        }}
                      >
                        {r.sku ?? "—"}
                      </Text>

                      {/* STOCK */}
                      <View
                        style={{
                          width: 110,
                          alignItems: "center",
                        }}
                      >
                        <Text
                          style={{
                            color: "#D97706",
                            fontWeight: "900",
                            fontSize: 13,
                          }}
                        >
                          {r.qty}
                        </Text>
                      </View>

                      {/* QTY TO MOVE */}
                      <View
                        style={{
                          width: 150,
                          flexDirection: "row",
                          alignItems: "center",
                          justifyContent: "flex-end",
                          gap: 6,
                        }}
                      >
                        <TextInput
                          value={currentQty}
                          onChangeText={(t) => setInlineQty(pid, t)}
                          keyboardType="decimal-pad"
                          placeholder="0"
                          placeholderTextColor="rgba(255,255,255,0.35)"
                          style={{
                            width: isSelected ? 92 : 120,
                            height: 34,
                            borderWidth: 1,
                            borderColor: isSelected
                              ? "rgba(52,211,153,0.55)"
                              : theme.colors.border,
                            borderRadius: 8,
                            backgroundColor: "rgba(255,255,255,0.05)",
                            paddingHorizontal: 10,
                            paddingVertical: 4,
                            color: theme.colors.text,
                            fontWeight: "900",
                            textAlign: "center",
                          }}
                        />

                        {isSelected ? (
                          <Pressable
                            onPress={() => setInlineQty(pid, "")}
                            style={({ pressed }) => ({
                              width: 28,
                              height: 28,
                              borderRadius: 7,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              backgroundColor: theme.colors.surface2,
                              alignItems: "center",
                              justifyContent: "center",
                              opacity: pressed ? 0.65 : 1,
                            })}
                          >
                            <Text
                              style={{
                                color: theme.colors.muted,
                                fontWeight: "900",
                                fontSize: 12,
                              }}
                            >
                              ×
                            </Text>
                          </Pressable>
                        ) : null}
                      </View>
                    </View>
                  );
                })}
                </ScrollView>
              </View>
            ) : (
              filtered.slice(0, 40).map((r) => {
                const pid = String(r.product_id);
                const currentQty = selectedMap[pid]?.qty ?? "";
                const isSelected = parsePositiveQty(currentQty) > 0;

                return (
                  <View
                    key={pid}
                    style={{
                      borderWidth: 1,
                      borderColor: isSelected
                        ? "rgba(52,211,153,0.55)"
                        : theme.colors.border,
                      borderRadius: theme.radius.xl,
                      backgroundColor: theme.colors.card,
                      padding: 14,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "flex-start",
                      }}
                    >
                      <View style={{ flex: 1, paddingRight: 12 }}>
                        <Text
                          style={{
                            color: theme.colors.text,
                            fontWeight: "900",
                          }}
                        >
                          {r.product_name}
                        </Text>

                        <Text
                          style={{
                            color: theme.colors.muted,
                            fontWeight: "800",
                            marginTop: 6,
                          }}
                        >
                          {uiText("SKU:")}{" "}
                          <Text style={{ color: theme.colors.text }}>
                            {r.sku ?? "—"}
                          </Text>
                          {"   "}|{"   "}
                          {uiText("QTY:")}{" "}
                          <Text style={{ color: theme.colors.text }}>
                            {r.qty}
                          </Text>
                        </Text>

                        <Text
                          style={{
                            marginTop: 8,
                            fontWeight: "900",
                            color: isSelected
                              ? theme.colors.emerald
                              : theme.colors.faint,
                          }}
                        >
                          {isSelected ? uiText("Selected ✓") : uiText("Type qty to select")}
                        </Text>
                      </View>

                      <View style={{ width: 110 }}>
                        <Text
                          style={{
                            color: theme.colors.muted,
                            fontWeight: "900",
                            marginBottom: 8,
                          }}
                        >
                          {uiText("Qty")}</Text>

                        <TextInput
                          value={currentQty}
                          onChangeText={(t) => setInlineQty(pid, t)}
                          keyboardType="decimal-pad"
                          placeholder="0"
                          placeholderTextColor="rgba(255,255,255,0.35)"
                          style={{
                            borderWidth: 1,
                            borderColor: isSelected
                              ? "rgba(156, 166, 163, 0.55)"
                              : theme.colors.border,
                            borderRadius: theme.radius.lg,
                            backgroundColor: "rgba(255,255,255,0.05)",
                            paddingHorizontal: 12,
                            paddingVertical: 10,
                            color: theme.colors.text,
                            fontWeight: "900",
                            textAlign: "center",
                          }}
                        />

                        {isSelected ? (
                          <Pressable
                            onPress={() => setInlineQty(pid, "")}
                            style={{
                              marginTop: 10,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              borderRadius: theme.radius.lg,
                              backgroundColor: theme.colors.surface2,
                              paddingVertical: 8,
                              alignItems: "center",
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                              }}
                            >
                              {uiText("Clear")}</Text>
                          </Pressable>
                        ) : null}
                      </View>
                    </View>
                  </View>
                );
              })
            )}

          </>
        )}
      </Card>

      <View style={{ height: 24 }} />
    </Screen>
  );
}
