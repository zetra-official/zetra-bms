import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
﻿import {useCommonText} from "@/src/i18n/useCommonText";
// app/(tabs)/club/orders/create/index.tsx
import { supabase } from "@/src/supabase/supabaseClient";
import { Card } from "@/src/ui/Card";
import { Screen } from "@/src/ui/Screen";
import { theme } from "@/src/ui/theme";
import { formatMoney } from "@/src/ui/money";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, Pressable, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type DraftItem = {
  key: string;
  product_id?: string | null;
  product_name: string;
  unit_price: string; // string input
  qty: string; // string input
};

type PreviewRow = {
  post_id: string;
  store_id: string | null;
  product_id: string | null;
  product_name: string | null;
  unit_price: number | string | null;
  currency: string | null;
  caption?: string | null;
};

function clean(x: any) {
  return String(x ?? "").trim();
}

function upper(x: any) {
  return clean(x).toUpperCase();
}

function asQty(x: string) {
  const n = Number(clean(x));
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.floor(n));
}

function asMoney(x: string) {
  const n = Number(clean(x));
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, n);
}

export default function CreateClubOrderScreen() {
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const params = useLocalSearchParams<{
    storeId?: string;
    storeName?: string;
    postId?: string;
    postCaption?: string;
    postImageUrl?: string;
  }>();

  // Route params
  const paramStoreId = clean(params?.storeId);
  const storeName = clean(params?.storeName) || "";
  const postId = clean(params?.postId);

  const topPad = Math.max(insets.top, 10) + 8;

  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  // ✅ Customer details (required)
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");

  // ✅ Auto-fill mode (when order is created from a post)
  const fromPost = useMemo(() => !!postId, [postId]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewErr, setPreviewErr] = useState<string | null>(null);
  const [currency, setCurrency] = useState<string>("TZS");

  // ✅ Effective storeId (keep stability; allow fallback if param missing)
  const [storeId, setStoreId] = useState<string>(paramStoreId);

  const [items, setItems] = useState<DraftItem[]>([
    { key: "1", product_name: "", unit_price: "", qty: "1", product_id: null },
  ]);

  const fmt = useCallback(
    (amount: number) => formatMoney(amount, { currency: upper(currency) || "TZS" }),
    [currency]
  );

  // ✅ Load order preview from post (auto product + price)
  const loadPreview = useCallback(async () => {
    if (!postId) return;

    setPreviewErr(null);
    setPreviewLoading(true);
    try {
      const { data, error } = await supabase.rpc("get_club_post_order_preview_v2", {
        p_post_id: postId,
      });

      if (error) throw error;

      const row = (Array.isArray(data) ? data?.[0] : data) as PreviewRow | undefined;
      const pName = clean(row?.product_name);
      const pId = clean(row?.product_id);
      const pStore = clean(row?.store_id);
      const pCurrency = upper(row?.currency || "TZS");
      const unit = row?.unit_price as any;
      const pUnit = Number(unit);
      const unitPrice = Number.isFinite(pUnit) ? pUnit : 0;

      if (!storeId && pStore) setStoreId(pStore);
      setCurrency(pCurrency || "TZS");

      setItems((prev) => {
        const first =
          prev?.[0] ?? { key: "1", product_name: "", unit_price: "", qty: "1", product_id: null };
        const qtyKeep = asQty(first.qty) >= 1 ? first.qty : "1";

        return [
          {
            key: "1",
            product_id: pId || null,
            product_name: pName || first.product_name || "",
            unit_price:
              pName || pId
                ? String(unitPrice)
                : first.unit_price || "",
            qty: qtyKeep,
          },
        ];
      });

      if (!pName && !pId) {
        setPreviewErr("Post hii haina product iliyofungwa. Unaweza kuandika item manually na kutuma order kawaida.");
      }
    } catch (e: any) {
      setPreviewErr(e?.message ?? "Failed to load post order preview");
    } finally {
      setPreviewLoading(false);
    }
  }, [postId, storeId]);

  useEffect(() => {
    if (!postId) return;
    void loadPreview();
  }, [loadPreview, postId]);

  const subtotal = useMemo(() => {
    let s = 0;
    for (const it of items) {
      const q = asQty(it.qty);
      const p = asMoney(it.unit_price);
      if (!clean(it.product_name).length) continue;
      if (q < 1) continue;
      s += p * q;
    }
    return s;
  }, [items]);

  const totalQty = useMemo(() => {
    let q = 0;
    for (const it of items) {
      if (!clean(it.product_name).length) continue;
      q += asQty(it.qty);
    }
    return q;
  }, [items]);

  const canSubmit = useMemo(() => {
    if (!storeId) return false;

    if (clean(customerName).length < 2) return false;
    if (clean(customerPhone).length < 6) return false;

    const valid = items.some((it) => clean(it.product_name).length && asQty(it.qty) >= 1);
    return valid && !busy && !previewLoading;
  }, [busy, customerName, customerPhone, items, previewLoading, storeId]);

  const addLine = useCallback(() => {
    // ✅ In post-mode: lock to single item (product from post)
    if (fromPost) return;

    setItems((prev) => {
      const nextKey = String(prev.length + 1);
      return [...prev, { key: nextKey, product_name: "", unit_price: "", qty: "1", product_id: null }];
    });
  }, [fromPost]);

  const removeLine = useCallback(
    (key: string) => {
      // ✅ In post-mode: do not allow removing the only item
      if (fromPost) return;

      setItems((prev) => {
        const next = prev.filter((x) => x.key !== key);
        return next.length ? next : [{ key: "1", product_name: "", unit_price: "", qty: "1", product_id: null }];
      });
    },
    [fromPost]
  );

  const updateLine = useCallback(
    (key: string, patch: Partial<DraftItem>) => {
      setItems((prev) =>
        prev.map((x) => {
          if (x.key !== key) return x;

          const hasLockedPostProduct =
            fromPost &&
            x.key === "1" &&
            !!clean(x.product_id) &&
            !!clean(x.product_name);

          if (hasLockedPostProduct) {
            return { ...x, qty: patch.qty ?? x.qty };
          }

          return { ...x, ...patch };
        })
      );
    },
    [fromPost]
  );

  // ✅ SUBMIT (PATCHED): safeNote + customer route
  const submit = useCallback(async () => {
    if (!storeId) return;
    if (!canSubmit) return;

    // In post-mode:
    // - kama post ina product, itatumika auto-fill
    // - kama post haina product, customer anaweza kuandika item manually
    if (fromPost) {
      const first = items?.[0];
      if (!clean(first?.product_name)) {
        Alert.alert(uiText("Order"), uiText("Andika angalau item name kabla ya kutuma order."));
        return;
      }
    }

    const payloadItems = items
      .map((it) => ({
        product_id: clean(it.product_id) || null,
        product_name: clean(it.product_name),
        unit_price: String(asMoney(it.unit_price)),
        qty: String(asQty(it.qty) || 1),
      }))
      .filter((x) => x.product_name.length && Number(x.qty) >= 1);

    if (!payloadItems.length) {
      Alert.alert(uiText("Order"), uiText("Weka angalau item 1 (jina + qty)."));
      return;
    }

    // ✅ ONLY CHANGE: note NOT NULL safety
    const safeNote = clean(note) || "—";

    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("create_club_order_with_items", {
        p_store_id: storeId,
        p_note: safeNote,
        p_items: payloadItems,
        p_customer_name: clean(customerName),
        p_customer_phone: clean(customerPhone),
      });

      if (error) throw error;

      const orderId = clean(data);

      Alert.alert(uiText("Order"), uiText("Order imetumwa ✅"), [
        {
          text: uiText("OPEN"),
          onPress: () => {
            if (!orderId) return router.back();

            // ✅ Customer route (NOT staff confirm screen)
            router.replace({
              pathname: "/(tabs)/club/orders/customer/[orderId]" as any,
              params: { orderId, storeId, storeName },
            } as any);
          },
        },
        { text: uiText("OK") },
      ]);
    } catch (e: any) {
      Alert.alert(uiText("Order"), e?.message ?? uiText("Failed to create order"));
    } finally {
      setBusy(false);
    }
  }, [storeId, canSubmit, fromPost, items, note, customerName, customerPhone, router, storeName]);

  const title = "Create Order";

  return (
    <Screen scroll contentStyle={{ paddingTop: topPad }}>
      <View style={{ gap: 12 }}>
        <Card>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <View
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 999,
                  borderWidth: 1,
                  borderColor: theme.colors.emeraldBorder,
                  backgroundColor: theme.colors.emeraldSoft,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="bag-handle-outline" size={18} color={theme.colors.emerald} />
              </View>

              <View>
                <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}>{uiText("Create Order")}</Text>
                <Text style={{ color: theme.colors.faint, fontWeight: "900", fontSize: 12 }}>
                  {uiText("Store:")}{storeName ? storeName : storeId ? storeId.slice(0, 8) + "…" : "—"}
                </Text>
              </View>
            </View>

            <Pressable
              onPress={() => router.back()}
              hitSlop={10}
              style={({ pressed }) => [
                {
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                  borderRadius: 999,
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.12)",
                  backgroundColor: "rgba(255,255,255,0.06)",
                  opacity: pressed ? 0.92 : 1,
                },
              ]}
            >
              <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Back")}</Text>
            </Pressable>
          </View>
        </Card>

        {/* ✅ Preview state (post-mode) */}
        {fromPost ? (
          <Card style={{ padding: 14, backgroundColor: theme.colors.surface2, borderColor: theme.colors.borderSoft }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Ionicons name="sparkles-outline" size={18} color={theme.colors.emerald} />
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Post auto-fill")}</Text>
              </View>

              <Pressable
                onPress={() => void loadPreview()}
                hitSlop={10}
                style={({ pressed }) => [
                  {
                    paddingHorizontal: 12,
                    paddingVertical: 8,
                    borderRadius: 999,
                    borderWidth: 1,
                    borderColor: theme.colors.emeraldBorder,
                    backgroundColor: theme.colors.emeraldSoft,
                    opacity: pressed ? 0.92 : 1,
                  },
                ]}
              >
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
                  {previewLoading ? uiText("Loading...") : uiText("Refresh")}
                </Text>
              </Pressable>
            </View>

            {!!previewErr ? (
              <Text style={{ marginTop: 10, color: theme.colors.danger, fontWeight: "900" }}>
                {systemText(previewErr)}
              </Text>
            ) : null}

            {previewLoading ? (
              <View style={{ marginTop: 10, flexDirection: "row", alignItems: "center", gap: 10 }}>
                <ActivityIndicator />
                <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Loading product + price from post…")}</Text>
              </View>
            ) : null}
          </Card>
        ) : null}

        {/* ✅ Customer block */}
        <Card style={{ padding: 14, gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 14 }}>{uiText("Customer details")}</Text>

          <TextInput
            value={customerName}
            onChangeText={setCustomerName}
            placeholder={uiText("Customer name (required)")}
            placeholderTextColor={theme.colors.muted}
            style={{
              height: 44,
              paddingHorizontal: 12,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.12)",
              backgroundColor: "rgba(255,255,255,0.06)",
              color: theme.colors.text,
              fontWeight: "800",
            }}
          />

          <TextInput
            value={customerPhone}
            onChangeText={setCustomerPhone}
            placeholder={uiText("Phone (required)")}
            placeholderTextColor={theme.colors.muted}
            keyboardType="phone-pad"
            style={{
              height: 44,
              paddingHorizontal: 12,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.12)",
              backgroundColor: "rgba(255,255,255,0.06)",
              color: theme.colors.text,
              fontWeight: "800",
            }}
          />

          <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12, lineHeight: 16 }}>
            {uiText("NOTE: Hizi details zinaenda kwa muuzaji (anaye-receive order) ili athibitishe na kuendelea na malipo.")}</Text>
        </Card>

        {/* ✅ Items */}
        <Card style={{ padding: 14, gap: 12 }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 14 }}>{uiText("Items")}</Text>

          {items.map((it) => {
            const lockItem =
              fromPost &&
              it.key === "1" &&
              !!clean(it.product_id) &&
              !!clean(it.product_name);
            return (
              <Card
                key={it.key}
                style={{
                  padding: 12,
                  backgroundColor: theme.colors.surface2,
                  borderColor: theme.colors.borderSoft,
                  gap: 10,
                }}
              >
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                  <Text style={{ color: theme.colors.faint, fontWeight: "900" }}>{uiText("Item #")}{it.key}</Text>

                  {!fromPost ? (
                    <Pressable
                      onPress={() => removeLine(it.key)}
                      hitSlop={10}
                      style={({ pressed }) => [
                        {
                          paddingHorizontal: 10,
                          paddingVertical: 6,
                          borderRadius: 999,
                          borderWidth: 1,
                          borderColor: theme.colors.dangerBorder,
                          backgroundColor: theme.colors.dangerSoft,
                          opacity: pressed ? 0.92 : 1,
                        },
                      ]}
                    >
                      <Text style={{ color: theme.colors.danger, fontWeight: "900" }}>{uiText("Remove")}</Text>
                    </Pressable>
                  ) : (
                    <View
                      style={{
                        paddingHorizontal: 10,
                        paddingVertical: 6,
                        borderRadius: 999,
                        borderWidth: 1,
                        borderColor: theme.colors.emeraldBorder,
                        backgroundColor: theme.colors.emeraldSoft,
                      }}
                    >
                      <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("AUTO")}</Text>
                    </View>
                  )}
                </View>

                <TextInput
                  value={it.product_name}
                  onChangeText={(v) => updateLine(it.key, { product_name: v })}
                  editable={!lockItem}
                  placeholder={uiText("Product name")}
                  placeholderTextColor={theme.colors.muted}
                  style={{
                    height: 44,
                    paddingHorizontal: 12,
                    borderRadius: 14,
                    borderWidth: 1,
                    borderColor: "rgba(255,255,255,0.12)",
                    backgroundColor: lockItem ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.06)",
                    color: theme.colors.text,
                    fontWeight: "800",
                    opacity: lockItem ? 0.92 : 1,
                  }}
                />

                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.colors.faint, fontWeight: "900", marginBottom: 6 }}>{uiText("Qty")}</Text>
                    <TextInput
                      value={it.qty}
                      onChangeText={(v) => updateLine(it.key, { qty: v })}
                      keyboardType="numeric"
                      placeholder="1"
                      placeholderTextColor={theme.colors.muted}
                      style={{
                        height: 44,
                        paddingHorizontal: 12,
                        borderRadius: 14,
                        borderWidth: 1,
                        borderColor: "rgba(255,255,255,0.12)",
                        backgroundColor: "rgba(255,255,255,0.06)",
                        color: theme.colors.text,
                        fontWeight: "800",
                      }}
                    />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.colors.faint, fontWeight: "900", marginBottom: 6 }}>
                      {uiText("Price")}</Text>
                    <TextInput
                      value={it.unit_price}
                      onChangeText={(v) => updateLine(it.key, { unit_price: v })}
                      keyboardType="numeric"
                      editable={!lockItem}
                      placeholder="0"
                      placeholderTextColor={theme.colors.muted}
                      style={{
                        height: 44,
                        paddingHorizontal: 12,
                        borderRadius: 14,
                        borderWidth: 1,
                        borderColor: "rgba(255,255,255,0.12)",
                        backgroundColor: lockItem ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.06)",
                        color: theme.colors.text,
                        fontWeight: "800",
                        opacity: lockItem ? 0.92 : 1,
                      }}
                    />
                  </View>
                </View>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Line total:")}{fmt(asMoney(it.unit_price) * asQty(it.qty))}
                </Text>

                {lockItem ? (
                  <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12, lineHeight: 16 }}>
                    {uiText("Product & price zimetoka kwenye post (snapshot). Customer anaweka qty tu.")}</Text>
                ) : fromPost && it.key === "1" ? (
                  <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12, lineHeight: 16 }}>
                    {uiText("Post hii haina product ya DB. Andika item manually kisha tuma order kwa seller.")}</Text>
                ) : null}
              </Card>
            );
          })}

          {!fromPost ? (
            <Pressable
              onPress={addLine}
              hitSlop={10}
              style={({ pressed }) => [
                {
                  height: 44,
                  borderRadius: theme.radius.pill,
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.12)",
                  backgroundColor: "rgba(255,255,255,0.06)",
                  alignItems: "center",
                  justifyContent: "center",
                  flexDirection: "row",
                  gap: 10,
                  opacity: pressed ? 0.92 : 1,
                },
              ]}
            >
              <Ionicons name="add-circle-outline" size={18} color={theme.colors.text} />
              <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Add item")}</Text>
            </Pressable>
          ) : null}

          <Text style={{ color: theme.colors.text, fontWeight: "900", marginTop: 6 }}>{uiText("Note")}</Text>
          <TextInput
            value={note}
            onChangeText={setNote}
            placeholder={uiText("Optional note...")}
            placeholderTextColor={theme.colors.muted}
            multiline
            style={{
              minHeight: 70,
              paddingHorizontal: 12,
              paddingVertical: 10,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.12)",
              backgroundColor: "rgba(255,255,255,0.06)",
              color: theme.colors.text,
              fontWeight: "800",
            }}
          />

          <Card style={{ padding: 12, backgroundColor: theme.colors.surface2, borderColor: theme.colors.borderSoft }}>
            <Text style={{ color: theme.colors.faint, fontWeight: "900" }}>{uiText("Summary")}</Text>
            <View style={{ marginTop: 8, gap: 6 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("Total qty")}</Text>
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{String(totalQty)}</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("Subtotal")}</Text>
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{fmt(subtotal)}</Text>
              </View>
            </View>
          </Card>

          <Pressable
            onPress={submit}
            disabled={!canSubmit}
            hitSlop={10}
            style={({ pressed }) => [
              {
                height: 48,
                borderRadius: theme.radius.pill,
                borderWidth: 1,
                borderColor: theme.colors.emeraldBorder,
                backgroundColor: theme.colors.emeraldSoft,
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "row",
                gap: 10,
                opacity: !canSubmit ? 0.6 : pressed ? 0.92 : 1,
              },
            ]}
          >
            <Ionicons name="send-outline" size={18} color={theme.colors.emerald} />
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
              {busy ? uiText("Sending...") : uiText("Submit Order")}
            </Text>
          </Pressable>

          <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12, lineHeight: 16 }}>
            {uiText("NOTE: Totals zinahesabiwa UI kwa preview; DB bado inafanya validation/usalama kwenye function.")}</Text>
        </Card>
      </View>
    </Screen>
  );
}