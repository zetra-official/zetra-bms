import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
import {useCommonText} from "@/src/i18n/useCommonText";
// CLEAN_ORDERS_DASHBOARD_V1
// MOBILE_COMPACT_V2
// app/stores/orders.tsx
import { useOrg } from "@/src/context/OrgContext";
import { Ionicons } from "@expo/vector-icons";
import { supabase } from "@/src/supabase/supabaseClient";
import { Card } from "@/src/ui/Card";
import { Screen } from "@/src/ui/Screen";
import { theme } from "@/src/ui/theme";
import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  useWindowDimensions,
  Alert,
  Modal,
  Pressable,
  Text,
  TextInput,
  View,
} from "react-native";

type TabMode = "RESERVATIONS" | "PRE_ORDERS";
type SectionKey = "PENDING" | "READY" | "COMPLETED";

type StoreOrderRow = {
  id: string;
  order_type?: string | null;
  status?: string | null;
  customer_name?: string | null;
  customer_phone?: string | null;
  product_name?: string | null;
  note?: string | null;
  total_amount?: number | null;
  paid_amount?: number | null;
  balance_amount?: number | null;
  created_at?: string | null;
};

type PaymentHistoryLine = {
  amount: number;
  method: string;
  reference: string | null;
  at: string | null;
};

type ParsedOrderNote = {
  cleanNote: string | null;
  itemsText: string | null;
  paymentText: string | null;
  discountText: string | null;
  payments: PaymentHistoryLine[];
};

type CustomerFile = {
  key: string;
  name: string;
  phone: string;
  orders: StoreOrderRow[];
  total: number;
  paid: number;
  balance: number;
};

type CustomerSuggestion = {
  key: string;
  name: string;
  phone: string;
};

function money(v: any) {
  return `TSh ${Number(v || 0).toLocaleString()}`;
}

function shortDate(v?: string | null) {
  if (!v) return "—";
  try {
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }).format(new Date(v));
  } catch {
    return "—";
  }
}
function shortDateTime(v?: string | null) {
  if (!v) return "—";
  try {
    return new Intl.DateTimeFormat("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(v));
  } catch {
    return String(v);
  }
}
function normalizePhone(v?: string | null) {
  return String(v ?? "").replace(/\s+/g, "").trim();
}

function isCompletedOrder(r: StoreOrderRow) {
  const s = String(r.status ?? "").trim().toUpperCase();
  return s === "COMPLETED" || s === "PICKED_UP" || s === "CLOSED";
}

function parseOrderNote(note?: string | null): ParsedOrderNote {
  const raw = String(note ?? "").trim();
  if (!raw) {
  return {
    cleanNote: null,
    itemsText: null,
    paymentText: null,
    discountText: null,
    payments: [],
  };
}

 let itemsText: string | null = null;
let paymentText: string | null = null;
let discountText: string | null = null;
const payments: PaymentHistoryLine[] = [];

  const paymentMatch = raw.match(/ORDER_PAYMENT:\s*([^\n]+)/i);
  if (paymentMatch?.[1]) paymentText = paymentMatch[1].replace(/\s*\|\s*/g, " • ").trim();
const paymentLines = raw.matchAll(
  /(ORDER_PAYMENT|PRE_ORDER_PAYMENT|PAYMENT_HISTORY):\s*([^\n]+)/gi
);

for (const m of paymentLines) {
  const line = String(m?.[2] ?? "");

  const paidMatch = line.match(/PAID\s*=\s*([0-9.]+)/i);
  const methodMatch = line.match(/METHOD\s*=\s*([^|•]+)/i);
  const refMatch = line.match(/REF\s*=\s*([^|•]+)/i);
  const atMatch = line.match(/AT\s*=\s*([^|•]+)/i);

  const amount = Number(paidMatch?.[1] ?? 0);

  if (amount > 0) {
    payments.push({
      amount,
      method: String(methodMatch?.[1] ?? "CASH").trim(),
      reference: refMatch?.[1] ? String(refMatch[1]).trim() : null,
      at: atMatch?.[1] ? String(atMatch[1]).trim() : null,
    });
  }
}
  const discountMatch = raw.match(/DISCOUNT:\s*"([^"]*)"\s*\|\s*DISCOUNT_AMOUNT:\s*([0-9.]+)/i);
  if (discountMatch?.[1]) {
    const label = discountMatch[1] === "—" ? "Discount" : discountMatch[1];
    discountText = `${label} • ${money(discountMatch[2])}`;
  }

  const jsonIndex = raw.indexOf("ITEMS_JSON:");
  if (jsonIndex >= 0) {
    const after = raw.slice(jsonIndex + "ITEMS_JSON:".length).trim();
    const discountIndex = after.indexOf("DISCOUNT:");
    const jsonRaw = discountIndex >= 0 ? after.slice(0, discountIndex).trim() : after.trim();

    try {
      const parsed = JSON.parse(jsonRaw);
      if (Array.isArray(parsed)) {
        itemsText = parsed
          .map((x: any) => `${String(x?.name ?? "Item")} x ${Number(x?.qty ?? 1)}`)
          .join(", ");
      }
    } catch {}
  }

  const cleaned = raw
    .replace(/ORDER_PAYMENT:[^\n]*\n?/gi, "")
    .replace(/CHANNEL:[^\n]*\n?/gi, "")
    .replace(/ITEMS_JSON:[\s\S]*?(?=DISCOUNT:|$)/gi, "")
    .replace(/DISCOUNT:[\s\S]*$/gi, "")
    .trim();

  return { cleanNote: cleaned || null, itemsText, paymentText, discountText, payments };
}

function MiniPill({
  label,
  tone = "default",
}: {
  label: string;
  tone?: "default" | "green" | "amber" | "blue";
}) {
  const bg =
    tone === "green"
      ? "rgba(16,185,129,0.10)"
      : tone === "amber"
        ? "rgba(180,83,9,0.10)"
        : tone === "blue"
          ? "rgba(59,130,246,0.10)"
          : "#F8FAFC";

  const color =
    tone === "green"
      ? "#059669"
      : tone === "amber"
        ? "#B45309"
        : tone === "blue"
          ? "#2563EB"
          : "#0F172A";

  return (
    <View
      style={{
        borderWidth: 1,
        borderColor: "rgba(15,23,42,0.08)",
        backgroundColor: bg,
        borderRadius: 999,
        paddingHorizontal: 10,
        paddingVertical: 6,
      }}
    >
      <Text style={{ color, fontWeight: "900", fontSize: 12 }}>{label}</Text>
    </View>
  );
}

export default function StoreOrdersScreen() {
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const params = useLocalSearchParams<{ orgId?: string; storeId?: string; storeName?: string; category?: string }>();
  const orgCtx: any = useOrg();

  const orgId = String(params?.orgId ?? orgCtx?.activeOrgId ?? "").trim();
  const storeId = String(params?.storeId ?? orgCtx?.activeStoreId ?? "").trim();
  const storeName = String(params?.storeName ?? orgCtx?.activeStoreName ?? "Active Store").trim();

  const category = String(params?.category ?? "").trim().toLowerCase();
  const isDetail = ["reservations", "pre-orders", "pending", "ready", "completed"].includes(category);
  const { width: ordersWidth } = useWindowDimensions();
  const desktopOrders = ordersWidth >= 900;

  const [tab, setTab] = useState<TabMode>(
    category === "pre-orders" ? "PRE_ORDERS" : "RESERVATIONS"
  );

  useEffect(() => {
    setTab(category === "pre-orders" ? "PRE_ORDERS" : "RESERVATIONS");
  }, [category]);
  const [rows, setRows] = useState<StoreOrderRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [overview, setOverview] = useState<{
    reservations: StoreOrderRow[];
    preOrders: StoreOrderRow[];
  }>({ reservations: [], preOrders: [] });
  const [overviewLoading, setOverviewLoading] = useState(false);
  const [overviewError, setOverviewError] = useState<string | null>(null);
  const overviewRequest = React.useRef(0);

  const [payModalOpen, setPayModalOpen] = useState(false);
  const [payTarget, setPayTarget] = useState<StoreOrderRow | null>(null);
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("CASH");
  const [payReference, setPayReference] = useState("");
  const [paySaving, setPaySaving] = useState(false);

  const [preModalOpen, setPreModalOpen] = useState(false);
  const [preCustomerName, setPreCustomerName] = useState("");
  const [preCustomerPhone, setPreCustomerPhone] = useState("");
  const [preProductName, setPreProductName] = useState("");
  const [preTotalAmount, setPreTotalAmount] = useState("");
  const [prePaidAmount, setPrePaidAmount] = useState("");
  const [prePaymentMethod, setPrePaymentMethod] = useState("CASH");
  const [preReference, setPreReference] = useState("");
  const [preNote, setPreNote] = useState("");
  const [preSaving, setPreSaving] = useState(false);
  const [preCustomerSuggestions, setPreCustomerSuggestions] = useState<CustomerSuggestion[]>([]);

  const [pickupConfirmOpen, setPickupConfirmOpen] = useState(false);
  const [pickupTarget, setPickupTarget] = useState<StoreOrderRow | null>(null);
  const [pickupSaving, setPickupSaving] = useState(false);

  const [pickupDoneOpen, setPickupDoneOpen] = useState(false);
  const [pickupReceiptSaleId, setPickupReceiptSaleId] = useState("");

  const [openSections, setOpenSections] = useState<Record<SectionKey, boolean>>({
    PENDING: true,
    READY: true,
    COMPLETED: false,
  });
  const [openCustomers, setOpenCustomers] = useState<Record<string, boolean>>({});

  const [orderSearch, setOrderSearch] = useState("");
  const [orderPage, setOrderPage] = useState(1);

  useEffect(() => {
    setOrderSearch("");
    setOrderPage(1);
  }, [category, storeId]);

  const C: any = (theme as any)?.colors ?? {};
  const TEXT = C?.text ?? "#0F172A";
  const MUTED = C?.muted ?? "#64748B";
  const FAINT = C?.faint ?? "#94A3B8";
  const BORDER = C?.borderSoft ?? "#E5EAF1";
  const EMERALD = C?.emerald ?? "#10B981";

  const title = tab === "RESERVATIONS" ? "Reservations" : "Pre Orders";
  const dbType = tab === "RESERVATIONS" ? "RESERVATION" : "PRE_ORDER";

  const goPickProducts = useCallback(() => {
    if (!orgId || !storeId) {
      Alert.alert(uiText("Missing"), uiText("Organization au Store haijapatikana."));
      return;
    }

    router.push({
      pathname: "/(tabs)/sales",
      params: {
        orderMode: "1",
        orderType: dbType,
        orderOrgId: orgId,
        orderStoreId: storeId,
        orderStoreName: storeName,
      },
    } as any);
  }, [router, orgId, storeId, storeName, dbType]);
const loadOrders = useCallback(async () => {
    if (!storeId) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.rpc("get_store_orders_v1", {
        p_org_id: orgId || null,
        p_store_id: storeId,
        p_order_type: dbType,
      });

      if (error) throw error;
      setRows(Array.isArray(data) ? (data as StoreOrderRow[]) : []);
    } catch (err: any) {
      Alert.alert(uiText("Failed"), err?.message ?? uiText("Imeshindikana kupakia store orders."));
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [orgId, storeId, dbType]);

  const loadOverview = useCallback(async () => {
    const rid = ++overviewRequest.current;

    if (!storeId) {
      setOverviewLoading(false);
      setOverviewError("No active store selected.");
      return;
    }

    setOverviewLoading(true);
    setOverviewError(null);

    try {
      const [a, b] = await Promise.all([
        supabase.rpc("get_store_orders_v1", {
          p_org_id: orgId || null,
          p_store_id: storeId,
          p_order_type: "RESERVATION",
        }),
        supabase.rpc("get_store_orders_v1", {
          p_org_id: orgId || null,
          p_store_id: storeId,
          p_order_type: "PRE_ORDER",
        }),
      ]);

      if (a.error) throw a.error;
      if (b.error) throw b.error;
      if (rid !== overviewRequest.current) return;

      setOverview({
        reservations: Array.isArray(a.data) ? a.data as StoreOrderRow[] : [],
        preOrders: Array.isArray(b.data) ? b.data as StoreOrderRow[] : [],
      });
    } catch (e: any) {
      if (rid !== overviewRequest.current) return;
      setOverviewError(e?.message ?? "Failed to load overview.");
    } finally {
      if (rid === overviewRequest.current) setOverviewLoading(false);
    }
  }, [orgId, storeId]);

  useFocusEffect(
    useCallback(() => {
      if (isDetail) return;
      void loadOverview();
      return () => { overviewRequest.current += 1; };
    }, [isDetail, loadOverview])
  );

  const openCategory = useCallback((slug: string) => {
    router.push({
      pathname: "/stores/order-category/[category]",
      params: { category: slug, orgId, storeId, storeName },
    } as any);
  }, [router, orgId, storeId, storeName]);

  const openNewOrder = useCallback(() => {
    if (tab === "PRE_ORDERS") {
      setPreModalOpen(true);
      return;
    }

    goPickProducts();
  }, [tab, goPickProducts]);

  const closePreOrderModal = useCallback(() => {
    if (preSaving) return;
    setPreModalOpen(false);
    setPreCustomerSuggestions([]);
  }, [preSaving]);

  const onChangePreCustomerName = useCallback((v: string) => {
    setPreCustomerName(v);

    const q = v.trim().toLowerCase();
    if (q.length < 2) {
      setPreCustomerSuggestions([]);
      return;
    }

    const map = new Map<string, CustomerSuggestion>();

    for (const r of rows) {
      const name = String(r.customer_name ?? "").trim();
      const phone = String(r.customer_phone ?? "").trim();
      if (!name && !phone) continue;

      const hay = `${name} ${phone}`.toLowerCase();
      if (!hay.includes(q)) continue;

      const key = normalizePhone(phone) || name.toLowerCase();
      map.set(key, { key, name: name || "Customer", phone });
    }

    setPreCustomerSuggestions(Array.from(map.values()).slice(0, 6));
  }, [rows]);

  const choosePreCustomer = useCallback((c: CustomerSuggestion) => {
    setPreCustomerName(c.name);
    setPreCustomerPhone(c.phone);
    setPreCustomerSuggestions([]);
  }, []);

  const savePreOrder = useCallback(async () => {
    if (!orgId || !storeId) {
      Alert.alert(uiText("Missing"), uiText("Organization au Store haijapatikana."));
      return;
    }

    const name = preCustomerName.trim();
    const phone = preCustomerPhone.trim();
    const product = preProductName.trim();
    const total = Number(String(preTotalAmount || "0").replace(/[^\d]/g, ""));
    const paid = Number(String(prePaidAmount || "0").replace(/[^\d]/g, ""));

    if (!name) return Alert.alert(uiText("Missing"), uiText("Weka jina la mteja."));
    if (!phone) return Alert.alert(uiText("Missing"), uiText("Weka namba ya simu."));
    if (!product) return Alert.alert(uiText("Missing"), uiText("Andika bidhaa/design anayohitaji."));
    if (!Number.isFinite(total) || total <= 0) return Alert.alert(uiText("Invalid"), uiText("Weka makadirio ya bei."));
    if (!Number.isFinite(paid) || paid < 0) return Alert.alert(uiText("Invalid"), uiText("Paid amount si sahihi."));
    if (paid > total) return Alert.alert(uiText("Invalid"), uiText("Paid haiwezi kuzidi total."));

    const balance = Math.max(0, total - paid);
    const noteParts = [
      `PRE_ORDER_PAYMENT: METHOD=${prePaymentMethod || "CASH"} | PAID=${paid} | BALANCE=${balance}`,
      `REF: ${preReference.trim() || "-"}`,
      preNote.trim() ? `NOTE: ${preNote.trim()}` : "",
    ].filter(Boolean);

    setPreSaving(true);
    try {
      const { error } = await supabase.rpc("create_store_order_v1", {
        p_org_id: orgId,
        p_store_id: storeId,
        p_order_type: "PRE_ORDER",
        p_customer_name: name,
        p_customer_phone: phone,
        p_product_name: product,
        p_total_amount: total,
        p_paid_amount: paid,
        p_note: noteParts.join("\n"),
      });

      if (error) throw error;

      setPreCustomerName("");
      setPreCustomerPhone("");
      setPreProductName("");
      setPreTotalAmount("");
      setPrePaidAmount("");
      setPrePaymentMethod("CASH");
      setPreReference("");
      setPreNote("");
      setPreModalOpen(false);

      await loadOrders();
      Alert.alert(uiText("Success ✅"), uiText("Pre-order imehifadhiwa vizuri."));
    } catch (err: any) {
      Alert.alert(uiText("Failed"), err?.message ?? uiText("Imeshindikana kuhifadhi pre-order."));
    } finally {
      setPreSaving(false);
    }
  }, [
    orgId,
    storeId,
    preCustomerName,
    preCustomerPhone,
    preProductName,
    preTotalAmount,
    prePaidAmount,
    prePaymentMethod,
    preReference,
    preNote,
    loadOrders,
  ]);
  

  useFocusEffect(
    useCallback(() => {
      if (!isDetail) return;
      void loadOrders();
      const t = setTimeout(() => void loadOrders(), 600);
      return () => clearTimeout(t);
    }, [isDetail, loadOrders])
  );

  const openAddPayment = useCallback((order: StoreOrderRow) => {
    if (isCompletedOrder(order)) {
      Alert.alert(uiText("Closed"), uiText("Order hii tayari imekamilishwa."));
      return;
    }

    setPayTarget(order);
    setPayAmount(String(Math.round(Number(order.balance_amount || 0))));
    setPayMethod("CASH");
    setPayReference("");
    setPayModalOpen(true);
  }, []);

  const closeAddPayment = useCallback(() => {
    if (paySaving) return;
    setPayModalOpen(false);
    setPayTarget(null);
    setPayAmount("");
    setPayMethod("CASH");
    setPayReference("");
  }, [paySaving]);

  const submitAddPayment = useCallback(async () => {
    if (!payTarget?.id) return;

    const amount = Number(String(payAmount || "0").replace(/[^\d]/g, ""));
    const balance = Number(payTarget.balance_amount || 0);

    if (!Number.isFinite(amount) || amount <= 0) {
      Alert.alert(uiText("Invalid"), uiText("Weka kiasi sahihi cha malipo."));
      return;
    }

    if (amount > balance) {
      Alert.alert(uiText("Invalid"), uiText("Malipo hayawezi kuzidi balance iliyobaki."));
      return;
    }

    setPaySaving(true);
    try {
      const { error } = await supabase.rpc("add_store_reserved_order_payment_v1", {
        p_order_id: payTarget.id,
        p_amount: amount,
        p_method: payMethod || "CASH",
        p_reference: payReference.trim() || null,
        p_note: `PAYMENT_HISTORY: METHOD=${payMethod || "CASH"} | PAID=${amount} | REF=${payReference.trim() || "-"} | AT=${new Date().toISOString()}`,
      });

      if (error) throw error;

      closeAddPayment();
      await loadOrders();
      Alert.alert(uiText("Success ✅"), uiText("Malipo yameongezwa vizuri."));
    } catch (err: any) {
      Alert.alert(uiText("Failed"), err?.message ?? uiText("Imeshindikana kuongeza malipo."));
    } finally {
      setPaySaving(false);
    }
  }, [payTarget, payAmount, payMethod, payReference, closeAddPayment, loadOrders]);

  const completePickup = useCallback((order: StoreOrderRow) => {
    if (!order?.id) return;

    if (isCompletedOrder(order)) {
      Alert.alert(uiText("Already Completed"), uiText("Pickup hii tayari imekamilishwa."));
      return;
    }

    if (Number(order.balance_amount || 0) > 0) {
      Alert.alert(uiText("Blocked"), uiText("Order bado ina balance. Ongeza malipo kwanza."));
      return;
    }

    setPickupTarget(order);
    setPickupConfirmOpen(true);
  }, []);

  const cancelPickupConfirm = useCallback(() => {
    if (pickupSaving) return;
    setPickupConfirmOpen(false);
    setPickupTarget(null);
  }, [pickupSaving]);

  const submitCompletePickup = useCallback(async () => {
    if (!pickupTarget?.id || pickupSaving) return;

    setPickupSaving(true);
    try {
      const { data, error } = await supabase.rpc("complete_store_reserved_order_pickup_v1", {
        p_order_id: pickupTarget.id,
        p_payment_method: "CASH",
        p_payment_channel: null,
        p_reference: null,
      });

      if (error) throw error;

      const row: any = Array.isArray(data) ? data[0] : data;
      const saleId = typeof row === "string" ? row : String(row?.sale_id ?? row?.id ?? "").trim();

      setPickupConfirmOpen(false);
      setPickupTarget(null);
      setPickupReceiptSaleId(saleId);
      setPickupDoneOpen(true);

      await loadOrders();
    } catch (err: any) {
      Alert.alert(uiText("Failed"), err?.message ?? uiText("Imeshindikana kukamilisha pickup."));
    } finally {
      setPickupSaving(false);
    }
  }, [pickupTarget, pickupSaving, loadOrders]);

  const openPickupReceipt = useCallback(() => {
    const saleId = pickupReceiptSaleId.trim();
    setPickupDoneOpen(false);

    if (saleId) {
      router.push({
        pathname: "/(tabs)/sales/receipt",
        params: { saleId },
      } as any);
    }
  }, [pickupReceiptSaleId, router]);

  const summary = useMemo(() => {
    return rows.reduce(
      (a, r) => {
        a.total += Number(r.total_amount || 0);
        a.paid += Number(r.paid_amount || 0);
        a.balance += Number(r.balance_amount || 0);
        return a;
      },
      { total: 0, paid: 0, balance: 0 }
    );
  }, [rows]);

  const pendingRows = rows.filter((r) => !isCompletedOrder(r) && Number(r.balance_amount || 0) > 0);
  const readyRows = rows.filter((r) => !isCompletedOrder(r) && Number(r.balance_amount || 0) <= 0);
  const completedRows = rows.filter((r) => isCompletedOrder(r));

  const makeCustomerFiles = useCallback((sourceRows: StoreOrderRow[]) => {
    const map = new Map<string, CustomerFile>();

    for (const r of sourceRows) {
      const phone = normalizePhone(r.customer_phone);
      const name = String(r.customer_name ?? "Customer").trim() || "Customer";
      const key = phone || name.toLowerCase();

      const existing =
        map.get(key) ??
        ({
          key,
          name,
          phone: phone || "—",
          orders: [],
          total: 0,
          paid: 0,
          balance: 0,
        } as CustomerFile);

      existing.orders.push(r);
      existing.total += Number(r.total_amount || 0);
      existing.paid += Number(r.paid_amount || 0);
      existing.balance += Number(r.balance_amount || 0);

      map.set(key, existing);
    }

    return Array.from(map.values()).sort((a, b) => b.orders.length - a.orders.length);
  }, []);

  const pendingFiles = useMemo(() => makeCustomerFiles(pendingRows), [makeCustomerFiles, pendingRows]);
  const readyFiles = useMemo(() => makeCustomerFiles(readyRows), [makeCustomerFiles, readyRows]);
  const completedFiles = useMemo(
    () => makeCustomerFiles(completedRows),
    [makeCustomerFiles, completedRows]
  );

  const allCustomerFiles = useMemo(
    () => makeCustomerFiles(rows),
    [makeCustomerFiles, rows]
  );

  const reservationOverview = overview.reservations;
  const overviewCards = [
    { slug: "reservations", label: "Reservations", data: reservationOverview, bg: "#E8F8F2", color: "#059669" },
    { slug: "pre-orders", label: "Pre Orders", data: overview.preOrders, bg: "#EEF2FF", color: "#2563EB" },
    { slug: "pending", label: "Pending Payments", data: reservationOverview.filter(r => !isCompletedOrder(r) && Number(r.balance_amount || 0) > 0), bg: "#FFF4EA", color: "#B45309" },
    { slug: "ready", label: "Ready for Pickup", data: reservationOverview.filter(r => !isCompletedOrder(r) && Number(r.balance_amount || 0) <= 0), bg: "#EFF8FF", color: "#2563EB" },
    { slug: "completed", label: "Completed Pickups", data: reservationOverview.filter(isCompletedOrder), bg: "#EAF8F0", color: "#059669" },
  ];

  const renderOrderCompact = (r: StoreOrderRow, orderIndex: number) => {
    const parsed = parseOrderNote(r.note);
    const itemText = parsed.itemsText || r.product_name || "Order item";
    const paid = Number(r.paid_amount || 0);
    const bal = Number(r.balance_amount || 0);
    const total = Number(r.total_amount || 0);
    const completed = isCompletedOrder(r);
    const paidStatus = bal <= 0 && total > 0 ? "PAID" : paid > 0 ? "PARTIAL" : "UNPAID";

    return (
      <View
        key={r.id || String(orderIndex)}
        style={{
          borderWidth: 1,
          borderColor: BORDER,
          backgroundColor: "#F8FAFC",
          borderRadius: 14,
          padding: 10,
          gap: 6,
        }}
      >
        <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
          <Text style={{ color: TEXT, fontWeight: "900", flex: 1 }}>{uiText("Order #")}{orderIndex + 1}</Text>
          <Text style={{ color: FAINT, fontWeight: "900", fontSize: 12 }}>
            {shortDate(r.created_at)}
          </Text>
        </View>

        <Text style={{ color: TEXT, fontWeight: "900", lineHeight: 19 }}>{((parsed.itemsText || r.product_name) || uiText("Order item"))}</Text>

        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          <MiniPill label={money(total)} />
          <MiniPill label={uiText("Paid {p0}", {p0: (money(paid))})} tone="green" />
          <MiniPill label={uiText("Bal {p0}", {p0: (money(bal))})} tone={bal > 0 ? "amber" : "green"} />
        </View>

        <Text style={{ color: FAINT, fontWeight: "900", lineHeight: 18 }}>
          {completed ? uiText("PICKED UP") : uiText(String(r.status || "ACTIVE").toUpperCase())} • {uiText(paidStatus)}
        </Text>

   {parsed.paymentText ? (
  <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 18 }}>
    {uiText("Payment:")}{parsed.paymentText}
  </Text>
) : null}

{parsed.payments.length > 0 ? (
  <View
    style={{
      borderWidth: 1,
      borderColor: BORDER,
      backgroundColor: "#FFFFFF",
      borderRadius: 12,
      padding: 10,
      gap: 6,
      marginTop: 4,
    }}
  >
    <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Payment History")}</Text>

    {parsed.payments.map((p, idx) => (
      <View
        key={`${r.id}-pay-${idx}`}
        style={{
          borderTopWidth: idx === 0 ? 0 : 1,
          borderTopColor: BORDER,
          paddingTop: idx === 0 ? 0 : 6,
          gap: 2,
        }}
      >
        <Text style={{ color: TEXT, fontWeight: "900" }}>
          {idx + 1}. {money(p.amount)}
        </Text>

        <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 18 }}>
          {uiText("Method:")}{p.method}
          {p.reference && p.reference !== "-" ? uiText(" • Ref: {p0}", {p0: (p.reference)}) : ""}
        </Text>

        <Text style={{ color: FAINT, fontWeight: "800", fontSize: 12 }}>
          {shortDateTime(p.at || r.created_at)}
        </Text>
      </View>
    ))}
  </View>
) : null}

        {parsed.discountText ? (
          <Text style={{ color: "#047857", fontWeight: "900", lineHeight: 18 }}>
            {uiText("Discount:")}{parsed.discountText}
          </Text>
        ) : null}

        {parsed.cleanNote ? (
          <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 18 }}>
            {uiText("Note:")}{parsed.cleanNote}
          </Text>
        ) : null}

        {!completed ? (
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap", marginTop: 2 }}>
            {bal > 0 ? (
              <Pressable
                onPress={() => openAddPayment(r)}
                style={{
                  borderWidth: 1,
                  borderColor: "rgba(16,185,129,0.35)",
                  backgroundColor: "rgba(16,185,129,0.10)",
                  borderRadius: 999,
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                }}
              >
                <Text style={{ color: EMERALD, fontWeight: "900" }}>{uiText("Add Payment")}</Text>
              </Pressable>
            ) : null}

            {tab === "RESERVATIONS" ? (
            <Pressable
              onPress={() => completePickup(r)}
              style={{
                borderWidth: 1,
                borderColor: "rgba(15,23,42,0.10)",
                backgroundColor: "#FFFFFF",
                borderRadius: 999,
                paddingHorizontal: 12,
                paddingVertical: 8,
              }}
            >
              <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Complete Pickup")}</Text>
            </Pressable>
            ) : null}
          </View>
        ) : null}
      </View>
    );
  };

  const renderSection = (
    sectionKey: SectionKey,
    heading: string,
    subtitle: string,
    files: CustomerFile[],
    tone: "amber" | "green" | "blue"
  ) => {
    const open = isDetail || openSections[sectionKey];

    const totals = files.reduce(
      (a, f) => {
        a.orders += f.orders.length;
        a.total += f.total;
        a.paid += f.paid;
        a.balance += f.balance;
        return a;
      },
      { orders: 0, total: 0, paid: 0, balance: 0 }
    );

    const query = orderSearch.trim().toLowerCase();
    const filteredFiles = files.filter((file) => {
      if (!query) return true;

      const products = file.orders
        .map((r) => String(r.product_name ?? ""))
        .join(" ");

      const searchable = [
        file.name,
        file.phone,
        products,
      ].join(" ").toLowerCase();

      return searchable.includes(query);
    });

    const pageSize = 10;
    const totalPages = Math.max(1, Math.ceil(filteredFiles.length / pageSize));
    const currentPage = Math.min(orderPage, totalPages);
    const visibleFiles = filteredFiles.slice(
      (currentPage - 1) * pageSize,
      currentPage * pageSize
    );

    return (
      <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 10 }}>
        <Pressable
          onPress={() => setOpenSections((p) => ({ ...p, [sectionKey]: !p[sectionKey] }))}
          style={{ gap: 8 }}
        >
          <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}>
            <Text style={{ color: TEXT, fontWeight: "900", fontSize: 19, flex: 1 }}>{heading}</Text>
            <Text style={{ color: FAINT, fontWeight: "900", fontSize: 20 }}>{open ? "▲" : "▼"}</Text>
          </View>

          <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 19 }}>{subtitle}</Text>

          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
            <MiniPill label={uiText("{p0} Orders", {p0: (totals.orders)})} tone={tone} />
            <MiniPill label={uiText("Paid {p0}", {p0: (money(totals.paid))})} tone="green" />
            <MiniPill label={uiText("Bal {p0}", {p0: (money(totals.balance))})} tone={totals.balance > 0 ? "amber" : "green"} />
          </View>
        </Pressable>

        <TextInput
          value={orderSearch}
          onChangeText={(value) => {
            setOrderSearch(value);
            setOrderPage(1);
          }}
          placeholder={uiText("Search customer, phone or product...")}
          placeholderTextColor={FAINT}
          autoCapitalize="none"
          style={{
            borderWidth: 1,
            borderColor: BORDER,
            backgroundColor: "#F8FAFC",
            borderRadius: 14,
            paddingHorizontal: 14,
            paddingVertical: 12,
            color: TEXT,
            fontSize: 14,
          }}
        />

        {open ? (
          <View style={{ gap: 10 }}>
            {filteredFiles.length === 0 ? (
              <View
                style={{
                  borderWidth: 1,
                  borderColor: BORDER,
                  backgroundColor: "#F8FAFC",
                  borderRadius: 14,
                  padding: 12,
                }}
              >
                <Text style={{ color: MUTED, fontWeight: "800" }}>{uiText("Hakuna taarifa kwenye sehemu hii.")}</Text>
              </View>
            ) : (
              visibleFiles.map((file, index) => {
                const customerKey = `${sectionKey}:${file.key}`;
                const customerOpen = openCustomers[customerKey] ?? false;

                return (
                  <View
                    key={customerKey}
                    style={{
                      borderWidth: 1,
                      borderColor: BORDER,
                      backgroundColor: "#FFFFFF",
                      borderRadius: 16,
                      padding: 12,
                      gap: 8,
                    }}
                  >
                    <Pressable
                      onPress={() =>
                        setOpenCustomers((p) => ({ ...p, [customerKey]: !(p[customerKey] ?? false) }))
                      }
                      style={{ gap: 7 }}
                    >
                      <Text style={{ color: TEXT, fontWeight: "900", fontSize: 18 }}>
                        {(currentPage - 1) * pageSize + index + 1}. {file.name}
                      </Text>
                      <Text style={{ color: MUTED, fontWeight: "900" }}>{uiText("Phone:")}{file.phone}</Text>

                      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
                        <MiniPill label={uiText("{p0} Orders", {p0: (file.orders.length)})} tone={tone} />
                        <MiniPill label={uiText("Total {p0}", {p0: (money(file.total))})} />
                        <MiniPill label={uiText("Bal {p0}", {p0: (money(file.balance))})} tone={file.balance > 0 ? "amber" : "green"} />
                      </View>

                      <Text style={{ color: FAINT, fontWeight: "900" }}>
                        {customerOpen ? uiText("Close customer file ▲") : uiText("Open customer file ▼")}
                      </Text>
                    </Pressable>

                    {customerOpen ? (
                      <View style={{ gap: 8 }}>
                        {file.orders.map((r, i) => renderOrderCompact(r, i))}
                      </View>
                    ) : null}
                  </View>
                );
              })
            )}

            {filteredFiles.length > pageSize ? (
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: 10,
                  paddingTop: 10,
                  borderTopWidth: 1,
                  borderTopColor: BORDER,
                }}
              >
                <Text style={{ color: MUTED, fontWeight: "800", fontSize: 12 }}>
                  {uiText("Page")}{currentPage} {uiText("of")}{totalPages} | {filteredFiles.length} {uiText("customers")}</Text>

                <View style={{ flexDirection: "row", gap: 8 }}>
                  <Pressable
                    disabled={currentPage <= 1}
                    onPress={() => setOrderPage(Math.max(1, currentPage - 1))}
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 10,
                      borderWidth: 1,
                      borderColor: BORDER,
                      borderRadius: 10,
                      opacity: currentPage <= 1 ? 0.4 : 1,
                    }}
                  >
                    <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Previous")}</Text>
                  </Pressable>

                  <Pressable
                    disabled={currentPage >= totalPages}
                    onPress={() => setOrderPage(Math.min(totalPages, currentPage + 1))}
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 10,
                      borderRadius: 10,
                      backgroundColor: "#059669",
                      opacity: currentPage >= totalPages ? 0.4 : 1,
                    }}
                  >
                    <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{uiText("Next")}</Text>
                  </Pressable>
                </View>
              </View>
            ) : null}
          </View>
        ) : null}
      </Card>
    );
  };

  return (
    <Screen scroll contentStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 140 }}>
      <Modal visible={payModalOpen} transparent animationType="fade" onRequestClose={closeAddPayment}>
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.45)",
            justifyContent: "center",
            padding: 18,
          }}
        >
          <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 12 }}>
            <Text style={{ color: TEXT, fontWeight: "900", fontSize: 20 }}>{uiText("Add Payment")}</Text>

            <Text style={{ color: MUTED, fontWeight: "800" }}>
              {uiText("Balance:")}{money(payTarget?.balance_amount)}
            </Text>

            <TextInput
              value={payAmount}
              onChangeText={(v) => setPayAmount(v.replace(/[^\d]/g, ""))}
              placeholder={uiText("Amount")}
              placeholderTextColor={FAINT}
              keyboardType="numeric"
              style={{
                borderWidth: 1,
                borderColor: BORDER,
                borderRadius: 16,
                padding: 12,
                fontWeight: "900",
                color: TEXT,
              }}
            />

            <TextInput
              value={payMethod}
              onChangeText={setPayMethod}
              placeholder={uiText("Method: CASH / MOBILE / BANK")}
              placeholderTextColor={FAINT}
              style={{
                borderWidth: 1,
                borderColor: BORDER,
                borderRadius: 16,
                padding: 12,
                fontWeight: "900",
                color: TEXT,
              }}
            />

            <TextInput
              value={payReference}
              onChangeText={setPayReference}
              placeholder={uiText("Reference optional")}
              placeholderTextColor={FAINT}
              style={{
                borderWidth: 1,
                borderColor: BORDER,
                borderRadius: 16,
                padding: 12,
                fontWeight: "900",
                color: TEXT,
              }}
            />

            <Pressable
              onPress={paySaving ? undefined : submitAddPayment}
              style={{
                backgroundColor: paySaving ? "#94A3B8" : EMERALD,
                borderRadius: 18,
                paddingVertical: 14,
                alignItems: "center",
              }}
            >
              <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>
                {paySaving ? uiText("Saving...") : uiText("Save Payment")}
              </Text>
            </Pressable>

            <Pressable
              onPress={closeAddPayment}
              style={{
                borderWidth: 1,
                borderColor: BORDER,
                borderRadius: 18,
                paddingVertical: 14,
                alignItems: "center",
              }}
            >
              <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Cancel")}</Text>
            </Pressable>
          </Card>
        </View>
      </Modal>
<Modal visible={preModalOpen} transparent animationType="fade" onRequestClose={closePreOrderModal}>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", padding: 18 }}>
          <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 10 }}>
            <Text style={{ color: TEXT, fontWeight: "900", fontSize: 20 }}>{uiText("New Pre Order")}</Text>
            <Text style={{ color: MUTED, fontWeight: "800" }}>
              {uiText("Hii ni kwa mzigo ambao bado haupo dukani. Haitapunguza stock wala kufungua checkout.")}</Text>

            <TextInput value={preCustomerName} onChangeText={onChangePreCustomerName} placeholder={uiText("Customer name")} placeholderTextColor={FAINT} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />

{preCustomerSuggestions.length > 0 ? (
  <View style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, overflow: "hidden" }}>
    {preCustomerSuggestions.map((c) => (
      <Pressable
        key={c.key}
        onPress={() => choosePreCustomer(c)}
        style={{
          paddingHorizontal: 12,
          paddingVertical: 10,
          backgroundColor: "#F8FAFC",
          borderBottomWidth: 1,
          borderBottomColor: BORDER,
        }}
      >
        <Text style={{ color: TEXT, fontWeight: "900" }}>{c.name}</Text>
        <Text style={{ color: MUTED, fontWeight: "800", marginTop: 2 }}>{c.phone || uiText("No phone")}</Text>
      </Pressable>
    ))}
  </View>
) : null}
            <TextInput value={preCustomerPhone} onChangeText={setPreCustomerPhone} placeholder={uiText("Phone number")} placeholderTextColor={FAINT} keyboardType="phone-pad" style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />
            <TextInput value={preProductName} onChangeText={setPreProductName} placeholder={uiText("Bidhaa / design anayohitaji")} placeholderTextColor={FAINT} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />

            <View style={{ flexDirection: "row", gap: 8 }}>
              <TextInput value={preTotalAmount} onChangeText={(v) => setPreTotalAmount(v.replace(/[^\d]/g, ""))} placeholder={uiText("Estimated total")} placeholderTextColor={FAINT} keyboardType="numeric" style={{ flex: 1, borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />
              <TextInput value={prePaidAmount} onChangeText={(v) => setPrePaidAmount(v.replace(/[^\d]/g, ""))} placeholder={uiText("Paid")} placeholderTextColor={FAINT} keyboardType="numeric" style={{ flex: 1, borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />
            </View>

            <TextInput value={prePaymentMethod} onChangeText={setPrePaymentMethod} placeholder={uiText("Method: CASH / MOBILE / BANK")} placeholderTextColor={FAINT} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />
            <TextInput value={preReference} onChangeText={setPreReference} placeholder={uiText("Reference optional")} placeholderTextColor={FAINT} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT }} />
            <TextInput value={preNote} onChangeText={setPreNote} placeholder={uiText("Note optional")} placeholderTextColor={FAINT} multiline style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 16, padding: 12, fontWeight: "900", color: TEXT, minHeight: 70 }} />

            <Pressable onPress={preSaving ? undefined : savePreOrder} style={{ backgroundColor: preSaving ? "#94A3B8" : EMERALD, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}>
              <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{preSaving ? uiText("Saving...") : uiText("Save Pre Order")}</Text>
            </Pressable>

            <Pressable onPress={closePreOrderModal} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}>
              <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Cancel")}</Text>
            </Pressable>
          </Card>
        </View>
      </Modal>
      <Modal visible={pickupConfirmOpen} transparent animationType="fade" onRequestClose={cancelPickupConfirm}>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", padding: 18 }}>
          <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 12 }}>
            <Text style={{ color: TEXT, fontWeight: "900", fontSize: 20 }}>{uiText("Complete Pickup")}</Text>
            <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 20 }}>
              {uiText("Una uhakika mteja amechukua mzigo huu? Mfumo utaunda sale na order itahamia Completed Pickups.")}</Text>

            <Pressable
              onPress={pickupSaving ? undefined : submitCompletePickup}
              style={{ backgroundColor: pickupSaving ? "#94A3B8" : EMERALD, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}
            >
              <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>
                {pickupSaving ? uiText("Completing...") : uiText("Complete Pickup")}
              </Text>
            </Pressable>

            <Pressable onPress={cancelPickupConfirm} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}>
              <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Cancel")}</Text>
            </Pressable>
          </Card>
        </View>
      </Modal>

      <Modal visible={pickupDoneOpen} transparent animationType="fade" onRequestClose={() => setPickupDoneOpen(false)}>
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "center", padding: 18 }}>
          <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 12 }}>
            <Text style={{ color: TEXT, fontWeight: "900", fontSize: 20 }}>{uiText("Success ✅")}</Text>
            <Text style={{ color: MUTED, fontWeight: "800", lineHeight: 20 }}>
              {uiText("Pickup imekamilishwa na sale imeundwa vizuri.")}</Text>

            <Pressable onPress={openPickupReceipt} style={{ backgroundColor: EMERALD, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}>
              <Text style={{ color: "#FFFFFF", fontWeight: "900" }}>{uiText("Open Receipt")}</Text>
            </Pressable>

            <Pressable onPress={() => setPickupDoneOpen(false)} style={{ borderWidth: 1, borderColor: BORDER, borderRadius: 18, paddingVertical: 14, alignItems: "center" }}>
              <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("OK")}</Text>
            </Pressable>
          </Card>
        </View>
      </Modal>


      <View style={{ gap: 14, width: "100%", maxWidth: 1440, alignSelf: "center" }}>
        <Pressable onPress={() => router.back()} style={{ alignSelf: "flex-start", padding: 12 }}>
          <Text style={{ color: TEXT, fontWeight: "900" }}>{uiText("Back")}</Text>
        </Pressable>

        <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER, gap: 8 }}>
          <Text style={{ color: TEXT, fontSize: 25, fontWeight: "900" }}>
            {isDetail
              ? (overviewCards.find((x) => x.slug === category)?.label ?? "Reservations")
              : uiText("Reservations & Orders")}
          </Text>
          <Text style={{ color: MUTED, fontWeight: "800" }}>{String(((params?.storeName ?? orgCtx?.activeStoreName) ?? uiText("Active Store"))).trim()}</Text>
          <Text style={{ color: MUTED }}>
            {isDetail
              ? uiText("Manage customer files and orders in this category.")
              : uiText("Manage reservations, pre-orders, payments and pickups.")}
          </Text>
        </Card>

        {!isDetail ? (
          <>
            {overviewLoading ? <ActivityIndicator color={EMERALD} /> : null}

            {overviewError ? (
              <Card style={{ backgroundColor: "#FFF7ED", borderColor: "#FED7AA", gap: 8 }}>
                <Text style={{ color: "#9A3412" }}>{systemText(overviewError)}</Text>
                <Pressable onPress={() => void loadOverview()}>
                  <Text style={{ color: "#059669", fontWeight: "900" }}>{uiText("Retry")}</Text>
                </Pressable>
              </Card>
            ) : null}


            {!overviewLoading && !overviewError ? (
              <View style={{
                flexDirection: "row",
                flexWrap: "wrap",
                justifyContent: "space-between",
                gap: 8,
              }}>
                {overviewCards.map((card, index) => {
                  const small = !desktopOrders && index >= 2;
                  const paid = card.data.reduce((a, r) => a + Number(r.paid_amount || 0), 0);
                  const balance = card.data.reduce((a, r) => a + Number(r.balance_amount || 0), 0);

                  const fmt = (n: number) => {
                    if (!small) return money(n);
                    if (n >= 1000000) return "TSh " + (n / 1000000).toFixed(2) + "M";
                    if (n >= 1000) return "TSh " + Math.round(n / 1000) + "K";
                    return money(n);
                  };

                  const iconNames = ["calendar-outline", "document-text-outline", "time-outline", "cube-outline", "checkmark-circle-outline"] as const;

                  return (
                    <Pressable
                      key={card.slug}
                      onPress={() => openCategory(card.slug)}
                      style={{
                        width: desktopOrders ? "19%" : index < 2 ? "48%" : "31%",
                        minWidth: 0,
                      }}
                    >
                      <View style={{
                        backgroundColor: card.bg,
                        borderWidth: 1,
                        borderColor: BORDER,
                        borderRadius: 18,
                        padding: small ? 8 : 11,
                        minHeight: desktopOrders ? 145 : small ? 135 : 151,
                        gap: 5,
                      }}>
                        <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                          <View style={{
                            backgroundColor: "#FFFFFF",
                            width: small ? 23 : 29,
                            height: small ? 23 : 29,
                            borderRadius: 99,
                            alignItems: "center",
                            justifyContent: "center",
                          }}>
                            <Ionicons name={iconNames[index]} size={small ? 14 : 18} color={card.color} />
                          </View>
                          <Text numberOfLines={2} style={{
                            color: TEXT,
                            flex: 1,
                            fontWeight: "900",
                            fontSize: small ? 10 : 12,
                          }}>{uiText(card.label)}</Text>
                        </View>

                        <Text style={{ color: TEXT, fontWeight: "900", fontSize: small ? 20 : 25 }}>
                          {card.data.length}
                          <Text style={{ color: MUTED, fontSize: 10 }}> {uiText("orders")}</Text>
                        </Text>

                        <Text style={{ color: MUTED, fontSize: 10 }}>{uiText("Paid")}</Text>
                        <Text numberOfLines={1} adjustsFontSizeToFit style={{
                          color: "#047857",
                          fontWeight: "900",
                          fontSize: small ? 11 : 12,
                        }}>{fmt(paid)}</Text>

                        <Text style={{ color: MUTED, fontSize: 10 }}>{uiText("Balance")}</Text>
                        <Text numberOfLines={1} adjustsFontSizeToFit style={{
                          color: balance > 0 ? "#B45309" : "#047857",
                          fontWeight: "900",
                          fontSize: small ? 11 : 12,
                        }}>{fmt(balance)}</Text>
                      </View>
                    </Pressable>
                  );
                })}
              </View>
            ) : null}


            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable onPress={goPickProducts} style={{ flex: 1, minWidth: 0 }}>
                <View style={{
                  backgroundColor: "#059669",
                  borderRadius: 17,
                  minHeight: 100,
                  padding: 13,
                  justifyContent: "center",
                  gap: 5,
                }}>
                  <Ionicons name="add-circle-outline" size={24} color="#FFFFFF" />
                  <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 14 }}>
                    {uiText("New Reservation")}</Text>
                  <Text style={{ color: "#ECFDF5", fontSize: 11 }}>{uiText("From Sales")}</Text>
                </View>
              </Pressable>

              <Pressable onPress={() => setPreModalOpen(true)} style={{ flex: 1, minWidth: 0 }}>
                <View style={{
                  backgroundColor: "#2563EB",
                  borderRadius: 17,
                  minHeight: 100,
                  padding: 13,
                  justifyContent: "center",
                  gap: 5,
                }}>
                  <Ionicons name="add-circle-outline" size={24} color="#FFFFFF" />
                  <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 14 }}>
                    {uiText("New Order")}</Text>
                  <Text style={{ color: "#EFF6FF", fontSize: 11 }}>{uiText("Create Pre Order")}</Text>
                </View>
              </Pressable>
            </View>


          </>
        ) : (
          <>
            {category === "pre-orders" ? (
              <Pressable onPress={() => setPreModalOpen(true)}>
                <Card style={{ backgroundColor: "#E8F8F2", borderColor: "#A7F3D0" }}>
                  <Text style={{ color: "#047857", fontWeight: "900" }}>{uiText("+ New Pre Order")}</Text>
                </Card>
              </Pressable>
            ) : null}

            {loading ? (
              <ActivityIndicator color={EMERALD} />
            ) : rows.length === 0 ? (
              <Card style={{ backgroundColor: "#FFFFFF", borderColor: BORDER }}>
                <Text style={{ color: MUTED }}>{uiText("No orders found for this store.")}</Text>
              </Card>
            ) : category === "pending" ? (
              renderSection("PENDING", "Pending Payments", "Outstanding payments.", pendingFiles, "amber")
            ) : category === "ready" ? (
              renderSection("READY", "Ready for Pickup", "Fully paid, not picked up.", readyFiles, "blue")
            ) : category === "completed" ? (
              renderSection("COMPLETED", "Completed Pickups", "Pickup history.", completedFiles, "green")
            ) : category === "pre-orders" ? (
              renderSection("PENDING", "Pre Orders", "Pre-order customer files.", allCustomerFiles, "blue")
            ) : (
              renderSection("PENDING", "Reservations", "All reservation customer files.", allCustomerFiles, "green")
            )}
          </>
        )}
      </View>
    </Screen>
  );
}