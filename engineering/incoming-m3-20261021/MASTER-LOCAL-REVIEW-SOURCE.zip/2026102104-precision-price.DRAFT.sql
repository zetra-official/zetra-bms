-- MASTER M3 LOCAL EXTENSION ONLY. Requires 2026102102 and M2; no hosted execution.
BEGIN;
CREATE OR REPLACE FUNCTION incoming_m3.validate_product_line(p public.products,l jsonb) RETURNS void LANGUAGE plpgsql SET search_path=pg_catalog AS $$
DECLARE mode text:=coalesce(l->>'stock_mode','UNIT');entered numeric:=coalesce(l->>'entered_quantity',l->>'quantity')::numeric;computed numeric;
BEGIN
 IF p.name IS DISTINCT FROM l->>'product_name' OR coalesce(p.sku,'') IS DISTINCT FROM coalesce(l->>'sku','') OR coalesce(p.barcode,'') IS DISTINCT FROM coalesce(l->>'barcode','') OR coalesce(nullif(p.unit,''),'pcs') IS DISTINCT FROM l->>'unit' THEN RAISE EXCEPTION 'PRODUCT_IDENTITY_CHANGED';END IF;
 IF coalesce(p.is_precision_product,false) IS DISTINCT FROM coalesce((l->>'is_precision')::boolean,false) THEN RAISE EXCEPTION 'PRECISION_METADATA_CHANGED';END IF;
 IF mode NOT IN ('UNIT','PACK','BOX','CARTON') OR entered<=0 THEN RAISE EXCEPTION 'INVALID_AMOUNT';END IF;
 IF coalesce(p.is_precision_product,false) THEN
  IF p.precision_pack_size IS NULL OR p.precision_pack_size<=0 OR (l->>'pack_size')::numeric IS DISTINCT FROM p.precision_pack_size OR l->>'base_unit' IS DISTINCT FROM p.precision_base_unit THEN RAISE EXCEPTION 'PRECISION_METADATA_CHANGED';END IF;
  IF mode='UNIT' AND NOT p.precision_allow_unit_sales OR mode<>'UNIT' AND NOT p.precision_allow_box_sales THEN RAISE EXCEPTION 'PRECISION_METADATA_CHANGED';END IF;
 ELSIF mode<>'UNIT' THEN RAISE EXCEPTION 'PRECISION_METADATA_CHANGED';END IF;
 computed:=entered*CASE WHEN mode='UNIT' THEN 1 ELSE p.precision_pack_size END;
 IF computed<>(l->>'quantity')::numeric OR computed<>trunc(computed) OR computed>999999999 THEN RAISE EXCEPTION 'UNSUPPORTED_QUANTITY_PRECISION';END IF;
 IF (l->>'unit_cost')::numeric IS DISTINCT FROM p.cost_price THEN RAISE EXCEPTION 'COST_BASIS_POLICY_REQUIRED';END IF;
 IF (l->>'selling_price')::numeric IS DISTINCT FROM p.selling_price THEN
  IF l->>'expected_selling_price' IS NULL THEN RAISE EXCEPTION 'PRICE_CONFIRMATION_REQUIRED';END IF;
  IF (l->>'expected_selling_price')::numeric IS DISTINCT FROM p.selling_price THEN RAISE EXCEPTION 'PRICE_CONFLICT';END IF;
  IF EXISTS(SELECT 1 FROM public.inventory i WHERE i.product_id=p.id AND i.store_id<>p.store_id) THEN RAISE EXCEPTION 'SHARED_PRODUCT_PRICE_POLICY_REQUIRED';END IF;
 END IF;
END $$;
REVOKE ALL ON FUNCTION incoming_m3.validate_product_line(public.products,jsonb) FROM PUBLIC,anon,authenticated;
CREATE OR REPLACE FUNCTION incoming_m3.current_cost(o uuid,s uuid,p uuid) RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT (v->>'unit_cost')::numeric FROM incoming_m3.batches b CROSS JOIN LATERAL jsonb_array_elements(b.payload->'lines') v WHERE b.organization_id=o AND b.store_id=s AND b.actor_id=auth.uid() AND b.transaction_id=txid_current() AND b.state='PROCESSING' AND b.payload->>'mode'='RECEIVE_NOW' AND v->>'product_id'=p::text $$;
REVOKE ALL ON FUNCTION incoming_m3.current_cost(uuid,uuid,uuid) FROM PUBLIC,anon,authenticated;
CREATE OR REPLACE FUNCTION public.m3_incoming_catalog_v1(p_org_id uuid,p_store_id uuid,p_kind text,p_query text DEFAULT '') RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,pg_temp AS $$
DECLARE result jsonb;
BEGIN
 PERFORM security_m2.require_owner(p_org_id,p_store_id);PERFORM security_m2.require_store(p_org_id,p_store_id);
 IF length(coalesce(p_query,''))>100 THEN RAISE EXCEPTION 'INVALID_SEARCH';END IF;
 IF p_kind='CONTEXT' THEN SELECT jsonb_build_object('organization_id',p_org_id,'store_id',s.id,'store_type',s.store_type) INTO result FROM public.stores s WHERE s.id=p_store_id AND s.organization_id=p_org_id AND s.is_active IS TRUE;
 ELSIF p_kind='PRODUCT' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO result FROM(SELECT p.id,p.name,p.sku,p.barcode,p.unit,p.category,p.cost_price::text,p.selling_price::text,p.is_precision_product,p.precision_pack_size::text,p.precision_base_unit,p.precision_sell_mode,p.precision_allow_box_sales,p.precision_allow_unit_sales FROM public.products p WHERE p.organization_id=p_org_id AND p.store_id=p_store_id AND (strpos(lower(p.name),lower(coalesce(p_query,'')))>0 OR strpos(lower(coalesce(p.sku,'')),lower(coalesce(p_query,'')))>0 OR strpos(lower(coalesce(p.barcode,'')),lower(coalesce(p_query,'')))>0) ORDER BY p.name,p.id LIMIT 50)t;
 ELSIF p_kind='SUPPLIER' THEN
  SELECT coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) INTO result FROM(SELECT s.id,s.name,s.phone,s.email,s.address FROM public.suppliers s WHERE s.organization_id=p_org_id AND s.is_active IS TRUE AND (strpos(lower(s.name),lower(coalesce(p_query,'')))>0 OR strpos(lower(coalesce(s.phone,'')),lower(coalesce(p_query,'')))>0 OR strpos(lower(coalesce(s.email,'')),lower(coalesce(p_query,'')))>0) ORDER BY s.name,s.id LIMIT 50)t;
 ELSE RAISE EXCEPTION 'INVALID_SEARCH';END IF;
 RETURN result;
END $$;
CREATE OR REPLACE FUNCTION public.m3_submit_incoming_v1(p_org_id uuid,p_store_id uuid,p_request_id uuid,p_payload jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,pg_temp AS $$
DECLARE b incoming_m3.batches;h text;v_mode text;v_supplier public.suppliers;v_order uuid;v_item uuid;line jsonb;v_product public.products;v_count integer;v_qty numeric;v_cost numeric;v_sell numeric;v_event uuid;v_code text;v_lines jsonb;v_total numeric;v_currency text;v_operator text;v_notifications integer;
BEGIN
 PERFORM security_m2.require_owner(p_org_id,p_store_id);
 IF p_request_id IS NULL OR p_payload IS NULL OR pg_column_size(p_payload)>2000000 OR jsonb_typeof(p_payload)<>'object' THEN RAISE EXCEPTION 'INVALID_DRAFT'; END IF;
 h:=encode(sha256(convert_to(p_payload::text,'UTF8')),'hex');PERFORM pg_advisory_xact_lock(hashtextextended('incoming-m3:'||p_request_id::text,0));
 SELECT * INTO b FROM incoming_m3.batches WHERE request_id=p_request_id FOR UPDATE;
 IF FOUND THEN
  IF b.organization_id<>p_org_id OR b.store_id<>p_store_id OR b.actor_id<>auth.uid() OR b.payload_hash<>h THEN RAISE EXCEPTION 'REQUEST_CONFLICT';END IF;
  IF b.state NOT IN ('SAVED','RECEIVED') THEN RAISE EXCEPTION 'SUBMISSION_UNCERTAIN';END IF;
  RETURN jsonb_build_object('orderId',b.order_id,'eventId',b.event_id,'status',b.state);
 END IF;
 PERFORM security_m2.require_store(p_org_id,p_store_id);
 IF NOT EXISTS(SELECT 1 FROM public.stores s WHERE s.id=p_store_id AND s.organization_id=p_org_id AND s.is_active IS TRUE AND s.store_type IN ('STANDARD','PRECISION_RETAIL')) THEN RAISE EXCEPTION 'STORE_TYPE_NOT_CERTIFIED'; END IF;
 -- Currency is verified from canonical authority. Unconfirmed legacy organizations remain TZS; authority failures do not become a fabricated confirmation.
 BEGIN
  SELECT public.get_org_accounting_currency_v1(p_org_id)->>'currency' INTO v_currency;
 EXCEPTION WHEN OTHERS THEN
  IF SQLERRM='ACCOUNTING_CURRENCY_UNCONFIRMED' THEN v_currency:='TZS';ELSE RAISE EXCEPTION 'ACCOUNTING_AUTHORITY_UNAVAILABLE';END IF;
 END;
 IF v_currency IS DISTINCT FROM 'TZS' OR p_payload->>'currency' IS DISTINCT FROM 'TZS' THEN RAISE EXCEPTION 'NATIVE_FINANCIAL_POSTING_NOT_CERTIFIED'; END IF;
 v_mode:=p_payload->>'mode';IF v_mode NOT IN ('SAVE_ORDER','RECEIVE_NOW') OR v_mode IS NULL THEN RAISE EXCEPTION 'INVALID_DRAFT';END IF;
 IF p_payload ?| ARRAY['payment','payments','paid_amount','payable','settlement','funding','payment_channel'] THEN RAISE EXCEPTION 'FINANCIAL_INTEGRATION_BLOCKED';END IF;
 IF v_mode='RECEIVE_NOW' AND (p_payload->>'purpose' IS DISTINCT FROM 'EXISTING_NON_CREDIT_STOCK' OR p_payload->>'non_credit_confirmed' IS DISTINCT FROM 'true') THEN RAISE EXCEPTION 'NON_CREDIT_REQUIRED';END IF;
 IF jsonb_typeof(p_payload->'lines') IS DISTINCT FROM 'array' OR jsonb_array_length(p_payload->'lines') NOT BETWEEN 1 AND 500 THEN RAISE EXCEPTION 'LINE_LIMIT';END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended('incoming-store:'||p_store_id::text,0));
 IF nullif(p_payload->>'supplier_id','') IS NOT NULL THEN
  SELECT * INTO v_supplier FROM public.suppliers s WHERE s.id=(p_payload->>'supplier_id')::uuid AND s.organization_id=p_org_id AND s.is_active IS TRUE FOR SHARE;
  IF v_supplier.id IS NULL THEN RAISE EXCEPTION 'SUPPLIER_REQUIRED';END IF;
  IF (SELECT count(*) FROM public.suppliers s WHERE s.organization_id=p_org_id AND s.is_active IS TRUE AND lower(btrim(s.name))=lower(btrim(v_supplier.name)))<>1 THEN RAISE EXCEPTION 'AMBIGUOUS_SUPPLIER';END IF;
 ELSIF v_mode='SAVE_ORDER' THEN RAISE EXCEPTION 'SUPPLIER_REQUIRED';END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(p_payload->'lines') a GROUP BY a->>'product_id' HAVING nullif(a->>'product_id','') IS NOT NULL AND count(*)>1) THEN RAISE EXCEPTION 'DUPLICATE_PRODUCT';END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(p_payload->'lines') a CROSS JOIN LATERAL(VALUES('sku:'||nullif(btrim(a->>'sku'),'')),('barcode:'||nullif(btrim(a->>'barcode'),''))) k(v) WHERE k.v IS NOT NULL GROUP BY k.v HAVING count(*)>1) THEN RAISE EXCEPTION 'DUPLICATE_PRODUCT';END IF;
 -- Validate every line before creating canonical records. New immediate receipts must reference registered product identities.
 FOR line IN SELECT * FROM jsonb_array_elements(p_payload->'lines') LOOP
  IF nullif(btrim(line->>'product_name'),'') IS NULL OR length(line->>'product_name')>500 OR nullif(btrim(line->>'unit'),'') IS NULL THEN RAISE EXCEPTION 'PRODUCT_REQUIRED';END IF;
  IF coalesce(line->>'quantity','')!~'^[1-9][0-9]{0,8}$' THEN RAISE EXCEPTION 'WHOLE_QUANTITY_REQUIRED';END IF;
  IF coalesce(line->>'unit_cost','')!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' OR coalesce(line->>'selling_price','')!~'^(0|[1-9][0-9]{0,11})(\.[0-9]{1,6})?$' THEN RAISE EXCEPTION 'INVALID_AMOUNT';END IF;
  IF v_mode='SAVE_ORDER' AND (scale((line->>'unit_cost')::numeric)>2 OR scale((line->>'selling_price')::numeric)>2) THEN RAISE EXCEPTION 'CANONICAL_PRECISION_REQUIRED';END IF;
  v_qty:=(line->>'quantity')::numeric;v_cost:=(line->>'unit_cost')::numeric;v_sell:=(line->>'selling_price')::numeric;IF v_cost<=0 THEN RAISE EXCEPTION 'INVALID_AMOUNT';END IF;
  v_product:=NULL;
  IF nullif(line->>'product_id','') IS NOT NULL THEN
   SELECT * INTO v_product FROM public.products p WHERE p.id=(line->>'product_id')::uuid AND p.organization_id=p_org_id AND p.store_id=p_store_id;
   IF v_product.id IS NULL THEN RAISE EXCEPTION 'PRODUCT_SCOPE_REQUIRED';END IF;
   IF v_mode='RECEIVE_NOW' AND ((line->>'unit_cost')::numeric IS DISTINCT FROM v_product.cost_price OR (line->>'selling_price')::numeric IS DISTINCT FROM v_product.selling_price) THEN PERFORM incoming_m3.validate_product_line(v_product,line);END IF;
   IF v_mode='RECEIVE_NOW' THEN PERFORM incoming_m3.validate_product_line(v_product,line);END IF;
   IF coalesce(nullif(v_product.unit,''),'pcs') IS DISTINCT FROM line->>'unit' THEN RAISE EXCEPTION 'PRODUCT_UNIT_CHANGED';END IF;
   IF coalesce(v_product.sku,'')<>coalesce(line->>'sku','') OR coalesce(v_product.barcode,'')<>coalesce(line->>'barcode','') OR v_product.name<>line->>'product_name' THEN RAISE EXCEPTION 'PRODUCT_IDENTITY_CHANGED';END IF;
  ELSIF v_mode='RECEIVE_NOW' THEN RAISE EXCEPTION 'REGISTER_PRODUCT_FIRST';
  ELSIF nullif(btrim(line->>'sku'),'') IS NULL AND nullif(btrim(line->>'barcode'),'') IS NULL THEN RAISE EXCEPTION 'PRODUCT_REQUIRED';
  END IF;
 END LOOP;
 INSERT INTO incoming_m3.batches(request_id,organization_id,store_id,actor_id,payload_hash,payload,state,transaction_id,event_id) VALUES(p_request_id,p_org_id,p_store_id,auth.uid(),h,p_payload,'PROCESSING',txid_current(),CASE WHEN v_mode='RECEIVE_NOW' THEN gen_random_uuid() ELSE NULL END) RETURNING event_id INTO v_event;
 IF v_mode='SAVE_ORDER' THEN
  v_order:=public.create_inbound_stock_order_v1(p_org_id,p_store_id,v_supplier.name,p_payload->>'source_country',p_payload->>'source_city',p_payload->>'destination_name',p_payload->>'invoice_number',p_payload->>'tracking_number',nullif(p_payload->>'expected_arrival_date','')::date,p_payload->>'note');
  IF (SELECT supplier_id FROM public.inbound_stock_orders WHERE id=v_order)<>v_supplier.id THEN RAISE EXCEPTION 'SUPPLIER_IDENTITY_CHANGED';END IF;
  FOR line IN SELECT * FROM jsonb_array_elements(p_payload->'lines') LOOP
   v_item:=public.add_inbound_stock_item_v1(v_order,line->>'product_name',line->>'sku',line->>'unit',line->>'category',line->>'barcode',(line->>'quantity')::numeric,(line->>'unit_cost')::numeric,(line->>'selling_price')::numeric,line->>'note');
   IF nullif(line->>'product_id','') IS NOT NULL THEN UPDATE public.inbound_stock_items SET product_id=(line->>'product_id')::uuid,is_new_product=false WHERE id=v_item;END IF;
  END LOOP;
  UPDATE incoming_m3.batches SET state='SAVED',order_id=v_order WHERE request_id=p_request_id;
  RETURN jsonb_build_object('orderId',v_order,'eventId',NULL,'status','SAVED');
 END IF;
 -- Acquire inventory then product locks, matching the canonical adjustment engine.
 FOR line IN SELECT v FROM jsonb_array_elements(p_payload->'lines') v ORDER BY v->>'product_id' LOOP
  INSERT INTO public.inventory(organization_id,store_id,product_id,qty) VALUES(p_org_id,p_store_id,(line->>'product_id')::uuid,0) ON CONFLICT(store_id,product_id) DO NOTHING;
  PERFORM 1 FROM public.inventory WHERE store_id=p_store_id AND product_id=(line->>'product_id')::uuid FOR UPDATE;
  SELECT * INTO v_product FROM public.products p WHERE p.id=(line->>'product_id')::uuid AND p.organization_id=p_org_id AND p.store_id=p_store_id FOR UPDATE;
  IF v_product.id IS NULL THEN RAISE EXCEPTION 'PRODUCT_SCOPE_REQUIRED';END IF;
  PERFORM incoming_m3.validate_product_line(v_product,line);
  IF EXISTS(SELECT 1 FROM public.inventory i WHERE i.store_id=p_store_id AND i.product_id=v_product.id AND (i.qty<>trunc(i.qty) OR i.qty+(line->>'quantity')::numeric>999999999)) THEN RAISE EXCEPTION 'WHOLE_QUANTITY_REQUIRED';END IF;
 END LOOP;
 IF (SELECT sum((v->>'quantity')::numeric) FROM jsonb_array_elements(p_payload->'lines') v)>2147483647 THEN RAISE EXCEPTION 'WHOLE_QUANTITY_REQUIRED';END IF;
 FOR line IN SELECT * FROM jsonb_array_elements(p_payload->'lines') LOOP
  PERFORM public.adjust_stock(p_store_id,(line->>'product_id')::uuid,(line->>'quantity')::numeric,'ADD','M3 non-credit receipt '||p_request_id::text,NULL::date,v_supplier.name,p_payload->>'invoice_number',30,'UNIT');
  UPDATE public.products SET selling_price=(line->>'selling_price')::numeric,updated_at=now() WHERE id=(line->>'product_id')::uuid AND organization_id=p_org_id AND store_id=p_store_id AND selling_price IS DISTINCT FROM (line->>'selling_price')::numeric;
 END LOOP;
 SELECT count(*) INTO v_count FROM public.stock_movements m WHERE m.event_id=v_event AND m.organization_id=p_org_id AND m.store_id=p_store_id AND m.supplier_id IS NOT DISTINCT FROM v_supplier.id;
 IF v_count<>jsonb_array_length(p_payload->'lines') THEN RAISE EXCEPTION 'RECEIVING_EVENT_MISMATCH';END IF;
 SELECT jsonb_agg(jsonb_build_object('product_id',v->>'product_id','product_name',v->>'product_name','sku',v->>'sku','barcode',v->>'barcode','unit',CASE WHEN (v->>'is_precision')::boolean THEN v->>'base_unit' ELSE v->>'unit' END,'package_unit',v->>'unit','pack_size',v->>'pack_size','entered_quantity',coalesce(v->>'entered_quantity',v->>'quantity'),'stock_mode',coalesce(v->>'stock_mode','UNIT'),'previous_selling_price',coalesce(v->>'expected_selling_price',v->>'selling_price'),'qty',v->>'quantity','selling_price',v->>'selling_price','unit_cost',v->>'unit_cost','total_cost',((v->>'quantity')::numeric*(v->>'unit_cost')::numeric)::text,'note',v->>'note') ORDER BY ord),sum((v->>'quantity')::numeric*(v->>'unit_cost')::numeric) INTO v_lines,v_total FROM jsonb_array_elements(p_payload->'lines') WITH ORDINALITY z(v,ord);
 v_code:='RCV-'||upper(replace(p_request_id::text,'-',''));v_operator:=auth.uid()::text;
 UPDATE incoming_m3.batches SET state='RECEIVED',receipt=jsonb_build_object('event_id',v_event,'receipt_reference',v_code,'organization_id',p_org_id,'organization_name',(SELECT name FROM public.organizations WHERE id=p_org_id),'store_id',p_store_id,'store_name',(SELECT name FROM public.stores WHERE id=p_store_id),'supplier_id',v_supplier.id,'supplier_name',v_supplier.name,'operator_id',auth.uid(),'operator',v_operator,'created_at',now(),'currency','TZS','line_count',jsonb_array_length(v_lines),'lines',v_lines,'total_cost',v_total::text,'purpose','EXISTING_NON_CREDIT_STOCK','note',p_payload->>'note') WHERE request_id=p_request_id;
 INSERT INTO public.notifications(organization_id,store_id,event_id,event_type,title,body,items,total_units,total_skus,actor_user_id,actor_name,created_by)
 VALUES(p_org_id,p_store_id,v_event,'STOCK_IN',v_code,jsonb_build_object('source','incoming_m3','event_id',v_event),
 (SELECT jsonb_agg(jsonb_build_object('product_id',x->'product_id','product_name',x->'product_name','sku',x->'sku','unit',x->'unit','qty',x->'qty')) FROM jsonb_array_elements(v_lines) x),
 (SELECT sum((x->>'qty')::numeric)::integer FROM jsonb_array_elements(v_lines) x),jsonb_array_length(v_lines),auth.uid(),v_operator,auth.uid());
 RETURN jsonb_build_object('orderId',NULL,'eventId',v_event,'status','RECEIVED');
END $$;
CREATE OR REPLACE FUNCTION public.adjust_stock(p_store_id uuid, p_product_id uuid, p_amount numeric, p_mode text, p_note text DEFAULT NULL::text, p_expiry_date date DEFAULT NULL::date, p_supplier_name text DEFAULT NULL::text, p_supplier_invoice_no text DEFAULT NULL::text, p_expiry_alert_days integer DEFAULT 30, p_precision_stock_mode text DEFAULT 'UNIT'::text)
 RETURNS TABLE(new_qty numeric)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$

declare

  v_mode text;

  v_org_id uuid;

  v_store_type text := 'STANDARD';



  v_current_qty numeric(12,3) := 0;

  v_next_qty numeric(12,3) := 0;

  v_effective_amount numeric(12,3) := 0;



  v_product_exists boolean := false;



  v_supplier_id uuid := null;

  v_supplier_name text := null;

  v_supplier_invoice_no text := null;



  v_batch_id uuid;



  v_is_precision boolean := false;

  v_pack_size numeric(12,3) := null;

  v_precision_mode text := 'UNIT';

begin

  if auth.uid() is null then

    raise exception 'Not authenticated';

  end if;



  v_mode := upper(trim(coalesce(p_mode, '')));



  if v_mode = 'ADD' then

    v_mode := 'IN';

  elsif v_mode = 'REDUCE' then

    v_mode := 'OUT';

  end if;



  if v_mode not in ('IN', 'OUT') then

    raise exception 'Invalid mode';

  end if;



  if p_amount is null or p_amount < 0 then

    raise exception 'Invalid amount';

  end if;



  perform public.ensure_my_store_access(p_store_id);



  select

    s.organization_id,

    coalesce(s.store_type, 'STANDARD')

  into

    v_org_id,

    v_store_type

  from public.stores s

  where s.id = p_store_id

  limit 1;



  if v_org_id is null then

    raise exception 'Store not found';

  end if;
 PERFORM pg_advisory_xact_lock(hashtextextended('incoming-store:'||p_store_id::text,0));



  select exists (

    select 1

    from public.products p

    where p.id = p_product_id

      and p.organization_id = v_org_id

  )

  into v_product_exists;



  if not v_product_exists then

    raise exception 'Product not found in this organization';

  end if;



  select

    coalesce(p.is_precision_product, false),

    p.precision_pack_size

  into

    v_is_precision,

    v_pack_size

  from public.products p

  where p.id = p_product_id

    and p.organization_id = v_org_id

  limit 1;



  v_precision_mode := upper(trim(coalesce(p_precision_stock_mode, 'UNIT')));



  if v_precision_mode not in ('UNIT', 'PACK', 'BOX', 'CARTON') then

    v_precision_mode := 'UNIT';

  end if;



  -- Standard products: old behavior remains.

  -- Precision products: PACK/BOX/CARTON converts to base units.

  if v_is_precision

     and coalesce(v_pack_size, 0) > 0

     and v_precision_mode in ('PACK', 'BOX', 'CARTON') then

    v_effective_amount := p_amount * v_pack_size;

  else

    v_effective_amount := p_amount;

  end if;



  v_effective_amount := v_effective_amount::numeric(12,3);



  v_supplier_name := nullif(trim(coalesce(p_supplier_name, '')), '');

  v_supplier_invoice_no := nullif(trim(coalesce(p_supplier_invoice_no, '')), '');



  IF incoming_m3.active_batch(v_org_id,p_store_id) THEN
 v_supplier_id:=incoming_m3.current_supplier(v_org_id,p_store_id);
 IF v_supplier_id IS NOT NULL THEN
  SELECT name INTO v_supplier_name FROM public.suppliers WHERE id=v_supplier_id AND organization_id=v_org_id AND is_active IS TRUE;
  IF v_supplier_name IS NULL THEN RAISE EXCEPTION 'SUPPLIER_REQUIRED';END IF;
 END IF;
ELSIF v_mode='IN' AND v_supplier_name IS NOT NULL THEN

    insert into public.suppliers (

      organization_id,

      name,

      created_by,

      created_at,

      updated_at

    )

    values (

      v_org_id,

      v_supplier_name,

      auth.uid(),

      now(),

      now()

    )

    on conflict (organization_id, name)

    do update set updated_at = now()

    returning id into v_supplier_id;

  end if;



  insert into public.inventory (

    organization_id,

    store_id,

    product_id,

    qty

  )

  values (

    v_org_id,

    p_store_id,

    p_product_id,

    0

  )

  on conflict (store_id, product_id)

  do nothing;



  select coalesce(i.qty, 0)::numeric(12,3)

  into v_current_qty

  from public.inventory i

  where i.store_id = p_store_id

    and i.product_id = p_product_id

  for update;



  if v_mode = 'OUT' then

    v_next_qty := v_current_qty - v_effective_amount;



    if v_next_qty < 0 then

      raise exception 'Insufficient stock. Current=% , Needed=%',

        v_current_qty,

        v_effective_amount;

    end if;

  else

    v_next_qty := v_current_qty + v_effective_amount;

  end if;



  update public.inventory

  set

    qty = v_next_qty,

    organization_id = v_org_id,

    updated_at = now()

  where store_id = p_store_id

    and product_id = p_product_id;



  update public.products

  set

    qty_on_hand = v_next_qty,

    updated_at = now()

  where id = p_product_id

    and organization_id = v_org_id

    and store_id = p_store_id;



  if not found then

    update public.products

    set

      qty_on_hand = v_next_qty,

      updated_at = now()

    where id = p_product_id

      and organization_id = v_org_id

      and store_id is null;

  end if;



  if v_mode = 'IN'

     and p_expiry_date is not null

     and v_effective_amount > 0 then



    insert into public.stock_batches (

      organization_id,

      store_id,

      product_id,

      received_qty,

      remaining_qty,

      expiry_date,

      expiry_alert_days,

      created_by,

      created_at,

      updated_at

    )

    values (

      v_org_id,

      p_store_id,

      p_product_id,

      v_effective_amount::integer,

      v_effective_amount::integer,

      p_expiry_date,

      greatest(coalesce(p_expiry_alert_days, 30), 1),

      auth.uid(),

      now(),

      now()

    )

    returning id into v_batch_id;

  end if;



  if v_effective_amount > 0 then

    insert into public.stock_movements (

      organization_id,

      store_id,

      product_id,

      mode,

      amount,

      note,

      supplier_id,

      supplier_name,

      supplier_invoice_no,

      created_by,

      created_at, event_id,unit_cost,total_cost)

    values (

      v_org_id,

      p_store_id,

      p_product_id,

      case when v_mode = 'IN' then 'ADD' else 'REDUCE' end,

      v_effective_amount,

      p_note,

      v_supplier_id,

      v_supplier_name,

      v_supplier_invoice_no,

      auth.uid(),

      now(), coalesce(incoming_m3.current_event(v_org_id,p_store_id),gen_random_uuid()),coalesce(incoming_m3.current_cost(v_org_id,p_store_id,p_product_id),0),coalesce(incoming_m3.current_cost(v_org_id,p_store_id,p_product_id),0)*v_effective_amount);

  end if;



  return query

  select v_next_qty;

end;

$function$;
CREATE OR REPLACE FUNCTION public.receive_inbound_stock_partial_v1(p_order_id uuid, p_receipts jsonb)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog', 'public', 'pg_temp'
AS $function$
declare
  v_org_id uuid;
  v_store_id uuid;
  v_supplier_id uuid;
  v_supplier_name text;
  v_order_code text;
  v_product_id uuid;
  v_all_received boolean;
  v_goods_total numeric := 0;
  v_paid_total numeric := 0;
  v_balance numeric := 0;
  v_existing_debt_id uuid;
  v_current_qty numeric := 0;
  v_next_qty numeric := 0;

  -- One canonical business event for THIS receiving execution.
  v_receive_event_id uuid := gen_random_uuid();

  x jsonb;
  r record;
  v_receive_qty numeric;
  v_remaining numeric;
BEGIN
PERFORM security_m2.require_store((SELECT o.organization_id FROM public.inbound_stock_orders o WHERE o.id=p_order_id),(SELECT o.store_id FROM public.inbound_stock_orders o WHERE o.id=p_order_id));
IF EXISTS(SELECT 1 FROM public.inbound_stock_orders o WHERE o.id=p_order_id AND (NOT EXISTS(SELECT 1 FROM public.stores s WHERE s.id=o.store_id AND s.organization_id=o.organization_id) OR o.supplier_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM public.suppliers s WHERE s.id=o.supplier_id AND s.organization_id=o.organization_id) OR EXISTS(SELECT 1 FROM public.inbound_stock_items i LEFT JOIN public.products p ON p.id=i.product_id WHERE i.inbound_order_id=o.id AND (i.organization_id IS DISTINCT FROM o.organization_id OR i.product_id IS NOT NULL AND p.organization_id IS DISTINCT FROM o.organization_id)))) THEN RAISE EXCEPTION USING ERRCODE='42501',MESSAGE='INBOUND_EXISTING_SCOPE_MISMATCH'; END IF;
PERFORM 1 FROM public.inbound_stock_orders o WHERE o.id=p_order_id FOR UPDATE;
IF EXISTS(SELECT 1 FROM incoming_m3.batches b WHERE b.order_id=p_order_id AND EXISTS(SELECT 1 FROM jsonb_array_elements(b.payload->'lines') l WHERE (l->>'is_precision')::boolean IS TRUE OR l->>'expected_selling_price' IS NOT NULL AND (l->>'expected_selling_price')::numeric IS DISTINCT FROM (l->>'selling_price')::numeric)) THEN RAISE EXCEPTION 'M3_ORDER_RECEIVING_CONTRACT_REQUIRED';END IF;
IF EXISTS(SELECT 1 FROM incoming_m3.batches b WHERE b.order_id=p_order_id AND (EXISTS(SELECT 1 FROM public.stores st WHERE st.id=b.store_id AND st.store_type='PRECISION_RETAIL') OR EXISTS(SELECT 1 FROM jsonb_array_elements(b.payload->'lines') l JOIN public.products pp ON pp.id=(l->>'product_id')::uuid WHERE pp.cost_price IS DISTINCT FROM (l->>'unit_cost')::numeric))) THEN RAISE EXCEPTION 'M3_ORDER_RECEIVING_CONTRACT_REQUIRED';END IF;

IF EXISTS(SELECT 1 FROM public.inbound_stock_orders o WHERE o.id=p_order_id AND (o.deleted_at IS NOT NULL OR o.status='CANCELLED')) THEN RAISE EXCEPTION 'INBOUND_ORDER_CLOSED'; END IF;
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select
    organization_id,
    store_id,
    supplier_id,
    supplier_name,
    order_code
  into
    v_org_id,
    v_store_id,
    v_supplier_id,
    v_supplier_name,
    v_order_code
  from public.inbound_stock_orders
  where id = p_order_id;

  if v_org_id is null then
    raise exception 'Invalid inbound order';
  end if;

  if v_store_id is null then
    raise exception 'Order has no store selected';
  end if;

  PERFORM pg_advisory_xact_lock(hashtextextended('incoming-store:'||v_store_id::text,0));
 if v_supplier_id is null then
    raise exception 'Supplier is not linked to this inbound order';
  end if;

  if not exists (
    select 1
    from public.org_memberships m
    where m.organization_id = v_org_id
      and m.user_id = auth.uid()
      and m.role in ('owner','admin')
      and coalesce(m.is_active,true)=true
  ) then
    raise exception 'Access denied';
  end if;

  if exists (
    select 1
    from public.inbound_stock_orders
    where id = p_order_id
      and status = 'RECEIVED'
  ) then
    raise exception 'This inbound order is already fully received';
  end if;

  for x in
    select *
    from jsonb_array_elements(coalesce(p_receipts, '[]'::jsonb))
  loop

    v_receive_qty := coalesce((x->>'qty')::numeric, 0);

    if v_receive_qty <= 0 then
      continue;
    end if;

    select *
    into r
    from public.inbound_stock_items
    where id = (x->>'item_id')::uuid
      and inbound_order_id = p_order_id;

    if r.id is null then
      raise exception 'Invalid inbound item';
    end if;

    v_remaining :=
      coalesce(r.qty_ordered,0) -
      coalesce(r.qty_received,0);

    if v_receive_qty > v_remaining then
      raise exception 'Receive qty cannot exceed remaining qty';
    end if;

    v_product_id := null;

    select p.id
    into v_product_id
    from public.products p
    where p.organization_id = v_org_id
      and p.store_id = v_store_id
      and (
        (
          r.barcode is not null
          and r.barcode <> ''
          and p.barcode = r.barcode
        )
        or
        (
          r.sku is not null
          and r.sku <> ''
          and p.sku = r.sku
        )
      )
    limit 1;

    if v_product_id is null then

      insert into public.products (
        organization_id,
        store_id,
        name,
        sku,
        barcode,
        unit,
        category,
        cost_price,
        selling_price,
        qty_on_hand,
        created_by
      )
      values (
        v_org_id,
        v_store_id,
        coalesce(
          nullif(trim(r.product_name),''),
          'Unnamed Product'
        ),
        nullif(trim(coalesce(r.sku,'')),''),
        nullif(trim(coalesce(r.barcode,'')),''),
        coalesce(
          nullif(trim(coalesce(r.unit,'')),''),
          'pcs'
        ),
        nullif(trim(coalesce(r.category,'')),''),
        coalesce(r.unit_cost,0),
        coalesce(r.proposed_sell_price,0),
        0,
        auth.uid()
      )
      returning id into v_product_id;

    end if;

    insert into public.inventory (
      organization_id,
      store_id,
      product_id,
      qty
    )
    values (
      v_org_id,
      v_store_id,
      v_product_id,
      0
    )
    on conflict (store_id, product_id)
    do nothing;

    select coalesce(i.qty, 0)
    into v_current_qty
    from public.inventory i
    where i.store_id = v_store_id
      and i.product_id = v_product_id
    for update;

    v_next_qty :=
      coalesce(v_current_qty, 0) +
      v_receive_qty;

    update public.inventory
    set
      qty = v_next_qty,
      organization_id = v_org_id,
      updated_at = now()
    where store_id = v_store_id
      and product_id = v_product_id;

    update public.products
    set
      qty_on_hand = v_next_qty,
      unit = coalesce(
        nullif(trim(coalesce(r.unit,'')),''),
        unit
      ),
      category = coalesce(
        nullif(trim(coalesce(r.category,'')),''),
        category
      ),
      cost_price = coalesce(
        nullif(r.unit_cost,0),
        cost_price
      ),
      selling_price = coalesce(
        nullif(r.proposed_sell_price,0),
        selling_price
      ),
      updated_at = now()
    where id = v_product_id;

    -- ========================================================
    -- IMPORTANT CHANGE:
    -- Every movement produced by THIS receive execution gets
    -- the SAME event_id.
    -- ========================================================

    insert into public.stock_movements (
      organization_id,
      store_id,
      product_id,
      mode,
      amount,
      note,
      created_by,
      supplier_id,
      supplier_name,
      supplier_invoice_no,
      event_id
    )
    values (
      v_org_id,
      v_store_id,
      v_product_id,
      'ADD',
      v_receive_qty,
      'Partial received from inbound order ' ||
        coalesce(v_order_code, p_order_id::text),
      auth.uid(),
      v_supplier_id,
      v_supplier_name,
      v_order_code,
      v_receive_event_id
    );

    update public.inbound_stock_items
    set
      product_id = v_product_id,
      qty_received =
        coalesce(qty_received,0) +
        v_receive_qty,
      updated_at = now()
    where id = r.id;

  end loop;

  select not exists (
    select 1
    from public.inbound_stock_items
    where inbound_order_id = p_order_id
      and coalesce(qty_received,0) <
          coalesce(qty_ordered,0)
  )
  into v_all_received;

  select
    coalesce(total_goods_value,0),
    coalesce(total_paid_amount,0),
    coalesce(total_balance_amount,0)
  into
    v_goods_total,
    v_paid_total,
    v_balance
  from public.inbound_stock_orders
  where id = p_order_id;

  if coalesce(v_balance,0) <= 0 then
    v_balance :=
      greatest(
        coalesce(v_goods_total,0) -
        coalesce(v_paid_total,0),
        0
      );
  end if;

  select id
  into v_existing_debt_id
  from public.business_debts
  where organization_id = v_org_id
    and supplier_id = v_supplier_id
    and note ilike '%' || p_order_id::text || '%'
  limit 1;

  if v_balance > 0
     and v_existing_debt_id is null then

    insert into public.business_debts (
      organization_id,
      store_id,
      debt_scope,
      lender_name,
      lender_phone,
      debt_type,
      principal_amount,
      paid_amount,
      purpose,
      note,
      debt_date,
      status,
      supplier_id,
      created_by
    )
    values (
      v_org_id,
      v_store_id,
      'STORE',
      coalesce(
        nullif(trim(v_supplier_name),''),
        'Supplier'
      ),
      null,
      'SUPPLIER',
      v_balance,
      0,
      'Inbound stock balance: ' ||
        coalesce(v_order_code, p_order_id::text),
      'Auto-created from inbound order. INBOUND_ORDER_ID:' ||
        p_order_id::text,
      current_date,
      'OPEN',
      v_supplier_id,
      auth.uid()
    );

  end if;

  update public.inbound_stock_orders
  set
    status =
      case
        when v_all_received
          then 'RECEIVED'
        else 'PARTIAL_RECEIVED'
      end,

    received_at =
      case
        when v_all_received
          then coalesce(received_at, now())
        else received_at
      end,

    updated_at = now()

  where id = p_order_id;

  return true;
end;
$function$;
NOTIFY pgrst,'reload schema';
COMMIT;
