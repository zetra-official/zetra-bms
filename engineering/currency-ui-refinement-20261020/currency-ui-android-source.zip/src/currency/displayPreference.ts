import {isSelectableCurrency} from './metadata';
export type PreferenceStorage={getString:(key:string)=>Promise<string|null>;setString:(key:string,value:string|null)=>Promise<unknown>};
export const displayPreferenceKey=(actor:string,organization:string)=>actor&&organization?`zetra_display_currency_v2:${encodeURIComponent(actor)}:${encodeURIComponent(organization)}`:'';
/** Display preferences only. Unscoped legacy values are preserved, never attributed to another user. */
export class ScopedDisplayPreference{
 private state={key:'',currency:null as string|null,ready:false,error:false};private epoch=0;private listeners=new Set<()=>void>();private writes=new Map<string,Promise<unknown>>();
 constructor(private storage:PreferenceStorage){}
 getSnapshot=()=>this.state;
 subscribe=(listener:()=>void)=>{this.listeners.add(listener);return()=>{this.listeners.delete(listener)}};
 private publish(next:typeof this.state){this.state=next;this.listeners.forEach(fn=>fn())}
 activate(key:string){
  const epoch=++this.epoch;this.publish({key,currency:null,ready:!key,error:false});if(!key)return;
  void (this.writes.get(key)??Promise.resolve()).catch(()=>{}).then(()=>this.storage.getString(key)).then(value=>{if(epoch===this.epoch)this.publish({key,currency:value&&isSelectableCurrency(value)?value:null,ready:true,error:false})},()=>{if(epoch===this.epoch)this.publish({key,currency:null,ready:true,error:true})});
 }
 select(key:string,value:string|null){
  const code=value?.trim().toUpperCase()||null;if(!key||this.state.key!==key||code&&!isSelectableCurrency(code))return;
  const epoch=++this.epoch;this.publish({key,currency:code,ready:true,error:false});
  const prior=this.writes.get(key)??Promise.resolve();
  const next=prior.catch(()=>{}).then(()=>this.storage.setString(key,code)).catch(()=>{if(this.state.key===key&&this.epoch===epoch)this.publish({...this.state,error:true})});this.writes.set(key,next);
 }
}
