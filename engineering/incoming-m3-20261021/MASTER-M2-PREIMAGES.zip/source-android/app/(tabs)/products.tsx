import {PreferredRateNote} from '@/src/currency/PreferredDisplay';
import {usePreferredDisplayMoney} from '@/src/currency/PreferredDisplay';
import {indexCatalog, searchCatalog} from "@/src/search/catalogSearch";
import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
import {useCommonText} from "@/src/i18n/useCommonText";
// MOBILE_PRODUCT_COMPACT_V3
﻿// app/(tabs)/products.tsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  Image,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as ImagePicker from "expo-image-picker";

import {
  useFocusEffect,
  useLocalSearchParams,
  useRouter,
} from "expo-router";
import { useOrg } from "../../src/context/OrgContext";
import { supabase } from "../../src/supabase/supabaseClient";
import { Button } from "../../src/ui/Button";
import { Card } from "../../src/ui/Card";
import { Screen } from "../../src/ui/Screen";
import { theme } from "../../src/ui/theme";
import { useOrgMoneyPrefs } from "../../src/ui/money";
import { setActiveScanScope, subscribeScanBarcode } from "@/src/utils/scanBus";

type ProductRow = {
  id: string;
  organization_id: string;
  store_id?: string | null;
  name: string;
  sku: string | null;
  unit: string | null;
  category: string | null;
  selling_price: number | null;
  cost_price?: number | null;
  barcode?: string | null;
  image_url?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;

  is_precision_product?: boolean | null;
  precision_pack_size?: number | null;
  precision_base_unit?: string | null;
  precision_sell_mode?: string | null;
  precision_allow_box_sales?: boolean | null;
  precision_allow_unit_sales?: boolean | null;
};

const PRODUCT_PRICE_DECIMALS = 6;
const PRODUCT_DRAFT_VERSION = "v1";

function safeStorageKey(parts: Array<string | null | undefined>) {
  return parts.map((p) => String(p ?? "none").trim() || "none").join(":");
}

function readWebLocalStorage(key: string) {
  if (Platform.OS !== "web") return null;
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeWebLocalStorage(key: string, value: string) {
  if (Platform.OS !== "web") return;
  try {
    window.localStorage.setItem(key, value);
  } catch {}
}

function removeWebLocalStorage(key: string) {
  if (Platform.OS !== "web") return;
  try {
    window.localStorage.removeItem(key);
  } catch {}
}

function isPrecisionRetailType(storeType: any) {
  const t = String(storeType ?? "").trim().toUpperCase();
  return (
    t === "PRECISION_RETAIL" ||
    t === "PRECISION" ||
    t === "PHARMACY" ||
    t === "PHARMA"
  );
}

function fmtFormulaNumber(n: number) {
  if (!Number.isFinite(n)) return "";

  const fixed = n.toFixed(PRODUCT_PRICE_DECIMALS);

  return fixed.includes(".")
    ? fixed.replace(/\.?0+$/, "")
    : fixed;
}

function normalizeDecimalInput(raw: string) {
  const cleaned = String(raw ?? "")
    .replace(",", ".")
    .replace(/[^0-9.]/g, "")
    .replace(/(\..*)\./g, "$1");

  const [whole, decimal] = cleaned.split(".");
  return decimal !== undefined
    ? `${whole}.${decimal.slice(0, PRODUCT_PRICE_DECIMALS)}`
    : whole;
}

function parsePositiveNumberOrNull(raw: string): number | null {
  const t = normalizeDecimalInput(raw).trim();
  if (!t) return null;
  const n = Number(t);
  if (!Number.isFinite(n) || n <= 0) return null;
  return Number(n.toFixed(PRODUCT_PRICE_DECIMALS));
}

function parseZeroOrPositiveNumberOrNull(raw: string): number | null {
  const t = normalizeDecimalInput(raw).trim();
  if (!t) return null;
  const n = Number(t);
  if (!Number.isFinite(n) || n < 0) return null;
  return Number(n.toFixed(PRODUCT_PRICE_DECIMALS));
}

function cleanBarcode(raw: string) {
  const s = String(raw ?? "").trim();
  if (!s) return "";
  return s.replace(/\s+/g, "");
}

function normalizeDuplicateKey(raw: any) {
  return String(raw ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function getProductLimitFriendlyMessage(err: any) {
  const raw = String(err?.message ?? "").trim();
  const msg = raw.toLowerCase();

  if (
    msg.includes("free plan limit reached") ||
    msg.includes("product limit") ||
    msg.includes("upgrade to continue")
  ) {
    const m = raw.match(/(\d+)/);
    const limit = m?.[1] ?? "30";

    return `Umefikia limit ya bidhaa ${limit} kwenye FREE plan. Ili kuendelea kuongeza bidhaa zaidi, tafadhali upgrade kwenda LITE plan.`;
  }

  return raw || "Unknown error";
}

function isTypingIntoField(target: any) {
  if (!target) return false;
  const tag = String(target.tagName ?? "").toLowerCase();
  const editable = !!target.isContentEditable;
  return editable || tag === "input" || tag === "textarea" || tag === "select";
}

function WebSafeIcon({
  name,
  size = 22,
  color = "#0F172A",
}: {
  name: string;
  size?: number;
  color?: string;
}) {
  const glyph =
    name === "search"
      ? "⌕"
      : name === "refresh"
      ? "↻"
      : name === "close-circle"
      ? "✕"
      : name === "close"
      ? "✕"
      : name === "image-outline"
      ? "▧"
      : name === "cube-outline"
      ? "□"
      : name === "chevron-up"
      ? "⌃"
      : name === "chevron-down"
      ? "⌄"
      : "□";

  return (
    <Text style={{ color, fontSize: size, fontWeight: "900", lineHeight: size + 4 }}>
      {glyph}
    </Text>
  );
}

function isMobileWebBrowser() {
  if (Platform.OS !== "web") return false;

  try {
    return /Android|iPhone|iPad|iPod|Mobile/i.test(window.navigator.userAgent);
  } catch {
    return false;
  }
}

function ScannerFabIcon({ size = 28, color = "#E5E7EB" }: { size?: number; color?: string }) {
  const w = Math.max(22, Math.round(size * 1.05));
  const h = Math.max(18, Math.round(size * 0.78));
  const barHeights = [0.72, 0.46, 0.86, 0.58, 0.92, 0.52, 0.8];
  const barWidths = [2, 1.5, 2.2, 1.4, 2.4, 1.6, 2];
  const gap = Math.max(1.5, Math.round(size * 0.04));

  return (
    <View
      style={{
        width: size + 4,
        height: size + 4,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <View
        style={{
          width: w,
          height: h,
          borderRadius: 7,
          borderWidth: 1.8,
          borderColor: color,
          paddingHorizontal: 3,
          flexDirection: "row",
          alignItems: "flex-end",
          justifyContent: "center",
          backgroundColor: "transparent",
          gap,
        }}
      >
        {barHeights.map((ratio, idx) => (
          <View
            key={idx}
            style={{
              width: barWidths[idx],
              height: Math.max(5, Math.round(h * ratio)),
              backgroundColor: color,
              borderRadius: 1.5,
            }}
          />
        ))}
      </View>

      <View
        style={{
          position: "absolute",
          left: -1,
          top: -1,
          width: 8,
          height: 8,
          borderLeftWidth: 2,
          borderTopWidth: 2,
          borderColor: color,
          borderTopLeftRadius: 3,
        }}
      />
      <View
        style={{
          position: "absolute",
          right: -1,
          top: -1,
          width: 8,
          height: 8,
          borderRightWidth: 2,
          borderTopWidth: 2,
          borderColor: color,
          borderTopRightRadius: 3,
        }}
      />
      <View
        style={{
          position: "absolute",
          left: -1,
          bottom: -1,
          width: 8,
          height: 8,
          borderLeftWidth: 2,
          borderBottomWidth: 2,
          borderColor: color,
          borderBottomLeftRadius: 3,
        }}
      />
      <View
        style={{
          position: "absolute",
          right: -1,
          bottom: -1,
          width: 8,
          height: 8,
          borderRightWidth: 2,
          borderBottomWidth: 2,
          borderColor: color,
          borderBottomRightRadius: 3,
        }}
      />
    </View>
  );
}

export default function ProductsTabScreen() {
 const preferredMoney=usePreferredDisplayMoney();

 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const { width } = useWindowDimensions();
  const isDesktopWeb = Platform.OS === "web" && width >= 900;
  const router = useRouter();

  const {
  activeOrgId,
  activeOrgName,
  activeRole,
  activeStoreId,
  activeStoreName,
  activeStoreType,
} = useOrg();

  const money = useOrgMoneyPrefs(activeOrgId ?? "");
const isCapitalRecoveryStore = activeStoreType === "CAPITAL_RECOVERY";
const isPrecisionRetailStore = isPrecisionRetailType(activeStoreType);
const scopedStoreId = String(activeStoreId ?? "").trim() || null;
// Products list must be organization-wide.
// Store is only needed for active context/inventory, not for product ownership.
const productStoreScope =
  isCapitalRecoveryStore || isPrecisionRetailStore ? scopedStoreId : null;

  const canManage = useMemo(
    () => (activeRole ?? "staff") === "owner",
    [activeRole]
  );

  const canSeeCost = useMemo(
    () => (activeRole ?? "staff") === "owner" && !isCapitalRecoveryStore,
    [activeRole, isCapitalRecoveryStore]
  );

  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<ProductRow[]>([]);
  // SMART_PRODUCT_SEARCH_ALL_V1
  const [productSearchFocused, setProductSearchFocused] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [unit, setUnit] = useState("");
  const [category, setCategory] = useState("");
  const [sellingPrice, setSellingPrice] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [barcode, setBarcode] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [imageUploading, setImageUploading] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [editProductId, setEditProductId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editSku, setEditSku] = useState("");
  const [editUnit, setEditUnit] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [editSellingPrice, setEditSellingPrice] = useState("");
  const [editCostPrice, setEditCostPrice] = useState("");
  const [editBarcode, setEditBarcode] = useState("");
  const [editImageUrl, setEditImageUrl] = useState("");
  const [editImageUploading, setEditImageUploading] = useState(false);

  const [permission, requestPermission] = useCameraPermissions();
const [scanOpen, setScanOpen] = useState(false);
const [scanBusy, setScanBusy] = useState(false);
const [keyboardSpace, setKeyboardSpace] = useState(0);

const [productSearch, setProductSearch] = useState("");

// ==========================================================
// DESKTOP GLOBAL SEARCH DEEP FOCUS
// Desktop Web only.
// Android and Mobile Web behavior remain unchanged.
// ==========================================================
const productRouteParams = useLocalSearchParams<{
  focusProductId?: string | string[];
  focusProductName?: string | string[];
}>();

const focusProductId = useMemo(() => {
  const raw = productRouteParams.focusProductId;

  return String(
    Array.isArray(raw)
      ? raw[0] ?? ""
      : raw ?? ""
  ).trim();
}, [productRouteParams.focusProductId]);

const focusProductName = useMemo(() => {
  const raw = productRouteParams.focusProductName;

  return String(
    Array.isArray(raw)
      ? raw[0] ?? ""
      : raw ?? ""
  ).trim();
}, [productRouteParams.focusProductName]);

const [highlightedProductId, setHighlightedProductId] =
  useState<string | null>(null);

const desktopProductsScrollRef =
  useRef<ScrollView | null>(null);

const desktopProductRowYRef =
  useRef<Record<string, number>>({});

const desktopFocusHandledRef =
  useRef("");

/* PRODUCTS TABLE POLISH 5C */
const [desktopActionProductId, setDesktopActionProductId] =
  useState<string | null>(null);

// Category autocomplete / dropdown
const [storeCategories, setStoreCategories] = useState<string[]>([]);
const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
const [editCategoryDropdownOpen, setEditCategoryDropdownOpen] = useState(false);
const [categoriesLoading, setCategoriesLoading] = useState(false);
// Performance:
// Usirender Product Catalog yote kwa wakati mmoja.
// Hii inapunguza cards + remote images zinazokuwa mounted simultaneously.
const PRODUCTS_PAGE_SIZE = 20;
const [visibleProductCount, setVisibleProductCount] =
  useState(PRODUCTS_PAGE_SIZE);

const [precisionPackQty, setPrecisionPackQty] = useState("");
const [precisionPackCost, setPrecisionPackCost] = useState("");
const [precisionPackSelling, setPrecisionPackSelling] = useState("");
const [precisionUnit, setPrecisionUnit] = useState("");

const [editPrecisionPackQty, setEditPrecisionPackQty] = useState("");
const [editPrecisionPackCost, setEditPrecisionPackCost] = useState("");
const [editPrecisionPackSelling, setEditPrecisionPackSelling] = useState("");
const [editPrecisionUnit, setEditPrecisionUnit] = useState("");

const [precisionCalcOpen, setPrecisionCalcOpen] = useState(false);
const [editPrecisionCalcOpen, setEditPrecisionCalcOpen] = useState(false);




const productDraftKey = useMemo(
  () =>
    safeStorageKey([
      "zetra",
      "product_add_draft",
      PRODUCT_DRAFT_VERSION,
      activeOrgId,
      productStoreScope ?? "org",
      activeRole,
    ]),
  [activeOrgId, productStoreScope, activeRole]
);

const draftHydratedRef = useRef(false);

const uploadProductImageFile = useCallback(
  async (file: any, mode: "add" | "edit") => {
    if (!activeOrgId) {
      Alert.alert(uiText("Missing"), uiText("No active organization."));
      return;
    }

    const setBusy = mode === "edit" ? setEditImageUploading : setImageUploading;
    const setUrl = mode === "edit" ? setEditImageUrl : setImageUrl;

    setBusy(true);

    try {
      const fileName = String(file?.name ?? "product.jpg");
      const ext = fileName.split(".").pop()?.toLowerCase() || "jpg";
      const safeExt = ["jpg", "jpeg", "png", "webp"].includes(ext) ? ext : "jpg";
      const path = `${activeOrgId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${safeExt}`;
      const contentType = file?.type || `image/${safeExt === "jpg" ? "jpeg" : safeExt}`;

      const { error: uploadError } = await supabase.storage
        .from("product-images")
        .upload(path, file, {
          contentType,
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage.from("product-images").getPublicUrl(path);
      const publicUrl = data?.publicUrl ?? "";
      if (!publicUrl) throw new Error("Image uploaded but URL was not returned.");

      setUrl(publicUrl);
    } catch (e: any) {
      Alert.alert(uiText("Image Upload Failed"), e?.message ?? uiText("Failed to upload product image."));
    } finally {
      setBusy(false);
    }
  },
  [activeOrgId]
);

const uploadProductImage = useCallback(
    async (uri: string, mode: "add" | "edit") => {
      if (!activeOrgId) {
        Alert.alert(uiText("Missing"), uiText("No active organization."));
        return;
      }

      const setBusy = mode === "edit" ? setEditImageUploading : setImageUploading;
      const setUrl = mode === "edit" ? setEditImageUrl : setImageUrl;

      setBusy(true);

      try {
        const ext = String(uri).split(".").pop()?.split("?")[0]?.toLowerCase() || "jpg";
        const safeExt = ["jpg", "jpeg", "png", "webp"].includes(ext) ? ext : "jpg";
        const path = `${activeOrgId}/${Date.now()}-${Math.random()
          .toString(36)
          .slice(2)}.${safeExt}`;

        const response = await fetch(uri);

        if (!response.ok) {
          throw new Error("Failed to read selected image.");
        }

        const arrayBuffer = await response.arrayBuffer();
        const contentType = `image/${safeExt === "jpg" ? "jpeg" : safeExt}`;

        const { error: uploadError } = await supabase.storage
          .from("product-images")
          .upload(path, arrayBuffer, {
            contentType,
            upsert: false,
          });

        if (uploadError) throw uploadError;

        const { data } = supabase.storage.from("product-images").getPublicUrl(path);

        const publicUrl = data?.publicUrl ?? "";
        if (!publicUrl) throw new Error("Image uploaded but URL was not returned.");

        setUrl(publicUrl);
      } catch (e: any) {
        Alert.alert(uiText("Image Upload Failed"), e?.message ?? uiText("Failed to upload product image."));
      } finally {
        setBusy(false);
      }
    },
    [activeOrgId]
  );

  const pickWebProductImage = useCallback(
    async (mode: "add" | "edit", captureCamera = false) => {
      if (!canManage || Platform.OS !== "web") return;

      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";

      if (captureCamera) {
        input.setAttribute("capture", "environment");
      }

      input.onchange = async () => {
        const file = input.files?.[0];
        if (file) await uploadProductImageFile(file, mode);
      };

      input.click();
    },
    [canManage, uploadProductImageFile]
  );

  const pickProductImage = useCallback(
    async (mode: "add" | "edit") => {
      if (!canManage) return;

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.75,
      });

      if (result.canceled) return;

      const uri = result.assets?.[0]?.uri;
      if (uri) await uploadProductImage(uri, mode);
    },
    [canManage, uploadProductImage]
  );

  const takeProductPhoto = useCallback(
    async (mode: "add" | "edit") => {
      if (!canManage) return;

      const permissionResult = await ImagePicker.requestCameraPermissionsAsync();
      if (!permissionResult.granted) {
        Alert.alert(uiText("Camera Permission"), uiText("Ruhusa ya camera inahitajika kupiga picha ya bidhaa."));
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.75,
      });

      if (result.canceled) return;

      const uri = result.assets?.[0]?.uri;
      if (uri) await uploadProductImage(uri, mode);
    },
    [canManage, uploadProductImage]
  );

  const chooseImageSource = useCallback(
    (mode: "add" | "edit") => {
      if (Platform.OS === "web") {
        if (!isMobileWebBrowser()) {
          void pickWebProductImage(mode, false);
          return;
        }

        Alert.alert(uiText("Product Image"), uiText("Chagua namna ya kuweka picha ya bidhaa."), [
          { text: uiText("Camera"), onPress: () => void pickWebProductImage(mode, true) },
          { text: uiText("Gallery / File"), onPress: () => void pickWebProductImage(mode, false) },
          { text: uiText("Cancel"), style: "cancel" },
        ]);
        return;
      }

      Alert.alert(uiText("Product Image"), uiText("Chagua namna ya kuweka picha ya bidhaa."), [
        { text: uiText("Camera"), onPress: () => void takeProductPhoto(mode) },
        { text: uiText("Gallery / File"), onPress: () => void pickProductImage(mode) },
        { text: uiText("Cancel"), style: "cancel" },
      ]);
    },
    [pickProductImage, pickWebProductImage, takeProductPhoto]
  );
  const handleProductsScopedScan = useCallback(
    (rawInput: any) => {
      if (!canManage) return;

      const code = cleanBarcode(rawInput);
      if (!code) return;

      if (editOpen) {
        setEditBarcode(code);
      } else {
        setBarcode(code);
      }
    },
    [canManage, editOpen]
  );

  const webScanBufferRef = useRef("");
  const webScanLastAtRef = useRef(0);
  const webScanTimerRef = useRef<any>(null);

  const openScan = useCallback(async () => {
    if (!canManage) {
      Alert.alert(uiText("No Access"), uiText("Owner only."));
      return;
    }

    if (isCapitalRecoveryStore) {
      Alert.alert(uiText("Not Needed"), uiText("Barcode haitumiki kwenye Capital Recovery products."));
      return;
    }

    try {
      if (!permission?.granted) {
        const res = await requestPermission();
        if (!res.granted) {
          Alert.alert(uiText("Camera Permission"), uiText("Ruhusa ya camera inahitajika ili kuscan barcode."));
          return;
        }
      }

      setScanBusy(false);
      setScanOpen(true);
    } catch {
      Alert.alert(uiText("Camera"), uiText("Imeshindikana kuomba ruhusa ya camera."));
    }
  }, [canManage, isCapitalRecoveryStore, permission?.granted, requestPermission]);

  const closeScan = useCallback(() => {
    setScanOpen(false);
    setScanBusy(false);
  }, []);

  useEffect(() => {
    if (!canManage) return;
    if (!activeOrgId) return;
    if (draftHydratedRef.current) return;

    const raw = readWebLocalStorage(productDraftKey);
    if (!raw) {
      draftHydratedRef.current = true;
      return;
    }

    try {
      const draft = JSON.parse(raw);

      setName(String(draft.name ?? ""));
      setSku(String(draft.sku ?? ""));
      setUnit(String(draft.unit ?? ""));
      setCategory(String(draft.category ?? ""));
      setSellingPrice(String(draft.sellingPrice ?? ""));
      setCostPrice(String(draft.costPrice ?? ""));
      setBarcode(String(draft.barcode ?? ""));
      setImageUrl(String(draft.imageUrl ?? ""));
      setPrecisionPackQty(String(draft.precisionPackQty ?? ""));
      setPrecisionPackCost(String(draft.precisionPackCost ?? ""));
      setPrecisionPackSelling(String(draft.precisionPackSelling ?? ""));
      setPrecisionUnit(String(draft.precisionUnit ?? ""));
      setPrecisionCalcOpen(Boolean(draft.precisionCalcOpen ?? false));
    } catch {}

    draftHydratedRef.current = true;
  }, [activeOrgId, canManage, productDraftKey]);

  const onBarcodeScanned = useCallback(
    (result: any) => {
      if (!scanOpen || scanBusy) return;

      const raw = String(result?.data ?? "").trim();
      const v = cleanBarcode(raw);
      if (!v) return;

      setScanBusy(true);
      setBarcode(v);

      setTimeout(() => {
        closeScan();
      }, 180);
    },
    [closeScan, scanBusy, scanOpen]
  );
const loadStoreCategories = useCallback(async () => {
  if (!activeOrgId || !scopedStoreId) {
    setStoreCategories([]);
    return;
  }

  setCategoriesLoading(true);

  try {
    // Hii query ni maalum kwa category suggestions.
    // Product Catalog yako bado inaendelea kutumia productStoreScope yake kama kawaida.
    const { data, error: categoryError } = await supabase.rpc(
      canManage ? "get_products_manage" : "get_products",
      {
        p_org_id: activeOrgId,
        p_store_id: scopedStoreId,
      }
    );

    if (categoryError) throw categoryError;

    const categoryMap = new Map<string, string>();

    ((data ?? []) as ProductRow[]).forEach((product) => {
      const rawCategory = String(product?.category ?? "").trim();

      if (!rawCategory) return;

      const normalized = rawCategory
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();

      if (!normalized) return;

      // Duplicate categories zinaondolewa bila kuharibu spelling ya original.
      if (!categoryMap.has(normalized)) {
        categoryMap.set(normalized, rawCategory);
      }
    });

    const nextCategories = Array.from(categoryMap.values()).sort((a, b) =>
      a.localeCompare(b, undefined, {
        sensitivity: "base",
      })
    );

    setStoreCategories(nextCategories);
  } catch (err) {
    console.warn("Failed to load store categories:", err);
    setStoreCategories([]);
  } finally {
    setCategoriesLoading(false);
  }
}, [activeOrgId, scopedStoreId, canManage]);
const load = useCallback(async () => {
  if (!activeOrgId) {
    setRows([]);
    return;
  }

  if (isCapitalRecoveryStore && !scopedStoreId) {
    setRows([]);
    setError("No active store selected");
    return;
  }

  setLoading(true);
  setError(null);

  try {
    if (canManage) {
      const { data, error: e } = await supabase.rpc("get_products_manage", {
        p_org_id: activeOrgId,
        p_store_id: productStoreScope,
      });
      if (e) throw e;
      setRows((data ?? []) as ProductRow[]);
    } else {
      const { data, error: e } = await supabase.rpc("get_products", {
        p_org_id: activeOrgId,
        p_store_id: productStoreScope,
      });
      if (e) throw e;
      setRows((data ?? []) as ProductRow[]);
    }
  } catch (err: any) {
    setError(err?.message ?? "Failed to load products");
    setRows([]);
  } finally {
    setLoading(false);
  }
}, [activeOrgId, canManage, isCapitalRecoveryStore, productStoreScope, scopedStoreId]);

useEffect(() => {
  void load();
  void loadStoreCategories();
}, [load, loadStoreCategories]);

  useEffect(() => {
    if (!canManage) return;
    if (!activeOrgId) return;
    if (!draftHydratedRef.current) return;

    const hasDraft =
      !!name.trim() ||
      !!sku.trim() ||
      !!unit.trim() ||
      !!category.trim() ||
      !!sellingPrice.trim() ||
      !!costPrice.trim() ||
      !!barcode.trim() ||
      !!imageUrl.trim() ||
      !!precisionPackQty.trim() ||
      !!precisionPackCost.trim() ||
      !!precisionPackSelling.trim() ||
      !!precisionUnit.trim();

    if (!hasDraft) {
      removeWebLocalStorage(productDraftKey);
      return;
    }

    writeWebLocalStorage(
      productDraftKey,
      JSON.stringify({
        name,
        sku,
        unit,
        category,
        sellingPrice,
        costPrice,
        barcode,
        imageUrl,
        precisionPackQty,
        precisionPackCost,
        precisionPackSelling,
        precisionUnit,
        precisionCalcOpen,
        savedAt: new Date().toISOString(),
      })
    );
  }, [
    activeOrgId,
    canManage,
    productDraftKey,
    name,
    sku,
    unit,
    category,
    sellingPrice,
    costPrice,
    barcode,
    imageUrl,
    precisionPackQty,
    precisionPackCost,
    precisionPackSelling,
    precisionUnit,
    precisionCalcOpen,
  ]);

 useFocusEffect(
  useCallback(() => {
    // Product data inaweza kubadilishwa kutoka Catalog/Import screen.
    // Kila Products tab inapopata focus, soma database upya.
    void load();
    void loadStoreCategories();

    if (isCapitalRecoveryStore) {
      setActiveScanScope("GLOBAL");

      return () => {
        setActiveScanScope("GLOBAL");
      };
    }

    setActiveScanScope("PRODUCTS");

    const unsub = subscribeScanBarcode(
      (barcode) => {
        handleProductsScopedScan(barcode);
      },
      { scope: "PRODUCTS" }
    );

    return () => {
      unsub();
      setActiveScanScope("GLOBAL");
    };
  }, [
    handleProductsScopedScan,
    isCapitalRecoveryStore,
    load,
    loadStoreCategories,
  ])
);

  useEffect(() => {
    const showSub = Keyboard.addListener("keyboardDidShow", (e) => {
      setKeyboardSpace(Math.max(0, e.endCoordinates?.height ?? 0) + 24);
    });

    const hideSub = Keyboard.addListener("keyboardDidHide", () => {
      setKeyboardSpace(0);
    });

    return () => {
      showSub.remove();
      hideSub.remove();
    };
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web") return;
    if (!canManage) return;

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as any;
      if (isTypingIntoField(target)) return;

      const key = String(e.key ?? "");
      const now = Date.now();

      if (key === "Enter") {
        const code = cleanBarcode(webScanBufferRef.current);
        webScanBufferRef.current = "";
        webScanLastAtRef.current = 0;

        if (webScanTimerRef.current) {
          clearTimeout(webScanTimerRef.current);
          webScanTimerRef.current = null;
        }

        if (code.length >= 4) {
          handleProductsScopedScan(code);
        }
        return;
      }

      if (key.length !== 1) return;
      if (e.ctrlKey || e.altKey || e.metaKey) return;

      if (now - webScanLastAtRef.current > 120) {
        webScanBufferRef.current = "";
      }

      webScanBufferRef.current += key;
      webScanLastAtRef.current = now;

      if (webScanTimerRef.current) clearTimeout(webScanTimerRef.current);
      webScanTimerRef.current = setTimeout(() => {
        webScanBufferRef.current = "";
        webScanLastAtRef.current = 0;
      }, 180);
    };

    window.addEventListener("keydown", onKeyDown);

    return () => {
      window.removeEventListener("keydown", onKeyDown);
      if (webScanTimerRef.current) {
        clearTimeout(webScanTimerRef.current);
        webScanTimerRef.current = null;
      }
    };
  }, [canManage, handleProductsScopedScan]);

  const applyPrecisionFormula = useCallback(() => {
  const packQty = Number(normalizeDecimalInput(precisionPackQty));
  const packCost = Number(normalizeDecimalInput(precisionPackCost));
  const packSelling = Number(normalizeDecimalInput(precisionPackSelling));

  if (!Number.isFinite(packQty) || packQty <= 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Pack Size / Quantity, mfano 100."));
    return;
  }

  if (!Number.isFinite(packCost) || packCost < 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Buying/Cost Price ya box/pack."));
    return;
  }

  if (!Number.isFinite(packSelling) || packSelling <= 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Selling Price ya box/pack."));
    return;
  }

  const unitCost = packCost / packQty;
  const unitSelling = packSelling / packQty;

  // Usibadilishe Unit ya juu. Unit ya juu ni pack/jumla mfano Box, Carton, Belo.
  // PrecisionUnit ni unit ya ndani mfano Capsule, Tablet, Piece.
  setCostPrice(fmtFormulaNumber(unitCost));
  setSellingPrice(fmtFormulaNumber(unitSelling));

  if (!category.trim()) setCategory("General");
}, [category, precisionPackCost, precisionPackQty, precisionPackSelling, precisionUnit]);

const applyEditPrecisionFormula = useCallback(() => {
  const packQty = Number(normalizeDecimalInput(editPrecisionPackQty));
  const packCost = Number(normalizeDecimalInput(editPrecisionPackCost));
  const packSelling = Number(normalizeDecimalInput(editPrecisionPackSelling));

  if (!Number.isFinite(packQty) || packQty <= 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Pack Size / Quantity, mfano 100."));
    return;
  }

  if (!Number.isFinite(packCost) || packCost < 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Buying/Cost Price ya box/pack."));
    return;
  }

  if (!Number.isFinite(packSelling) || packSelling <= 0) {
    Alert.alert(uiText("Missing"), uiText("Weka Selling Price ya box/pack."));
    return;
  }

  setEditCostPrice(fmtFormulaNumber(packCost / packQty));
  setEditSellingPrice(fmtFormulaNumber(packSelling / packQty));

  if (!editCategory.trim()) setEditCategory("General");
}, [editCategory, editPrecisionPackCost, editPrecisionPackQty, editPrecisionPackSelling]);

const openEdit = useCallback((p: ProductRow) => {
    setEditProductId(p.id);
    setEditName(String(p.name ?? ""));
    setEditSku(String(p.sku ?? ""));
    setEditUnit(String(p.unit ?? ""));
    setEditCategory(String(p.category ?? ""));
    setEditSellingPrice(p.selling_price != null ? String(Number(p.selling_price)) : "");
setEditCostPrice(p.cost_price != null ? String(Number(p.cost_price)) : "");
    setEditBarcode(String(p.barcode ?? ""));
    setEditImageUrl(String(p.image_url ?? ""));

    setEditPrecisionPackQty(
      p.precision_pack_size != null ? String(Number(p.precision_pack_size)) : ""
    );
    setEditPrecisionPackCost("");
    setEditPrecisionPackSelling("");
    setEditPrecisionUnit(String(p.precision_base_unit ?? ""));

    setEditOpen(true);
  }, []);

  const closeEdit = useCallback(() => {
    setEditOpen(false);
    setEditProductId(null);
    setEditName("");
    setEditSku("");
    setEditUnit("");
    setEditCategory("");
    setEditCategoryDropdownOpen(false);
    setEditSellingPrice("");
    setEditCostPrice("");
    setEditBarcode("");
    setEditImageUrl("");
    setEditPrecisionPackQty("");
    setEditPrecisionPackCost("");
    setEditPrecisionPackSelling("");
    setEditPrecisionUnit("");
  }, []);

 const add = useCallback(async (forceDuplicateSave?: boolean | any) => {
  const allowDuplicateSave = forceDuplicateSave === true;
  if (!activeOrgId) return;
if (isCapitalRecoveryStore && !scopedStoreId) return;

    const n = name.trim();
    if (!n) {
      Alert.alert(uiText("Missing"), uiText("Weka product name."));
      return;
    }

    if (!canManage) {
      Alert.alert(uiText("No Access"), uiText("Owner only."));
      return;
    }

    const sp = parsePositiveNumberOrNull(sellingPrice);
    if (sellingPrice.trim() && sp === null) {
      Alert.alert(uiText("Invalid"), uiText("Selling Price iwe namba (> 0) au uiache wazi."));
      return;
    }

    const cp = parseZeroOrPositiveNumberOrNull(costPrice);
    if (!isCapitalRecoveryStore && costPrice.trim() && cp === null) {
      Alert.alert(uiText("Invalid"), uiText("Cost Price iwe namba (>= 0) au uiache wazi."));
      return;
    }
if (!isCapitalRecoveryStore && cp !== null && sp !== null && sp < cp) {
  Alert.alert(
    uiText("Bei si sahihi"),
    uiText("Selling Price uliyoweka ni ndogo kuliko Cost Price. Hii italeta hasara. Weka Selling Price kubwa kuliko au sawa na Cost Price.")
  );
  return;
}
    if (isCapitalRecoveryStore) {
      if (sp === null) {
        Alert.alert(uiText("Missing"), uiText("Weka Selling Price kwa Capital Recovery product."));
        return;
      }
    } else {
      if (sp === null && cp === null) {
        Alert.alert(uiText("Missing"), uiText("Weka angalau Cost Price au Selling Price (hata moja)."));
        return;
      }
    }

    const bc = cleanBarcode(barcode);
    if (!isCapitalRecoveryStore && bc && bc.length < 6) {
      Alert.alert(uiText("Invalid"), uiText("Barcode inaonekana fupi sana. Hakikisha ume-scan sahihi."));
      return;
    }

    if (!allowDuplicateSave && !isCapitalRecoveryStore) {
      const nextNameKey = normalizeDuplicateKey(n);
      const nextSkuKey = normalizeDuplicateKey(sku);
      const nextUnitKey = normalizeDuplicateKey(unit);
      const nextCategoryKey = normalizeDuplicateKey(category);
      const nextBarcodeKey = normalizeDuplicateKey(bc);

      const duplicate = rows.find((p) => {
        if (p.is_active === false) return false;

        const sameScope =
          productStoreScope == null ||
          String(p.store_id ?? "") === String(productStoreScope ?? "");

        return (
          sameScope &&
          normalizeDuplicateKey(p.name) === nextNameKey &&
          normalizeDuplicateKey(p.sku) === nextSkuKey &&
          normalizeDuplicateKey(p.unit) === nextUnitKey &&
          normalizeDuplicateKey(p.category) === nextCategoryKey &&
          normalizeDuplicateKey(p.barcode) === nextBarcodeKey
        );
      });

      if (duplicate) {
        const msg =
          `Bidhaa inayofanana ipo tayari.\n\n` +
          `Jina: ${duplicate.name}\n` +
          `SKU: ${duplicate.sku ?? "—"}\n` +
          `Unit: ${duplicate.unit ?? "—"}\n` +
          `Category: ${duplicate.category ?? "—"}\n\n` +
          `Unataka kuisave tena kama bidhaa tofauti?`;

        if (Platform.OS === "web") {
          const ok = window.confirm(msg);
          if (!ok) return;
          await add(true);
          return;
        }

        Alert.alert(uiText("Duplicate Product"), msg, [
          { text: uiText("Cancel"), style: "cancel" },
          {
            text: uiText("Save Anyway"),
            style: "destructive",
            onPress: () => void add(true),
          },
        ]);
        return;
      }
    }

    setLoading(true);
    setError(null);

    try {
      const { error: e } = await supabase.rpc("upsert_product", {
  p_org_id: activeOrgId,
  p_product_id: null,
  p_name: n,
  p_sku: isCapitalRecoveryStore ? null : sku.trim() || null,
  p_unit: isCapitalRecoveryStore ? null : unit.trim() || null,
  p_category: category.trim() || null,
  p_is_active: true,
  p_selling_price: sp,
  p_cost_price: isCapitalRecoveryStore ? null : cp,
  p_barcode: isCapitalRecoveryStore ? null : bc || null,
  p_store_id: productStoreScope,
p_is_precision_product: isPrecisionRetailStore,
p_precision_pack_size: isPrecisionRetailStore ? parsePositiveNumberOrNull(precisionPackQty) : null,
p_precision_base_unit: isPrecisionRetailStore ? precisionUnit.trim() || unit.trim() || null : null,
p_precision_sell_mode: isPrecisionRetailStore ? "BOTH" : "UNIT",
p_precision_allow_box_sales: isPrecisionRetailStore,
p_precision_allow_unit_sales: true,
p_image_url: imageUrl.trim() || null,
});

      if (e) throw e;

      removeWebLocalStorage(productDraftKey);

      setName("");
setSku("");
setUnit("");
setCategory("");
setCategoryDropdownOpen(false);
setSellingPrice("");
      setCostPrice("");
      setBarcode("");
      setImageUrl("");
      setPrecisionPackQty("");
      setPrecisionPackCost("");
      setPrecisionPackSelling("");
      setPrecisionUnit("");

await load();
await loadStoreCategories();

      const productAddedMessage =
        isCapitalRecoveryStore
          ? "Income product added"
          : bc
          ? "Product added (barcode saved)"
          : "Product added";

      if (Platform.OS === "web") {
        window.alert(uiText("Success ✅")+"\n\n"+uiText(productAddedMessage));
      } else {
        Alert.alert(uiText("Success ✅"), uiText(productAddedMessage));
      }
    } catch (err: any) {
      const productSaveError =
        getProductLimitFriendlyMessage(err);

      if (Platform.OS === "web") {
        window.alert(uiText("Product Save Failed ❌")+"\n\n"+systemText(productSaveError));
      } else {
        Alert.alert(uiText("Plan Limit"), systemText(productSaveError));
      }
    } finally {
      setLoading(false);
    }
  }, [
    activeOrgId,
    scopedStoreId,
    productStoreScope,
    barcode,
    canManage,
    category,
    costPrice,
    isCapitalRecoveryStore,
    load,
loadStoreCategories,
name,
    sellingPrice,
    sku,
    unit,
isPrecisionRetailStore,
precisionPackQty,
precisionUnit,
imageUrl,
productDraftKey,
rows,
  ]);

  const saveEdit = useCallback(async () => {
    if (!activeOrgId || !editProductId) return;
if (isCapitalRecoveryStore && !scopedStoreId) return;

    if (!canManage) {
      Alert.alert(uiText("No Access"), uiText("Owner only."));
      return;
    }

    const n = editName.trim();
    if (!n) {
      Alert.alert(uiText("Missing"), uiText("Weka product name."));
      return;
    }

    const sp = parsePositiveNumberOrNull(editSellingPrice);
    if (editSellingPrice.trim() && sp === null) {
      Alert.alert(uiText("Invalid"), uiText("Selling Price iwe namba (> 0) au uiache wazi."));
      return;
    }

    const cp = parseZeroOrPositiveNumberOrNull(editCostPrice);
    if (!isCapitalRecoveryStore && editCostPrice.trim() && cp === null) {
      Alert.alert(uiText("Invalid"), uiText("Cost Price iwe namba (>= 0) au uiache wazi."));
      return;
    }
if (!isCapitalRecoveryStore && cp !== null && sp !== null && sp < cp) {
  Alert.alert(
    uiText("Bei si sahihi"),
    uiText("Selling Price uliyoweka ni ndogo kuliko Cost Price. Hii italeta hasara. Weka Selling Price kubwa kuliko au sawa na Cost Price.")
  );
  return;
}
    if (isCapitalRecoveryStore) {
      if (sp === null) {
        Alert.alert(uiText("Missing"), uiText("Weka Selling Price kwa Capital Recovery product."));
        return;
      }
    } else {
      if (sp === null && cp === null) {
        Alert.alert(uiText("Missing"), uiText("Weka angalau Cost Price au Selling Price (hata moja)."));
        return;
      }
    }

    const bc = cleanBarcode(editBarcode);
    if (!isCapitalRecoveryStore && bc && bc.length < 6) {
      Alert.alert(uiText("Invalid"), uiText("Barcode inaonekana fupi sana. Hakikisha umeweka sahihi."));
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { error: e } = await supabase.rpc("upsert_product", {
        p_org_id: activeOrgId,
        p_product_id: editProductId,
        p_name: n,
        p_sku: isCapitalRecoveryStore ? null : editSku.trim() || null,
        p_unit: isCapitalRecoveryStore ? null : editUnit.trim() || null,
        p_category: editCategory.trim() || null,
        p_is_active: true,
        p_selling_price: sp,
        p_cost_price: isCapitalRecoveryStore ? null : cp,
        p_barcode: isCapitalRecoveryStore ? null : bc || null,
p_store_id: productStoreScope,

p_is_precision_product: isPrecisionRetailStore,
p_precision_pack_size: isPrecisionRetailStore
  ? parsePositiveNumberOrNull(editPrecisionPackQty)
  : null,
p_precision_base_unit: isPrecisionRetailStore
  ? editPrecisionUnit.trim() || editUnit.trim() || null
  : null,
p_precision_sell_mode: isPrecisionRetailStore ? "BOTH" : "UNIT",
p_precision_allow_box_sales: isPrecisionRetailStore,
p_precision_allow_unit_sales: true,
p_image_url: editImageUrl.trim() || null,
});
      if (e) throw e;

     closeEdit();
await load();
await loadStoreCategories();
if (Platform.OS === "web") {
  window.alert(uiText("Success ✅")+"\n\n"+uiText("Product updated"));
} else {
  Alert.alert(uiText("Success ✅"), uiText("Product updated"));
}
    } catch (err: any) {
      const productUpdateError =
        getProductLimitFriendlyMessage(err);

      if (Platform.OS === "web") {
        window.alert(uiText("Product Update Failed ❌")+"\n\n"+systemText(productUpdateError));
      } else {
        Alert.alert(uiText("Plan Limit"), systemText(productUpdateError));
      }
    } finally {
      setLoading(false);
    }}, [
    activeOrgId,
    scopedStoreId,
    productStoreScope,
    canManage,
    closeEdit,
    editBarcode,
    editCategory,
    editCostPrice,
    editName,
    editProductId,
    editSellingPrice,
    editSku,
    editUnit,
    editImageUrl,
    isCapitalRecoveryStore,
    isPrecisionRetailStore,
  load,
loadStoreCategories,
editPrecisionPackQty,
    editPrecisionUnit,
  ]);

const remove = useCallback(
  async (productId: string, productName: string) => {
    if (!activeOrgId) return;

    if (!canManage) {
      Alert.alert(uiText("No Access"), uiText("Owner only."));
      return;
    }

    const doDelete = async () => {
      setLoading(true);
      try {
        const { error: e } = await supabase.rpc("delete_product", {
          p_org_id: activeOrgId,
          p_product_id: productId,
          p_store_id: productStoreScope,
        });

        if (e) throw e;

        await load();
        await loadStoreCategories();

        if (Platform.OS === "web") {
          window.alert(uiText("Success ✅")+"\n\n"+uiText("Product deleted/archived safely"));
        } else {
          Alert.alert(uiText("Success ✅"), uiText("Product deleted/archived safely"));
        }
      } catch (err: any) {
        const deleteError =
          err?.message ?? "Unknown error";

        if (Platform.OS === "web") {
          window.alert(uiText("Delete Failed ❌")+"\n\n"+systemText(deleteError));
        } else {
          Alert.alert(uiText("Failed"), systemText(deleteError));
        }
      } finally {
        setLoading(false);
      }
    };

    if (Platform.OS === "web") {
      const ok = window.confirm(uiText("Delete Product?\n\n{p0}", {p0: productName}));
      if (!ok) return;
      await doDelete();
      return;
    }

    Alert.alert(
      uiText("Delete Product?"),
      productName,
      [
        { text: uiText("Cancel"), style: "cancel" },
        {
          text: uiText("Delete"),
          style: "destructive",
          onPress: () => void doDelete(),
        },
      ],
      { cancelable: true }
    );
  },
  [activeOrgId, productStoreScope, canManage, load, loadStoreCategories]
);

const catalogSearchIndex = useMemo(() => indexCatalog(rows), [rows]);
const visibleRows = useMemo(() => searchCatalog(catalogSearchIndex, productSearch), [catalogSearchIndex, productSearch]);

// Search mpya, organization mpya au store mpya ikibadilika,
// rudisha catalog kwenye page ya kwanza ili isibebe items nyingi.
useEffect(() => {
  setVisibleProductCount(PRODUCTS_PAGE_SIZE);
}, [productSearch, activeOrgId, productStoreScope]);

// Hizi tu ndizo products zitakazokuwa mounted/rendered kwenye UI.
// visibleRows bado ina products zote kwa ajili ya search na count.
const renderedRows = useMemo(() => {
  return visibleRows.slice(0, visibleProductCount);
}, [visibleRows, visibleProductCount]);

const hasMoreProducts = visibleProductCount < visibleRows.length;

const loadMoreProducts = useCallback(() => {
  setVisibleProductCount((current) =>
    Math.min(current + PRODUCTS_PAGE_SIZE, visibleRows.length)
  );
}, [visibleRows.length]);


// ==========================================================
// DESKTOP GLOBAL SEARCH -> EXACT PRODUCT ENGINE
// ==========================================================
useEffect(() => {
  if (!isDesktopWeb) return;
  if (!focusProductId) return;

  const exactProduct =
    rows.find(
      (row) =>
        String(row.id) === focusProductId
    );

  if (!exactProduct) {
    return;
  }

  const focusKey =
    `${focusProductId}:${focusProductName}`;

  if (
    desktopFocusHandledRef.current !== focusKey
  ) {
    desktopFocusHandledRef.current =
      focusKey;

    const targetSearch =
      focusProductName ||
      String(exactProduct.name ?? "").trim();

    if (
      targetSearch &&
      productSearch !== targetSearch
    ) {
      setProductSearch(targetSearch);
    }

    setHighlightedProductId(
      focusProductId
    );
  }
}, [
  isDesktopWeb,
  focusProductId,
  focusProductName,
  rows,
  productSearch,
]);

useEffect(() => {
  if (!isDesktopWeb) return;
  if (!focusProductId) return;

  const targetIndex =
    visibleRows.findIndex(
      (row) =>
        String(row.id) === focusProductId
    );

  if (targetIndex < 0) {
    return;
  }

  const requiredCount =
    Math.min(
      visibleRows.length,
      Math.max(
        PRODUCTS_PAGE_SIZE,
        targetIndex + 1
      )
    );

  if (
    visibleProductCount <
    requiredCount
  ) {
    setVisibleProductCount(
      requiredCount
    );

    return;
  }

  const scrollTimer =
    setTimeout(() => {
      const rowY =
        desktopProductRowYRef.current[
          focusProductId
        ];

      if (
        typeof rowY === "number"
      ) {
        desktopProductsScrollRef.current?.scrollTo({
          y: Math.max(0, rowY - 6),
          animated: true,
        });
      }
    }, 180);

  const highlightTimer =
    setTimeout(() => {
      setHighlightedProductId(
        (current) =>
          current === focusProductId
            ? null
            : current
      );
    }, 4200);

  return () => {
    clearTimeout(scrollTimer);
    clearTimeout(highlightTimer);
  };
}, [
  isDesktopWeb,
  focusProductId,
  visibleRows,
  visibleProductCount,
]);
const filteredCategorySuggestions = useMemo(() => {
  const q = category.trim().toLowerCase();

  if (!q) {
    return storeCategories;
  }

  return storeCategories.filter((item) =>
    item.toLowerCase().includes(q)
  );
}, [category, storeCategories]);

const filteredEditCategorySuggestions = useMemo(() => {
  const q = editCategory.trim().toLowerCase();

  if (!q) {
    return storeCategories;
  }

  return storeCategories.filter((item) =>
    item.toLowerCase().includes(q)
  );
}, [editCategory, storeCategories]);
const solidInputStyle = {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.lg,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: theme.colors.text,
    fontWeight: "800" as const,
  };

  return (
    <Screen scroll><PreferredRateNote />
      <View style={{ gap: 6 }}>
  <Text style={{ fontSize: isDesktopWeb ? 25 : 30, fontWeight: "900", color: theme.colors.text }}>
    {uiText("Products")}</Text>
  <Text style={{ color: theme.colors.muted, fontWeight: "800", lineHeight: 22 }}>
    {uiText("Manage catalog, barcode, pricing, units, and store-ready products.")}</Text>
</View>

      {/* PRODUCTS DESKTOP HEADER 5A V2 */}
      {isDesktopWeb ? (
        <View style={{ gap: 8 }}>
          <View
            style={{
                display: (productSearchFocused || productSearch.trim().length > 0) ? "none" : "flex",
              flexDirection: "row",
              alignItems: "stretch",
              gap: 10,
              width: "100%",
            }}
          >
            {/* ORGANIZATION / STORE */}
            <View
              style={{
                flex: 1.25,
                minWidth: 0,
                minHeight: 68,
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.24)",
                borderRadius: 11,
                backgroundColor: "#FFFFFF",
                paddingHorizontal: 13,
                paddingVertical: 9,
                flexDirection: "row",
                alignItems: "center",
                gap: 11,
              }}
            >
              <View
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 10,
                  backgroundColor: "rgba(16,185,129,0.10)",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <WebSafeIcon
                  name="business-outline"
                  size={19}
                  color="#059669"
                />
              </View>

              <View style={{ flex: 1, minWidth: 0 }}>
                <Text
                  style={{
                    color: theme.colors.muted,
                    fontWeight: "900",
                    fontSize: 9,
                    textTransform: "uppercase",
                  }}
                >
                  {uiText("Organization")}</Text>

                <Text
                  style={{
                    color: theme.colors.text,
                    fontWeight: "900",
                    fontSize: 13,
                    marginTop: 2,
                  }}
                  numberOfLines={1}
                >
                  {activeOrgName ?? "—"}
                </Text>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 7,
                    marginTop: 4,
                  }}
                >
                  <Text
                    style={{
                      color: theme.colors.muted,
                      fontWeight: "800",
                      fontSize: 10,
                    }}
                    numberOfLines={1}
                  >
                    {activeStoreName ?? "—"}
                  </Text>

                  <View
                    style={{
                      width: 3,
                      height: 3,
                      borderRadius: 2,
                      backgroundColor: "#94A3B8",
                    }}
                  />

                  <Text
                    style={{
                      color: theme.colors.muted,
                      fontWeight: "800",
                      fontSize: 10,
                    }}
                    numberOfLines={1}
                  >
                    {activeRole ?? "—"}
                  </Text>
                </View>
              </View>
            </View>

            {/* PRODUCT MODE */}
            <View
              style={{
                flex: 0.85,
                minWidth: 260,
                minHeight: 68,
                borderWidth: 1,
                borderColor:
                  isCapitalRecoveryStore || isPrecisionRetailStore
                    ? theme.colors.emeraldBorder
                    : "rgba(148,163,184,0.24)",
                borderRadius: 11,
                backgroundColor:
                  isCapitalRecoveryStore || isPrecisionRetailStore
                    ? "rgba(16,185,129,0.055)"
                    : "#FFFFFF",
                paddingHorizontal: 13,
                paddingVertical: 9,
                flexDirection: "row",
                alignItems: "center",
                gap: 11,
              }}
            >
              <View
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 10,
                  backgroundColor: "rgba(245,158,11,0.11)",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <WebSafeIcon
                  name="cube-outline"
                  size={19}
                  color="#D97706"
                />
              </View>

              <View style={{ flex: 1, minWidth: 0 }}>
                <Text
                  style={{
                    color: theme.colors.muted,
                    fontWeight: "900",
                    fontSize: 9,
                    textTransform: "uppercase",
                  }}
                >
                  {uiText("Product Mode")}</Text>

                <Text
                  style={{
                    color: theme.colors.text,
                    fontWeight: "900",
                    fontSize: 12,
                    marginTop: 3,
                  }}
                  numberOfLines={1}
                >
                  {isCapitalRecoveryStore
                    ? uiText("Capital Recovery Product Mode")
                    : isPrecisionRetailStore
                    ? uiText("Precision Retail Product Mode")
                    : uiText("Standard Product Mode")}
                </Text>

                <Text
                  style={{
                    color: theme.colors.muted,
                    fontWeight: "700",
                    fontSize: 9,
                    marginTop: 3,
                  }}
                  numberOfLines={1}
                >
                  {isCapitalRecoveryStore
                    ? uiText("Income-focused products")
                    : isPrecisionRetailStore
                    ? uiText("Pack-to-unit precision products")
                    : uiText("Standard inventory products")}
                </Text>
              </View>
            </View>
          </View>

          {/* SEARCH / REFRESH */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
              width: "100%",
            }}
          >
            <View
              style={{
                flex: 1,
                height: 40,
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.28)",
                borderRadius: 9,
                backgroundColor: "#FFFFFF",
                paddingHorizontal: 11,
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
              }}
            >
              <WebSafeIcon
                name="search"
                size={17}
                color={theme.colors.muted}
              />

              <TextInput
                value={productSearch}
                onChangeText={setProductSearch}
                onFocus={() => setProductSearchFocused(true)}
                onBlur={() => setProductSearchFocused(false)}
                placeholder={uiText("Search name, SKU, category...")}
                placeholderTextColor={theme.colors.faint}
                autoCorrect={false}
                autoCapitalize="none"
                style={{
                  flex: 1,
                  color: theme.colors.text,
                  fontWeight: "800",
                  fontSize: 11,
                  paddingVertical: 7,
                  outlineStyle: "none" as any,
                }}
              />

              {!!productSearch.trim() && (
                <Pressable
                  onPress={() => setProductSearch("")}
                  hitSlop={8}
                >
                  <WebSafeIcon
                    name="close-circle"
                    size={18}
                    color={theme.colors.muted}
                  />
                </Pressable>
              )}
            </View>

            <Pressable
              onPress={load}
              disabled={loading}
              style={({ pressed }) => ({
                width: 40,
                height: 40,
                borderRadius: 9,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.28)",
                backgroundColor: pressed
                  ? "#F1F5F9"
                  : "#FFFFFF",
                opacity: loading ? 0.55 : 1,
              })}
            >
              <WebSafeIcon
                name="refresh"
                size={19}
                color={theme.colors.text}
              />
            </Pressable>
          </View>
        </View>
      ) : (
        <>
      {/* PRODUCT_ORG_COMPACT_V1 */}
      <Card
        style={{
          width: "100%",
          minWidth: 0,
          alignSelf: "stretch",
          paddingHorizontal: 16,
          paddingVertical: 14,
          gap: 11,
          borderRadius: 20,
          borderWidth: 1,
          borderColor: "rgba(148,163,184,0.22)",
          backgroundColor: "#FFFFFF",
        }}
      >
        <View style={{ display: (productSearchFocused || productSearch.trim().length > 0) ? "none" : "flex", gap: 11 }}>
        <View style={{ minWidth: 0, gap: 3 }}>
          <Text
            style={{
              color: theme.colors.muted,
              fontSize: 11,
              fontWeight: "800",
            }}
          >
            {uiText("Organization")}</Text>
          <Text
            style={{
              color: theme.colors.text,
              fontSize: 17,
              lineHeight: 23,
              fontWeight: "900",
              flexShrink: 1,
            }}
          >
            {activeOrgName ?? uiText("Not selected")}
          </Text>
        </View>

        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            alignItems: "flex-start",
            gap: 12,
            minWidth: 0,
          }}
        >
          <View style={{ flex: 1, minWidth: 148, gap: 3 }}>
            <Text
              style={{
                color: theme.colors.muted,
                fontWeight: "800",
                fontSize: 11,
              }}
            >
              {uiText("Active Store")}</Text>
            <Text
              style={{
                color: theme.colors.text,
                fontWeight: "800",
                fontSize: 14,
                lineHeight: 20,
                flexShrink: 1,
              }}
            >
              {activeStoreName ?? uiText("Not selected")}
            </Text>
          </View>

          <View
            style={{
              minWidth: 78,
              maxWidth: 120,
              gap: 3,
            }}
          >
            <Text
              style={{
                color: theme.colors.muted,
                fontWeight: "800",
                fontSize: 11,
              }}
            >
              {uiText("Role")}</Text>
            <Text
              style={{
                color: theme.colors.text,
                fontWeight: "800",
                fontSize: 14,
                lineHeight: 20,
                flexShrink: 1,
              }}
            >
              {activeRole ?? "-"}
            </Text>
          </View>
        </View>

        <View
          style={{
            minWidth: 0,
            paddingHorizontal: 12,
            paddingVertical: 10,
            gap: 4,
            borderRadius: 14,
            borderWidth: 1,
            borderColor:
              isCapitalRecoveryStore || isPrecisionRetailStore
                ? theme.colors.emeraldBorder
                : "rgba(148,163,184,0.20)",
            backgroundColor:
              isCapitalRecoveryStore || isPrecisionRetailStore
                ? "rgba(16,185,129,0.07)"
                : "#F8FAFC",
          }}
        >
          <Text
            style={{
              color: theme.colors.text,
              fontSize: 14,
              lineHeight: 20,
              fontWeight: "900",
              flexShrink: 1,
            }}
          >
            {isCapitalRecoveryStore
              ? uiText("Capital Recovery Product Mode")
              : isPrecisionRetailStore
              ? uiText("Precision Retail Product Mode")
              : uiText("Standard Product Mode")}
          </Text>

          <Text
            style={{
              color: theme.colors.muted,
              fontSize: 12,
              lineHeight: 18,
              fontWeight: "600",
              flexShrink: 1,
            }}
          >
            {isCapitalRecoveryStore
              ? uiText("Sajili bidhaa za mapato. Taarifa za stock, barcode na gharama hazitumiki kwenye mode hii.")
              : isPrecisionRetailStore
              ? uiText("Sajili bidhaa kwa pakiti au jumla na ufuatilie vipimo vidogo kwa bei na gharama sahihi.")
              : uiText("Sajili bidhaa za kawaida pamoja na bei, gharama, barcode na taarifa nyingine.")}
          </Text>
        </View>

        </View>
        <View style={{ flexDirection: "row", gap: 10, marginTop: 2, alignItems: "center" }}>
  <View style={{ flex: 1 }}>
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
        borderWidth: 1,
        borderColor: theme.colors.emeraldBorder,
        borderRadius: theme.radius.lg,
        backgroundColor: "rgba(16,185,129,0.10)",
        paddingHorizontal: 14,
        minHeight: isDesktopWeb ? 44 : 54,
      }}
    >
      <WebSafeIcon name="search" size={18} color={theme.colors.muted} />
      <TextInput
        value={productSearch}
        onChangeText={setProductSearch}
        onFocus={() => setProductSearchFocused(true)}
        onBlur={() => setProductSearchFocused(false)}
        placeholder={uiText("Search name, SKU, category...")}
        placeholderTextColor={theme.colors.faint}
        autoCorrect={false}
        autoCapitalize="none"
        style={{
          flex: 1,
          color: theme.colors.text,
          fontWeight: "900",
          paddingVertical: isDesktopWeb ? 8 : 12,
        }}
      />
      {!!productSearch.trim() && (
        <Pressable onPress={() => setProductSearch("")} hitSlop={10}>
          <WebSafeIcon name="close-circle" size={20} color={theme.colors.muted} />
        </Pressable>
      )}
    </View>
  </View>

  <Pressable
    onPress={load}
    disabled={loading}
    style={({ pressed }) => ({
      width: isDesktopWeb ? 46 : 58,
      height: isDesktopWeb ? 44 : 54,
      borderRadius: theme.radius.lg,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: theme.colors.emeraldBorder,
      backgroundColor: theme.colors.emeraldSoft,
      opacity: loading ? 0.55 : pressed ? 0.88 : 1,
    })}
  >
    <WebSafeIcon
      name="refresh"
      size={22}
      color={theme.colors.text}
    />
  </Pressable>
</View>
      </Card>


        </>
      )}
      {!!error && (
        <Card
          style={{
            borderColor: theme.colors.dangerBorder,
            backgroundColor: theme.colors.dangerSoft,
          }}
        >
          <Text style={{ color: theme.colors.danger, fontWeight: "900" }}>{systemText(error)}</Text>
        </Card>
      )}

      {canManage && !(productSearchFocused || productSearch.trim().length > 0) && (
        <Card
  style={{
    width: "100%",
    minWidth: 0,
    alignSelf: "stretch",
    gap: isDesktopWeb ? 12 : 16,
    paddingHorizontal: isDesktopWeb ? 16 : 16,
    paddingVertical: isDesktopWeb ? 16 : 20,
    borderRadius: isDesktopWeb ? 18 : 24,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.22)",
    backgroundColor: "#FFFFFF",
    marginTop: isDesktopWeb ? 0 : 10,
    marginBottom: isDesktopWeb ? 12 : 18,
  }}
>
          <Text
            style={{
              color: theme.colors.text,
              fontWeight: "900",
              fontSize: isDesktopWeb ? 16 : 18,
              lineHeight: isDesktopWeb ? 23 : 26,
              marginBottom: isDesktopWeb ? 2 : 4,
              flexShrink: 1,
            }}
          >
            {isCapitalRecoveryStore ? uiText("Add Income Product") : uiText("Add Product")}
          </Text>

          <TextInput
            value={name}
            onChangeText={setName}
            placeholder={uiText("Product name")}
            placeholderTextColor={theme.colors.faint}
            style={{
              borderWidth: 1,
              borderColor: theme.colors.border,
              borderRadius: theme.radius.lg,
              backgroundColor: "#FFFFFF",
              paddingHorizontal: 14,
              paddingVertical: isDesktopWeb ? 8 : 12,
              color: theme.colors.text,
              fontWeight: "800",
            }}
          />

                    {/* DESKTOP PRODUCT IDENTITY GRID 4B */}
          <View
            style={{
              flexDirection: isDesktopWeb ? "row" : "column",
              alignItems: "flex-start",
              gap: isDesktopWeb ? 8 : 12,
              width: "100%",
            }}
          >
            <View
              style={{
                flex: isDesktopWeb ? 1.15 : undefined,
                minWidth: 0,
                width: isDesktopWeb ? undefined : "100%",
              }}
            >{!isCapitalRecoveryStore && (
            <View style={{ flexDirection: "row", gap: isDesktopWeb ? 8 : 10 }}>
              <View style={{ flex: 1 }}>
                <TextInput
                  value={sku}
                  onChangeText={setSku}
                  placeholder={uiText("SKU (optional)")}
                  placeholderTextColor={theme.colors.faint}
                  style={{
                    borderWidth: 1,
                    borderColor: theme.colors.border,
                    borderRadius: theme.radius.lg,
                    backgroundColor: "#FFFFFF",
                    paddingHorizontal: 14,
                    paddingVertical: isDesktopWeb ? 9 : 12,
                    color: theme.colors.text,
                    fontWeight: "800",
                  }}
                />
              </View>

              <View style={{ flex: 1 }}>
                <TextInput
                  value={unit}
                  onChangeText={setUnit}
                  placeholder={uiText("Unit (optional)")}
                  placeholderTextColor={theme.colors.faint}
                  style={{
                    borderWidth: 1,
                    borderColor: theme.colors.border,
                    borderRadius: theme.radius.lg,
                    backgroundColor: "#FFFFFF",
                    paddingHorizontal: 14,
                    paddingVertical: isDesktopWeb ? 9 : 12,
                    color: theme.colors.text,
                    fontWeight: "800",
                  }}
                />
              </View>
            </View>
          )}
            </View>

            <View
              style={{
                flex: isDesktopWeb ? 0.85 : undefined,
                minWidth: 0,
                width: isDesktopWeb ? undefined : "100%",
                position: "relative",
                zIndex: 30,
              }}
            ><View style={{ position: "relative", zIndex: 30 }}>
  <View
    style={{
      flexDirection: "row",
      alignItems: "center",
      borderWidth: 1,
      borderColor: categoryDropdownOpen
        ? theme.colors.emeraldBorder
        : theme.colors.border,
      borderRadius: theme.radius.lg,
      backgroundColor: "#FFFFFF",
      paddingRight: 12,
    }}
  >
    <TextInput
      value={category}
      onChangeText={(text) => {
        setCategory(text);
        setCategoryDropdownOpen(true);
      }}
      onFocus={() => {
        setCategoryDropdownOpen(true);

        // Refresh categories unapofungua field.
        if (!categoriesLoading) {
          void loadStoreCategories();
        }
      }}
      placeholder={uiText("Category (optional)")}
      placeholderTextColor={theme.colors.faint}
      autoCorrect={false}
      style={{
        flex: 1,
        paddingHorizontal: 14,
        paddingVertical: isDesktopWeb ? 9 : 12,
        color: theme.colors.text,
        fontWeight: "800",
      }}
    />

    <Pressable
      onPress={() => {
        setCategoryDropdownOpen((current) => !current);

        if (!categoryDropdownOpen && !categoriesLoading) {
          void loadStoreCategories();
        }
      }}
      hitSlop={8}
      style={{
        width: isDesktopWeb ? 32 : 34,
        height: isDesktopWeb ? 32 : 34,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <WebSafeIcon
        name={categoryDropdownOpen ? "chevron-up" : "chevron-down"}
        size={20}
        color={theme.colors.muted}
      />
    </Pressable>
  </View>

  {categoryDropdownOpen && (
    <View
      style={{
        marginTop: 6,
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: 16,
        backgroundColor: "#FFFFFF",
        overflow: "hidden",

        shadowColor: "#0F172A",
        shadowOpacity: Platform.OS === "android" ? 0 : 0.12,
        shadowRadius: Platform.OS === "android" ? 0 : 14,
        shadowOffset: { width: 0, height: 8 },
        elevation: 6,
      }}
    >
      {categoriesLoading ? (
        <View
          style={{
            paddingHorizontal: 14,
            paddingVertical: 14,
          }}
        >
          <Text
            style={{
              color: theme.colors.muted,
              fontWeight: "800",
            }}
          >
            {uiText("Loading categories...")}</Text>
        </View>
      ) : filteredCategorySuggestions.length > 0 ? (
        <ScrollView
          style={{
            maxHeight: isDesktopWeb ? 180 : 220,
          }}
          keyboardShouldPersistTaps="always"
          nestedScrollEnabled
          showsVerticalScrollIndicator
        >
          {filteredCategorySuggestions.map((item, index) => (
            <Pressable
              key={`${item}-${index}`}
              onPress={() => {
                setCategory(item);
                setCategoryDropdownOpen(false);
              }}
              style={({ pressed }) => ({
                paddingHorizontal: 14,
                paddingVertical: 13,
                backgroundColor: pressed
                  ? "rgba(16,185,129,0.10)"
                  : "#FFFFFF",
                borderBottomWidth:
                  index < filteredCategorySuggestions.length - 1 ? 1 : 0,
                borderBottomColor: "rgba(148,163,184,0.16)",
              })}
            >
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "800",
                }}
              >
                {item}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      ) : (
        <View
          style={{
            paddingHorizontal: 14,
            paddingVertical: 14,
          }}
        >
          <Text
            style={{
              color: theme.colors.muted,
              fontWeight: "800",
              lineHeight: 20,
            }}
          >
            {category.trim()
              ? uiText("\"{p0}\" haipo bado. Endelea kuandika kuitengeneza kama category mpya.", {p0: (category.trim())})
              : uiText("Hakuna category iliyopatikana kwenye store hii bado.")}
          </Text>
        </View>
      )}
    </View>
  )}
</View>
            </View>
          </View>
{/* DESKTOP ADD PRODUCT LOWER GRID */}
          <View
            style={{
              flexDirection: isDesktopWeb ? "row" : "column",
              alignItems: "stretch",
              gap: isDesktopWeb ? 12 : 8,
              width: "100%",
            }}
          >
<View style={{ flex: 1, minWidth: 0, gap: 8 }}>
            <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Product Image (optional)")}</Text>

            <Pressable
              onPress={() => chooseImageSource("add")}
              disabled={imageUploading || loading}
              style={({ pressed }) => ({
                minHeight: isDesktopWeb ? 70 : 86,
                borderRadius: 22,
                borderWidth: 1,
                borderColor: imageUrl ? theme.colors.emeraldBorder : theme.colors.border,
                backgroundColor: imageUrl ? "#ECFDF5" : "#F8FAFC",
                padding: 12,
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                opacity: imageUploading || loading ? 0.6 : pressed ? 0.9 : 1,
              })}
            >
              {imageUrl ? (
              <Image
  source={{ uri: imageUrl }}
  style={{
    width: 62,
    height: 62,
    borderRadius: 18,
    backgroundColor: "#E2E8F0",
  }}
  resizeMode="cover"
  resizeMethod={
    Platform.OS === "android" ? "resize" : undefined
  }
  fadeDuration={
    Platform.OS === "android" ? 0 : undefined
  }
/>
              ) : (
                <View
                  style={{
                    width: 62,
                    height: 62,
                    borderRadius: 18,
                    backgroundColor: "rgba(16,185,129,0.10)",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <WebSafeIcon name="image-outline" size={28} color={theme.colors.text} />
                </View>
              )}

              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
                  {imageUploading ? uiText("Uploading image...") : imageUrl ? uiText("Product image selected") : uiText("Add product photo")}
                </Text>
                <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 4 }}>
                  {uiText("Camera au Gallery/File")}</Text>
              </View>
            </Pressable>

            {!!imageUrl && (
              <Pressable onPress={() => setImageUrl("")} disabled={loading}>
                <Text style={{ color: "#B91C1C", fontWeight: "900" }}>{uiText("Remove image")}</Text>
              </Pressable>
            )}
          </View>

          {!isCapitalRecoveryStore && (
            <View style={{ flex: 1, minWidth: 0, gap: 8 }}>
              <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Barcode (optional)")}</Text>

            <View style={{ flexDirection: "row", gap: 10, alignItems: "center" }}>
              <View style={{ flex: 1 }}>
                <TextInput
                  value={barcode}
                  onChangeText={(t) => setBarcode(cleanBarcode(t))}
                  placeholder={uiText("Scan or type barcode")}
                  placeholderTextColor={theme.colors.faint}
                  style={{
                    borderWidth: 1,
                    borderColor: theme.colors.border,
                    borderRadius: theme.radius.lg,
                    backgroundColor: "#FFFFFF",
                    paddingHorizontal: 14,
                    paddingVertical: isDesktopWeb ? 8 : 12,
                    color: theme.colors.text,
                    fontWeight: "900",
                  }}
                />
              </View>

              <Pressable
                onPress={openScan}
                disabled={loading}
                style={({ pressed }) => ({
                  width: isDesktopWeb ? 42 : 62,
                  height: isDesktopWeb ? 42 : 62,
                  borderRadius: 999,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: theme.colors.emeraldBorder,
                  backgroundColor: theme.colors.emeraldSoft,
                  opacity: loading ? 0.55 : pressed ? 0.92 : 1,
                  transform: pressed ? [{ scale: 0.995 }] : [{ scale: 1 }],
                })}
              >
                <View style={{ marginLeft: 1, marginTop: 1 }}>
                  <ScannerFabIcon size={28} color={theme.colors.text} />
                </View>
              </Pressable>

              {!!barcode && (
                <Pressable
                  onPress={() => setBarcode("")}
                  disabled={loading}
                  style={({ pressed }) => ({
                    width: 52,
                    height: 52,
                    borderRadius: 999,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 1,
                    borderColor: theme.colors.border,
                    backgroundColor: "rgba(255,255,255,0.06)",
                    opacity: loading ? 0.55 : pressed ? 0.92 : 1,
                    transform: pressed ? [{ scale: 0.995 }] : [{ scale: 1 }],
                  })}
                >
                  <WebSafeIcon name="close" size={20} color={theme.colors.text} />
                </Pressable>
              )}
            </View>

            <Text style={{ color: theme.colors.faint, fontWeight: "800" }}>
                {uiText("Tip: Scan barcode ili iwe fast kama supermarket.")}</Text>
            </View>
          )}

                 </View>

{isPrecisionRetailStore && canSeeCost && (
  <Card
    style={{
      gap: 10,
      borderRadius: 22,
      borderColor: "rgba(52,211,153,0.30)",
      backgroundColor: "rgba(16,185,129,0.07)",
      shadowOpacity: 0.06,
      shadowRadius: 12,
      elevation: 2,
    }}
  >
    <Pressable
      onPress={() => setPrecisionCalcOpen((v) => !v)}
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 10,
      }}
    >
            <View style={{ flex: 1 }}>
  <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
    {uiText("Unit & Pack Calculator")}</Text>
  <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 3 }}>
    {uiText("Auto calculate unit cost/selling")}</Text>
</View>

<WebSafeIcon
  name={precisionCalcOpen ? "chevron-up" : "chevron-down"}
  size={22}
  color={theme.colors.text}
/>
</Pressable>

{precisionCalcOpen && (
  <>

<Text style={{ color: theme.colors.muted, fontWeight: "800", lineHeight: 19 }}>
  {uiText("Mfano: Box, carton, dozen, sack au pack inaweza kugawanywa kwenye unit ndogo. Mfumo utapata cost/selling ya unit moja automatic.")}</Text>

          <View style={{ flexDirection: "row", gap: 10 }}>
  <View style={{ flex: 1.15 }}>
    <TextInput
      value={precisionPackQty}
      onChangeText={(t) => setPrecisionPackQty(normalizeDecimalInput(t))}
      placeholder={uiText("Pack size e.g. 100")}
      keyboardType="numeric"
      placeholderTextColor={theme.colors.faint}
      style={[
        solidInputStyle,
        {
          fontSize: 13,
          backgroundColor: "#FFFFFF",
        },
      ]}
    />
  </View>

  <View style={{ flex: 1 }}>
    <TextInput
      value={precisionUnit}
      onChangeText={setPrecisionUnit}
      placeholder={uiText("Unit e.g. tablet")}
      placeholderTextColor={theme.colors.faint}
      style={[
        solidInputStyle,
        {
          fontSize: 13,
          backgroundColor: "#ECFDF5",
          borderColor: theme.colors.emeraldBorder,
          color: theme.colors.text,
          fontWeight: "900",
        },
      ]}
    />
  </View>
</View>

              <TextInput
                value={precisionPackCost}
                onChangeText={(t) => setPrecisionPackCost(normalizeDecimalInput(t))}
                placeholder={uiText("Buying/Cost price ya box/pack")}
                keyboardType="numeric"
                placeholderTextColor={theme.colors.faint}
                style={solidInputStyle}
              />

              <TextInput
                value={precisionPackSelling}
                onChangeText={(t) => setPrecisionPackSelling(normalizeDecimalInput(t))}
                placeholder={uiText("Selling price ya box/pack")}
                keyboardType="numeric"
                placeholderTextColor={theme.colors.faint}
                style={solidInputStyle}
              />

              <Button
                title={uiText("Calculate Per Unit Price")}
                onPress={applyPrecisionFormula}
                disabled={loading}
                variant="secondary"
              />

              <Text style={{ color: theme.colors.faint, fontWeight: "800" }}>
  {uiText("Baada ya calculate, Cost Price na Selling Price chini zitajazwa kama bei ya unit moja.")}</Text>
</>
)}
            </Card>
          )}

        <View
          style={{
            flexDirection: isDesktopWeb ? "row" : "column",
            gap: isDesktopWeb ? 12 : 8,
            width: "100%",
          }}
        >
          <View style={{ flex: 1, minWidth: 0 }}>
        {canSeeCost && (
            <TextInput
              value={costPrice}
              onChangeText={(t) => setCostPrice(normalizeDecimalInput(t))}
              placeholder={uiText("Cost Price (optional)")}
              keyboardType="numeric"
              placeholderTextColor={theme.colors.faint}
              style={{
                borderWidth: 1,
                borderColor: theme.colors.border,
                borderRadius: theme.radius.lg,
                backgroundColor: "#FFFFFF",
                paddingHorizontal: 14,
                paddingVertical: isDesktopWeb ? 8 : 12,
                color: theme.colors.text,
                fontWeight: "800",
              }}
            />
          )}
          </View>

          <View style={{ flex: 1, minWidth: 0 }}>
<TextInput
            value={sellingPrice}
            onChangeText={(t) => setSellingPrice(normalizeDecimalInput(t))}
            placeholder={isCapitalRecoveryStore ? uiText("Selling Price") : uiText("Selling Price (optional)")}
            keyboardType="numeric"
            placeholderTextColor={theme.colors.faint}
            style={{
              borderWidth: 1,
              borderColor: theme.colors.border,
              borderRadius: theme.radius.lg,
              backgroundColor: "#FFFFFF",
              paddingHorizontal: 14,
              paddingVertical: isDesktopWeb ? 8 : 12,
              color: theme.colors.text,
              fontWeight: "800",
            }}
          />
          </View>
        </View>

       <Pressable
  onPress={add}
  disabled={loading}
  style={({ pressed }) => ({
    minHeight: isDesktopWeb ? 46 : 58,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: loading ? "rgba(16,185,129,0.45)" : "#059669",
    opacity: pressed ? 0.9 : 1,
    shadowColor: "#059669",
    shadowOpacity: 0.22,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 4,
  })}
>
  <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 16 }}>
    {loading ? uiText("Saving...") : isCapitalRecoveryStore ? uiText("Add Income Product") : uiText("Add Product")}
  </Text>
</Pressable>

          <Modal
            visible={scanOpen}
            animationType="fade"
            transparent
            presentationStyle="overFullScreen"
            statusBarTranslucent
            onRequestClose={closeScan}
          >
            <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.82)" }}>
              <View style={{ padding: 16, paddingTop: 18, gap: 10 }}>
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                  <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 18 }}>{uiText("Scan Barcode")}</Text>

                  <Pressable
                    onPress={closeScan}
                    hitSlop={10}
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 999,
                      alignItems: "center",
                      justifyContent: "center",
                      borderWidth: 1,
                      borderColor: "rgba(255,255,255,0.12)",
                      backgroundColor: "rgba(255,255,255,0.06)",
                    }}
                  >
                    <WebSafeIcon name="close" size={22} color={theme.colors.text} />
                  </Pressable>
                </View>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Elekeza camera kwenye barcode. Itajaza moja kwa moja.")}</Text>
              </View>

              <View style={{ flex: 1, paddingHorizontal: 16, paddingBottom: 18 }}>
                <View
                  style={{
                    flex: 1,
                    borderRadius: 18,
                    overflow: "hidden",
                    borderWidth: 1,
                    borderColor: "rgba(255,255,255,0.12)",
                    backgroundColor: "rgba(255,255,255,0.04)",
                  }}
                >
                  <CameraView
                    style={{ flex: 1 }}
                    facing="back"
                    onBarcodeScanned={onBarcodeScanned}
                    barcodeScannerSettings={{
                      barcodeTypes: [
                        "ean13",
                        "ean8",
                        "upc_a",
                        "upc_e",
                        "code128",
                        "code39",
                        "itf14",
                        "qr",
                        "pdf417",
                        "aztec",
                        "datamatrix",
                      ],
                    }}
                  />

                  <View
                    pointerEvents="none"
                    style={{
                      position: "absolute",
                      left: 18,
                      right: 18,
                      top: "32%",
                      height: 140,
                      borderRadius: 16,
                      borderWidth: 2,
                      borderColor: "rgba(52,211,153,0.55)",
                      backgroundColor: "rgba(0,0,0,0.05)",
                    }}
                  />
                </View>

                <View style={{ marginTop: 12, gap: 10 }}>
                  <Card style={{ gap: 6 }}>
                    <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("Last scanned")}</Text>
                    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{barcode ? barcode : "—"}</Text>
                    <Text style={{ color: theme.colors.faint, fontWeight: "800" }}>
                      {uiText("Ukiscan, modal itajifunga na barcode itaingia kwenye form.")}</Text>
                  </Card>

                  <Button title={uiText("Close")} onPress={closeScan} variant="secondary" />
                </View>
              </View>
            </View>
          </Modal>
        </Card>
      )}


      {/* PRODUCTS DESKTOP TABLE 5B */}
      {isDesktopWeb ? (
        <View style={{ marginTop: 2, gap: 8 }}>

          {/* DESKTOP PRODUCTS TITLE / CATALOG */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
            }}
          >
            <View style={{ gap: 2 }}>
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "900",
                  fontSize: 18,
                }}
              >
                {isCapitalRecoveryStore
                  ? uiText("Income Products ({p0})", {p0: (visibleRows.length)})
                  : uiText("My Products ({p0})", {p0: (visibleRows.length)})}
              </Text>

              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "700",
                  fontSize: 10,
                }}
              >
                {uiText(visibleRows.length === 1 ? "{p0} active item" : "{p0} active items", {p0: visibleRows.length})}
              </Text>
            </View>

            {canManage && !isCapitalRecoveryStore && !(productSearchFocused || productSearch.trim().length > 0) && (
              <Pressable
                onPress={() => router.push("/catalog" as any)}
                style={({ pressed }) => ({
                  width: 340,
                  minHeight: 58,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: pressed
                    ? "rgba(5,150,105,0.38)"
                    : "rgba(5,150,105,0.22)",
                  backgroundColor: pressed
                    ? "#ECFDF5"
                    : "#F8FFFC",
                  paddingHorizontal: 10,
                  paddingVertical: 8,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 10,
                  opacity: pressed ? 0.94 : 1,
                  shadowColor: "#059669",
                  shadowOpacity: 0.06,
                  shadowRadius: 10,
                  shadowOffset: {
                    width: 0,
                    height: 4,
                  },
                })}
              >
                <View
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: 10,
                    backgroundColor: "#059669",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  <View
                    style={{
                      position: "relative",
                      width: 24,
                      height: 24,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <WebSafeIcon
                      name="grid-outline"
                      size={19}
                      color="#FFFFFF"
                    />

                    <View
                      style={{
                        position: "absolute",
                        right: -3,
                        bottom: -3,
                        width: 12,
                        height: 12,
                        borderRadius: 999,
                        backgroundColor: "#D1FAE5",
                        borderWidth: 1.5,
                        borderColor: "#059669",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <WebSafeIcon
                        name="search"
                        size={7}
                        color="#047857"
                      />
                    </View>
                  </View>
                </View>

                <View
                  style={{
                    flex: 1,
                    minWidth: 0,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 7,
                      minWidth: 0,
                    }}
                  >
                    <Text
                      style={{
                        color: "#0F172A",
                        fontWeight: "900",
                        fontSize: 12.5,
                      }}
                      numberOfLines={1}
                    >
                      {uiText("Product Catalog")}</Text>

                    <View
                      style={{
                        borderRadius: 999,
                        backgroundColor: "#D1FAE5",
                        borderWidth: 1,
                        borderColor: "rgba(5,150,105,0.18)",
                        paddingHorizontal: 6,
                        paddingVertical: 2,
                      }}
                    >
                      <Text
                        style={{
                          color: "#047857",
                          fontWeight: "900",
                          fontSize: 7.5,
                          letterSpacing: 0.35,
                        }}
                      >
                        {uiText("GLOBAL LIBRARY")}</Text>
                    </View>
                  </View>

                  <Text
                    style={{
                      color: "#64748B",
                      fontWeight: "700",
                      fontSize: 9.5,
                      marginTop: 2,
                    }}
                    numberOfLines={1}
                  >
                    {uiText("Search • Import • Share")}</Text>
                </View>

                <View
                  style={{
                    minWidth: 54,
                    height: 30,
                    borderRadius: 8,
                    backgroundColor: "#FFFFFF",
                    borderWidth: 1,
                    borderColor: "rgba(5,150,105,0.20)",
                    paddingHorizontal: 8,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 3,
                    flexShrink: 0,
                  }}
                >
                  <Text
                    style={{
                      color: "#047857",
                      fontWeight: "900",
                      fontSize: 9.5,
                    }}
                  >
                    {uiText("Open")}</Text>

                  <WebSafeIcon
                    name="arrow-forward"
                    size={12}
                    color="#059669"
                  />
                </View>
              </Pressable>
            )}
          </View>

          {visibleRows.length === 0 ? (
            <View
              style={{
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.24)",
                borderRadius: 10,
                backgroundColor: "#FFFFFF",
                paddingHorizontal: 14,
                paddingVertical: 16,
              }}
            >
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "900",
                  fontSize: 12,
                }}
              >
                {productSearch.trim()
                  ? uiText("No matching products")
                  : isCapitalRecoveryStore
                  ? uiText("No income products yet")
                  : uiText("No products yet")}
              </Text>

              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "700",
                  fontSize: 10,
                  marginTop: 4,
                }}
              >
                {productSearch.trim()
                  ? uiText("Change or clear the search to see other products.")
                  : canManage
                  ? uiText("Add a product above, then refresh.")
                  : uiText("Ask the owner to add or update products.")}
              </Text>
            </View>
          ) : (
            <View
              style={{
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.24)",
                borderRadius: 10,
                backgroundColor: "#FFFFFF",
                overflow: "hidden",
              }}
            >

              {/* TABLE HEADER */}
              <View
                style={{
                  minHeight: 34,
                  flexDirection: "row",
                  alignItems: "center",
                  paddingHorizontal: 10,
                  backgroundColor: "#F1F5F9",
                  borderBottomWidth: 1,
                  borderBottomColor: "rgba(148,163,184,0.22)",
                }}
              >
                <Text
                  style={{
                    width: 52,
                    color: "#0F766E",
                    fontWeight: "900",
                    fontSize: 12,
                  }}
                >
                  {uiText("Image")}</Text>

                <Text
                  style={{
                    flex: 1.55,
                    color: "#0F172A",
                    fontWeight: "900",
                    fontSize: 12,
                  }}
                >
                  {uiText("Name")}</Text>

                {!isCapitalRecoveryStore && (
                  <Text
                    style={{
                      flex: 0.8,
                      color: "#2563EB",
                      fontWeight: "900",
                      fontSize: 12,
                    }}
                  >
                    SKU
                  </Text>
                )}

                <Text
                  style={{
                    flex: 0.9,
                    color: "#4F46E5",
                    fontWeight: "900",
                    fontSize: 12,
                  }}
                >
                  {uiText("Category")}</Text>

                {!isCapitalRecoveryStore && (
                  <Text
                    style={{
                      flex: 0.6,
                      color: "#0369A1",
                      fontWeight: "900",
                      fontSize: 12,
                    }}
                  >
                    {uiText("Unit")}</Text>
                )}

                {canSeeCost && (
                  <Text
                    style={{
                      flex: 0.85,
                      color: "#B45309",
                      fontWeight: "900",
                      fontSize: 12,
                      textAlign: "right",
                    }}
                  >
                    {uiText("Cost Price")}</Text>
                )}

                <Text
                  style={{
                    flex: 0.85,
                    color: "#047857",
                    fontWeight: "900",
                    fontSize: 12,
                    textAlign: "right",
                  }}
                >
                  {uiText("Selling Price")}</Text>

                {canManage && (
                  <Text
                    style={{
                      width: 122,
                      color: "#1D4ED8",
                      fontWeight: "900",
                      fontSize: 12,
                      textAlign: "center",
                    }}
                  >
                    {uiText("Actions")}</Text>
                )}
              </View>

              {/* TABLE ROWS */}
              {/* DESKTOP SCROLLABLE PRODUCT ROWS */}
              <ScrollView
                ref={desktopProductsScrollRef}
                nestedScrollEnabled
                showsVerticalScrollIndicator
                keyboardShouldPersistTaps="always"
                style={{
                  maxHeight: 560,
                  minHeight: 0,
                }}
                contentContainerStyle={{
                  flexGrow: 0,
                }}
              >
              {renderedRows.map((p, rowIndex) => {
                const sp = Number(p.selling_price ?? 0);
                const cp = Number(p.cost_price ?? NaN);

                return (
                  <View
                    key={p.id}
                    onLayout={(event) => {
                      desktopProductRowYRef.current[
                        String(p.id)
                      ] = event.nativeEvent.layout.y;
                    }}
                    style={{
                      minHeight: 56,
                      flexDirection: "row",
                      alignItems: "center",
                      paddingHorizontal: 10,
                      borderBottomWidth:
                        rowIndex < renderedRows.length - 1
                          ? 1
                          : 0,
                      borderBottomColor:
                        highlightedProductId === String(p.id)
                          ? "#10B981"
                          : "rgba(148,163,184,0.16)",
                      backgroundColor:
                        highlightedProductId === String(p.id)
                          ? "#ECFDF5"
                          : "#FFFFFF",
                      borderLeftWidth:
                        highlightedProductId === String(p.id)
                          ? 4
                          : 0,
                      borderLeftColor: "#10B981",
                    }}
                  >

                    {/* IMAGE */}
                    <View
                      style={{
                        width: 52,
                        alignItems: "flex-start",
                        justifyContent: "center",
                      }}
                    >
                      {p.image_url ? (
                        <Image
                          source={{ uri: p.image_url }}
                          style={{
                            width: 38,
                            height: 38,
                            borderRadius: 7,
                            backgroundColor: "#E2E8F0",
                          }}
                          resizeMode="cover"
                        />
                      ) : (
                        <View
                          style={{
                            width: 38,
                            height: 38,
                            borderRadius: 7,
                            backgroundColor: "#F1F5F9",
                            borderWidth: 1,
                            borderColor:
                              "rgba(148,163,184,0.22)",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <WebSafeIcon
                            name="cube-outline"
                            size={15}
                            color={theme.colors.muted}
                          />
                        </View>
                      )}
                    </View>

                    {/* NAME */}
                    <View
                      style={{
                        flex: 1.55,
                        minWidth: 0,
                        paddingRight: 7,
                      }}
                    >
                      <Text
                        style={{
                          color: "#0F172A",
                          fontWeight: "900",
                          fontSize: 13,
                        }}
                        numberOfLines={1}
                      >
                        {p.name}
                      </Text>
                    </View>

                    {/* SKU */}
                    {!isCapitalRecoveryStore && (
                      <Text
                        style={{
                          flex: 0.8,
                          color: "#2563EB",
                          fontWeight: "800",
                          fontSize: 13,
                          paddingRight: 6,
                        }}
                        numberOfLines={1}
                      >
                        {p.sku ?? "—"}
                      </Text>
                    )}

                    {/* CATEGORY */}
                    <Text
                      style={{
                        flex: 0.9,
                        color: "#4F46E5",
                        fontWeight: "800",
                        fontSize: 13,
                        paddingRight: 6,
                      }}
                      numberOfLines={1}
                    >
                      {p.category ?? "—"}
                    </Text>

                    {/* UNIT */}
                    {!isCapitalRecoveryStore && (
                      <Text
                        style={{
                          flex: 0.6,
                          color: "#0369A1",
                          fontWeight: "800",
                          fontSize: 13,
                          paddingRight: 6,
                        }}
                        numberOfLines={1}
                      >
                        {p.unit ?? "—"}
                      </Text>
                    )}

                    {/* COST */}
                    {canSeeCost && (
                      <Text
                        style={{
                          flex: 0.85,
                          color: "#92400E",
                          fontWeight: "800",
                          fontSize: 13,
                          textAlign: "right",
                          paddingLeft: 4,
                        }}
                        numberOfLines={1}
                      >
                        {Number.isFinite(cp)
                          ? preferredMoney(cp)
                          : "—"}
                      </Text>
                    )}

                    {/* SELLING */}
                    <Text
                      style={{
                        flex: 0.85,
                        color: "#047857",
                        fontWeight: "900",
                        fontSize: 13,
                        textAlign: "right",
                        paddingLeft: 4,
                      }}
                      numberOfLines={1}
                    >
                      {sp > 0 ? preferredMoney(sp) : "—"}
                    </Text>

                    {/* ACTIONS */}
                    {canManage && (
                      <View
                        style={{
                          width: 122,
                          flexDirection: "row",
                          alignItems: "center",
                          justifyContent: "flex-end",
                          gap: 5,
                          paddingLeft: 8,
                        }}
                      >
                        {desktopActionProductId === p.id ? (
                          <>
                            <Pressable
                              onPress={() => {
                                setDesktopActionProductId(null);
                                openEdit(p);
                              }}
                              disabled={loading}
                              style={({ pressed }) => ({
                                flex: 1,
                                height: 30,
                                borderRadius: 6,
                                backgroundColor: pressed
                                  ? "#1D4ED8"
                                  : "#2563EB",
                                alignItems: "center",
                                justifyContent: "center",
                                opacity: loading ? 0.5 : 1,
                              })}
                            >
                              <Text
                                style={{
                                  color: "#FFFFFF",
                                  fontWeight: "900",
                                  fontSize: 10,
                                }}
                              >
                                {uiText("Edit")}</Text>
                            </Pressable>

                            <Pressable
                              onPress={() => {
                                setDesktopActionProductId(null);
                                void remove(p.id, p.name);
                              }}
                              disabled={loading}
                              style={({ pressed }) => ({
                                flex: 1,
                                height: 30,
                                borderRadius: 6,
                                borderWidth: 1,
                                borderColor: "#FCA5A5",
                                backgroundColor: pressed
                                  ? "#FEF2F2"
                                  : "#FFFFFF",
                                alignItems: "center",
                                justifyContent: "center",
                                opacity: loading ? 0.5 : 1,
                              })}
                            >
                              <Text
                                style={{
                                  color: "#B91C1C",
                                  fontWeight: "900",
                                  fontSize: 10,
                                }}
                              >
                                {uiText("Delete")}</Text>
                            </Pressable>
                          </>
                        ) : (
                          <Pressable
                            onPress={() =>
                              setDesktopActionProductId(p.id)
                            }
                            disabled={loading}
                            style={({ pressed }) => ({
                              width: 86,
                              height: 30,
                              borderRadius: 7,
                              borderWidth: 1,
                              borderColor: "rgba(37,99,235,0.24)",
                              backgroundColor: pressed
                                ? "#EFF6FF"
                                : "#FFFFFF",
                              flexDirection: "row",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: 5,
                              opacity: loading ? 0.5 : 1,
                            })}
                          >
                            <Text
                              style={{
                                color: "#1D4ED8",
                                fontWeight: "900",
                                fontSize: 10,
                              }}
                            >
                              {uiText("Actions")}</Text>

                            <WebSafeIcon
                              name="chevron-down"
                              size={13}
                              color="#1D4ED8"
                            />
                          </Pressable>
                        )}
                      </View>
                    )}
                  </View>
                );
              })}
              </ScrollView>
            </View>
          )}

          {/* LOAD MORE */}
          {hasMoreProducts && (
            <Pressable
              onPress={loadMoreProducts}
              style={({ pressed }) => ({
                minHeight: 36,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: theme.colors.emeraldBorder,
                backgroundColor: pressed
                  ? "rgba(16,185,129,0.12)"
                  : "rgba(16,185,129,0.06)",
                alignItems: "center",
                justifyContent: "center",
                paddingHorizontal: 12,
              })}
            >
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "900",
                  fontSize: 11,
                }}
              >
                {uiText("Load More Products · Showing")}{" "}
                {renderedRows.length} {uiText("of")}{visibleRows.length}
              </Text>
            </Pressable>
          )}
        </View>
      ) : (
        <>
     <View style={{ marginTop: 4, gap: 12 }}>
  <View style={{ gap: 4 }}>
    <Text
      style={{
        fontWeight: "900",
        fontSize: 20,
        color: theme.colors.text,
      }}
    >
      {isCapitalRecoveryStore ? uiText("Income Products") : uiText("My Products")}
    </Text>

    <Text
      style={{
        color: theme.colors.muted,
        fontWeight: "800",
      }}
    >
      {uiText(visibleRows.length === 1 ? "{p0} active item" : "{p0} active items", {p0: visibleRows.length})}
    </Text>
  </View>

  {canManage && !isCapitalRecoveryStore && (
    <Pressable
      onPress={() => router.push("/catalog" as any)}
      style={({ pressed }) => ({
        width: "100%",
        borderRadius: 22,
        borderWidth: 1.5,
        borderColor: theme.colors.emeraldBorder,
        backgroundColor: pressed
          ? "rgba(16,185,129,0.14)"
          : "rgba(16,185,129,0.08)",
        paddingHorizontal: 16,
        paddingVertical: 16,
        flexDirection: "row",
        alignItems: "center",
        gap: 14,

        shadowColor: "#059669",
        shadowOpacity: Platform.OS === "android" ? 0 : 0.10,
        shadowRadius: Platform.OS === "android" ? 0 : 14,
        shadowOffset: { width: 0, height: 7 },
        elevation: Platform.OS === "android" ? 2 : 3,

        opacity: pressed ? 0.92 : 1,
      })}
    >
      <View
        style={{
          width: 52,
          height: 52,
          borderRadius: 16,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#059669",
        }}
      >
        <Ionicons
          name="albums-outline"
          size={25}
          color="#FFFFFF"
        />
      </View>

      <View style={{ flex: 1 }}>
        <Text
          style={{
            color: theme.colors.text,
            fontWeight: "900",
            fontSize: 18,
          }}
        >
          {uiText("Product Catalog")}</Text>

        <Text
          style={{
            color: theme.colors.muted,
            fontWeight: "800",
            fontSize: 13,
            lineHeight: 19,
            marginTop: 3,
          }}
        >
          {uiText("Import, share & manage product catalogs")}</Text>

        <Text
          style={{
            color: "#059669",
            fontWeight: "900",
            fontSize: 12,
            marginTop: 7,
          }}
        >
          {uiText("Global • Share • Import Code")}</Text>
      </View>

      <View
        style={{
          width: 38,
          height: 38,
          borderRadius: 999,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#FFFFFF",
          borderWidth: 1,
          borderColor: "rgba(16,185,129,0.24)",
        }}
      >
        <Ionicons
          name="chevron-forward"
          size={20}
          color="#059669"
        />
      </View>
    </Pressable>
  )}
</View>

{visibleRows.length === 0 ? (
  <Card>
    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
      {productSearch.trim()
        ? uiText("No matching products")
        : isCapitalRecoveryStore
        ? uiText("No income products yet")
        : uiText("No products yet")}
    </Text>

    <Text
      style={{
        color: theme.colors.muted,
        fontWeight: "700",
        marginTop: 6,
      }}
    >
      {productSearch.trim()
        ? uiText("Badili neno la search au futa search kuona bidhaa zote.")
        : canManage
        ? isCapitalRecoveryStore
          ? uiText("Ongeza bidhaa ya income juu kisha Refresh.")
          : uiText("Ongeza product juu kisha Refresh.")
        : uiText("Muombe owner aongeze au abadili products.")}
    </Text>
  </Card>
) : (
  <>
    {renderedRows.map((p) => {
      const sp = Number(p.selling_price ?? 0);
      const cp = Number(p.cost_price ?? NaN);
      const bc = String(p.barcode ?? "").trim();



    return (
  <View
    key={p.id}
    style={{
            borderWidth: 1,
            borderColor: "rgba(148,163,184,0.22)",
            borderRadius: 18,
            backgroundColor: "#FFFFFF",
            padding: 12,
            marginBottom: 8,

            // Web/iOS inaweza kubaki na shadow nzuri.
            // Android tunapunguza expensive shadow rendering.
            shadowColor: "#0F172A",
            shadowOpacity: Platform.OS === "android" ? 0 : 0.08,
            shadowRadius: Platform.OS === "android" ? 0 : 14,
            shadowOffset: { width: 0, height: 8 },
            elevation: Platform.OS === "android" ? 1 : 3,
          }}
        >
          <View
            style={{
              flexDirection: "row", gap: 9, alignItems: "center",
            }}
          >
            {p.image_url ? (
              <Image
                source={{ uri: p.image_url }}
                style={{
                  width: 50, height: 50, borderRadius: 12,
                  backgroundColor: "#E2E8F0",
                }}
                resizeMode="cover"

                // Muhimu hasa Android:
                // image kubwa ipunguzwe kwa matumizi ya thumbnail.
                resizeMethod={
                  Platform.OS === "android" ? "resize" : undefined
                }

                // Ondoa fade animation ya kila remote image Android.
                fadeDuration={
                  Platform.OS === "android" ? 0 : undefined
                }
              />
            ) : (
              <View
                style={{
                  width: 50, height: 50, borderRadius: 12,
                  backgroundColor: "#F1F5F9",
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1,
                  borderColor: "rgba(148,163,184,0.22)",
                }}
              >
                <WebSafeIcon
                  name="cube-outline"
                  size={26}
                  color={theme.colors.muted}
                />
              </View>
            )}

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "900",
                  fontSize: 15,
                }}
              >
                {p.name}
              </Text>

              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "800",
                  marginTop: 1,
                }}
              >
                {p.image_url ? uiText("Image attached") : uiText("No image")}
              </Text>
            </View>
          </View>

          {!isCapitalRecoveryStore && (
            <>
              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "800",
                  marginTop: 2,
                }}
              >
                {uiText("SKU:")}{" "}
                <Text style={{ color: theme.colors.text }}>
                  {p.sku ?? "—"}
                </Text>
                {"   "}•{"   "}
                {uiText("Unit:")}{" "}
                <Text style={{ color: theme.colors.text }}>
                  {p.unit ?? "—"}
                </Text>
              </Text>

              <View style={{ flexDirection: "row", flexWrap: "wrap", columnGap: 12, rowGap: 2 }}><Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "800",
                  marginTop: 2,
                }}
              >
                {uiText("Category:")}{" "}
                <Text style={{ color: theme.colors.text }}>
                  {p.category ?? "—"}
                </Text>
              </Text>

              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "900",
                  marginTop: 4,
                }}
              >
                {uiText("Barcode:")}{" "}
                <Text style={{ color: theme.colors.text }}>
                  {bc ? bc : "—"}
                </Text>
              </Text></View>
            </>
          )}

          {isCapitalRecoveryStore && (
            <Text
              style={{
                color: theme.colors.muted,
                fontWeight: "800",
                marginTop: 2,
              }}
            >
              {uiText("Category:")}{" "}
              <Text style={{ color: theme.colors.text }}>
                {p.category ?? "—"}
              </Text>
            </Text>
          )}

          <View style={{ flexDirection: "row", flexWrap: "wrap", alignItems: "center", columnGap: 14, rowGap: 3 }}><Text
            style={{
              color: theme.colors.muted,
              fontWeight: "900",
              marginTop: 4,
            }}
          >
            {uiText("Selling Price:")}{" "}
            <Text style={{ color: theme.colors.text }}>
              {sp > 0 ? preferredMoney(sp) : "—"}
            </Text>
          </Text>

          {canSeeCost && (
            <Text
              style={{
                color: theme.colors.muted,
                fontWeight: "900",
                marginTop: 2,
              }}
            >
              {uiText("Cost Price:")}{" "}
              <Text style={{ color: theme.colors.text }}>
                {Number.isFinite(cp) ? preferredMoney(cp) : "—"}
              </Text>
            </Text>
          )}</View>

          {canManage && (
            <View
              style={{
                flexDirection: "row",
                gap: 10,
                marginTop: 8,
              }}
            >
              <View style={{ flex: 1 }}>
                <Pressable
    onPress={() => openEdit(p)}
    disabled={loading}
    style={({ pressed }) => ({
      minHeight: 44,
      borderRadius: 12,
      backgroundColor: pressed ? "#0755AA" : "#0963BD",
      alignItems: "center",
      justifyContent: "center",
      opacity: loading ? 0.5 : 1,
    })}
  >
    <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 13 }}>
      {uiText("Edit")}</Text>
  </Pressable>
              </View>

              <View style={{ flex: 1 }}>
                <Pressable
                  onPress={() => void remove(p.id, p.name)}
                  disabled={loading}
                  style={({ pressed }) => ({
                    minHeight: 44,
                    borderRadius: 14,
                    borderWidth: 1,
                    borderColor: "rgba(148,163,184,0.45)",
                    backgroundColor: pressed
                      ? "#F1F5F9"
                      : "#FFFFFF",
                    alignItems: "center",
                    justifyContent: "center",
                    opacity: loading ? 0.5 : 1,
                    cursor:
                      Platform.OS === "web"
                        ? "pointer"
                        : undefined,
                  })}
                >
                  <Text
                    style={{
                      color: theme.colors.text,
                      fontWeight: "900",
                      fontSize: 13,
                    }}
                  >
                    {uiText("Delete")}</Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      );
    })}

    {hasMoreProducts && (
      <Pressable
        onPress={loadMoreProducts}
        style={({ pressed }) => ({
          minHeight: 58,
          borderRadius: 18,
          borderWidth: 1,
          borderColor: theme.colors.emeraldBorder,
          backgroundColor: pressed
            ? "rgba(16,185,129,0.16)"
            : "rgba(16,185,129,0.08)",
          alignItems: "center",
          justifyContent: "center",
          paddingHorizontal: 16,
          marginTop: 2,
          marginBottom: 14,
        })}
      >
        <Text
          style={{
            color: theme.colors.text,
            fontWeight: "900",
            fontSize: 15,
          }}
        >
          {uiText("Load More Products")}</Text>

        <Text
          style={{
            color: theme.colors.muted,
            fontWeight: "800",
            fontSize: 12,
            marginTop: 3,
          }}
        >
          {uiText("Showing")}{renderedRows.length} {uiText("of")}{visibleRows.length}
        </Text>
      </Pressable>
    )}
  </>
)}


        </>
      )}
     <View style={{ height: keyboardSpace }} />

      {/* PRODUCTS DESKTOP EDIT MODAL 5D */}
<Modal
  visible={editOpen}
  animationType="fade"
  transparent
  presentationStyle="overFullScreen"
  statusBarTranslucent
  onRequestClose={closeEdit}
>
  <KeyboardAvoidingView
    style={{ flex: 1 }}
    behavior={Platform.OS === "ios" ? "padding" : "height"}
    keyboardVerticalOffset={0}
  >
    <View
      style={{
        flex: 1,
        backgroundColor: "rgba(15,23,42,0.34)",
        paddingHorizontal: isDesktopWeb ? 24 : 16,
        paddingTop: isDesktopWeb ? 18 : 28,
        paddingBottom: 18,
        justifyContent: "center",
        alignItems: isDesktopWeb ? "center" : undefined,
      }}
    >
      <View
        style={{
          width: "100%",
          maxWidth: isDesktopWeb ? 820 : undefined,
          maxHeight: isDesktopWeb ? "90%" : "88%",
          borderWidth: 1,
          borderColor: "rgba(15,23,42,0.12)",
          borderRadius: isDesktopWeb ? 14 : 28,
          backgroundColor: "#FFFFFF",
          overflow: "hidden",
          shadowColor: "#000",
          shadowOpacity: isDesktopWeb ? 0.18 : 0.35,
          shadowRadius: isDesktopWeb ? 18 : 24,
          shadowOffset: {
            width: 0,
            height: isDesktopWeb ? 8 : 12,
          },
          elevation: isDesktopWeb ? 10 : 18,
        }}
      >
        {/* HEADER */}
        <View
          style={{
            paddingHorizontal: isDesktopWeb ? 18 : 16,
            paddingTop: isDesktopWeb ? 12 : 16,
            paddingBottom: isDesktopWeb ? 11 : 14,
            borderBottomWidth: 1,
            borderBottomColor: "rgba(15,23,42,0.10)",
            backgroundColor: "#FFFFFF",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <View style={{ gap: isDesktopWeb ? 2 : 0 }}>
            <Text
              style={{
                color: theme.colors.text,
                fontWeight: "900",
                fontSize: isDesktopWeb ? 17 : 20,
              }}
            >
              {uiText("Edit Product")}</Text>

            {isDesktopWeb && (
              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "700",
                  fontSize: 11,
                }}
              >
                {uiText("Update product information")}</Text>
            )}
          </View>

          <Pressable
            onPress={closeEdit}
            hitSlop={10}
            style={({ pressed }) => ({
              width: isDesktopWeb ? 32 : 44,
              height: isDesktopWeb ? 32 : 44,
              borderRadius: 999,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: "rgba(15,23,42,0.12)",
              backgroundColor: pressed
                ? "#E2E8F0"
                : "#F8FAFC",
            })}
          >
            <Ionicons
              name="close"
              size={isDesktopWeb ? 18 : 22}
              color={theme.colors.text}
            />
          </Pressable>
        </View>

        {/* BODY */}
        <ScrollView
          style={{
            flexGrow: 0,
            maxHeight: isDesktopWeb ? 610 : undefined,
          }}
          contentContainerStyle={{
            padding: 16,
            paddingBottom: isDesktopWeb ? 16 : 22,
            gap: isDesktopWeb ? 9 : 12,
          }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={isDesktopWeb}
        >
          {/* PRODUCT NAME */}
          <TextInput
            value={editName}
            onChangeText={setEditName}
            placeholder={uiText("Product name")}
            placeholderTextColor={theme.colors.faint}
            style={[
              solidInputStyle,
              isDesktopWeb && {
                paddingHorizontal: 12,
                paddingVertical: 9,
                borderRadius: 8,
                fontSize: 13,
              },
            ]}
          />

          {/* SKU + UNIT */}
          {!isCapitalRecoveryStore && (
            <View
              style={{
                flexDirection: "row",
                gap: isDesktopWeb ? 8 : 10,
              }}
            >
              <View style={{ flex: 1 }}>
                <TextInput
                  value={editSku}
                  onChangeText={setEditSku}
                  placeholder={uiText("SKU (optional)")}
                  placeholderTextColor={theme.colors.faint}
                  style={[
                    solidInputStyle,
                    isDesktopWeb && {
                      paddingHorizontal: 12,
                      paddingVertical: 9,
                      borderRadius: 8,
                      fontSize: 13,
                    },
                  ]}
                />
              </View>

              <View style={{ flex: 1 }}>
                <TextInput
                  value={editUnit}
                  onChangeText={setEditUnit}
                  placeholder={uiText("Unit / UOM (optional)")}
                  placeholderTextColor={theme.colors.faint}
                  style={[
                    solidInputStyle,
                    isDesktopWeb && {
                      paddingHorizontal: 12,
                      paddingVertical: 9,
                      borderRadius: 8,
                      fontSize: 13,
                    },
                  ]}
                />
              </View>
            </View>
          )}

          {/* CATEGORY */}
          <View
            style={{
              position: "relative",
              zIndex: 30,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                borderWidth: 1,
                borderColor: editCategoryDropdownOpen
                  ? theme.colors.emeraldBorder
                  : theme.colors.border,
                borderRadius: isDesktopWeb
                  ? 8
                  : theme.radius.lg,
                backgroundColor: "#FFFFFF",
                paddingRight: isDesktopWeb ? 8 : 12,
              }}
            >
              <TextInput
                value={editCategory}
                onChangeText={(text) => {
                  setEditCategory(text);
                  setEditCategoryDropdownOpen(true);
                }}
                onFocus={() => {
                  setEditCategoryDropdownOpen(true);

                  if (!categoriesLoading) {
                    void loadStoreCategories();
                  }
                }}
                placeholder={uiText("Category (optional)")}
                placeholderTextColor={theme.colors.faint}
                autoCorrect={false}
                style={{
                  flex: 1,
                  paddingHorizontal: isDesktopWeb ? 12 : 14,
                  paddingVertical: isDesktopWeb ? 9 : 12,
                  color: theme.colors.text,
                  fontWeight: "800",
                  fontSize: isDesktopWeb ? 13 : undefined,
                }}
              />

              <Pressable
                onPress={() => {
                  setEditCategoryDropdownOpen(
                    (current) => !current
                  );

                  if (
                    !editCategoryDropdownOpen &&
                    !categoriesLoading
                  ) {
                    void loadStoreCategories();
                  }
                }}
                hitSlop={8}
                style={{
                  width: isDesktopWeb ? 30 : 34,
                  height: isDesktopWeb ? 30 : 34,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <WebSafeIcon
                  name={
                    editCategoryDropdownOpen
                      ? "chevron-up"
                      : "chevron-down"
                  }
                  size={isDesktopWeb ? 17 : 20}
                  color={theme.colors.muted}
                />
              </Pressable>
            </View>

            {editCategoryDropdownOpen && (
              <View
                style={{
                  marginTop: 6,
                  borderWidth: 1,
                  borderColor: theme.colors.border,
                  borderRadius: isDesktopWeb ? 8 : 16,
                  backgroundColor: "#FFFFFF",
                  overflow: "hidden",
                  elevation: 6,
                }}
              >
                {categoriesLoading ? (
                  <View
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: isDesktopWeb ? 10 : 14,
                    }}
                  >
                    <Text
                      style={{
                        color: theme.colors.muted,
                        fontWeight: "800",
                        fontSize: isDesktopWeb ? 12 : undefined,
                      }}
                    >
                      {uiText("Loading categories...")}</Text>
                  </View>
                ) : filteredEditCategorySuggestions.length > 0 ? (
                  <ScrollView
                    style={{
                      maxHeight: isDesktopWeb ? 150 : 190,
                    }}
                    keyboardShouldPersistTaps="always"
                    nestedScrollEnabled
                    showsVerticalScrollIndicator
                  >
                    {filteredEditCategorySuggestions.map(
                      (item, index) => (
                        <Pressable
                          key={`${item}-${index}`}
                          onPress={() => {
                            setEditCategory(item);
                            setEditCategoryDropdownOpen(false);
                          }}
                          style={({ pressed }) => ({
                            paddingHorizontal: 14,
                            paddingVertical: isDesktopWeb
                              ? 9
                              : 13,
                            backgroundColor: pressed
                              ? "rgba(16,185,129,0.10)"
                              : "#FFFFFF",
                            borderBottomWidth:
                              index <
                              filteredEditCategorySuggestions.length -
                                1
                                ? 1
                                : 0,
                            borderBottomColor:
                              "rgba(148,163,184,0.16)",
                          })}
                        >
                          <Text
                            style={{
                              color: theme.colors.text,
                              fontWeight: "800",
                              fontSize: isDesktopWeb
                                ? 12
                                : undefined,
                            }}
                          >
                            {item}
                          </Text>
                        </Pressable>
                      )
                    )}
                  </ScrollView>
                ) : (
                  <View
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: isDesktopWeb ? 10 : 14,
                    }}
                  >
                    <Text
                      style={{
                        color: theme.colors.muted,
                        fontWeight: "800",
                        fontSize: isDesktopWeb
                          ? 12
                          : undefined,
                      }}
                    >
                      {editCategory.trim()
                        ? uiText("\"{p0}\" haipo bado. Unaweza kuitumia kama category mpya.", {p0: (editCategory.trim())})
                        : uiText("Hakuna category iliyopatikana kwenye store hii bado.")}
                    </Text>
                  </View>
                )}
              </View>
            )}
          </View>

          {/* IMAGE + BARCODE */}
          <View
            style={{
              flexDirection: isDesktopWeb
                ? "row"
                : "column",
              gap: isDesktopWeb ? 10 : 12,
              alignItems: isDesktopWeb
                ? "flex-start"
                : "stretch",
            }}
          >
            <View
              style={{
                flex: isDesktopWeb ? 1 : undefined,
                width: isDesktopWeb ? undefined : "100%",
                gap: isDesktopWeb ? 5 : 8,
              }}
            >
              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "900",
                  fontSize: isDesktopWeb ? 11 : undefined,
                }}
              >
                {uiText("Product Image")}</Text>

              <Pressable
                onPress={() => chooseImageSource("edit")}
                disabled={editImageUploading || loading}
                style={({ pressed }) => ({
                  minHeight: isDesktopWeb ? 62 : 88,
                  borderRadius: isDesktopWeb ? 9 : 22,
                  borderWidth: 1,
                  borderColor: editImageUrl
                    ? theme.colors.emeraldBorder
                    : theme.colors.border,
                  backgroundColor: editImageUrl
                    ? "#ECFDF5"
                    : "#F8FAFC",
                  padding: isDesktopWeb ? 8 : 12,
                  flexDirection: "row",
                  alignItems: "center",
                  gap: isDesktopWeb ? 9 : 12,
                  opacity:
                    editImageUploading || loading
                      ? 0.6
                      : pressed
                      ? 0.9
                      : 1,
                })}
              >
                {editImageUrl ? (
                  <Image
                    source={{ uri: editImageUrl }}
                    style={{
                      width: isDesktopWeb ? 44 : 64,
                      height: isDesktopWeb ? 44 : 64,
                      borderRadius: isDesktopWeb ? 8 : 18,
                      backgroundColor: "#E2E8F0",
                    }}
                    resizeMode="cover"
                    resizeMethod={
                      Platform.OS === "android"
                        ? "resize"
                        : undefined
                    }
                    fadeDuration={
                      Platform.OS === "android"
                        ? 0
                        : undefined
                    }
                  />
                ) : (
                  <View
                    style={{
                      width: isDesktopWeb ? 44 : 64,
                      height: isDesktopWeb ? 44 : 64,
                      borderRadius: isDesktopWeb ? 8 : 18,
                      backgroundColor:
                        "rgba(16,185,129,0.10)",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Ionicons
                      name="image-outline"
                      size={isDesktopWeb ? 21 : 28}
                      color={theme.colors.text}
                    />
                  </View>
                )}

                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      color: theme.colors.text,
                      fontWeight: "900",
                      fontSize: isDesktopWeb
                        ? 12
                        : undefined,
                    }}
                  >
                    {editImageUploading
                      ? uiText("Uploading image...")
                      : editImageUrl
                      ? uiText("Change product image")
                      : uiText("Add product image")}
                  </Text>

                  <Text
                    style={{
                      color: theme.colors.muted,
                      fontWeight: "800",
                      marginTop: isDesktopWeb ? 2 : 4,
                      fontSize: isDesktopWeb
                        ? 10
                        : undefined,
                    }}
                  >
                    {uiText("Camera au Gallery/File")}</Text>
                </View>
              </Pressable>

              {!!editImageUrl && (
                <Pressable
                  onPress={() => setEditImageUrl("")}
                  disabled={loading}
                >
                  <Text
                    style={{
                      color: "#B91C1C",
                      fontWeight: "900",
                      fontSize: isDesktopWeb
                        ? 10
                        : undefined,
                    }}
                  >
                    {uiText("Remove image")}</Text>
                </Pressable>
              )}
            </View>

            {!isCapitalRecoveryStore && (
              <View
                style={{
                  flex: isDesktopWeb ? 1 : undefined,
                  width: isDesktopWeb
                    ? undefined
                    : "100%",
                  paddingTop: isDesktopWeb ? 20 : 0,
                }}
              >
                <TextInput
                  value={editBarcode}
                  onChangeText={(t) =>
                    setEditBarcode(cleanBarcode(t))
                  }
                  placeholder={uiText("Barcode (optional)")}
                  placeholderTextColor={theme.colors.faint}
                  style={[
                    solidInputStyle,
                    isDesktopWeb && {
                      paddingHorizontal: 12,
                      paddingVertical: 9,
                      borderRadius: 8,
                      fontSize: 13,
                    },
                  ]}
                />
              </View>
            )}
          </View>

          {/* PRECISION RETAIL */}
          {isPrecisionRetailStore && canSeeCost && (
            <Card
              style={{
                gap: isDesktopWeb ? 8 : 10,
                padding: isDesktopWeb ? 11 : undefined,
                borderRadius: isDesktopWeb ? 10 : undefined,
                borderColor: "rgba(52,211,153,0.28)",
                backgroundColor: "rgba(52,211,153,0.08)",
              }}
            >
              <Text
                style={{
                  color: theme.colors.text,
                  fontWeight: "900",
                  fontSize: isDesktopWeb ? 13 : 15,
                }}
              >
                {uiText("Unit & Pack Calculator")}</Text>

              <Text
                style={{
                  color: theme.colors.muted,
                  fontWeight: "800",
                  lineHeight: isDesktopWeb ? 16 : 19,
                  fontSize: isDesktopWeb ? 11 : undefined,
                }}
              >
                {uiText("Badili pack size, unit ya ndani, cost ya pack na selling ya pack. Mfumo utahesabu bei ya unit moja automatic.")}</Text>

              <View
                style={{
                  flexDirection: "row",
                  gap: isDesktopWeb ? 8 : 10,
                }}
              >
                <View style={{ flex: 1.15 }}>
                  <TextInput
                    value={editPrecisionPackQty}
                    onChangeText={(t) =>
                      setEditPrecisionPackQty(
                        normalizeDecimalInput(t)
                      )
                    }
                    placeholder={uiText("Pack size e.g. 100")}
                    keyboardType="numeric"
                    placeholderTextColor={theme.colors.faint}
                    style={[
                      solidInputStyle,
                      {
                        fontSize: 13,
                        backgroundColor: "#FFFFFF",
                      },
                      isDesktopWeb && {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 8,
                      },
                    ]}
                  />
                </View>

                <View style={{ flex: 1 }}>
                  <TextInput
                    value={editPrecisionUnit}
                    onChangeText={setEditPrecisionUnit}
                    placeholder={uiText("Unit e.g. capsule")}
                    placeholderTextColor={theme.colors.faint}
                    style={[
                      solidInputStyle,
                      {
                        fontSize: 13,
                        backgroundColor: "#ECFDF5",
                        borderColor: theme.colors.emeraldBorder,
                        color: theme.colors.text,
                        fontWeight: "900",
                      },
                      isDesktopWeb && {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 8,
                      },
                    ]}
                  />
                </View>
              </View>

              <View
                style={{
                  flexDirection: isDesktopWeb
                    ? "row"
                    : "column",
                  gap: isDesktopWeb ? 8 : 10,
                }}
              >
                <View style={{ flex: 1 }}>
                  <TextInput
                    value={editPrecisionPackCost}
                    onChangeText={(t) =>
                      setEditPrecisionPackCost(
                        normalizeDecimalInput(t)
                      )
                    }
                    placeholder={uiText("Buying/Cost price ya box/pack")}
                    keyboardType="numeric"
                    placeholderTextColor={theme.colors.faint}
                    style={[
                      solidInputStyle,
                      isDesktopWeb && {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 8,
                        fontSize: 12,
                      },
                    ]}
                  />
                </View>

                <View style={{ flex: 1 }}>
                  <TextInput
                    value={editPrecisionPackSelling}
                    onChangeText={(t) =>
                      setEditPrecisionPackSelling(
                        normalizeDecimalInput(t)
                      )
                    }
                    placeholder={uiText("Selling price ya box/pack")}
                    keyboardType="numeric"
                    placeholderTextColor={theme.colors.faint}
                    style={[
                      solidInputStyle,
                      isDesktopWeb && {
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 8,
                        fontSize: 12,
                      },
                    ]}
                  />
                </View>
              </View>

              <Button
                title={uiText("Calculate Per Unit Price")}
                onPress={applyEditPrecisionFormula}
                disabled={loading}
                variant="secondary"
              />

              <Text
                style={{
                  color: theme.colors.faint,
                  fontWeight: "800",
                  fontSize: isDesktopWeb ? 10 : undefined,
                }}
              >
                {uiText("Baada ya calculate, Cost Price na Selling Price chini zitabadilishwa kama bei ya unit moja.")}</Text>
            </Card>
          )}

          {/* COST + SELLING PRICE */}
          <View
            style={{
              flexDirection:
                isDesktopWeb && canSeeCost
                  ? "row"
                  : "column",
              gap: isDesktopWeb ? 8 : 12,
            }}
          >
            {canSeeCost && (
              <View style={{ flex: 1 }}>
                <TextInput
                  value={editCostPrice}
                  onChangeText={(t) =>
                    setEditCostPrice(
                      normalizeDecimalInput(t)
                    )
                  }
                  placeholder={uiText("Cost Price (optional)")}
                  keyboardType="numeric"
                  placeholderTextColor={theme.colors.faint}
                  style={[
                    solidInputStyle,
                    isDesktopWeb && {
                      paddingHorizontal: 12,
                      paddingVertical: 9,
                      borderRadius: 8,
                      fontSize: 13,
                    },
                  ]}
                />
              </View>
            )}

            <View style={{ flex: 1 }}>
              <TextInput
                value={editSellingPrice}
                onChangeText={(t) =>
                  setEditSellingPrice(
                    normalizeDecimalInput(t)
                  )
                }
                placeholder={
                  isCapitalRecoveryStore
                    ? uiText("Selling Price")
                    : uiText("Selling Price (optional)")
                }
                keyboardType="numeric"
                placeholderTextColor={theme.colors.faint}
                style={[
                  solidInputStyle,
                  isDesktopWeb && {
                    paddingHorizontal: 12,
                    paddingVertical: 9,
                    borderRadius: 8,
                    fontSize: 13,
                  },
                ]}
              />
            </View>
          </View>

          {/* ACTIONS */}
          <View
            style={{
              flexDirection: "row",
              gap: isDesktopWeb ? 8 : 10,
              marginTop: isDesktopWeb ? 3 : 6,
              justifyContent: isDesktopWeb
                ? "flex-end"
                : undefined,
            }}
          >
            <View
              style={{
                flex: isDesktopWeb ? undefined : 1,
                width: isDesktopWeb ? 130 : undefined,
              }}
            >
              <Button
                title={uiText("Cancel")}
                variant="secondary"
                onPress={closeEdit}
                disabled={loading}
              />
            </View>

            <View
              style={{
                flex: isDesktopWeb ? undefined : 1,
                width: isDesktopWeb ? 170 : undefined,
              }}
            >
              <Button
                title={loading ? uiText("Saving...") : uiText("Save Changes")}
                variant="primary"
                onPress={saveEdit}
                disabled={loading}
              />
            </View>
          </View>
        </ScrollView>
      </View>
    </View>
  </KeyboardAvoidingView>
</Modal>
    </Screen>
  );
}