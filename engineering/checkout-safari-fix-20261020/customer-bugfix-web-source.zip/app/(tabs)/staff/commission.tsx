import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
import {useCommonText} from "@/src/i18n/useCommonText";
// app/(tabs)/staff/commission.tsx
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useMemo, useState } from "react";
import {
  Alert,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useOrg } from "../../../src/context/OrgContext";
import { supabase } from "../../../src/supabase/supabaseClient";
import { formatMoney, useOrgMoneyPrefs } from "@/src/ui/money";

type StaffCommissionRow = {
  membership_id: string;
  user_id: string;
  email: string | null;
  role: string | null;
  total_sales: number | string | null;
  sales_count: number | string | null;
  commission_percent: number | string | null;

  accrued_commission: number | string | null;
  paid_commission: number | string | null;
  remaining_commission: number | string | null;

  payout_payment_method: string | null;
  payout_mobile_network: string | null;
  payout_mobile_number: string | null;
  payout_bank_name: string | null;
  payout_bank_account_name: string | null;
  payout_bank_account_number: string | null;
  payout_account_holder_name: string | null;
  payout_profile_configured: boolean | null;
};

const UI = {
  bg0: "#F3F7FC",
  card: "#FFFFFF",
  border: "rgba(15,23,42,0.10)",
  text: "#0F172A",
  muted: "#64748B",
  faint: "#94A3B8",
  emerald: "#059669",
  emeraldSoft: "rgba(5,150,105,0.10)",
  danger: "#E11D48",
};

function shortId(v: string) {
  if (!v) return "—";
  return v.length > 10 ? `${v.slice(0, 8)}...` : v;
}

function toNum(v: any) {
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
}

function cleanPercentInput(raw: string) {
  return String(raw ?? "")
    .replace(/[^\d.]/g, "")
    .replace(/(\..*)\./g, "$1");
}

function toPercentValue(raw: string) {
  const n = Number(String(raw ?? "").trim());
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, n));
}

function initialsFromEmail(email: string | null, fallback = "ST") {
  if (!email) return fallback;
  const base = email.split("@")[0]?.trim() ?? "";
  const letters = base.replace(/[^a-zA-Z]/g, "");
  if (letters.length >= 2) return letters.slice(0, 2).toUpperCase();
  if (letters.length === 1) return (letters + "T").toUpperCase();
  return fallback;
}

function commissionStatusMeta(row: StaffCommissionRow) {
  const paid = Math.max(0, toNum(row.paid_commission));
  const remaining = Math.max(0, toNum(row.remaining_commission));
  const accrued = Math.max(0, toNum(row.accrued_commission));
  const hasProfile = !!row.payout_profile_configured;

  if (hasProfile && accrued > 0 && remaining <= 0) {
    return {
      label: "SETTLED",
      color: UI.emerald,
      borderColor: "rgba(52,211,153,0.30)",
      backgroundColor: "rgba(52,211,153,0.10)",
    };
  }

  if (hasProfile && remaining > 0) {
    return {
      label: "UNPAID BALANCE",
      color: UI.text,
      borderColor: "rgba(245,158,11,0.24)",
      backgroundColor: "rgba(245,158,11,0.08)",
    };
  }

  if (hasProfile && paid <= 0 && accrued <= 0) {
    return {
      label: "READY",
      color: UI.emerald,
      borderColor: "rgba(52,211,153,0.30)",
      backgroundColor: "rgba(52,211,153,0.10)",
    };
  }

  return {
    label: "NO PROFILE",
    color: UI.danger,
    borderColor: "rgba(251,113,133,0.28)",
    backgroundColor: "rgba(251,113,133,0.08)",
  };
}

export default function StaffCommissionScreen() {
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const { activeOrgId, activeOrgName, activeRole } = useOrg();

const orgId = String(activeOrgId ?? "").trim();

const role = String(activeRole ?? "")
  .trim()
  .toLowerCase();

const canManage =
  role === "owner" ||
  role === "admin";

  const money = useOrgMoneyPrefs(orgId);
  const currency = money.currency || "TZS";
  const locale = money.locale || "en-TZ";

  const fmtMoney = useCallback(
    (n: number) =>
      formatMoney(n, {
        currency,
        locale,
      }).replace(/\s+/g, " "),
    [currency, locale]
  );

  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [savingMembershipId, setSavingMembershipId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [rows, setRows] = useState<StaffCommissionRow[]>([]);
  const [q, setQ] = useState("");
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  const loadData = useCallback(
    async (opts?: { silent?: boolean }) => {
      const silent = !!opts?.silent;

      if (!canManage) {
        setRows([]);
        setError("Owner/Admin only.");
        return;
      }

      if (!orgId) {
        setRows([]);
        setError("No active organization.");
        return;
      }

      if (!silent) {
        setLoading(true);
        setError(null);
      }

      try {
        const { data, error: e } = await supabase.rpc(
  "get_org_staff_commission_dashboard_v2",
  { p_org_id: orgId }
);

        if (e) throw e;

        const nextRows = ((data ?? []) as StaffCommissionRow[]).filter(
          (r) => String(r.role ?? "").toLowerCase() === "staff"
        );

        setRows(nextRows);

        setDrafts((prev) => {
          const next = { ...prev };
          for (const row of nextRows) {
            const key = String(row.membership_id ?? "");
            if (!key) continue;
            if (prev[key] == null) {
              next[key] = String(toNum(row.commission_percent));
            }
          }
          return next;
        });
      } catch (err: any) {
        setError(err?.message ?? "Failed to load staff commission");
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [canManage, orgId]
  );

  useFocusEffect(
    useCallback(() => {
      void loadData({ silent: true });
    }, [loadData])
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }, [loadData]);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return rows;

    return rows.filter((r) => {
      const hay = `${r.email ?? ""} ${r.membership_id ?? ""} ${r.user_id ?? ""} ${r.role ?? ""}`.toLowerCase();
      return hay.includes(needle);
    });
  }, [rows, q]);

  const performanceInsight = useMemo(() => {
    const ranked = [...rows]
      .map((r) => ({
        row: r,
        sales: toNum(r.total_sales),
        count: Math.trunc(toNum(r.sales_count)),
        commission: toNum(r.remaining_commission),
      }))
      .sort((a, b) => {
        if (b.sales !== a.sales) return b.sales - a.sales;
        return b.count - a.count;
      });

    const top = ranked.find((x) => x.sales > 0 || x.count > 0) ?? null;
    const lowest =
      ranked
        .filter((x) => x.row.role?.toLowerCase() === "staff")
        .reverse()
        .find((x) => x.sales > 0 || x.count > 0) ?? null;

    return {
      top,
      lowest: lowest && top && lowest.row.membership_id !== top.row.membership_id ? lowest : null,
    };
  }, [rows]);

  const savePercent = useCallback(
    async (membershipId: string) => {
      if (!canManage) {
        Alert.alert(uiText("No Access"), uiText("Owner/Admin only."));
        return;
      }

      const raw = String(drafts[membershipId] ?? "").trim();
      const percent = toPercentValue(raw);

      try {
        setSavingMembershipId(membershipId);

       const { error: e } = await supabase.rpc("set_staff_commission_percent_v2", {
  p_org_id: orgId,
  p_membership_id: membershipId,
  p_percent: percent,
});

if (e) throw e;

setDrafts((prev) => ({
  ...prev,
  [membershipId]: String(percent),
}));

await loadData({ silent: true });

Alert.alert(uiText("Success"), uiText("Commission rate saved."));
      } catch (err: any) {
        Alert.alert(uiText("Failed"), err?.message ?? uiText("Failed to save commission rate"));
      } finally {
        setSavingMembershipId(null);
      }
    },
    [canManage, drafts, orgId]
  );

  if (!canManage) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: UI.bg0 }} edges={["top"]}>
        <View style={{ flex: 1, padding: 16, justifyContent: "center" }}>
          <View
            style={{
              borderWidth: 1,
              borderColor: "rgba(251,113,133,0.35)",
              borderRadius: 22,
              backgroundColor: "rgba(251,113,133,0.08)",
              padding: 16,
              gap: 10,
            }}
          >
            <Text style={{ color: UI.danger, fontWeight: "900", fontSize: 18 }}>
              {uiText("No Access")}</Text>
            <Text style={{ color: UI.text, fontWeight: "800", lineHeight: 22 }}>
              {uiText("Hii screen ni ya Owner/Admin tu.")}</Text>

            <Pressable
              onPress={() => router.back()}
              style={{
                marginTop: 8,
                borderWidth: 1,
                borderColor: UI.border,
                borderRadius: 18,
                backgroundColor: "rgba(255,255,255,0.05)",
                paddingVertical: 14,
                alignItems: "center",
              }}
            >
              <Text style={{ color: UI.text, fontWeight: "900" }}>{uiText("Back")}</Text>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: UI.bg0 }} edges={["top"]}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: 190,
          gap: 12,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <Pressable
            onPress={() => router.back()}
            style={{
              width: 44,
              height: 44,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: UI.border,
              backgroundColor: "rgba(255,255,255,0.06)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 18 }}>‹</Text>
          </Pressable>

          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 26, fontWeight: "900", color: UI.text }}>
              {uiText("Staff Sales & Commission")}</Text>
          <Text
  style={{
    color: UI.muted,
    fontWeight: "800",
    marginTop: 4,
  }}
>
  {uiText("Staff sales, accumulated commissions and unpaid balances")}</Text>
          </View>
        </View>

        <View
          style={{
            borderWidth: 1,
            borderColor: UI.border,
            borderRadius: 22,
            backgroundColor: UI.card,
            padding: 16,
            gap: 10,
          }}
        >
          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Organization")}</Text>
          <Text style={{ fontSize: 18, fontWeight: "900", color: UI.text }}>
            {activeOrgName ?? "—"}
          </Text>

          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Role:")}</Text>
            <View
              style={{
                borderWidth: 1,
                borderColor: "rgba(255,255,255,0.18)",
                backgroundColor: "rgba(255,255,255,0.06)",
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 999,
              }}
            >
              <Text style={{ color: UI.text, fontWeight: "900" }}>
                {String(activeRole ?? "—").toUpperCase()}
              </Text>
            </View>
          </View>

         <Text
  style={{
    color: UI.faint,
    fontWeight: "800",
    lineHeight: 20,
  }}
>
  {uiText("Mfumo huu unafuatilia mauzo, commission iliyokusanyika na balance ambayo bado haijalipwa kwa kila staff. Unpaid commission itaendelea kubebwa mbele bila ku-reset mwezi unapobadilika, mpaka ifanyiwe cash-out. Ukiweka rate 0%, mauzo yataendelea kurekodiwa lakini commission mpya haitahesabiwa.")}</Text>
        </View>

        {!!error ? (
          <View
            style={{
              borderWidth: 1,
              borderColor: "rgba(251,113,133,0.35)",
              borderRadius: 18,
              backgroundColor: "rgba(251,113,133,0.08)",
              padding: 12,
            }}
          >
            <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(error)}</Text>
          </View>
        ) : null}

        <View
          style={{
            flexDirection: "row",
            gap: 10,
          }}
        >
          <View
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: UI.border,
              borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.05)",
              padding: 14,
            }}
          >
            <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Staff Count")}</Text>
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 22, marginTop: 6 }}>
              {rows.length}
            </Text>
          </View>

          <View
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: UI.border,
              borderRadius: 18,
              backgroundColor: "rgba(255,255,255,0.05)",
              padding: 14,
            }}
          >
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
  {uiText("Total Staff Sales")}</Text>
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 18, marginTop: 6 }}>
              {fmtMoney(rows.reduce((a, r) => a + toNum(r.total_sales), 0))}
            </Text>
          </View>
        </View>

        <View
          style={{
            borderWidth: 1,
            borderColor: "rgba(52,211,153,0.20)",
            borderRadius: 18,
            backgroundColor: "rgba(52,211,153,0.08)",
            padding: 14,
          }}
        >
          <Text style={{ color: UI.muted, fontWeight: "800" }}>
  {uiText("Total Unpaid Commission")}</Text>
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 20, marginTop: 6 }}>
            {fmtMoney(rows.reduce((a, r) => a + toNum(r.remaining_commission), 0))}
          </Text>
        </View>

        <View
          style={{
            borderWidth: 1,
            borderColor: "rgba(37,99,235,0.18)",
            borderRadius: 22,
            backgroundColor: "#FFFFFF",
            padding: 16,
            gap: 12,
          }}
        >
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 17 }}>
  {uiText("Staff Performance Overview")}</Text>

          {performanceInsight.top ? (
            <>
              <View
                style={{
                  borderWidth: 1,
                  borderColor: "rgba(52,211,153,0.24)",
                  borderRadius: 18,
                  backgroundColor: "rgba(52,211,153,0.08)",
                  padding: 12,
                }}
              >
               <Text style={{ color: UI.emerald, fontWeight: "900", fontSize: 12 }}>
  {uiText("TOP PERFORMER")}</Text>
                <Text style={{ color: UI.text, fontWeight: "900", fontSize: 16, marginTop: 6 }}>
                  {performanceInsight.top.row.email ?? uiText("User: {p0}", {p0: (shortId(String(performanceInsight.top.row.user_id ?? "")))})}
                </Text>
                <Text style={{ color: UI.muted, fontWeight: "800", marginTop: 6 }}>
                  {uiText("Sales:")}{fmtMoney(performanceInsight.top.sales)} {uiText("• Receipts:")}{performanceInsight.top.count}
                </Text>
                <Text style={{ color: UI.muted, fontWeight: "800", marginTop: 4 }}>
  {uiText("Unpaid Commission:")}{fmtMoney(performanceInsight.top.commission)}
</Text>
              </View>

              {performanceInsight.lowest ? (
                <View
                  style={{
                    borderWidth: 1,
                    borderColor: "rgba(251,113,133,0.22)",
                    borderRadius: 18,
                    backgroundColor: "rgba(251,113,133,0.06)",
                    padding: 12,
                  }}
                >
                  <Text style={{ color: UI.danger, fontWeight: "900", fontSize: 12 }}>
                    {uiText("NEEDS FOLLOW UP")}</Text>
                  <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                    {performanceInsight.lowest.row.email ?? uiText("User: {p0}", {p0: (shortId(String(performanceInsight.lowest.row.user_id ?? "")))})}
                  </Text>
                  <Text style={{ color: UI.muted, fontWeight: "800", marginTop: 6 }}>
                    {uiText("Sales:")}{fmtMoney(performanceInsight.lowest.sales)} {uiText("• Receipts:")}{performanceInsight.lowest.count}
                  </Text>
                </View>
              ) : null}
            </>
          ) : (
          <Text style={{ color: UI.muted, fontWeight: "800", lineHeight: 20 }}>
  {uiText("Bado hakuna staff sales za kutosha kufanya performance ranking.")}</Text>
          )}
        </View>
<View
  style={{
    flexDirection: "row",
    gap: 10,
  }}
>
  <Pressable
    onPress={() =>
      router.push("/(tabs)/staff/cash-out" as any)
    }
    style={({ pressed }) => ({
      flex: 1,
      borderWidth: 1,
      borderColor: "rgba(52,211,153,0.30)",
      borderRadius: 18,
      backgroundColor: "rgba(52,211,153,0.10)",
      paddingVertical: 14,
      paddingHorizontal: 14,
      alignItems: "center",
      justifyContent: "center",
      opacity: pressed ? 0.92 : 1,
    })}
  >
    <Text
      style={{
        color: UI.text,
        fontWeight: "900",
        fontSize: 15,
      }}
    >
      {uiText("Cash Out")}</Text>
  </Pressable>

  <Pressable
    onPress={() =>
      router.push(
        "/(tabs)/staff/commission-history" as any
      )
    }
    style={({ pressed }) => ({
      flex: 1,
      borderWidth: 1,
      borderColor: UI.border,
      borderRadius: 18,
      backgroundColor: UI.card,
      paddingVertical: 14,
      paddingHorizontal: 14,
      alignItems: "center",
      justifyContent: "center",
      opacity: pressed ? 0.92 : 1,
    })}
  >
    <Text
      style={{
        color: UI.text,
        fontWeight: "900",
        fontSize: 15,
      }}
    >
      {uiText("Cash-Out History")}</Text>
  </Pressable>
</View>
        <Pressable
          onPress={() => void loadData()}
          disabled={loading}
          style={{
            backgroundColor: "rgba(255,255,255,0.05)",
            borderWidth: 1,
            borderColor: UI.border,
            paddingVertical: 14,
            borderRadius: 18,
            alignItems: "center",
            opacity: loading ? 0.65 : 1,
          }}
        >
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 16 }}>
            {loading ? uiText("Loading...") : uiText("Refresh Commission List")}
          </Text>
        </Pressable>

        <View style={{ marginBottom: 8 }}>
          <TextInput
            value={q}
          onChangeText={setQ}
          placeholder={uiText("Tafuta kwa email / membership / role...")}
          placeholderTextColor="rgba(255,255,255,0.35)"
          style={{
            borderWidth: 1,
            borderColor: UI.border,
            borderRadius: 18,
            backgroundColor: "rgba(255,255,255,0.05)",
            paddingHorizontal: 14,
            paddingVertical: 12,
            color: UI.text,
            fontWeight: "800",
          }}
        />
        </View>

        {filtered.length === 0 ? (
          <View
            style={{
              borderWidth: 1,
              borderColor: UI.border,
              borderRadius: 22,
              backgroundColor: UI.card,
              padding: 16,
            }}
          >
            <Text style={{ fontWeight: "900", color: UI.text }}>
              {uiText("No staff sales found")}</Text>
          <Text style={{ marginTop: 6, color: UI.muted, fontWeight: "700", lineHeight: 20 }}>
  {uiText("Hakuna staff commission data kwa sasa, au mauzo bado hayajahusishwa na staff husika.")}</Text>
          </View>
        ) : (
          filtered.map((r) => {
            const membershipId = String(r.membership_id ?? "");
            const email = String(r.email ?? "").trim() || null;
            const initials = initialsFromEmail(email, "ST");
            const totalSales = toNum(r.total_sales);
            const salesCount = Math.trunc(toNum(r.sales_count));
            const commissionPercent = toNum(r.commission_percent);
const accruedCommission = toNum(r.accrued_commission);
const paidCommission = toNum(r.paid_commission);
const remainingCommission = toNum(r.remaining_commission);

const payoutProfileConfigured = !!r.payout_profile_configured;
const payoutMethod = String(
  r.payout_payment_method ?? ""
)
  .trim()
  .toUpperCase();

const payoutDestination =
  payoutMethod === "MOBILE"
    ? String(r.payout_mobile_number ?? "").trim()
    : payoutMethod === "BANK"
      ? String(r.payout_bank_account_number ?? "").trim()
      : "";

const draft = drafts[membershipId] ?? String(commissionPercent);
const isSaving = savingMembershipId === membershipId;

            return (
              <View
                key={membershipId}
                style={{
                  borderWidth: 1,
                  borderColor: UI.border,
                  borderRadius: 22,
                  backgroundColor: UI.card,
                  padding: 16,
                  gap: 12,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <View
                    style={{
                      width: 46,
                      height: 46,
                      borderRadius: 999,
                      borderWidth: 1,
                      borderColor: "rgba(255,255,255,0.18)",
                      backgroundColor: "rgba(255,255,255,0.06)",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text style={{ color: UI.text, fontWeight: "900" }}>{initials}</Text>
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={{ color: UI.text, fontWeight: "900" }}>
                      {email ?? uiText("User: {p0}", {p0: (shortId(String(r.user_id ?? "")))})}
                    </Text>
                    <Text style={{ color: UI.muted, fontWeight: "800", marginTop: 4 }}>
                      {uiText("Membership:")}{shortId(membershipId)}
                    </Text>
                  </View>

                  {(() => {
                    const meta = commissionStatusMeta(r);
                    return (
                      <View
                        style={{
                          borderWidth: 1,
                          borderColor: meta.borderColor,
                          backgroundColor: meta.backgroundColor,
                          paddingHorizontal: 12,
                          paddingVertical: 7,
                          borderRadius: 999,
                        }}
                      >
                        <Text style={{ color: meta.color, fontWeight: "900" }}>
                          {uiText(meta.label)}
                        </Text>
                      </View>
                    );
                  })()}
                </View>

                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: UI.border,
                      borderRadius: 18,
                      backgroundColor: "rgba(255,255,255,0.04)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Sales")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {fmtMoney(totalSales)}
                    </Text>
                  </View>

                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: UI.border,
                      borderRadius: 18,
                      backgroundColor: "rgba(255,255,255,0.04)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Sales Count")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {salesCount}
                    </Text>
                  </View>
                </View>

                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: "rgba(52,211,153,0.20)",
                      borderRadius: 18,
                      backgroundColor: "rgba(52,211,153,0.08)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Rate")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {commissionPercent}%
                    </Text>
                  </View>

                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: "rgba(52,211,153,0.20)",
                      borderRadius: 18,
                      backgroundColor: "rgba(52,211,153,0.08)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>
  {uiText("Accumulated Commission")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {fmtMoney(accruedCommission)}
                    </Text>
                  </View>
                </View>

                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: UI.border,
                      borderRadius: 18,
                      backgroundColor: "rgba(255,255,255,0.04)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>
  {uiText("Total Cashed Out")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {fmtMoney(paidCommission)}
                    </Text>
                  </View>

                  <View
                    style={{
                      flex: 1,
                      borderWidth: 1,
                      borderColor: "rgba(52,211,153,0.20)",
                      borderRadius: 18,
                      backgroundColor: "rgba(52,211,153,0.08)",
                      padding: 12,
                    }}
                  >
                    <Text style={{ color: UI.muted, fontWeight: "800" }}>
  {uiText("Unpaid Balance")}</Text>
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 6 }}>
                      {fmtMoney(remainingCommission)}
                    </Text>
                  </View>
                </View>

                <View
                  style={{
                    borderWidth: 1,
                    borderColor: payoutProfileConfigured
                      ? "rgba(52,211,153,0.20)"
                      : "rgba(251,113,133,0.28)",
                    borderRadius: 18,
                    backgroundColor: payoutProfileConfigured
                      ? "rgba(52,211,153,0.08)"
                      : "rgba(251,113,133,0.08)",
                    padding: 12,
                    gap: 8,
                  }}
                >
                  <Text
                    style={{
                      color: payoutProfileConfigured ? UI.emerald : UI.danger,
                      fontWeight: "900",
                      fontSize: 12,
                    }}
                  >
                    {payoutProfileConfigured ? uiText("PAYOUT PROFILE READY") : uiText("PAYOUT PROFILE MISSING")}
                  </Text>

                  {!payoutProfileConfigured ? (
                    <Text style={{ color: UI.text, fontWeight: "900", marginTop: 2 }}>
                      {uiText("Staff hajajaza destination ya commission bado.")}</Text>
                  ) : (
                    <>
                      <Text style={{ color: UI.text, fontWeight: "900", marginTop: 2 }}>
                        {payoutMethod || "—"}{payoutDestination ? ` • ${payoutDestination}` : ""}
                      </Text>

                      <Text style={{ color: UI.muted, fontWeight: "800" }}>
                        {uiText("Account Holder")}</Text>
                      <Text style={{ color: UI.text, fontWeight: "900" }}>
                        {String(r.payout_account_holder_name ?? "").trim() || "—"}
                      </Text>

                      {payoutMethod.toUpperCase() === "MOBILE" ? (
                        <>
                          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Network")}</Text>
                          <Text style={{ color: UI.text, fontWeight: "900" }}>
                            {String(r.payout_mobile_network ?? "").trim() || "—"}
                          </Text>

                          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Mobile Number")}</Text>
                          <Text style={{ color: UI.text, fontWeight: "900" }}>
                            {String(r.payout_mobile_number ?? "").trim() || "—"}
                          </Text>
                        </>
                      ) : null}

                      {payoutMethod.toUpperCase() === "BANK" ? (
                        <>
                          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Bank")}</Text>
                          <Text style={{ color: UI.text, fontWeight: "900" }}>
                            {String(r.payout_bank_name ?? "").trim() || "—"}
                          </Text>

                          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Bank Account Name")}</Text>
                          <Text style={{ color: UI.text, fontWeight: "900" }}>
                            {String(r.payout_bank_account_name ?? "").trim() || "—"}
                          </Text>

                          <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Bank Account Number")}</Text>
                          <Text style={{ color: UI.text, fontWeight: "900" }}>
                            {String(r.payout_bank_account_number ?? "").trim() || "—"}
                          </Text>
                        </>
                      ) : null}
                    </>
                  )}
                </View>

                <View>
                  <Text style={{ color: UI.muted, fontWeight: "800", marginBottom: 6 }}>
                    {uiText("Set Commission %")}</Text>

                  <View style={{ flexDirection: "row", gap: 10 }}>
                    <TextInput
                      value={draft}
                      onChangeText={(v) =>
                        setDrafts((prev) => ({
                          ...prev,
                          [membershipId]: cleanPercentInput(v),
                        }))
                      }
                      placeholder="0"
                      placeholderTextColor="rgba(255,255,255,0.35)"
                      keyboardType="numeric"
                      style={{
                        flex: 1,
                        borderWidth: 1,
                        borderColor: UI.border,
                        borderRadius: 18,
                        backgroundColor: "rgba(255,255,255,0.05)",
                        paddingHorizontal: 14,
                        paddingVertical: 12,
                        color: UI.text,
                        fontWeight: "800",
                      }}
                    />

                    <Pressable
                      onPress={() => void savePercent(membershipId)}
                      disabled={isSaving}
                      style={{
                        minWidth: 110,
                        borderWidth: 1,
                        borderColor: "rgba(52,211,153,0.30)",
                        borderRadius: 18,
                        backgroundColor: "rgba(52,211,153,0.10)",
                        paddingHorizontal: 14,
                        paddingVertical: 12,
                        alignItems: "center",
                        justifyContent: "center",
                        opacity: isSaving ? 0.65 : 1,
                      }}
                    >
                      <Text style={{ color: UI.text, fontWeight: "900" }}>
                        {isSaving ? uiText("Saving...") : uiText("Save")}
                      </Text>
                    </Pressable>
                  </View>

                 <Text
  style={{
    color: UI.faint,
    fontWeight: "800",
    marginTop: 8,
    lineHeight: 20,
  }}
>
  {uiText("Ukiweka 0%, sales zitaendelea kurekodiwa kawaida lakini commission mpya haitahesabiwa. Commission iliyokwisha kukusanyika na ambayo bado haijalipwa itaendelea kuhifadhiwa mpaka ifanyiwe cash-out.")}</Text>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
} 