﻿import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
import {useCommonText} from "@/src/i18n/useCommonText";
import React from "react";

import {
  Modal,
  Pressable,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";

import FinancialChart, {
  type FinancialTrendMetric,
} from "./FinancialChart";

import type {
  FinancialComparisonResult,
  FinancialOverviewResult,
} from "./financialDataEngine";

import type {
  FinancialDateRange,
  FinancialPeriodMode,
} from "./periodEngine";

type PeriodOption = {
  value: FinancialPeriodMode;
  label: string;
};

type MetricOption = {
  value: FinancialTrendMetric;
  label: string;
  color: string;
  activeBackground: string;
};

type Props = {
  visible: boolean;
  onClose: () => void;

  result: FinancialOverviewResult;
  comparison: FinancialComparisonResult | null;

  periodMode: FinancialPeriodMode;
  onPeriodChange: (
    value: FinancialPeriodMode
  ) => void;

  selectedMetric: FinancialTrendMetric;
  onMetricChange: (
    value: FinancialTrendMetric
  ) => void;

  periodOptions: PeriodOption[];
  metricOptions: MetricOption[];

  rangeLabel: string;
  periodLabel: string;

  customRangeDraft: FinancialDateRange;
  customRangeError?: string;

  onCustomFromChange: (
    value: string
  ) => void;

  onCustomToChange: (
    value: string
  ) => void;

  onApplyCustomRange: () => void;

  loading?: boolean;
  errorText?: string;
};

function money(
  value: number
) {
  const amount = Number.isFinite(value)
    ? value
    : 0;

  return new Intl.NumberFormat(
    "en-US",
    {
      maximumFractionDigits: 0,
    }
  ).format(amount);
}

function signedPercent(
  value: number | null
) {
  if (
    value === null ||
    !Number.isFinite(value)
  ) {
    return "N/A";
  }

  const sign =
    value > 0
      ? "+"
      : "";

  return `${sign}${value.toFixed(1)}%`;
}

function signedMoney(
  value: number
) {
  const amount =
    Number.isFinite(value)
      ? value
      : 0;

  return `TSh ${money(amount)}`;
}

function changeColor(
  value: number | null,
  inverse = false
) {
  if (
    value === null ||
    !Number.isFinite(value) ||
    value === 0
  ) {
    return "#64748B";
  }

  const positive =
    inverse
      ? value < 0
      : value > 0;

  return positive
    ? "#16A34A"
    : "#DC2626";
}

function ChangeBadge({
  value,
  inverse = false,
}: {
  value: number | null;
  inverse?: boolean;
}) {
  const color =
    changeColor(
      value,
      inverse
    );

  return (
    <View
      style={{
        paddingHorizontal: 7,
        paddingVertical: 4,
        borderRadius: 999,
        backgroundColor:
          color === "#16A34A"
            ? "#F0FDF4"
            : color === "#DC2626"
              ? "#FEF2F2"
              : "#F8FAFC",
        borderWidth: 1,
        borderColor:
          color === "#16A34A"
            ? "#BBF7D0"
            : color === "#DC2626"
              ? "#FECACA"
              : "#E2E8F0",
      }}
    >
      <Text
        style={{
          color,
          fontSize: 9,
          fontWeight: "900",
        }}
      >
        {signedPercent(value)}
      </Text>
    </View>
  );
}

function IntelligenceCard({
  label,
  value,
  previousValue,
  change,
  color,
  inverseChange = false,
  valueIsPercent = false,
}: {
  label: string;
  value: number;
  previousValue?: number;
  change?: number | null;
  color: string;
  inverseChange?: boolean;
  valueIsPercent?: boolean;
}) {
 const uiText = useCommonText();
  return (
    <View
      style={{
        flex: 1,
        minWidth: 170,
        borderWidth: 1,
        borderColor: "#E2E8F0",
        borderRadius: 14,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 13,
        paddingVertical: 11,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent:
            "space-between",
          gap: 8,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 7,
            flex: 1,
            minWidth: 0,
          }}
        >
          <View
            style={{
              width: 8,
              height: 8,
              borderRadius: 999,
              backgroundColor:
                color,
            }}
          />

          <Text
            numberOfLines={1}
            style={{
              color: "#64748B",
              fontSize: 10,
              fontWeight: "800",
            }}
          >
            {label}
          </Text>
        </View>

        {change !== undefined ? (
          <ChangeBadge
            value={change}
            inverse={
              inverseChange
            }
          />
        ) : null}
      </View>

      <Text
        numberOfLines={1}
        style={{
          marginTop: 7,
          color: "#0F172A",
          fontSize: 17,
          fontWeight: "900",
        }}
      >
        {valueIsPercent
          ? `${value.toFixed(1)}%`
          : signedMoney(value)}
      </Text>

      {previousValue !==
      undefined ? (
        <Text
          numberOfLines={1}
          style={{
            marginTop: 4,
            color: "#94A3B8",
            fontSize: 9,
            fontWeight: "700",
          }}
        >
          {uiText("Previous:")}{" "}
          {signedMoney(
            previousValue
          )}
        </Text>
      ) : (
        <Text
          style={{
            marginTop: 4,
            color: "#94A3B8",
            fontSize: 9,
            fontWeight: "700",
          }}
        >
          {uiText("Verified current period")}</Text>
      )}
    </View>
  );
}

function PeriodInsightCard({
  title,
  bucket,
  accent,
}: {
  title: string;
  bucket:
    | FinancialOverviewResult["buckets"][number]
    | null;
  accent: string;
}) {
 const uiText = useCommonText();
  return (
    <View
      style={{
        flex: 1,
        minWidth: 190,
        borderWidth: 1,
        borderColor: "#E2E8F0",
        borderRadius: 14,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 13,
        paddingVertical: 10,
        borderLeftWidth: 3,
        borderLeftColor: accent,
        shadowColor: "#0F172A",
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.035,
        shadowRadius: 8,
        elevation: 1,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 7,
        }}
      >
        <View
          style={{
            width: 8,
            height: 8,
            borderRadius: 999,
            backgroundColor:
              accent,
          }}
        />

        <Text
          style={{
            color: "#64748B",
            fontSize: 9,
            fontWeight: "900",
            textTransform:
              "uppercase",
          }}
        >
          {title}
        </Text>
      </View>

      <Text
        numberOfLines={1}
        style={{
          marginTop: 6,
          color: "#0F172A",
          fontSize: 12,
          fontWeight: "900",
        }}
      >
        {bucket?.label ??
          uiText("Not available")}
      </Text>

      <Text
        numberOfLines={1}
        style={{
          marginTop: 3,
          color:
            bucket &&
            bucket.netProfit < 0
              ? "#DC2626"
              : "#475569",
          fontSize: 10,
          fontWeight: "800",
        }}
      >
        {bucket
          ? uiText("Net {p0}: {p1}", {p0: (bucket.netProfit < 0
                ? "Loss"
                : "Profit"), p1: (signedMoney(
              bucket.netProfit
            ))})
          : uiText("No verified period data")}
      </Text>
    </View>
  );
}
function MetricCard({
  label,
  value,
  color,
  subtitle,
}: {
  label: string;
  value: number;
  color: string;
  subtitle: string;
}) {
  return (
    <View
      style={{
        flex: 1,
        minWidth: 180,
        borderWidth: 1,
        borderColor: "#DDE6F0",
        borderRadius: 16,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 16,
        paddingVertical: 11,
        borderTopWidth: 3,
        borderTopColor: color,
        shadowColor: color,
        shadowOffset: {
          width: 0,
          height: 4,
        },
        shadowOpacity: 0.055,
        shadowRadius: 10,
        elevation: 2,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 8,
        }}
      >
        <View
          style={{
            width: 9,
            height: 9,
            borderRadius: 999,
            backgroundColor: color,
          }}
        />

        <Text
          style={{
            color: "#64748B",
            fontSize: 12,
            fontWeight: "800",
          }}
        >
          {label}
        </Text>
      </View>

      <Text
        style={{
          marginTop: 6,
          color: "#0F172A",
          fontSize: 20,
          fontWeight: "900",
        }}
      >
        TSh {money(value)}
      </Text>

      <Text
        style={{
          marginTop: 5,
          color: "#94A3B8",
          fontSize: 10,
          fontWeight: "700",
        }}
      >
        {subtitle}
      </Text>
    </View>
  );
}

export default function FinancialOverviewFullView({
  visible,
  onClose,
  result,
  comparison,
  periodMode,
  onPeriodChange,
  selectedMetric,
  onMetricChange,
  periodOptions,
  metricOptions,
  rangeLabel,
  periodLabel,
  customRangeDraft,
  customRangeError = "",
  onCustomFromChange,
  onCustomToChange,
  onApplyCustomRange,
  loading = false,
  errorText = "",
}: Props) {
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const { width, height } =
    useWindowDimensions();

  const workspaceWidth = Math.max(
    760,
    Math.min(
      1320,
      width - 48
    )
  );

  const workspaceHeight = Math.max(
    520,
    Math.min(
      920,
      height - 48
    )
  );

  const chartWidth = Math.max(
    680,
    workspaceWidth - 88
  );

  /*
   * Premium Full View has two desktop density modes.
   *
   * Compact mode is used on shorter laptop displays so the
   * complete financial workspace, including the chart axis,
   * remains visible inside one viewport.
   */
  const compactHeight =
    workspaceHeight < 760;

  const chartHeight = compactHeight
    ? Math.max(
        105,
        Math.min(
          165,
          workspaceHeight - 555
        )
      )
    : Math.max(
        150,
        Math.min(
          360,
          workspaceHeight - 500
        )
      );

  const contentPaddingTop =
    compactHeight ? 8 : 14;

  const contentPaddingBottom =
    compactHeight ? 5 : 10;

  const sectionGap =
    compactHeight ? 6 : 11;

  const chartPaddingTop =
    compactHeight ? 7 : 12;

  const chartPaddingBottom =
    compactHeight ? 4 : 8;

  const netProfitNegative =
    result.total.netProfit < 0;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor:
            "rgba(15, 23, 42, 0.58)",
          padding: 24,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <View
          style={{
            width: workspaceWidth,
            height: workspaceHeight,
            maxWidth: "100%",
            maxHeight: "100%",
            borderRadius: 24,
            backgroundColor: "#F8FAFC",
            overflow: "hidden",
            borderWidth: 1,
            borderColor: "#D7E0EA",
            shadowColor: "#0F172A",
            shadowOffset: {
              width: 0,
              height: 18,
            },
            shadowOpacity: 0.18,
            shadowRadius: 34,
            elevation: 18,
          }}
        >
          {/* HEADER */}
          <View
            style={{
              minHeight: 66,
              paddingHorizontal: 22,
              paddingVertical: 11,
              backgroundColor: "#FFFFFF",
              borderBottomWidth: 1,
              borderBottomColor: "#E2E8F0",
              shadowColor: "#0F172A",
              shadowOffset: {
                width: 0,
                height: 3,
              },
              shadowOpacity: 0.035,
              shadowRadius: 8,
              elevation: 2,
              flexDirection: "row",
              alignItems: "center",
              justifyContent:
                "space-between",
              gap: 18,
            }}
          >
            <View
              style={{
                flex: 1,
                minWidth: 0,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 10,
                }}
              >
                <Text
                  style={{
                    color: "#0F172A",
                    fontSize: 21,
                    fontWeight: "900",
                  }}
                >
                  {uiText("Business Financial Overview")}</Text>

                <View
                  style={{
                    borderRadius: 999,
                    backgroundColor: "#ECFDF5",
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                  }}
                >
                  <Text
                    style={{
                      color: "#047857",
                      fontSize: 9,
                      fontWeight: "900",
                    }}
                  >
                    {uiText("VERIFIED FINANCE")}</Text>
                </View>
              </View>

              <Text
                style={{
                  marginTop: 5,
                  color: "#64748B",
                  fontSize: 11,
                  fontWeight: "700",
                }}
              >
                {rangeLabel}
              </Text>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
              }}
            >
              <View
                style={{
                  borderRadius: 10,
                  backgroundColor: "#F1F5F9",
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                }}
              >
                <Text
                  style={{
                    color: "#334155",
                    fontSize: 10,
                    fontWeight: "900",
                  }}
                >
                  {periodLabel}
                </Text>
              </View>

              <Pressable
                onPress={onClose}
                style={{
                  minWidth: 40,
                  minHeight: 40,
                  borderRadius: 11,
                  backgroundColor: "#0F172A",
                  alignItems: "center",
                  justifyContent: "center",
                  paddingHorizontal: 12,
                }}
              >
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 17,
                    fontWeight: "900",
                  }}
                >
                  ×
                </Text>
              </Pressable>
            </View>
          </View>

          <View
            style={{
              flex: 1,
              minHeight: 0,
              paddingHorizontal: 20,
              paddingTop: contentPaddingTop,
              paddingBottom: contentPaddingBottom,
              overflow: "hidden",
            }}
          >
            {/* PERIOD CONTROLS */}
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                alignItems: "center",
                gap: 8,
              }}
            >
              {periodOptions.map(
                (option) => {
                  const selected =
                    option.value ===
                    periodMode;

                  return (
                    <Pressable
                      key={option.value}
                      onPress={() =>
                        onPeriodChange(
                          option.value
                        )
                      }
                      style={{
                        minHeight: 32,
                        paddingHorizontal: 13,
                        paddingVertical: 6,
                        borderRadius: 10,
                        borderWidth: 1,
                        borderColor: selected
                          ? "#2563EB"
                          : "#E2E8F0",
                        backgroundColor: selected
                          ? "#EFF6FF"
                          : "#FFFFFF",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Text
                        style={{
                          color: selected
                            ? "#1D4ED8"
                            : "#64748B",
                          fontSize: 11,
                          fontWeight: "900",
                        }}
                      >
                        {uiText(option.label)}
                      </Text>
                    </Pressable>
                  );
                }
              )}
            </View>

            {periodMode === "CUSTOM" ? (
              <View
                style={{
                  marginTop: 10,
                  padding: 12,
                  borderWidth: 1,
                  borderColor: "#BFDBFE",
                  borderRadius: 12,
                  backgroundColor: "#F8FBFF",
                }}
              >
                <Text
                  style={{
                    color: "#0F172A",
                    fontSize: 11,
                    fontWeight: "900",
                  }}
                >
                  {uiText("Select Custom Date Range")}</Text>

                <Text
                  style={{
                    marginTop: 3,
                    color: "#64748B",
                    fontSize: 9.5,
                    fontWeight: "700",
                  }}
                >
                  {uiText("Choose the exact start and end dates, then apply the range.")}</Text>

                <View
                  style={{
                    marginTop: 10,
                    flexDirection: "row",
                    alignItems: "flex-end",
                    flexWrap: "wrap",
                    gap: 10,
                  }}
                >
                  <View
                    style={{
                      minWidth: 180,
                      flex: 1,
                    }}
                  >
                    <Text
                      style={{
                        marginBottom: 5,
                        color: "#475569",
                        fontSize: 9,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("FROM DATE")}</Text>

                    <TextInput
                      value={
                        customRangeDraft.fromYMD
                      }
                      onChangeText={
                        onCustomFromChange
                      }
                      placeholder="YYYY-MM-DD"
                      placeholderTextColor="#94A3B8"
                      accessibilityLabel={uiText("Custom range start date")}
                      {...({
                        type: "date",
                      } as any)}
                      style={{
                        width: "100%",
                        height: 38,
                        borderWidth: 1,
                        borderColor: "#CBD5E1",
                        borderRadius: 10,
                        backgroundColor: "#FFFFFF",
                        paddingHorizontal: 11,
                        color: "#0F172A",
                        fontSize: 11,
                        fontWeight: "800",
                        outlineStyle: "none",
                      } as any}
                    />
                  </View>

                  <View
                    style={{
                      minWidth: 180,
                      flex: 1,
                    }}
                  >
                    <Text
                      style={{
                        marginBottom: 5,
                        color: "#475569",
                        fontSize: 9,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("TO DATE")}</Text>

                    <TextInput
                      value={
                        customRangeDraft.toYMD
                      }
                      onChangeText={
                        onCustomToChange
                      }
                      placeholder="YYYY-MM-DD"
                      placeholderTextColor="#94A3B8"
                      accessibilityLabel={uiText("Custom range end date")}
                      {...({
                        type: "date",
                      } as any)}
                      style={{
                        width: "100%",
                        height: 38,
                        borderWidth: 1,
                        borderColor: "#CBD5E1",
                        borderRadius: 10,
                        backgroundColor: "#FFFFFF",
                        paddingHorizontal: 11,
                        color: "#0F172A",
                        fontSize: 11,
                        fontWeight: "800",
                        outlineStyle: "none",
                      } as any}
                    />
                  </View>

                  <Pressable
                    onPress={
                      onApplyCustomRange
                    }
                    accessibilityRole="button"
                    accessibilityLabel={uiText("Apply custom financial date range")}
                    style={{
                      height: 38,
                      paddingHorizontal: 18,
                      borderRadius: 10,
                      backgroundColor: "#2563EB",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Text
                      style={{
                        color: "#FFFFFF",
                        fontSize: 10,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("Apply Range")}</Text>
                  </Pressable>
                </View>

                {customRangeError ? (
                  <Text
                    style={{
                      marginTop: 7,
                      color: "#DC2626",
                      fontSize: 9.5,
                      fontWeight: "800",
                    }}
                  >
                    {systemText(customRangeError)}
                  </Text>
                ) : null}
              </View>
            ) : null}

            {/* FINANCIAL KPIs */}
            <View
              style={{
                marginTop: sectionGap,
                flexDirection: "row",
                flexWrap: "wrap",
                gap: compactHeight ? 8 : 12,
              }}
            >
              <MetricCard
                label={uiText("Sales")}
                value={result.total.sales}
                color="#2563EB"
                subtitle={uiText("Verified sales in selected period")}
              />

              <MetricCard
                label={uiText("Expenses")}
                value={result.total.expenses}
                color="#F59E0B"
                subtitle={uiText("Verified expenses in selected period")}
              />

              <MetricCard
                label={
                  netProfitNegative
                    ? uiText("Net Loss")
                    : uiText("Net Profit")
                }
                value={result.total.netProfit}
                color={
                  netProfitNegative
                    ? "#DC2626"
                    : "#16A34A"
                }
                subtitle={
                  netProfitNegative
                    ? uiText("Verified loss in selected period")
                    : uiText("Verified net profit in selected period")
                }
              />
            </View>

            {/* PREMIUM FINANCIAL INTELLIGENCE */}
            {comparison ? (
              <View
                style={{
                  marginTop: sectionGap,
                  gap: compactHeight ? 5 : 9,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent:
                      "space-between",
                    gap: 10,
                  }}
                >
                  <View>
                    <Text
                      style={{
                        color: "#0F172A",
                        fontSize: 12,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("Performance Intelligence")}</Text>

                    <Text
                      style={{
                        marginTop: 2,
                        color: "#94A3B8",
                        fontSize: 9,
                        fontWeight: "700",
                      }}
                    >
                      {uiText("Current period compared with the previous equivalent period")}</Text>
                  </View>

                  <View
                    style={{
                      paddingHorizontal: 8,
                      paddingVertical: 5,
                      borderRadius: 999,
                      backgroundColor:
                        "#F8FAFC",
                      borderWidth: 1,
                      borderColor:
                        "#E2E8F0",
                    }}
                  >
                    <Text
                      style={{
                        color: "#475569",
                        fontSize: 8.5,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("VERIFIED COMPARISON")}</Text>
                  </View>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    gap: 9,
                  }}
                >
                  <IntelligenceCard
                    label={uiText("Sales Growth")}
                    value={
                      comparison.current
                        .total.sales
                    }
                    previousValue={
                      comparison.previous
                        .total.sales
                    }
                    change={
                      comparison.change
                        .sales
                    }
                    color="#2563EB"
                  />

                  <IntelligenceCard
                    label={uiText("Expense Change")}
                    value={
                      comparison.current
                        .total.expenses
                    }
                    previousValue={
                      comparison.previous
                        .total.expenses
                    }
                    change={
                      comparison.change
                        .expenses
                    }
                    color="#F59E0B"
                    inverseChange
                  />

                  <IntelligenceCard
                    label={
                      comparison.current
                        .total.netProfit <
                      0
                        ? uiText("Net Loss")
                        : uiText("Net Profit")
                    }
                    value={
                      comparison.current
                        .total.netProfit
                    }
                    previousValue={
                      comparison.previous
                        .total.netProfit
                    }
                    change={
                      comparison.change
                        .netProfit
                    }
                    color={
                      comparison.current
                        .total.netProfit <
                      0
                        ? "#DC2626"
                        : "#16A34A"
                    }
                  />

                  <IntelligenceCard
                    label={uiText("Profit Margin")}
                    value={
                      comparison.insight
                        .profitMargin ?? 0
                    }
                    color="#7C3AED"
                    valueIsPercent
                  />
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    gap: 9,
                  }}
                >
                  <PeriodInsightCard
                    title={uiText("Best Period")}
                    bucket={
                      comparison.insight
                        .bestPeriod
                    }
                    accent="#16A34A"
                  />

                  <PeriodInsightCard
                    title={uiText("Weakest Period")}
                    bucket={
                      comparison.insight
                        .weakestPeriod
                    }
                    accent="#DC2626"
                  />
                </View>
              </View>
            ) : null}
            {/* MAIN CHART WORKSPACE */}
            <View
              style={{
                marginTop: sectionGap,
                flex: 1,
                minHeight: 0,
                borderWidth: 1,
                borderColor: "#D8E2EC",
                borderRadius: 18,
                backgroundColor: "#FFFFFF",
                shadowColor: "#0F172A",
                shadowOffset: {
                  width: 0,
                  height: 5,
                },
                shadowOpacity: 0.045,
                shadowRadius: 12,
                elevation: 2,
                paddingHorizontal: 16,
                paddingTop: chartPaddingTop,
                paddingBottom: chartPaddingBottom,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent:
                    "space-between",
                  gap: 12,
                  flexWrap: "wrap",
                }}
              >
                <View>
                  <Text
                    style={{
                      color: "#0F172A",
                      fontSize: 16,
                      fontWeight: "900",
                      letterSpacing: -0.2,
                    }}
                  >
                    {uiText("Financial Performance")}</Text>

                  <Text
                    style={{
                      marginTop: 3,
                      color: "#94A3B8",
                      fontSize: 10,
                      fontWeight: "700",
                    }}
                  >
                    {uiText("Interactive verified financial trend")}</Text>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 7,
                    padding: 4,
                    borderRadius: 12,
                    backgroundColor: "#F8FAFC",
                    borderWidth: 1,
                    borderColor: "#E2E8F0",
                  }}
                >
                  {metricOptions.map(
                    (option) => {
                      const selected =
                        option.value ===
                        selectedMetric;

                      return (
                        <Pressable
                          key={option.value}
                          onPress={() =>
                            onMetricChange(
                              option.value
                            )
                          }
                          style={{
                            minHeight: 36,
                            flexDirection: "row",
                            alignItems: "center",
                            justifyContent:
                              "center",
                            gap: 7,
                            paddingHorizontal: 12,
                            paddingVertical: 7,
                            borderRadius: 9,
                            borderWidth:
                              selected ? 1 : 0,
                            borderColor:
                              selected
                                ? option.color
                                : "transparent",
                            backgroundColor:
                              selected
                                ? option.activeBackground
                                : "transparent",
                          }}
                        >
                          <View
                            style={{
                              width: 8,
                              height: 8,
                              borderRadius: 999,
                              backgroundColor:
                                option.color,
                            }}
                          />

                          <Text
                            style={{
                              color: selected
                                ? option.color
                                : "#64748B",
                              fontSize: 10,
                              fontWeight: "900",
                            }}
                          >
                            {uiText(option.label)}
                          </Text>
                        </Pressable>
                      );
                    }
                  )}
                </View>
              </View>

              {/* PERIOD COMPARISON LEGEND */}
              {comparison ? (
                <View
                  style={{
                    marginTop: compactHeight ? 4 : 7,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "flex-end",
                    gap: 16,
                    paddingRight: 4,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 7,
                    }}
                  >
                    <View
                      style={{
                        width: 24,
                        height: 3,
                        borderRadius: 999,
                        backgroundColor: "#2563EB",
                      }}
                    />

                    <Text
                      style={{
                        color: "#334155",
                        fontSize: 9.5,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("Selected Period")}</Text>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 7,
                    }}
                  >
                    <View
                      style={{
                        width: 7,
                        height: 3,
                        borderRadius: 999,
                        backgroundColor: "#7C3AED",
                      }}
                    />

                    <View
                      style={{
                        width: 7,
                        height: 3,
                        borderRadius: 999,
                        backgroundColor: "#7C3AED",
                      }}
                    />

                    <View
                      style={{
                        width: 7,
                        height: 3,
                        borderRadius: 999,
                        backgroundColor: "#7C3AED",
                      }}
                    />

                    <Text
                      style={{
                        color: "#6D28D9",
                        fontSize: 9.5,
                        fontWeight: "900",
                      }}
                    >
                      {uiText("Previous Equivalent Period")}</Text>
                  </View>
                </View>
              ) : null}

              {loading ? (
                <View
                  style={{
                    minHeight: chartHeight,
                    alignItems: "center",
                    justifyContent:
                      "center",
                  }}
                >
                  <Text
                    style={{
                      color: "#64748B",
                      fontSize: 12,
                      fontWeight: "800",
                    }}
                  >
                    {uiText("Loading verified finance data...")}</Text>
                </View>
              ) : errorText ? (
                <View
                  style={{
                    minHeight: chartHeight,
                    alignItems: "center",
                    justifyContent:
                      "center",
                    paddingHorizontal: 20,
                  }}
                >
                  <Text
                    style={{
                      color: "#B91C1C",
                      fontSize: 12,
                      fontWeight: "800",
                      textAlign: "center",
                    }}
                  >
                    {errorText}
                  </Text>
                </View>
              ) : (
                <View
                  style={{
                    marginTop: compactHeight ? 3 : 8,
                    flex: 1,
                    minHeight: 0,
                    width: "100%",
                    overflow: "hidden",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <FinancialChart
                    mode="TREND"
                    metric={
                      selectedMetric
                    }
                    total={result.total}
                    buckets={
                      result.buckets
                    }
                    previousBuckets={
                      comparison?.previous
                        .buckets ?? []
                    }
                    width={chartWidth}
                    height={chartHeight}
                  />
                </View>
              )}
            </View>

            <Text
              style={{
                marginTop: 5,
                color: "#64748B",
                fontSize: 8,
                fontWeight: "700",
                textAlign: "center",
              }}
            >
              {uiText("ZETRA Business Financial Intelligence")}</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}









