import {useCommonText} from "@/src/i18n/useCommonText";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";

import { useOrg } from "../src/context/OrgContext";
import { supabase } from "../src/supabase/supabaseClient";

import { Button } from "../src/ui/Button";
import { Card } from "../src/ui/Card";
import { Screen } from "../src/ui/Screen";
import { UI } from "../src/ui/theme";

type OrgItem = {
  organization_id: string;
  organization_name: string;
  role: "owner" | "admin" | "staff";
};

type PlanInfo = {
  code?: string;
  name?: string;
  max_organizations?: number;
};

type MySubRow = {
  plan_code?: string;
  plan_name?: string;
  max_organizations?: number;
  [k: string]: any;
};

function normName(s: string) {
  return String(s ?? "").trim().toUpperCase();
}

function isNonEmpty(s: string) {
  return String(s ?? "").trim().length > 0;
}

function roleLabel(role: OrgItem["role"]) {
  if (role === "owner") return "owner";
  if (role === "admin") return "admin";
  return "staff";
}

function Badge({
  text,
  variant,
}: {
  text: string;
  variant: "active" | "muted";
}) {
  const bg =
    variant === "active" ? "rgba(52,211,153,0.16)" : "rgba(148,163,184,0.10)";
  const border =
    variant === "active" ? "rgba(52,211,153,0.45)" : "rgba(148,163,184,0.22)";
  const color = variant === "active" ? "rgb(52,211,153)" : UI.muted;

  return (
    <View
      style={{
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 999,
        backgroundColor: bg,
        borderWidth: 1,
        borderColor: border,
      }}
    >
      <Text style={{ color, fontWeight: "900", fontSize: 12 }}>{text}</Text>
    </View>
  );
}

function clean(s: any) {
  return String(s ?? "").trim();
}

function upper(s: any) {
  return clean(s).toUpperCase();
}

/**
 * ORG_LIMIT_REACHED: plan=FREE | orgs_allowed=1 | owned=1
 */
function parseOrgLimitError(
  msgRaw: string
): { plan?: string; allowed?: string; owned?: string } | null {
  const msg = clean(msgRaw);
  if (!msg) return null;
  if (!msg.toUpperCase().includes("ORG_LIMIT_REACHED")) return null;

  const plan = (msg.match(/plan\s*=\s*([A-Z0-9_]+)/i)?.[1] || "").toUpperCase();
  const allowed = msg.match(/orgs_allowed\s*=\s*([0-9]+)/i)?.[1] || "";
  const owned = msg.match(/owned\s*=\s*([0-9]+)/i)?.[1] || "";
  return { plan, allowed, owned };
}

function prettyPlanLabel(p: PlanInfo) {
  const code = clean(p.code).toUpperCase();
  const name = clean(p.name);
  if (name) return name;
  if (code) return code;
  return "—";
}

function safeInt(x: any, fallback = 0) {
  const n = Number(x);
  return Number.isFinite(n) ? n : fallback;
}

async function fetchActiveOrgPlanInfo(
  activeOrgId: string | null | undefined
): Promise<PlanInfo | null> {
  const orgId = clean(activeOrgId);
  if (!orgId) return null;

  const { data, error } = await supabase.rpc("get_my_subscription", {
    p_org_id: orgId,
  });

  if (error) return null;

  const row = (Array.isArray(data) ? data?.[0] : data) as MySubRow | null;
  if (!row) return null;

  const code = upper(row?.plan_code);
  const name = clean(row?.plan_name);
  const maxOrganizations = safeInt(row?.max_organizations, 0);

  if (!code && !name && !maxOrganizations) return null;

  return {
    code: code || undefined,
    name: name || undefined,
    max_organizations: maxOrganizations || undefined,
  };
}

export default function OrgSwitcherScreen() {
 const uiText=useCommonText();
  const router = useRouter();
  const { width, height } = useWindowDimensions();

  const isWeb = Platform.OS === "web";
  const isDesktopWeb = isWeb && width >= 1100;
  const desktopMaxWidth = width >= 1600 ? 1460 : width >= 1380 ? 1320 : 1200;

  const {
    orgs,
    activeOrgId,
    setActiveOrgId,
    refresh,
    createOrgWithStore,
    loading,
    refreshing,
  } = useOrg();

  const [orgName, setOrgName] = useState("");
  const [storeName, setStoreName] = useState("");
  const [creating, setCreating] = useState(false);

  const [showAll, setShowAll] = useState(false);
  const [q, setQ] = useState("");

  const [renameOpen, setRenameOpen] = useState(false);
  const [renameOrg, setRenameOrg] = useState<OrgItem | null>(null);
  const [renameName, setRenameName] = useState("");
  const [renaming, setRenaming] = useState(false);

  const typedOrgs = (orgs ?? []) as OrgItem[];

  const filteredOrgs = useMemo(() => {
    const query = clean(q).toLowerCase();
    if (!query) return typedOrgs;

    return typedOrgs.filter((o) => {
      const name = clean(o.organization_name).toLowerCase();
      const role = clean(o.role).toLowerCase();
      return name.includes(query) || role.includes(query);
    });
  }, [typedOrgs, q]);

  const grouped = useMemo(() => {
    const map = new Map<string, OrgItem[]>();

    for (const o of filteredOrgs) {
      const key = `${normName(o.organization_name)}::${o.role}`;
      const list = map.get(key) ?? [];
      list.push(o);
      map.set(key, list);
    }

    const entries = Array.from(map.entries()).map(([key, list]) => {
      const isActiveInGroup = list.some((x) => x.organization_id === activeOrgId);
      const displayName = list[0]?.organization_name ?? "—";
      const role = list[0]?.role ?? "staff";
      return { key, list, displayName, role, isActiveInGroup };
    });

    entries.sort((a, b) => {
      if (a.isActiveInGroup && !b.isActiveInGroup) return -1;
      if (!a.isActiveInGroup && b.isActiveInGroup) return 1;
      return normName(a.displayName).localeCompare(normName(b.displayName));
    });

    return entries;
  }, [filteredOrgs, activeOrgId]);

  const canCreate = useMemo(() => {
    if (creating) return false;
    return isNonEmpty(orgName) && isNonEmpty(storeName);
  }, [orgName, storeName, creating]);

  const onSwitch = async (orgId: string) => {
    setActiveOrgId(orgId);

    // ruhusu OrgContext ipate muda wa kubadilisha org/store/role
    setTimeout(() => {
      router.replace("/(tabs)" as any);
    }, 0);
  };

  const onPressGroup = async (list: OrgItem[]) => {
    const pick = list.find((x) => x.organization_id === activeOrgId) ?? list[0] ?? null;
    if (!pick) return;
    await onSwitch(pick.organization_id);
  };

  const showUpgradeRequired = (info: { planLabel: string; allowed: number }) => {
    const planLabel = clean(info.planLabel) || "—";
    const allowed = safeInt(info.allowed, 1);

    const body =
      `Umefika limit ya kuongeza organizations kwenye kifurushi chako.\n\n` +
      `Kifurushi: ${planLabel}\n` +
      `Organizations zinazoruhusiwa: ${allowed}\n\n` +
      `Ili kuongeza organization nyingine, tafadhali fanya upgrade.`;

    Alert.alert(uiText("Upgrade Required"), body, [{ text: uiText("Sawa") }]);
  };

  const handleLimitPopup = async (errMsg: string) => {
    // First choice: active org subscription shown inside the app
    const plan = await fetchActiveOrgPlanInfo(activeOrgId);
    if (plan) {
      showUpgradeRequired({
        planLabel: prettyPlanLabel(plan),
        allowed: plan.max_organizations && plan.max_organizations > 0 ? plan.max_organizations : 1,
      });
      return;
    }

    // Fallback: parse DB error
    const lim = parseOrgLimitError(errMsg);
    if (lim) {
      const planLabel = lim.plan ? lim.plan.toUpperCase() : "CURRENT";
      const allowed = safeInt(lim.allowed, 1);
      showUpgradeRequired({ planLabel, allowed });
      return;
    }

    showUpgradeRequired({ planLabel: "CURRENT", allowed: 1 });
  };

  const onCreate = async () => {
    const nameRaw = clean(orgName);
    const storeRaw = clean(storeName);

    if (!nameRaw || !storeRaw) return;

    const desired = normName(nameRaw);
    const existingSameName = typedOrgs.filter((o) => normName(o.organization_name) === desired);

    if (existingSameName.length > 0) {
      const pick =
        existingSameName.find((x) => x.organization_id === activeOrgId) ?? existingSameName[0];

      Alert.alert(
        uiText("Organization already exists"),
        uiText("Organization \"{p0}\" tayari ipo. Unataka ku-switch badala ya ku-create nyingine?", {p0: (desired)}),
        [
          { text: uiText("Cancel"), style: "cancel" },
          { text: uiText("Switch"), onPress: () => { void onSwitch(pick.organization_id); } },
          {
            text: uiText("Create anyway"),
            style: "destructive",
            onPress: async () => {
              setCreating(true);
              try {
                await createOrgWithStore({
                  p_org_name: nameRaw,
                  p_first_store_name: storeRaw,
                });
                setOrgName("");
                setStoreName("");
                setQ("");
                Alert.alert(uiText("Success ✅"), uiText("Organization imeundwa"));
              } catch (e: any) {
                const msg = clean(e?.message);
                const lim = parseOrgLimitError(msg);
                if (lim) {
                  await handleLimitPopup(msg);
                } else {
                  Alert.alert(uiText("Failed"), msg || uiText("Failed to create organization"));
                }
              } finally {
                setCreating(false);
              }
            },
          },
        ]
      );
      return;
    }

    setCreating(true);
    try {
      await createOrgWithStore({
        p_org_name: nameRaw,
        p_first_store_name: storeRaw,
      });
      setOrgName("");
      setStoreName("");
      setQ("");
      Alert.alert(uiText("Success ✅"), uiText("Organization imeundwa"));
    } catch (e: any) {
      const msg = clean(e?.message);
      const lim = parseOrgLimitError(msg);
      if (lim) {
        await handleLimitPopup(msg);
      } else {
        Alert.alert(uiText("Failed"), msg || uiText("Failed to create organization"));
      }
    } finally {
      setCreating(false);
    }
  };
const openRenameOrg = (org: OrgItem) => {
    if (org.role !== "owner") {
      Alert.alert(uiText("Not allowed"), uiText("Owner pekee ndiye anaweza kubadili jina la organization."));
      return;
    }

    setRenameOrg(org);
    setRenameName(clean(org.organization_name));
    setRenameOpen(true);
  };

  const closeRenameOrg = () => {
    if (renaming) return;
    setRenameOpen(false);
    setRenameOrg(null);
    setRenameName("");
  };

  const onRenameOrg = async () => {
    const org = renameOrg;
    const newName = clean(renameName);

    if (!org) return;

    if (org.role !== "owner") {
      Alert.alert(uiText("Not allowed"), uiText("Owner pekee ndiye anaweza kubadili jina la organization."));
      return;
    }

    if (!newName) {
      Alert.alert(uiText("Required"), uiText("Weka jina jipya la organization."));
      return;
    }

    if (normName(newName) === normName(org.organization_name)) {
      closeRenameOrg();
      return;
    }

    setRenaming(true);
    try {
      const { error } = await supabase
        .from("organizations")
        .update({ name: newName })
        .eq("id", org.organization_id);

      if (error) throw error;

      await refresh();
      closeRenameOrg();
      Alert.alert(uiText("Success ✅"), uiText("Jina la organization limebadilishwa."));
    } catch (e: any) {
      Alert.alert(uiText("Failed"), clean(e?.message) || uiText("Failed to rename organization"));
    } finally {
      setRenaming(false);
    }
  };
  const topRightBusy = loading || refreshing || creating;

  return (
    <Screen>
      <View
        style={{
          flex: 1,
          width: "100%",
          maxWidth: isDesktopWeb ? desktopMaxWidth : undefined,
          alignSelf: "center",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "flex-start",
            gap: 12,
            marginBottom: 10,
          }}
        >
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: isDesktopWeb ? 34 : 26, fontWeight: "900", color: UI.text }}>
              {uiText("Organizations")}</Text>

            <Text
              style={{
                color: UI.muted,
                fontWeight: "700",
                marginTop: 6,
                fontSize: isDesktopWeb ? 15 : 14,
              }}
            >
              {uiText("Switch or create another organization")}</Text>
          </View>

          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <Pressable
              onPress={() => refresh()}
              disabled={loading || refreshing}
              hitSlop={12}
              style={{
                paddingHorizontal: 10,
                paddingVertical: 8,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: UI.border,
                opacity: loading || refreshing ? 0.6 : 1,
              }}
            >
              {loading || refreshing ? (
                <ActivityIndicator />
              ) : (
                <Text style={{ fontSize: 16, color: UI.muted, fontWeight: "900" }}>↻</Text>
              )}
            </Pressable>

            <Pressable
              onPress={() => router.back()}
              hitSlop={12}
              style={{
                paddingHorizontal: 10,
                paddingVertical: 8,
                borderRadius: 12,
                borderWidth: 1,
                borderColor: UI.border,
              }}
            >
              <Text style={{ fontSize: 16, color: UI.muted, fontWeight: "900" }}>✕</Text>
            </Pressable>
          </View>
        </View>

        <View
          style={{
            flex: 1,
            flexDirection: isDesktopWeb ? "row" : "column",
            alignItems: "flex-start",
            gap: 18,
          }}
        >
          <View
            style={{
              width: isDesktopWeb ? 380 : "100%",
              minWidth: isDesktopWeb ? 380 : undefined,
            }}
          >
            <Card style={{ marginTop: 6, gap: 10 }}>
              <Text style={{ color: UI.text, fontWeight: "900", fontSize: 16 }}>
                {uiText("Create Organization")}</Text>

              <TextInput
                value={orgName}
                onChangeText={setOrgName}
                placeholder={uiText("Organization / Business name")}
                placeholderTextColor={UI.faint}
                style={{
                  borderWidth: 1,
                  borderColor: UI.border,
                  borderRadius: 14,
                  padding: 14,
                  color: UI.text,
                  fontWeight: "800",
                }}
                autoCapitalize="words"
                returnKeyType="next"
              />

              <TextInput
                value={storeName}
                onChangeText={setStoreName}
                placeholder={uiText("First store name")}
                placeholderTextColor={UI.faint}
                style={{
                  borderWidth: 1,
                  borderColor: UI.border,
                  borderRadius: 14,
                  padding: 14,
                  color: UI.text,
                  fontWeight: "800",
                }}
                autoCapitalize="words"
                returnKeyType="done"
              />

              <Text style={{ color: UI.muted, fontWeight: "700", marginTop: 2 }}>
                {uiText("Tip: Jaza majina yote mawili ndipo “Create & Switch” iwe active.")}</Text>

              <Button
                title={creating ? uiText("Creating...") : uiText("Create & Switch")}
                onPress={onCreate}
                disabled={!canCreate}
                variant="primary"
              />
            </Card>
          </View>

          <View style={{ flex: 1, width: "100%" }}>
            <View
              style={{
                marginTop: 6,
                marginBottom: 8,
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
              }}
            >
              <Text style={{ color: UI.muted, fontWeight: "800", flex: 1, fontSize: isDesktopWeb ? 15 : 14 }}>
                {uiText("Your Organizations")}</Text>

              <Pressable
                onPress={() => setShowAll((v) => !v)}
                hitSlop={10}
                style={{
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  borderRadius: 999,
                  borderWidth: 1,
                  borderColor: UI.border,
                }}
              >
                <Text style={{ color: UI.muted, fontWeight: "900" }}>
                  {showAll ? uiText("Grouped view") : uiText("Show individual")}
                </Text>
              </Pressable>
            </View>

            <View style={{ marginBottom: 10 }}>
              <TextInput
                value={q}
                onChangeText={setQ}
                placeholder={uiText("Search organizations (name or role)...")}
                placeholderTextColor={UI.faint}
                style={{
                  borderWidth: 1,
                  borderColor: UI.border,
                  borderRadius: 14,
                  padding: 14,
                  color: UI.text,
                  fontWeight: "800",
                }}
                autoCapitalize="none"
                autoCorrect={false}
                clearButtonMode="while-editing"
              />
            </View>

            <ScrollView
              style={{
                flex: 1,
                height: isDesktopWeb ? Math.max(420, height - 185) : undefined,
                maxHeight: isDesktopWeb ? Math.max(420, height - 185) : undefined,
                ...(Platform.OS === "web" ? ({ overflowY: "auto" } as any) : {}),
              }}
              contentContainerStyle={{ paddingBottom: isDesktopWeb ? 80 : 18 }}
              showsVerticalScrollIndicator
              nestedScrollEnabled
              refreshControl={
                Platform.OS === "web" ? undefined : (
                  <RefreshControl refreshing={!!refreshing} onRefresh={refresh} tintColor={UI.muted} />
                )
              }
            >
          {loading ? (
            <Card style={{ marginTop: 6 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <ActivityIndicator />
                <Text style={{ color: UI.muted, fontWeight: "800" }}>{uiText("Loading organizations…")}</Text>
              </View>
            </Card>
          ) : null}

          {!loading && filteredOrgs.length === 0 ? (
            <Card style={{ marginTop: 6 }}>
              <Text style={{ color: UI.text, fontWeight: "900", fontSize: 16 }}>
                {uiText("No organizations found")}</Text>
              <Text style={{ color: UI.muted, fontWeight: "700", marginTop: 6 }}>
                {isNonEmpty(q)
                  ? uiText("Hakuna kilicholingana na search yako. Jaribu maneno mengine.")
                  : uiText("Bado hujaunda organization. Tumia form ya juu ku-create.")}
              </Text>
            </Card>
          ) : null}

          {!showAll
            ? grouped.map((g) => {
                const list = g.list;
                const activeInGroup = list.some((x) => x.organization_id === activeOrgId);
                const count = list.length;
                const ownerOrg = list.find((x) => x.role === "owner") ?? null;

                return (
                  <Pressable
                    key={g.key}
                    onPress={() => {
                      void onPressGroup(list);
                    }}
                    disabled={topRightBusy}
                  > 
                    <Card
                      style={{
                        marginBottom: 12,
                        borderColor: activeInGroup ? "rgba(52,211,153,0.55)" : UI.border,
                        padding: isDesktopWeb ? 18 : 16,
                      }}
                    >
                      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                        <View style={{ flex: 1, minWidth: 0 }}>
                          <Text
                            style={{
                              color: UI.text,
                              fontWeight: "900",
                              fontSize: isDesktopWeb ? 20 : 16,
                            }}
                            numberOfLines={1}
                          >
                            {g.displayName}
                          </Text>

                          <Text
                            style={{
                              color: UI.faint,
                              fontWeight: "700",
                              marginTop: 6,
                              fontSize: 12,
                            }}
                            numberOfLines={1}
                          >
                            {count > 1
                              ? uiText("{p0} linked memberships in this grouped view", {p0: (count)})
                              : uiText("Single organization entry")}
                          </Text>

                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "center",
                              flexWrap: "wrap",
                              gap: 8,
                              marginTop: 10,
                            }}
                          >
                            <Badge text={`ROLE: ${roleLabel(g.role).toUpperCase()}`} variant="muted" />
                            {count > 1 ? <Badge text={`${count} ITEMS`} variant="muted" /> : null}
                            {activeInGroup ? <Badge text="ACTIVE" variant="active" /> : null}

                            {ownerOrg ? (
                              <Pressable
                                onPress={(e: any) => {
                                  e?.stopPropagation?.();
                                  openRenameOrg(ownerOrg);
                                }}
                                hitSlop={8}
                                style={{
                                  paddingHorizontal: 10,
                                  paddingVertical: 6,
                                  borderRadius: 999,
                                  borderWidth: 1,
                                  borderColor: UI.border,
                                  backgroundColor: "rgba(255,255,255,0.04)",
                                }}
                              >
                                <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
                                  {uiText("✎ RENAME")}</Text>
                              </Pressable>
                            ) : null}
                          </View>
                        </View>
{ownerOrg ? (
  <Pressable
    onPress={(e: any) => {
      e?.stopPropagation?.();
      router.push({
        pathname: "/organization-profile" as any,
        params: { orgId: ownerOrg.organization_id },
      });
    }}
    hitSlop={8}
    style={{
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: UI.border,
      backgroundColor: "rgba(52,211,153,0.10)",
    }}
  >
    <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
      {uiText("🏢 PROFILE")}</Text>
  </Pressable>
) : null}
                        <View
                          style={{
                            minWidth: isDesktopWeb ? 120 : 36,
                            alignItems: "flex-end",
                            justifyContent: "center",
                          }}
                        >
                          {isDesktopWeb ? (
                            <View
                              style={{
                                paddingHorizontal: 14,
                                paddingVertical: 10,
                                borderRadius: 14,
                                borderWidth: 1,
                                borderColor: activeInGroup ? "rgba(52,211,153,0.45)" : UI.border,
                                backgroundColor: activeInGroup
                                  ? "rgba(52,211,153,0.10)"
                                  : "rgba(255,255,255,0.04)",
                              }}
                            >
                              <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
                                {activeInGroup ? uiText("Open Active") : uiText("Switch")}
                              </Text>
                            </View>
                          ) : (
                            <Text style={{ color: UI.muted, fontWeight: "900", fontSize: 18 }}>›</Text>
                          )}
                        </View>
                      </View>
                    </Card>
                  </Pressable>
                );
              })
            : filteredOrgs
                .slice()
                .sort((a, b) => {
                  const aActive = a.organization_id === activeOrgId;
                  const bActive = b.organization_id === activeOrgId;
                  if (aActive && !bActive) return -1;
                  if (!aActive && bActive) return 1;
                  return normName(a.organization_name).localeCompare(normName(b.organization_name));
                })
                .map((o) => {
                  const active = o.organization_id === activeOrgId;

                  return (
       <Pressable
                      key={o.organization_id}
                      onPress={() => { void onSwitch(o.organization_id); }}
                      disabled={topRightBusy}
                    >             
                      <Card
                        style={{
                          marginBottom: 12,
                          borderColor: active ? "rgba(52,211,153,0.55)" : UI.border,
                          padding: isDesktopWeb ? 18 : 16,
                        }}
                      >
                        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                          <View style={{ flex: 1, minWidth: 0 }}>
                            <Text
                              style={{
                                color: UI.text,
                                fontWeight: "900",
                                fontSize: isDesktopWeb ? 20 : 16,
                              }}
                              numberOfLines={1}
                            >
                              {o.organization_name}
                            </Text>

                            <Text
                              style={{
                                color: UI.faint,
                                fontWeight: "700",
                                marginTop: 6,
                                fontSize: 12,
                              }}
                              numberOfLines={1}
                            >
                              {uiText("Ready to open this organization workspace")}</Text>

                            <View
                              style={{
                                flexDirection: "row",
                                alignItems: "center",
                                flexWrap: "wrap",
                                gap: 8,
                                marginTop: 10,
                              }}
                            >
                              <Badge text={`ROLE: ${roleLabel(o.role).toUpperCase()}`} variant="muted" />
                              {active ? <Badge text="ACTIVE" variant="active" /> : null}

                              {o.role === "owner" ? (
                                <Pressable
                                  onPress={(e: any) => {
                                    e?.stopPropagation?.();
                                    openRenameOrg(o);
                                  }}
                                  hitSlop={8}
                                  style={{
                                    paddingHorizontal: 10,
                                    paddingVertical: 6,
                                    borderRadius: 999,
                                    borderWidth: 1,
                                    borderColor: UI.border,
                                    backgroundColor: "rgba(255,255,255,0.04)",
                                  }}
                                >
                                  <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
                                    {uiText("✎ RENAME")}</Text>
                                </Pressable>
                              ) : null}
                            </View>
                          </View>
{o.role === "owner" ? (
  <Pressable
    onPress={(e: any) => {
      e?.stopPropagation?.();
      router.push({
        pathname: "/organization-profile" as any,
        params: { orgId: o.organization_id },
      });
    }}
    hitSlop={8}
    style={{
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: UI.border,
      backgroundColor: "rgba(52,211,153,0.10)",
    }}
  >
    <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
      {uiText("🏢 PROFILE")}</Text>
  </Pressable>
) : null}
                          <View
                            style={{
                              minWidth: isDesktopWeb ? 120 : 36,
                              alignItems: "flex-end",
                              justifyContent: "center",
                            }}
                          >
                            {isDesktopWeb ? (
                              <View
                                style={{
                                  paddingHorizontal: 14,
                                  paddingVertical: 10,
                                  borderRadius: 14,
                                  borderWidth: 1,
                                  borderColor: active ? "rgba(52,211,153,0.45)" : UI.border,
                                  backgroundColor: active
                                    ? "rgba(52,211,153,0.10)"
                                    : "rgba(255,255,255,0.04)",
                                }}
                              >
                                <Text style={{ color: UI.text, fontWeight: "900", fontSize: 12 }}>
                                  {active ? uiText("Open Active") : uiText("Switch")}
                                </Text>
                              </View>
                            ) : (
                              <Text style={{ color: UI.muted, fontWeight: "900", fontSize: 18 }}>›</Text>
                            )}
                          </View>
                        </View>
                      </Card>
                    </Pressable>
                  );
                })}
        </ScrollView>
          </View>
        </View>
      </View>
      <Modal visible={renameOpen} transparent animationType="fade" onRequestClose={closeRenameOrg}>
  <View
    style={{
      flex: 1,
      backgroundColor: "rgba(15,23,42,0.45)",
      justifyContent: "center",
      padding: 18,
    }}
  >
    <View
      style={{
        width: "100%",
        maxWidth: 520,
        alignSelf: "center",
        borderRadius: 22,
        backgroundColor: UI.card,
        borderWidth: 1,
        borderColor: UI.border,
        padding: 18,
        gap: 12,
      }}
    >
      <Text style={{ color: UI.text, fontWeight: "900", fontSize: 20 }}>
        {uiText("Rename Organization")}</Text>

      <Text style={{ color: UI.muted, fontWeight: "700" }}>
        {uiText("Badili jina la biashara / organization yako.")}</Text>

      <TextInput
        value={renameName}
        onChangeText={setRenameName}
        placeholder={uiText("New organization name")}
        placeholderTextColor={UI.faint}
        style={{
          borderWidth: 1,
          borderColor: UI.border,
          borderRadius: 14,
          padding: 14,
          color: UI.text,
          fontWeight: "900",
        }}
        autoCapitalize="words"
      />

      <View style={{ flexDirection: "row", gap: 10, justifyContent: "flex-end" }}>
        <Pressable
          onPress={closeRenameOrg}
          disabled={renaming}
          style={{
            paddingHorizontal: 14,
            paddingVertical: 10,
            borderRadius: 14,
            borderWidth: 1,
            borderColor: UI.border,
            opacity: renaming ? 0.6 : 1,
          }}
        >
          <Text style={{ color: UI.muted, fontWeight: "900" }}>{uiText("Cancel")}</Text>
        </Pressable>

        <Pressable
          onPress={onRenameOrg}
          disabled={renaming}
          style={{
            paddingHorizontal: 16,
            paddingVertical: 10,
            borderRadius: 14,
            backgroundColor: UI.primary,
            opacity: renaming ? 0.6 : 1,
          }}
        >
          <Text style={{ color: "white", fontWeight: "900" }}>
            {renaming ? uiText("Saving...") : uiText("Save")}
          </Text>
        </Pressable>
      </View>
    </View>
  </View>
</Modal>
    </Screen>
  );
}