import {isRejectedRefresh} from '@/src/supabase/sessionRecovery';
import {emailRedirect,authLinkHasError} from "@/src/auth/emailRedirects";
import {LoginIcon} from '../../src/ui/login/LoginIcon';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {LoginBackdrop,LoginBrand,LoginHero,LoginMobileArtwork,LoginNavigation,masterLoginText} from '../../src/ui/login/LoginVisuals';
import {useAuthText} from "@/src/i18n/useAuthText";
import {useLanguage} from "@/src/i18n/LanguageProvider";
import {languages,languageNames} from "@/src/i18n/catalog";
import { useRouter } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  TouchableWithoutFeedback,
  View,
  useWindowDimensions,
} from "react-native";
import * as LocalAuthentication from "expo-local-authentication";
import * as SecureStore from "expo-secure-store";
import { useOrg } from "../../src/context/OrgContext";
import {
  clearCorruptSupabaseSession,
  supabase,
} from "../../src/supabase/supabaseClient";

function isDisabledAccountMessage(message: unknown) {
  const msg = String(message ?? "").toLowerCase();

  return (
    msg.includes("disabled") ||
    msg.includes("deleted") ||
    msg.includes("deactivated") ||
    msg.includes("inactive") ||
    msg.includes("account disabled") ||
    msg.includes("account deleted")
  );
}

const BIOMETRIC_ENABLED_KEY = "zetra_biometric_login_enabled_v1";
const BIOMETRIC_EMAIL_KEY = "zetra_biometric_login_email_v1";
const BIOMETRIC_PASSWORD_KEY = "zetra_biometric_login_password_v1";

function isEmailNotVerified(user: any) {
  const confirmedAt = user?.email_confirmed_at ?? user?.confirmed_at ?? null;
  return !confirmedAt;
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <Text
      style={{
        color: "white",
        fontWeight: "700",
        marginBottom: 8,
        fontSize: 12,
      }}
    >
      {children}
    </Text>
  );
}

function GlassInput({
  value,
  onChangeText,
  placeholder,
  secureTextEntry,
  keyboardType,
  autoCapitalize,
  rightSlot,
}: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder: string;
  secureTextEntry?: boolean;
  keyboardType?: "default" | "email-address";
  autoCapitalize?: "none" | "sentences" | "words" | "characters";
  rightSlot?: React.ReactNode;
}) {
  return (
    <View
      style={{
        minHeight: 44,
        borderWidth: 1,
        borderColor: "rgba(255,255,255,0.10)",
        backgroundColor: "rgba(255,255,255,0.06)",
        borderRadius: 8,
        paddingHorizontal: 12,
        flexDirection: "row",
        gap: 8,
        alignItems: "center",
      }}
    >
      <TextInput
        accessibilityLabel={placeholder}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={secureTextEntry}
        placeholder={placeholder}
        placeholderTextColor="rgba(219,233,245,0.60)"
        autoCapitalize={autoCapitalize ?? "none"}
        keyboardType={keyboardType ?? "default"}
        autoCorrect={false}
        autoComplete={keyboardType === "email-address" ? "email" : secureTextEntry ? "password" : "off"}
        textContentType={secureTextEntry ? "password" : keyboardType === "email-address" ? "emailAddress" : "none"}
        style={{
          flex: 1,
          color: "white",
          fontSize: 14,
          fontWeight: "500",
          paddingVertical: 10,
          minWidth: 0,
        }}
      />
      {rightSlot}
    </View>
  );
}

export default function LoginScreen() {
  const tr=useAuthText();
  const router = useRouter();
  useOrg();
  const { width } = useWindowDimensions();
  const insets=useSafeAreaInsets();

  // SSR and first browser render must match; responsive sizing follows hydration.
  const [layoutReady,setLayoutReady]=useState(Platform.OS!=="web");
  useEffect(()=>setLayoutReady(true),[]);
  const isDesktopWeb = layoutReady && Platform.OS === "web" && width >= 1000;

  const [authLinkError,setAuthLinkError] = useState(false);
  useEffect(()=>{if(Platform.OS === "web" && typeof window !== "undefined")setAuthLinkError(authLinkHasError(window.location.href));},[]);
  const [needsVerification,setNeedsVerification]=useState(false);
  const [verificationFeedback,setVerificationFeedback]=useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
const [loading, setLoading] = useState(false);
const [sendingReset, setSendingReset] = useState(false);
const [resendingVerification, setResendingVerification] = useState(false);
const [showPassword, setShowPassword] = useState(false);
  const [biometricReady, setBiometricReady] = useState(false);
  const [biometricEmail, setBiometricEmail] = useState("");
  const [biometricLoading, setBiometricLoading] = useState(false);

  const loginLockedRef = useRef(false);

  const emailTrimmed = useMemo(() => email.trim(), [email]);

  useEffect(() => {
    let cancelled = false;

    async function checkBiometric() {
      if (Platform.OS === "web") return;

      try {
        const enabled = await SecureStore.getItemAsync(BIOMETRIC_ENABLED_KEY);
        const savedEmail = await SecureStore.getItemAsync(BIOMETRIC_EMAIL_KEY);
        const savedPassword = await SecureStore.getItemAsync(BIOMETRIC_PASSWORD_KEY);

        const hasHardware = await LocalAuthentication.hasHardwareAsync();
        const enrolled = await LocalAuthentication.isEnrolledAsync();

        if (!cancelled) {
          setBiometricEmail(savedEmail ?? "");
          setBiometricReady(
            enabled === "true" && !!savedEmail && !!savedPassword && hasHardware && enrolled
          );
        }
      } catch {
        if (!cancelled) {
          setBiometricReady(false);
          setBiometricEmail("");
        }
      }
    }

    void checkBiometric();

    return () => {
      cancelled = true;
    };
  }, []);

  const onForgotPassword = async () => {
    const e = emailTrimmed;

    if (!e) {
      Alert.alert(
        tr("Email required"),
        tr("Andika email yako kwanza, kisha bonyeza Forgot Password.")
      );
      return;
    }

    setSendingReset(true);

    try {
      const redirectTo = emailRedirect("recovery", Platform.OS);

      const { error } = await supabase.auth.resetPasswordForEmail(e, {
        redirectTo,
      });

      if (error) throw error;

      Alert.alert(
        tr("Reset email sent"),
        tr("Email ya kubadili password imetumwa. Fungua email yako, bonyeza link ya reset, kisha weka password mpya.")
      );
    } catch (err: any) {
      Alert.alert(
        tr("Reset Failed"),
        err?.message ?? tr("Failed to send reset email.")
      );
    } finally {
      setSendingReset(false);
    }
  };
  const onResendVerification = async () => {
    const e = emailTrimmed.toLowerCase();

    if (!e) {
      Alert.alert(
        tr("Email required"),
        tr("Andika email yako kwanza, kisha bonyeza Resend Verification Email.")
      );
      return;
    }

    if (!e.includes("@") || !e.includes(".")) {
      Alert.alert(
        tr("Invalid Email"),
        tr("Tafadhali andika email address sahihi.")
      );
      return;
    }

    if (resendingVerification) return;

    setResendingVerification(true);

    try {
      const emailRedirectTo = emailRedirect("resend", Platform.OS);

      const { error } = await supabase.auth.resend({
        type: "signup",
        email: e,
        options: {
          emailRedirectTo,
        },
      });

      if (error) throw error;
      if (Platform.OS === "web") {setVerificationFeedback("Verification email sent");return;}

      Alert.alert(
        tr("Verification email sent"),
        tr("auth.resendEmailBody", { email: e })
      );
    } catch (err: any) {
      const msg =
        err?.message ?? tr("Imeshindikana kutuma verification email.");

      if (Platform.OS === "web") {setVerificationFeedback("Imeshindikana kutuma verification email.");return;}

      const lower = String(msg).toLowerCase();

      if (
        lower.includes("rate limit") ||
        lower.includes("rate_limit") ||
        lower.includes("too many") ||
        lower.includes("security purposes")
      ) {
        Alert.alert(
          tr("Please wait"),
          tr("Umetuma verification email mara nyingi kwa muda mfupi. Subiri kidogo kisha ujaribu tena.")
        );
        return;
      }

      Alert.alert(tr("Verification Failed"), msg);
    } finally {
      setResendingVerification(false);
    }
  };
  const offerEnableBiometric = async (loginEmail: string, loginPassword: string) => {
    if (Platform.OS === "web") return;

    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = await LocalAuthentication.isEnrolledAsync();

      if (!hasHardware || !enrolled) return;

      await new Promise<void>((resolve) => {
        Alert.alert(
          tr("Enable Fingerprint Login?"),
          tr("Unataka kuwezesha login kwa fingerprint/biometric kwenye simu hii? Utaendelea pia kutumia password ya kawaida ukitaka."),
          [
            { text: tr("Not now"), style: "cancel", onPress: () => resolve() },
            {
              text: tr("Enable"),
              onPress: async () => {
                try {
                  const auth = await LocalAuthentication.authenticateAsync({
                    promptMessage: tr("Confirm Fingerprint"),
                    fallbackLabel: tr("Use device passcode"),
                    cancelLabel: tr("Cancel"),
                    disableDeviceFallback: false,
                  });

                  if (!auth.success) {
                    resolve();
                    return;
                  }

                  await SecureStore.setItemAsync(BIOMETRIC_ENABLED_KEY, "true");
                  await SecureStore.setItemAsync(BIOMETRIC_EMAIL_KEY, loginEmail);
                  await SecureStore.setItemAsync(BIOMETRIC_PASSWORD_KEY, loginPassword);

                  setBiometricReady(true);
                  setBiometricEmail(loginEmail);
                } catch {}
                resolve();
              },
            },
          ]
        );
      });
    } catch {}
  };

  const onLogin = async (override?: {
    email?: string;
    password?: string;
    skipBiometricOffer?: boolean;
  }) => {
    if (loginLockedRef.current || loading) return;

    const e = String(override?.email ?? emailTrimmed).trim();
    const p = String(override?.password ?? password);

    if (!e) {
      Alert.alert(tr("Missing"), tr("Email is required."));
      return;
    }

    if (!p) {
      Alert.alert(tr("Missing"), tr("Password is required."));
      return;
    }

    loginLockedRef.current = true;
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: e,
        password: p,
      });

      if (error) throw error;

      const session = data?.session ?? null;
      const user = data?.user ?? session?.user ?? null;

      if (!session?.access_token) {
        throw new Error("Fresh session was not created after login.");
      }

      if (!user?.id) {
        throw new Error("Failed to load authenticated user after login.");
      }

      if (isEmailNotVerified(user)) {
        try {
          await supabase.auth.signOut();
        } catch (err: any) {
          console.log("unverified-account signOut ignore:", err);
        }

        await clearCorruptSupabaseSession();

        if (Platform.OS === "web") {setNeedsVerification(true);return;}
        Alert.alert(
          tr("Verify your email"),
          tr("Email yako bado haijaverify. Fungua email yako, verify account, kisha login.")
        );
        return;
      }

      const { data: profileRow, error: profileError } = await supabase
        .from("profiles")
        .select("is_disabled")
        .eq("id", user.id)
        .maybeSingle();

      if (profileError) throw profileError;

      if (profileRow?.is_disabled === true) {
        try {
          await supabase.auth.signOut();
        } catch (err: any) {
          console.log("disabled-account signOut ignore:", err);
        }

        await clearCorruptSupabaseSession();

        Alert.alert(
          tr("Account unavailable"),
          tr("Account hii imezimwa au imeondolewa. Huwezi kuingia tena.")
        );
        return;
      }

      const { data: myOrgs, error: myOrgsError } = await supabase.rpc(
        "get_my_orgs"
      );

      if (myOrgsError) {
        console.log("get_my_orgs login check error:", myOrgsError);

        throw new Error(
          "Imeshindikana kuthibitisha business account yako. Tafadhali jaribu tena."
        );
      }

      const hasOrganization =
        Array.isArray(myOrgs) && myOrgs.length > 0;

      if (!hasOrganization) {
        try {
          const { kv } = await import("@/src/storage/kv");

          try {
            await (kv as any)?.remove?.(
              "zetra_onboarding_referral_done_v1"
            );
          } catch {}

          try {
            await (kv as any)?.remove?.(
              "zetra_onboarding_referral_code_v1"
            );
          } catch {}

          try {
            await (kv as any)?.delete?.(
              "zetra_onboarding_referral_done_v1"
            );
          } catch {}

          try {
            await (kv as any)?.delete?.(
              "zetra_onboarding_referral_code_v1"
            );
          } catch {}
        } catch {}

        router.replace("/(onboarding)/referral");
        return;
      }

      if (!override?.skipBiometricOffer) {
        await offerEnableBiometric(e, p);
      }

      router.replace("/(tabs)");
    } catch (err: any) {
      const msg = err?.message ?? tr("Unknown login error");

      if (isDisabledAccountMessage(msg)) {
        try {
          await supabase.auth.signOut();
        } catch (signOutErr: any) {
          console.log("login disabled signOut ignore:", signOutErr);
        }

        await clearCorruptSupabaseSession();

        Alert.alert(
          tr("Account unavailable"),
          tr("Account hii imezimwa au imeondolewa. Huwezi kuingia tena.")
        );
        return;
      }

      if (
        String(msg).toLowerCase().includes("email not confirmed") ||
        String(msg).toLowerCase().includes("email_not_confirmed") ||
        String(msg).toLowerCase().includes("confirm your email")
      ) {
        Alert.alert(
          tr("Verify your email"),
          tr("Email yako bado haijaverify. Fungua email uliyotumiwa na ZETRA BMS na bonyeza Verify Account. Kama hujapokea email, unaweza kuituma tena."),
          [
            {
              text: tr("Cancel"),
              style: "cancel",
            },
            {
              text: resendingVerification
                ? tr("Sending...")
                : tr("Resend Email"),
              onPress: () => {
                void onResendVerification();
              },
            },
          ]
        );
        return;
      }

      if (isRejectedRefresh(err)) {
        try {
          await clearCorruptSupabaseSession();
        } catch {}
      }

      Alert.alert(tr("Login Failed"), msg);
    } finally {
      loginLockedRef.current = false;
      setLoading(false);
    }
  };

  const onBiometricLogin = async () => {
    if (Platform.OS === "web" || biometricLoading || loading) return;

    setBiometricLoading(true);

    try {
      const savedEmail = await SecureStore.getItemAsync(BIOMETRIC_EMAIL_KEY);
      const savedPassword = await SecureStore.getItemAsync(BIOMETRIC_PASSWORD_KEY);

      if (!savedEmail || !savedPassword) {
        Alert.alert(tr("Fingerprint Login"), tr("Login kwa fingerprint haijawezeshwa bado."));
        return;
      }

      const auth = await LocalAuthentication.authenticateAsync({
        promptMessage: tr("Login with Fingerprint"),
        fallbackLabel: tr("Use device passcode"),
        cancelLabel: tr("Cancel"),
        disableDeviceFallback: false,
      });

      if (!auth.success) return;

      await onLogin({
        email: savedEmail,
        password: savedPassword,
        skipBiometricOffer: true,
      });
    } catch (err: any) {
      Alert.alert(tr("Fingerprint Login Failed"), err?.message ?? tr("Imeshindikana kuingia."));
    } finally {
      setBiometricLoading(false);
    }
  };

  const {language,setLanguage}=useLanguage();
  const [languageMenuOpen,setLanguageMenuOpen]=useState(false);
  const content = (
    <View style={{ flex: 1, backgroundColor: "#03101F" }}>
      <LoginBackdrop desktop={isDesktopWeb}/>
      <View style={{width:"100%",maxWidth:1536,alignSelf:"center",paddingHorizontal:isDesktopWeb?48:16,paddingTop:Math.max(insets.top,12)+8,paddingBottom:12,flexDirection:"row",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:12,zIndex:20}}>
        <LoginBrand compact={!isDesktopWeb} width={isDesktopWeb?undefined:148}/>
        {isDesktopWeb&&<LoginNavigation/>}
        <View style={{alignItems:"flex-end",flexShrink:0,minWidth:isDesktopWeb?145:0,maxWidth:"100%",marginStart:"auto"}}>
        <Pressable accessibilityRole="button" accessibilityLabel={languageNames[language]} aria-expanded={languageMenuOpen} accessibilityState={{expanded:languageMenuOpen}} onPress={()=>setLanguageMenuOpen(v=>!v)}
          style={{minHeight:46,paddingHorizontal:14,borderRadius:12,borderWidth:1,borderColor:"#37536C",backgroundColor:"#10243A",justifyContent:"center",alignItems:"center"}}>
          <Text style={{color:"#F4FAFF",fontWeight:"600",fontSize:13,textAlign:"center"}}>{"🌐 "+languageNames[language]+"  "+(languageMenuOpen?"▴":"▾")}</Text>
        </Pressable>
        {languageMenuOpen&&<ScrollView style={{marginTop:8,width:190,maxWidth:"100%",maxHeight:270,borderRadius:14,backgroundColor:"#10243A",borderWidth:1,borderColor:"#37536C"}} keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:6}}>
          {languages.map(code=><Pressable key={code} accessibilityRole="button" accessibilityLabel={languageNames[code]} accessibilityState={{selected:language===code}}
            onPress={()=>{setLanguage(code);setLanguageMenuOpen(false)}}
            style={{minHeight:44,justifyContent:"center",paddingHorizontal:12,borderRadius:9,backgroundColor:language===code?"#164E52":"transparent"}}>
            <Text style={{color:language===code?"#8CF1C8":"#F4FAFF",fontWeight:"600",textAlign:code==='ar'?'right':'left'}}>{languageNames[code]} {language===code?"✓":""}</Text>
          </Pressable>)}
        </ScrollView>}
        </View>
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={
          Platform.OS === "ios"
            ? "padding"
            : Platform.OS === "android"
            ? "height"
            : undefined
        }
        keyboardVerticalOffset={0}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: isDesktopWeb ? "flex-start" : "flex-start",
            paddingHorizontal: isDesktopWeb ? 48 : 16,
            paddingTop: isDesktopWeb ? 28 : 8,
            paddingBottom: Math.max(insets.bottom,16)+16,
          }}
        >
          <View
            style={{
              width: "100%",
              maxWidth: isDesktopWeb ? 1440 : 500,
              alignSelf: "center",
              flexDirection: isDesktopWeb ? "row" : "column",
              gap: 0,
              alignItems: "flex-start",
              direction: "ltr",
            }}
          >
            {isDesktopWeb ? <LoginHero /> : <LoginMobileArtwork/>}

            <View
              style={{
                marginStart: isDesktopWeb ? "auto" : undefined,
                direction: language==='ar'?'rtl':'ltr',
                width: isDesktopWeb ? "28%" : "100%",
                maxWidth: isDesktopWeb ? 390 : undefined,
                minWidth: isDesktopWeb ? 320 : undefined,
                alignSelf: "flex-start",
                borderWidth: 1,
                borderColor: "#365270",
                backgroundColor: "rgba(5,26,47,0.97)",
                borderRadius: 20,
                paddingHorizontal: isDesktopWeb ? 22 : 22,
                paddingTop: isDesktopWeb ? 24 : 16,
                paddingBottom: 18,
                shadowColor: "#000",
                shadowOpacity: 0.18,
                shadowRadius: 24,
                shadowOffset: { width: 0, height: 10 },
                elevation: 8,
              }}
            >
              {isDesktopWeb&&<View style={{marginBottom:20,alignSelf:'center'}}><LoginBrand width={244}/></View>}

              <Text
                style={{
                  color: "white",
                  fontSize: 22,
                  lineHeight: 28,
                  fontWeight: "700",
                  marginBottom: 8,
                  letterSpacing: 0.2,
                }}
              >
                {masterLoginText(language,"signIn")}</Text>

              <Text
                style={{
                  color: "rgba(255,255,255,0.66)",
                  marginBottom: 18,
                  lineHeight: 19,
                  fontSize: 12,
                  fontWeight: "600",
                  maxWidth: 360,
                }}
              >
                {masterLoginText(language,"access")}</Text>

              {authLinkError && <Text accessibilityRole="alert" style={{color:"#FECACA",lineHeight:20,marginBottom:12}}>{tr("auth.invalidVerificationLink")}</Text>}

              <FieldLabel>{tr("Email")}</FieldLabel>
              <GlassInput
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
                placeholder="you@example.com"
              />

              {(authLinkError || needsVerification) && <View style={{marginTop:10}}>
                {needsVerification && <Text style={{color:"#FECACA",lineHeight:20,marginBottom:8}}>{tr("Email yako bado haijaverify. Fungua email uliyotumiwa na ZETRA BMS na bonyeza Verify Account. Kama hujapokea email, unaweza kuituma tena.")}</Text>}
                <Pressable accessibilityRole="button" onPress={()=>{setVerificationFeedback("");void onResendVerification();}} disabled={resendingVerification} style={{paddingVertical:10,minHeight:44}}>
                  <Text style={{color:"#6EE7B7",fontWeight:"700"}}>{tr(resendingVerification?"Sending...":"Resend Email")}</Text>
                </Pressable>
                {!!verificationFeedback && <Text accessibilityRole="alert" style={{color:verificationFeedback==="Verification email sent"?"#6EE7B7":"#FECACA",lineHeight:20}}>{tr(verificationFeedback)}</Text>}
              </View>}
              <View style={{ height: 14 }} />

              <FieldLabel>{tr("Password")}</FieldLabel>
              <View
                {...(Platform.OS === "web"
                  ? {
                      onKeyDown: (e: any) => {
                        if (e?.key === "Enter") {
                          e.preventDefault?.();
                          void onLogin();
                        }
                      },
                    }
                  : {})}
              >
                <GlassInput
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  placeholder={tr("Enter your password")}
                  rightSlot={
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={showPassword ? tr("Hide") : tr("Show")}
                      onPress={() => setShowPassword((v) => !v)}
                      hitSlop={10}
                      style={{ paddingLeft: 12, minHeight:44, justifyContent:"center" }}
                    >
                      <LoginIcon name={showPassword?"eye-off-outline":"eye-outline"} color="#9DB5CE" size={18}/>
                    </Pressable>
                  }
                />
              </View>

              <Pressable
                accessibilityRole="button"
                onPress={onForgotPassword}
                disabled={sendingReset}
                style={{
                  alignSelf: "flex-end",
                  marginTop: 4,
                  minHeight:44,
                  justifyContent:"center",
                  marginBottom: 12,
                }}
              >
                <Text style={{ color: "#34D399", fontWeight: "600", fontSize: 12 }}>
                  {sendingReset ? tr("Sending...") : tr("Forgot Password?")}
                </Text>
              </Pressable>

              <Pressable
                onPress={() => {
  void onLogin();
}}
                disabled={loading}
                accessibilityRole="button"
                style={{
                  backgroundColor: "#19D6A0",
                  paddingVertical: 12,
                  minHeight:46,
                  borderRadius: 8,
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: loading ? 0.7 : 1,
                  marginTop: 2,
                  shadowColor: "#22C58B",
                  shadowOpacity: 0.16,
                  shadowRadius: 16,
                  shadowOffset: { width: 0, height: 8 },
                  elevation: 6,
                  cursor: Platform.OS === "web" ? ("pointer" as any) : undefined,
                }}
              >
                <Text
                  style={{
                    color: "#04110C",
                    fontWeight: "700",
                    fontSize: 16,
                    letterSpacing: 0.2,
                    userSelect: Platform.OS === "web" ? ("none" as any) : undefined,
                  }}
                >
                  {loading ? tr("Signing In...") : tr("Login")}
                </Text>
              </Pressable>

              {biometricReady ? (
                <Pressable
                  onPress={onBiometricLogin}
                  disabled={biometricLoading || loading}
                  accessibilityRole="button"
                  style={{
                    marginTop: 12,
                    borderWidth: 1,
                    borderColor: "rgba(52,211,153,0.28)",
                    backgroundColor: "rgba(52,211,153,0.08)",
                    paddingVertical: 14,
                    borderRadius: 18,
                    alignItems: "center",
                    opacity: biometricLoading || loading ? 0.65 : 1,
                  }}
                >
                  <Text style={{ color: "#6EE7B7", fontWeight: "600", fontSize: 12 }}>
                    {biometricLoading ? tr("Checking Fingerprint...") : tr("Login with Fingerprint")}
                  </Text>

                  {!!biometricEmail ? (
                    <Text
                      numberOfLines={1}
                      style={{
                        marginTop: 4,
                        color: "rgba(255,255,255,0.45)",
                        fontWeight: "800",
                        fontSize: 11,
                      }}
                    >
                      {biometricEmail}
                    </Text>
                  ) : null}
                </Pressable>
              ) : null}

              <View style={{flexDirection:'row',alignItems:'center',gap:12,marginTop:18}}><View style={{height:1,backgroundColor:'#345068',flex:1}}/><Text style={{color:'#9EB0C4',fontSize:11}}>{masterLoginText(language,'or')}</Text><View style={{height:1,backgroundColor:'#345068',flex:1}}/></View>

              <Pressable
                accessibilityRole="link"
                onPress={() => router.push("/(auth)/register")}
                style={{
                  marginTop: 12,
                  minHeight:44,
                  justifyContent:"center",
                  alignItems: "center",
                }}
              >
                <Text
                  style={{
                    color: "rgba(255,255,255,0.88)",
                    fontSize: 12,
                    lineHeight: 20,
                    textAlign: "center",
                  }}
                >
                  {tr("Don&apos;t have an account?")}{" "}
                  <Text style={{ color: "#6EE7B7", fontWeight: "700" }}>{tr("Create account")}</Text>
                </Text>
              </Pressable>


            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );

  if (Platform.OS === "web") {
    return content;
  }

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      {content}
    </TouchableWithoutFeedback>
  );
}
