import {PreferredRateNote} from '@/src/currency/PreferredDisplay';
import {usePreferredDisplayMoney} from '@/src/currency/PreferredDisplay';
import {DashboardCurrency} from '@/src/currency/DashboardCurrency';
import {LegacyTzsValuation} from '@/src/currency/LegacyTzsValuation';
import { MobileFinanceEntry } from "@/src/finance/MobileFinance";
import {useLanguage} from "@/src/i18n/LanguageProvider";
import {localizedSearchResult} from "@/src/i18n/presentation";
import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
﻿import {useCommonText} from "@/src/i18n/useCommonText";
// app/(tabs)/index.tsx
import { useFocusEffect, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Animated,
  AppState,
  Image,
  Platform,
  Pressable,
  RefreshControl,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNetInfo } from "@react-native-community/netinfo";
import { syncSalesQueueOnce } from "../../src/offline/salesSync";

import { useOrg } from "../../src/context/OrgContext";
import { supabase } from "../../src/supabase/supabaseClient";
import { Card } from "../../src/ui/Card";
import { Screen } from "../../src/ui/Screen";
import { StoreGuard } from "../../src/ui/StoreGuard";
import { UI } from "../../src/ui/theme";
import { formatMoney, useOrgMoneyPrefs } from "../../src/ui/money";
import BusinessFinancialOverview from "../../src/components/home/business-financial-overview/BusinessFinancialOverview";
import SalesPerformanceWorkspace from "../../src/components/home/sales-performance-v2/SalesPerformanceWorkspace";

type RangeKey = "today" | "7d" | "30d";

type MoneyBreak = { revenue: number; orders: number };
type JsonBreak = Record<string, MoneyBreak>;

type DashRow = {
  store_id: string;
  from_ts: string;
  to_ts: string;
  currency: string;

  revenue: number;
  delivered_orders: number;

  total_orders: number;
  pending_orders: number;
  confirmed_orders: number;
  ready_orders: number;
  cancelled_orders: number;

  avg_order_value: number;

  paid_revenue: number;
  awaiting_revenue: number;
  paid_orders: number;
  awaiting_orders: number;

  by_method: JsonBreak | null;
  by_channel: JsonBreak | null;
};

type FinRow = {
  org_id: string;
  store_id: string | null;
  date_from: string;
  date_to: string;
  stock_on_hand_value: number;
  stock_in_value: number;
};

type SalesSummary = {
  total: number;
  orders: number;
  currency?: string | null;
};

type ExpenseSummary = {
  total: number;
  count: number;
};

type ProfitSummary = {
  net: number;
  sales: number | null;
  expenses: number | null;
};

type PayBreakdown = {
  cash: number;
  bank: number;
  mobile: number;
  credit: number;
  other: number;
  orders: number;
};

type CollectionBreakdown = {
  cash: number;
  bank: number;
  mobile: number;
  other: number;
  total: number;
  payments: number;
};

type ExpenseChannelBreakdown = {
  cash: number;
  bank: number;
  mobile: number;
};

type NotifRow = {
  id: string;
  organization_id: string;
  store_id: string;
  source_store_id: string | null;
  event_type: string;
  title: string;
  body: any;
  items: any;
  total_units: number;
  total_skus: number;
  actor_user_id: string;
  actor_name: string | null;
  ref_movement_id: string | null;
  created_by: string;
  created_at: string;
  is_read: boolean;
  read_at: string | null;
};

type Receipt = {
  key: string;
  movement_id: string | null;
  organization_id: string;
  store_id: string;
  source_store_id: string | null;
  event_type: string;
  title: string;
  actor_user_id: string;
  actor_name: string | null;
  created_at: string;
  total_units: number;
  total_skus: number;
  is_read: boolean;
  rows: NotifRow[];
  items: any[];
};

type CapitalRecoverySummaryRow = {
  total_asset: number;
  total_cost: number;
  total_income: number;
  remaining_cost: number;
  remaining_asset: number;
  realized_profit: number;
  entries_count: number;
  last_entry_at: string | null;
};

type CapitalRecoveryHistoryRow = {
  id: string;
  entry_type: "ASSET" | "COST" | "INCOME";
  amount: number;
  note: string | null;
  created_at: string;
  created_by?: string | null;
};

type CapitalRecoveryTodayReport = {
  asset: number;
  cost: number;
  income: number;
  net: number;
};

type HomeSubscriptionRow = {
  plan_code?: string | null;
  plan_name?: string | null;
  status?: string | null;
  expires_at?: string | null;
  end_at?: string | null;
  started_at?: string | null;
  start_at?: string | null;
  [k: string]: any;
};

const AUTO_REFRESH_MS = 20_000;

const HOME_CARD_TEXT = "#FFFFFF";
const HOME_CARD_MUTED = "rgba(255,255,255,0.86)";
const HOME_CARD_FAINT = "rgba(255,255,255,0.68)";

const HOME_CARD_BG = "#0B5CAD";
const HOME_CARD_ALT_BG = "#0F766E";
const HOME_CARD_AI_BG = "#0F766E";
const HOME_CARD_BORDER = "rgba(255,255,255,0.22)";
const HOME_CARD_BORDER_STRONG = "rgba(255,255,255,0.32)";
const HOME_CARD_SOFT_BLUE = "rgba(255,255,255,0.14)";
const HOME_CARD_SOFT_EMERALD = "rgba(255,255,255,0.16)";

const DESKTOP_PANEL_BG = "#0B5CAD";
const DESKTOP_PANEL_ALT_BG = "#0F766E";
const DESKTOP_PANEL_SOFT = "rgba(255,255,255,0.13)";
const DESKTOP_PANEL_BORDER = "rgba(255,255,255,0.24)";
const DESKTOP_PANEL_TEXT = "#FFFFFF";
const DESKTOP_PANEL_MUTED = "rgba(255,255,255,0.84)";
const DESKTOP_PANEL_FAINT = "rgba(255,255,255,0.66)";

const HOME_PALETTE = {
  finance: {
    bg: "#0B5CAD",
    border: "rgba(147,197,253,0.44)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#BFDBFE",
  },
  stock: {
    bg: "#0F766E",
    border: "rgba(153,246,228,0.42)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#99F6E4",
  },
  notification: {
    bg: "#0B5CAD",
    border: "rgba(147,197,253,0.44)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#BFDBFE",
  },
  ai: {
    bg: "#0F766E",
    border: "rgba(153,246,228,0.42)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#99F6E4",
  },
  club: {
    bg: "#92400E",
    border: "rgba(253,186,116,0.44)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#FDBA74",
  },
  workspace: {
    bg: "#1E3A8A",
    border: "rgba(191,219,254,0.44)",
    soft: "rgba(255,255,255,0.13)",
    accent: "#BFDBFE",
  },
} as const;

const HomeCardToneContext = React.createContext<{
  text: string;
  muted: string;
  faint: string;
}>({
  text: UI.text,
  muted: UI.muted,
  faint: UI.faint,
});

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function toIsoDateLocal(d: Date) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function startOfLocalDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
}

function endOfLocalDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
}

function rangeToFromTo(k: RangeKey) {
  const now = new Date();
  const from = startOfLocalDay(now);
  const to = startOfLocalDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));

  if (k === "today") {
    // no change
  } else if (k === "7d") {
    from.setDate(from.getDate() - 6);
  } else {
    from.setDate(from.getDate() - 29);
  }

  return { from: from.toISOString(), to: to.toISOString() };
}

function rangeToDates(k: RangeKey) {
  const now = new Date();
  const to = new Date(now);
  const from = new Date(now);

  if (k === "today") {
    // no change
  } else if (k === "7d") {
    from.setDate(from.getDate() - 6);
  } else {
    from.setDate(from.getDate() - 29);
  }

  return { from: toIsoDateLocal(from), to: toIsoDateLocal(to) };
}

function toNum(x: any) {
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
}

function toInt(x: any) {
  const n = Number(x);
  if (!Number.isFinite(n)) return 0;
  return Math.trunc(n);
}

function subtractFloor(a: number, b: number) {
  return Math.max(0, toNum(a) - toNum(b));
}

function normalizeBreak(obj: any): JsonBreak | null {
  if (!obj || typeof obj !== "object") return null;
  const out: JsonBreak = {};
  for (const [k, v] of Object.entries(obj)) {
    const revenue = toNum((v as any)?.revenue);
    const orders = toInt((v as any)?.orders);
    out[String(k)] = { revenue, orders };
  }
  return out;
}

function normalizeDash(
  raw: any,
  fallbackFrom: string,
  fallbackTo: string,
  storeId: string
): DashRow {
  const store_id = String(raw?.store_id ?? raw?.p_store_id ?? storeId ?? "").trim();

  const from_ts = String(raw?.from_ts ?? raw?.date_from ?? raw?.p_from ?? fallbackFrom ?? "").trim();
  const to_ts = String(raw?.to_ts ?? raw?.date_to ?? raw?.p_to ?? fallbackTo ?? "").trim();

  const currency = String(raw?.currency ?? "TZS").trim() || "TZS";

  const revenue = toNum(raw?.revenue ?? raw?.revenue_amount ?? 0);
  const delivered_orders = toInt(raw?.delivered_orders ?? raw?.revenue_orders ?? 0);

  const total_orders = toInt(raw?.total_orders ?? raw?.total ?? 0);
  const pending_orders = toInt(raw?.pending_orders ?? raw?.pending ?? 0);
  const confirmed_orders = toInt(raw?.confirmed_orders ?? raw?.confirmed ?? 0);
  const ready_orders = toInt(raw?.ready_orders ?? raw?.ready ?? 0);
  const cancelled_orders = toInt(raw?.cancelled_orders ?? raw?.cancelled ?? 0);

  const avg_order_value = toNum(raw?.avg_order_value ?? 0);

  const paid_revenue = toNum(raw?.paid_revenue ?? 0);
  const awaiting_revenue = toNum(raw?.awaiting_revenue ?? 0);
  const paid_orders = toInt(raw?.paid_orders ?? 0);
  const awaiting_orders = toInt(raw?.awaiting_orders ?? 0);

  const by_method = normalizeBreak(raw?.by_method);
  const by_channel = normalizeBreak(raw?.by_channel);

  return {
    store_id,
    from_ts,
    to_ts,
    currency,
    revenue,
    delivered_orders,
    total_orders,
    pending_orders,
    confirmed_orders,
    ready_orders,
    cancelled_orders,
    avg_order_value,
    paid_revenue,
    awaiting_revenue,
    paid_orders,
    awaiting_orders,
    by_method,
    by_channel,
  };
}

function extractScalarValue(x: any): number {
  if (x == null) return 0;
  if (typeof x === "number" || typeof x === "string") return toNum(x);

  if (typeof x === "object" && !Array.isArray(x)) {
    const known =
      x?.value ??
      x?.amount ??
      x?.total ??
      x?.sum ??
      x?.stock_value ??
      x?.stock_on_hand_value ??
      x?.on_hand_value ??
      x?.stock_in_value ??
      x?.stock_in ??
      x?.in_value ??
      x?.received_value;

    if (known != null) return toNum(known);

    const keys = Object.keys(x);
    if (keys.length === 1) return toNum((x as any)[keys[0]]);

    for (const k of keys) {
      const v = (x as any)[k];
      const n = Number(v);
      if (Number.isFinite(n)) return n;
    }
  }

  return 0;
}

function clean(v: any) {
  return String(v ?? "").trim();
}

function parseSubscriptionDateLocal(value: any): Date | null {
  const raw = clean(value);
  if (!raw) return null;

  // Prefer YYYY-MM-DD from DB so timezone does not shift the expiry day.
  const match = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);

  if (match) {
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);

    const d = new Date(year, month - 1, day);

    if (!Number.isNaN(d.getTime())) {
      return d;
    }
  }

  const parsed = new Date(raw);

  if (Number.isNaN(parsed.getTime())) {
    return null;
  }

  return new Date(
    parsed.getFullYear(),
    parsed.getMonth(),
    parsed.getDate()
  );
}

function getSubscriptionDaysLeft(value: any): number | null {
  const expiry = parseSubscriptionDateLocal(value);

  if (!expiry) return null;

  const today = new Date();

  // Compare calendar dates, not hours.
  const todayUTC = Date.UTC(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );

  const expiryUTC = Date.UTC(
    expiry.getFullYear(),
    expiry.getMonth(),
    expiry.getDate()
  );

  return Math.round(
    (expiryUTC - todayUTC) / (24 * 60 * 60 * 1000)
  );
}

function fmtSubscriptionHomeDate(value: any) {
  const d = parseSubscriptionDateLocal(value);

  if (!d) return "-";

  try {
    return d.toLocaleDateString(undefined, {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return clean(value).slice(0, 10) || "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â";
  }
}

function clampInt(n: any, fallback = 0) {
  const x = Number(n);
  if (!Number.isFinite(x)) return fallback;
  return Math.floor(x);
}

function fmtLocal(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  try {
    return d.toLocaleString();
  } catch {
    return iso;
  }
}

function isDesktopWebEnv(width?: number) {
  if (Platform.OS !== "web") return false;
  return Number(width ?? 0) >= 900;
}

function isMobileWebEnv(width?: number) {
  return Platform.OS === "web" && !isDesktopWebEnv(width);
}

function webIconFallback(name: keyof typeof Ionicons.glyphMap) {
  switch (name) {
    case "storefront-outline":
      return "S";
    case "ellipsis-horizontal":
      return "...";
    case "heart":
      return "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¾ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¥";
    case "heart-outline":
      return "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¾ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡";
    case "chatbubble-outline":
      return "C";
    case "paper-plane-outline":
      return ">";
    case "bookmark":
      return "B";
    case "bookmark-outline":
      return "B";
    case "add":
      return "+";
    case "person-circle-outline":
      return "P";
    case "speedometer-outline":
      return "O";
    case "refresh":
      return "R";
    case "hourglass-outline":
      return "...";
    case "chevron-down":
      return "v";
    default:
      return "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢";
  }
}

function SafeIcon({
  name,
  size = 18,
  color,
}: {
  name: keyof typeof Ionicons.glyphMap;
  size?: number;
  color: string;
}) {
  return <Ionicons name={name} size={size} color={color} />;
}

function MiniStat({
  label,
  value,
  hint,
  multilineValue = false,
}: {
  label: string;
  value: string;
  hint?: string;
  multilineValue?: boolean;
}) {
  const tone = React.useContext(HomeCardToneContext);

  return (
    <View style={{ flex: 1, gap: 4, minWidth: 0 }}>
      <Text
        style={{ color: tone.muted, fontWeight: "800", fontSize: 12 }}
        numberOfLines={1}
        ellipsizeMode="tail"
      >
        {label}
      </Text>

      <Text
        style={{ color: tone.text, fontWeight: "900", fontSize: 16, lineHeight: 20 }}
        numberOfLines={multilineValue ? 2 : 1}
        adjustsFontSizeToFit={!multilineValue}
        minimumFontScale={0.75}
        allowFontScaling={false}
      >
        {value}
      </Text>

      {!!hint && (
        <Text
         style={{ color: tone.faint, fontWeight: "800", fontSize: 12 }}
          numberOfLines={1}
          ellipsizeMode="tail"
        >
          {hint}
        </Text>
      )}
    </View>
  );
}

function useAutoRefresh(cb: () => void, enabled: boolean, ms: number) {
  const cbRef = useRef(cb);
  cbRef.current = cb;

  useEffect(() => {
    // ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ WEB HOTFIX:
    // Browser static export imekuwa ikipata request-storm / page freeze.
    // Auto refresh ibaki MOBILE only.
    if (!enabled || Platform.OS === "web") return;

    let alive = true;
    let interval: any = null;

    const start = () => {
      if (!alive) return;
      if (interval) clearInterval(interval);
      interval = setInterval(() => {
        if (!alive) return;
        cbRef.current();
      }, ms);
    };

    const sub = AppState.addEventListener("change", (state) => {
      if (!alive) return;
      if (state === "active") start();
      else {
        if (interval) clearInterval(interval);
        interval = null;
      }
    });

    start();

    return () => {
      alive = false;
      try {
        // @ts-ignore
        sub?.remove?.();
      } catch {}
      if (interval) clearInterval(interval);
    };
  }, [enabled, ms]);
}

function HeaderHero({
  activeOrgName,
  activeStoreName,
  isCashier,
  onOpenOrgSwitcher,
  organizationLogoUrl,
  onOpenBusinessProfile,
}: {
  activeOrgName?: string | null;
  activeStoreName?: string | null;
  isCashier: boolean;
  onOpenOrgSwitcher?: () => void;
  organizationLogoUrl?: string | null;
  onOpenBusinessProfile?: () => void;
}) {
 const uiText = useCommonText();
  const orgLabel =
    String(activeOrgName ?? "Workspace").trim() || "Workspace";

  const storeLabel =
    String(activeStoreName ?? "No active store").trim() ||
    "No active store";

  const headerDateLabel = new Intl.DateTimeFormat(
    "en",
    {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }
  )
    .format(new Date())
    .toUpperCase();

  return (
    <View style={{ marginBottom: 0 }}>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text
            style={{
              fontSize: 19,
              fontWeight: "900",
              color: UI.text,
              letterSpacing: 0.1,
            }}
          >
            ZETRA BMS
          </Text>

          <Text
            style={{
              color: UI.muted,
              fontWeight: "800",
              marginTop: 1,
              fontSize: 10,
            }}
          >
            {isCashier
              ? uiText("Cashier Dashboard")
              : uiText("Business Command Center")}
          </Text>
        </View>

        <View style={{marginHorizontal:6}}><DashboardCurrency compact /></View>
        <View
          style={{
            alignItems: "flex-end",
            marginLeft: 10,
            transform: [{ translateY: 8 }],
          }}
        >
          <Pressable
            onPress={onOpenBusinessProfile}
            disabled={!onOpenBusinessProfile}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={uiText("Open Business Profile")}
            style={({ pressed }) => ({
              width: 48,
              height: 48,
              borderRadius: 999,
              alignItems: "center",
              justifyContent: "center",
              overflow: "hidden",
              backgroundColor: "#EFF6FF",
              borderWidth: 1,
              borderColor: "rgba(37,99,235,0.14)",
              shadowColor: "#0F172A",
              shadowOpacity: 0.10,
              shadowRadius: 5,
              shadowOffset: {
                width: 0,
                height: 2,
              },
              elevation: 2,
              opacity:
                onOpenBusinessProfile && pressed
                  ? 0.84
                  : 1,
              transform: [
                {
                  scale:
                    onOpenBusinessProfile && pressed
                      ? 0.97
                      : 1,
                },
              ],
            })}
          >
            {organizationLogoUrl ? (
              <Image
                source={{ uri: organizationLogoUrl }}
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 999,
                }}
                resizeMode="cover"
              />
            ) : (
              <SafeIcon
                name="person-outline"
                size={20}
                color="#2563EB"
              />
            )}
          </Pressable>

          {!isCashier ? (
            <Text
              style={{
                color: "#64748B",
                fontWeight: "900",
                fontSize: 8,
                letterSpacing: 0.35,
                marginTop: 2,
              }}
              >
              {headerDateLabel}
            </Text>
          ) : null}
        </View>
      </View>

      <View
        style={{
          flexDirection: "row",
          gap: 5,
          marginTop: 2,
        }}
      >
        {onOpenOrgSwitcher && !isCashier ? (
          <Pressable
            onPress={onOpenOrgSwitcher}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={uiText("Switch Organization or Workspace")}
            style={({ pressed }) => ({
              width: "54%",
              maxWidth: 220,
              minWidth: 0,
              paddingHorizontal: 9,
              paddingVertical: 4,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(37,99,235,0.16)",
              backgroundColor: pressed ? "#DBEAFE" : "#F8FAFC",
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
              opacity: pressed ? 0.92 : 1,
            })}
          >
            <SafeIcon
              name="swap-horizontal"
              size={11}
              color="#2563EB"
            />

            <Text
              style={{
                flex: 1,
                minWidth: 0,
                color: UI.text,
                fontWeight: "900",
                fontSize: 9,
              }}
              >
              {(String((activeOrgName ?? uiText("Workspace"))).trim() || uiText("Workspace"))}
            </Text>

            <SafeIcon
              name="chevron-down"
              size={10}
              color="#64748B"
            />
          </Pressable>
        ) : (
          <View
            style={{
              flex: 1,
              minWidth: 0,
              paddingHorizontal: 9,
              paddingVertical: 4,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(148,163,184,0.16)",
              backgroundColor: "#F8FAFC",
            }}
          >
            <Text
              style={{
                color: UI.text,
                fontWeight: "900",
                fontSize: 9,
              }}
              >
              {(String((activeOrgName ?? uiText("Workspace"))).trim() || uiText("Workspace"))}
            </Text>
          </View>
        )}


      </View>
    </View>
  );
}
function SubscriptionExpiryHomeStrip({
  reloadKey = 0,
  compact = false,
}: {
  reloadKey?: number;
  compact?: boolean;
}) {
 const uiText=useCommonText();
  const router = useRouter();

  const {
    activeOrgId,
    activeRole,
  } = useOrg();

  const orgId = clean(activeOrgId);

  const roleLower = clean(activeRole).toLowerCase();

  // Billing CTA ibaki Owner/Admin pekee,
  // sawa na Subscription & Billing screen.
  const canManageSubscription =
    roleLower === "owner" || roleLower === "admin";

  const [loading, setLoading] = useState(false);
  const [subscription, setSubscription] =
    useState<HomeSubscriptionRow | null>(null);

  const requestSeqRef = useRef(0);

  const loadSubscription = useCallback(async () => {
    if (!orgId || !canManageSubscription) {
      setSubscription(null);
      return;
    }

    const seq = ++requestSeqRef.current;

    setLoading(true);

    try {
      const { data, error } = await supabase.rpc(
        "get_my_subscription",
        {
          p_org_id: orgId,
        }
      );

      if (error) throw error;

      if (seq !== requestSeqRef.current) return;

      const row = Array.isArray(data)
        ? data?.[0]
        : data;

      setSubscription(
        row ? (row as HomeSubscriptionRow) : null
      );
    } catch {
      if (seq !== requestSeqRef.current) return;

      // Subscription banner is supplementary.
      // Do not disturb Home Dashboard if billing RPC temporarily fails.
      setSubscription(null);
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
      }
    }
  }, [orgId, canManageSubscription]);

  useFocusEffect(
    useCallback(() => {
      void loadSubscription();
    }, [loadSubscription, reloadKey])
  );

  const planCode = useMemo(() => {
    return clean(
      subscription?.plan_code ||
        subscription?.plan_name
    ).toUpperCase();
  }, [subscription]);

  const status = useMemo(() => {
    return clean(subscription?.status).toUpperCase();
  }, [subscription]);

  const expiryRaw = useMemo(() => {
    return (
      subscription?.expires_at ||
      subscription?.end_at ||
      ""
    );
  }, [subscription]);

  const daysLeft = useMemo(
    () => getSubscriptionDaysLeft(expiryRaw),
    [expiryRaw]
  );

  const expiryLabel = useMemo(
    () => fmtSubscriptionHomeDate(expiryRaw),
    [expiryRaw]
  );

  if (!canManageSubscription || !orgId) {
    return null;
  }

  // Keep Home clean while first request is loading.
  if (loading && !subscription) {
    return null;
  }

  // FREE/no-expiry plans do not need expiry warning strip.
  if (
    !subscription ||
    !planCode ||
    planCode === "FREE" ||
    daysLeft === null
  ) {
    return null;
  }

  const isExpired = daysLeft < 0;
  const expiresToday = daysLeft === 0;
  const critical = daysLeft >= 0 && daysLeft <= 7;
  const warning = daysLeft >= 8 && daysLeft <= 14;

  // User requested red warning when roughly 1ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ2 weeks remain.
  const colors = isExpired
    ? {
        bg: "#FEE2E2",
        border: "rgba(185,28,28,0.55)",
        strong: "#991B1B",
        muted: "#7F1D1D",
        badgeBg: "#B91C1C",
        badgeText: "#FFFFFF",
      }
    : critical
    ? {
        bg: "#FEF2F2",
        border: "rgba(220,38,38,0.50)",
        strong: "#B91C1C",
        muted: "#991B1B",
        badgeBg: "#DC2626",
        badgeText: "#FFFFFF",
      }
    : warning
    ? {
        bg: "#FFF1F2",
        border: "rgba(239,68,68,0.40)",
        strong: "#B91C1C",
        muted: "#9F1239",
        badgeBg: "#EF4444",
        badgeText: "#FFFFFF",
      }
    : {
        bg: "#ECFDF5",
        border: "rgba(16,185,129,0.35)",
        strong: "#065F46",
        muted: "#047857",
        badgeBg: "#059669",
        badgeText: "#FFFFFF",
      };

  const remainingLabel = isExpired
    ? "EXPIRED"
    : expiresToday
    ? "EXPIRES TODAY"
    : daysLeft === 1
    ? "1 DAY LEFT"
    : `${daysLeft} DAYS LEFT`;

  const subtitle = isExpired
    ? `Expired ${expiryLabel}`
    : warning || critical || expiresToday
    ? `Renew before ${expiryLabel}`
    : `Active | Expires ${expiryLabel}`;

  const openSubscription = () => {
    router.push(
      "/(tabs)/settings/subscription" as any
    );
  };

  return (
    <View
      style={{
        marginTop: compact ? 0 : 5,
        width: compact ? 310 : undefined,
        flexShrink: compact ? 0 : undefined,
      }}
    >
      <Pressable
        onPress={openSubscription}
        // @ts-ignore - web click fallback
        onClick={openSubscription}
        hitSlop={6}
        style={({ pressed }) => ({
          minHeight: compact ? 38 : 42,
          borderRadius: compact ? 12 : 14,
          borderWidth: 1,
          borderColor: colors.border,
          backgroundColor: colors.bg,
          paddingHorizontal: compact ? 9 : 10,
          paddingVertical: compact ? 4 : 6,
          opacity: pressed ? 0.90 : 1,
          flexDirection: "row",
          alignItems: "center",
          gap: 8,
        })}
      >
        <View
          style={{
            width: compact ? 28 : 30,
            height: compact ? 28 : 30,
            borderRadius: compact ? 9 : 10,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor:
              warning ||
              critical ||
              isExpired ||
              expiresToday
                ? "rgba(239,68,68,0.10)"
                : "rgba(16,185,129,0.10)",
          }}
        >
          <SafeIcon
            name={
              warning ||
              critical ||
              isExpired ||
              expiresToday
                ? "warning-outline"
                : "hourglass-outline"
            }
            size={14}
            color={colors.strong}
          />
        </View>

        <View style={{ flex: 1, minWidth: 0 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Text
              style={{
                color: colors.strong,
                fontWeight: "900",
                fontSize: 11,
                flexShrink: 1,
              }}
              numberOfLines={1}
            >
              {planCode}
            </Text>

            {!!status && (
              <Text
                style={{
                  color: colors.muted,
                  fontWeight: "900",
                  fontSize: 8,
                }}
                numberOfLines={1}
              >
                {status}
              </Text>
            )}
          </View>

          <Text
            style={{
              color: colors.muted,
              fontWeight: "800",
              fontSize: 8,
              marginTop: 1,
            }}
            numberOfLines={1}
          >
            {(isExpired ? uiText("Expired {p0}", {p0: (expiryLabel)}) : (warning || critical || expiresToday ? uiText("Renew before {p0}", {p0: (expiryLabel)}) : uiText("Active | Expires {p0}", {p0: (expiryLabel)})))}
          </Text>
        </View>

        <View
          style={{
            paddingHorizontal: 7,
            paddingVertical: 4,
            borderRadius: 999,
            backgroundColor: colors.badgeBg,
          }}
        >
          <Text
            style={{
              color: colors.badgeText,
              fontWeight: "900",
              fontSize: 8,
            }}
            numberOfLines={1}
          >
            {(isExpired ? uiText("EXPIRED") : (expiresToday ? uiText("EXPIRES TODAY") : (daysLeft === 1 ? uiText("1 DAY LEFT") : uiText("{p0} DAYS LEFT", {p0: (daysLeft)}))))}
          </Text>
        </View>

        <SafeIcon
          name="chevron-forward"
          size={13}
          color={colors.strong}
        />
      </Pressable>
    </View>
  );
}

function PremiumMetricCard({
  title,
  subtitle,
  iconName,
  loading,
  badgeText,
  children,
  ctaLabel,
  onPress,
  footerRight,
  error,
  mobileWebLite = false,
  tone = "finance",
}: {
  title: string;
  subtitle: string;
  iconName: keyof typeof Ionicons.glyphMap;
  loading?: boolean;
  badgeText?: string;
  children: React.ReactNode;
  ctaLabel: string;
  onPress: () => void;
  footerRight?: React.ReactNode;
  error?: string | null;
  mobileWebLite?: boolean;
  tone?: keyof typeof HOME_PALETTE;
}) {
 const systemText = useSystemMessageText();
  const p = HOME_PALETTE[tone];

  return (
    <View style={{ paddingTop: 14 }}>
      <View
        style={{
          gap: 14,
          borderRadius: 22,
          borderWidth: 1,
          borderColor: p.border,
          backgroundColor: p.bg,
          overflow: "hidden",
          padding: 16,
        }}
      >
        

        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            height: 1,
            backgroundColor: UI.borderSoft,
          }}
        />

        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 16,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: "rgba(79,140,255,0.32)",
              backgroundColor: p.soft,
            }}
          >
            <SafeIcon
  name={loading ? "ellipsis-horizontal" : iconName}
  size={20}
  color={p.accent}
/>
          </View>

          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={{ color: HOME_CARD_TEXT, fontWeight: "900", fontSize: 16 }} numberOfLines={1}>
              {title}
            </Text>
            <Text style={{ color: HOME_CARD_MUTED, fontWeight: "800", marginTop: 2 }} numberOfLines={1}>
              {subtitle}
            </Text>
          </View>

          {badgeText ? (
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 6,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: "rgba(79,140,255,0.28)",
                backgroundColor: "rgba(79,140,255,0.10)",
              }}
            >
              <Text style={{ color: HOME_CARD_TEXT, fontWeight: "900", fontSize: 11 }}>{badgeText}</Text>
            </View>
          ) : null}
        </View>

        {!!error && (
          <Card
            style={{
              borderColor: "rgba(201,74,74,0.35)",
              backgroundColor: "rgba(201,74,74,0.10)",
              borderRadius: 18,
              padding: 12,
            }}
          >
            <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(error)}</Text>
          </Card>
        )}

        <HomeCardToneContext.Provider
          value={{
            text: HOME_CARD_TEXT,
            muted: HOME_CARD_MUTED,
            faint: HOME_CARD_FAINT,
          }}
        >
          {children}
        </HomeCardToneContext.Provider>

        <View style={{ height: 1, backgroundColor: UI.borderSoft }} />

        <Pressable
          onPress={onPress}
          // @ts-ignore - web click fallback
          onClick={onPress}
          hitSlop={10}
          style={({ pressed }) => ({
            borderRadius: 18,
            borderWidth: 1,
            borderColor: UI.primaryBorder,
            backgroundColor: p.soft,
            paddingVertical: 15,
            paddingHorizontal: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            opacity: pressed ? 0.92 : 1,
          })}
        >
          <Text style={{ color: HOME_CARD_TEXT, fontWeight: "900", fontSize: 15 }}>{ctaLabel}</Text>
          {footerRight ? footerRight : <Text style={{ color: UI.faint, fontWeight: "900", fontSize: 16 }}>›</Text>}
        </Pressable>
      </View>
    </View>
  );
}

function CompactNotificationsHomeCard({ compactHub = false }: { compactHub?: boolean }) {
 const uiText = useCommonText();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const { activeStoreId, activeStoreName, stores } = useOrg();
  const isDesktopWeb = isDesktopWebEnv(width);

  if (isDesktopWeb) return null;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rows, setRows] = useState<NotifRow[]>([]);

  const loadBusyRef = useRef(false);

  const storeNameById = useMemo(() => {
    const map: Record<string, string> = {};
    for (const s of stores ?? []) {
      map[String((s as any).store_id)] = String((s as any).store_name ?? "Store");
    }
    return map;
  }, [stores]);

  const load = useCallback(async () => {
    if (loadBusyRef.current) return;

    loadBusyRef.current = true;
    setLoading(true);
    setError(null);

    try {
      const { data, error: e } = await supabase.rpc("get_my_notifications", {
        p_store_id: null,
        p_limit: 80,
      });

      if (e) throw e;

      setRows((data ?? []) as NotifRow[]);
    } catch (err: any) {
      setError(err?.message ?? "Failed to load notifications");
      setRows([]);
    } finally {
      loadBusyRef.current = false;
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (isDesktopWeb) return;
      void load();
    }, [isDesktopWeb, load])
  );

  useAutoRefresh(() => {
    void load();
  }, true, AUTO_REFRESH_MS);

  const receipts: Receipt[] = useMemo(() => {
    const map = new Map<string, Receipt>();

    for (const n of rows ?? []) {
      const key = n.ref_movement_id ? `mv:${n.ref_movement_id}` : `n:${n.id}`;
      const itemsArr = Array.isArray(n.items) ? n.items : [];

      const existing = map.get(key);
      if (!existing) {
        map.set(key, {
          key,
          movement_id: n.ref_movement_id ?? null,
          organization_id: n.organization_id,
          store_id: n.store_id,
          source_store_id: n.source_store_id ?? null,
          event_type: n.event_type,
          title: n.title,
          actor_user_id: n.actor_user_id,
          actor_name: n.actor_name ?? null,
          created_at: n.created_at,
          total_units: clampInt(n.total_units, 0),
          total_skus: clampInt(n.total_skus, 0),
          is_read: !!n.is_read,
          rows: [n],
          items: [...itemsArr],
        });
        continue;
      }

      existing.rows.push(n);

      if (new Date(n.created_at).getTime() > new Date(existing.created_at).getTime()) {
        existing.created_at = n.created_at;
      }

      existing.total_units += clampInt(n.total_units, 0);

      if (itemsArr.length > 0) {
        existing.items.push(...itemsArr);
      }

      existing.is_read = existing.is_read && !!n.is_read;
    }

    const out = Array.from(map.values());
    out.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return out;
  }, [rows]);

  const unreadCount = useMemo(() => receipts.filter((r) => !r.is_read).length, [receipts]);

  const activeStoreUnread = useMemo(() => {
    const scopedStoreId = String(activeStoreId ?? "").trim();
    if (!scopedStoreId) return 0;
    return receipts.filter((r) => clean(r.store_id) === scopedStoreId && !r.is_read).length;
  }, [receipts, activeStoreId]);

  const openNotifications = useCallback(() => {
    router.push("/notifications");
  }, [router]);

  if (compactHub) {
    return (
      <Pressable
        onPress={openNotifications}
        hitSlop={7}
        accessibilityRole="button"
        accessibilityLabel={uiText("Notifications")}
        style={({ pressed }) => ({
          width: 62,
          alignItems: "center",
          opacity: pressed ? 0.82 : 1,
        })}
      >
        <View
          style={{
            width: 36,
            height: 36,
            borderRadius: 999,
            borderWidth: 1,
            borderColor: "rgba(59,130,246,0.18)",
                    backgroundColor: "#EFF6FF",
                    alignItems: "center",
                    justifyContent: "center",
                    shadowColor: "#3B82F6",
                    shadowOpacity: 0.16,
                    shadowRadius: 6,
                    shadowOffset: { width: 0, height: 2 },
                    elevation: 2,
          }}
        >
          <SafeIcon
            name={unreadCount > 0 ? "notifications" : "notifications-outline"}
            size={15}
                    color="#3B82F6"
          />

          {unreadCount > 0 ? (
            <View
              style={{
                position: "absolute",
                right: -7,
                top: -7,
                minWidth: 18,
                height: 18,
                paddingHorizontal: 4,
                borderRadius: 999,
                backgroundColor: "#EF4444",
                borderWidth: 2,
                borderColor: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontWeight: "900",
                  fontSize: 8,
                }}
              >
                {unreadCount > 99 ? "99+" : unreadCount}
              </Text>
            </View>
          ) : null}
        </View>

        <Text
          style={{
            color: "#0F172A",
            fontWeight: "900",
            fontSize: 10,
            marginTop: 2,
          }}
          numberOfLines={1}
        >
          {uiText("Notifications")}</Text>

        <Text
          style={{
            color: error ? "#B91C1C" : "#94A3B8",
            fontWeight: "800",
            fontSize: 8,
          }}
          numberOfLines={1}
        >
          {error
            ? uiText("Sync issue")
            : loading
            ? uiText("Checking...")
            : unreadCount > 0
            ? uiText("{p0} unread", {p0: (unreadCount)})
            : uiText("All caught up")}
        </Text>
      </Pressable>
    );
  }

  return (
    <View style={{ paddingTop: 5 }}>
      <Pressable
        onPress={openNotifications}
        hitSlop={8}
        style={({ pressed }) => ({
          minHeight: 50,
          borderRadius: 16,
          borderWidth: 1,
          borderColor: "rgba(37,99,235,0.12)",
          backgroundColor: "#FFFFFF",
          paddingHorizontal: 12,
          paddingVertical: 9,
          flexDirection: "row",
          alignItems: "center",
          gap: 10,
          opacity: pressed ? 0.92 : 1,
          transform: [{ scale: pressed ? 0.995 : 1 }],
        })}
      >
        <View
          style={{
            width: 34,
            height: 34,
            borderRadius: 13,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#EFF6FF",
            borderWidth: 1,
            borderColor: "rgba(37,99,235,0.12)",
          }}
        >
          <SafeIcon
            name={unreadCount > 0 ? "notifications" : "notifications-outline"}
            size={16}
            color="#2563EB"
          />

          {unreadCount > 0 ? (
            <View
              style={{
                position: "absolute",
                right: -5,
                top: -5,
                minWidth: 18,
                height: 18,
                paddingHorizontal: 4,
                borderRadius: 999,
                backgroundColor: "#EF4444",
                borderWidth: 2,
                borderColor: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontWeight: "900",
                  fontSize: 8,
                }}
              >
                {unreadCount > 99 ? "99+" : unreadCount}
              </Text>
            </View>
          ) : null}
        </View>

        <View style={{ flex: 1, minWidth: 0 }}>
          <Text
            style={{
              color: "#0F172A",
              fontWeight: "900",
              fontSize: 13,
            }}
            numberOfLines={1}
          >
            {uiText("Notifications")}</Text>

          <Text
            style={{
              color: error ? "#B91C1C" : "#64748B",
              fontWeight: "700",
              fontSize: 10,
              marginTop: 2,
            }}
            numberOfLines={1}
          >
            {error
              ? uiText("Notification sync unavailable")
              : loading
              ? uiText("Checking latest alerts...")
              : unreadCount > 0
              ? uiText("{p0} unread ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ {p1} this store", {p0: (unreadCount), p1: (activeStoreUnread)})
              : receipts.length > 0
              ? uiText("{p0} recent notifications", {p0: (receipts.length)})
              : uiText("You're all caught up")}
          </Text>
        </View>

        <View
          style={{
            width: 28,
            height: 28,
            borderRadius: 999,
            backgroundColor: "#F8FAFC",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <SafeIcon
            name="chevron-forward"
            size={16}
            color="#64748B"
          />
        </View>
      </Pressable>
    </View>
  );
}

function MobileWebFinanceShortcut() {
  const uiText = useCommonText();
  const router = useRouter();
  const openFinance = useCallback(() => {
    router.push("/finance/live" as any);
  }, [router]);
  return <MobileFinanceEntry text={uiText} onOpen={openFinance} />;
}
function CompactFinanceCardHomePreview() {


 const systemText = useSystemMessageText();
 const uiText = useCommonText();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const org = useOrg();
  const isDesktopWeb = isDesktopWebEnv(width);
  const isMobileWeb = isMobileWebEnv(width);
  const isNarrowHome = width < 360;

  if (isDesktopWeb) return null;

  const orgId = String(org.activeOrgId ?? "").trim();
  const storeId = String(org.activeStoreId ?? "").trim();
  const storeName = String(org.activeStoreName ?? "Store").trim() || "Store";
  const roleLower = String(org.activeRole ?? "").trim().toLowerCase();
  const isOwner = roleLower === "owner";
  const canSeeCapitalSecrets = isOwner;
  const isOwnerOrAdmin = roleLower === "owner" || roleLower === "admin";
  const isStaffView = roleLower === "staff";

  const [staffExpenseAllowed, setStaffExpenseAllowed] = useState(false);
  const [staffExpenseLoading, setStaffExpenseLoading] = useState(false);

  const money = useOrgMoneyPrefs(orgId);

  useFocusEffect(
    useCallback(() => {
      void money.refresh();
    }, [money])
  );

  const loadStaffExpensePermission = useCallback(async () => {
    if (!storeId || !isStaffView) {
      setStaffExpenseAllowed(false);
      setStaffExpenseLoading(false);
      return;
    }

    setStaffExpenseLoading(true);

    try {
      const { data, error } = await supabase
        .from("stores")
        .select("staff_can_manage_expense")
        .eq("id", storeId)
        .maybeSingle();

      if (error) throw error;
      setStaffExpenseAllowed(!!data?.staff_can_manage_expense);
    } catch {
      try {
        const { data, error } = await supabase
          .from("stores")
          .select("allow_staff_expense")
          .eq("id", storeId)
          .maybeSingle();

        if (error) throw error;
        setStaffExpenseAllowed(!!data?.allow_staff_expense);
      } catch {
        setStaffExpenseAllowed(false);
      }
    } finally {
      setStaffExpenseLoading(false);
    }
  }, [storeId, isStaffView]);

  useEffect(() => {
    void loadStaffExpensePermission();
  }, [loadStaffExpensePermission]);

  const displayCurrency = money.currency || "TZS";
  const displayLocale = money.locale || "en-TZ";

  const range: RangeKey = "today";

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [valuationScope,setValuationScope]=useState("");const [salesRow, setSalesRow] = useState<SalesSummary>({
    total: 0,
    orders: 0,
    currency: "TZS",
  });

  const [expRow, setExpRow] = useState<ExpenseSummary>({
    total: 0,
    count: 0,
  });

  const [profitRow, setProfitRow] = useState<ProfitSummary>({
    net: 0,
    sales: null,
    expenses: null,
  });

  const [pay, setPay] = useState<PayBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
    credit: 0,
    other: 0,
    orders: 0,
  });

  const [collections, setCollections] = useState<CollectionBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
    other: 0,
    total: 0,
    payments: 0,
  });

  const [expenseByChannel, setExpenseByChannel] = useState<ExpenseChannelBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
  });

  const reqIdRef = useRef(0);
  const loadingRef = useRef(false);

  const canStaffSeeExpenseFinance = isStaffView && staffExpenseAllowed;

  useEffect(() => {
    loadingRef.current = loading;
  }, [loading]);

  const callSalesForStore = useCallback(
    async (sid: string, fromISO: string, toISO: string): Promise<SalesSummary> => {
      const { data, error } = await supabase.rpc("get_sales", {
        p_store_id: sid,
        p_from: fromISO,
        p_to: toISO,
      } as any);
      if (error) throw error;

      const rows = (Array.isArray(data) ? data : []) as any[];

      const pickAmount = (r: any) => {
        const candidates = [
          r?.total_amount,
          r?.total,
          r?.amount,
          r?.grand_total,
          r?.paid_amount,
          r?.revenue,
        ];
        for (const c of candidates) {
          const n = Number(c);
          if (Number.isFinite(n)) return n;
        }
        return 0;
      };

      const isCancelled = (r: any) => {
        const st = String(r?.status ?? "").toLowerCase().trim();
        return st === "cancelled" || st === "canceled" || st === "void";
      };

      const total = rows.reduce((acc, r) => acc + toNum(pickAmount(r)), 0);
      const orders = rows.reduce((acc, r) => acc + (isCancelled(r) ? 0 : 1), 0);

      const currency = String(rows?.[0]?.currency ?? "TZS").trim() || "TZS";
      return { total, orders, currency };
    },
    []
  );

  const callExpenseForStore = useCallback(
    async (sid: string, fromYMD: string, toYMD: string): Promise<ExpenseSummary> => {
      const fnName = "get_expense_summary_v2";

      const { data, error } = await supabase.rpc(fnName, {
        p_store_id: sid,
        p_from: fromYMD,
        p_to: toYMD,
      } as any);
      if (error) throw error;

      const row = (Array.isArray(data) ? data[0] : data) as any;
      return {
        total: toNum(row?.total ?? row?.amount ?? row?.sum ?? 0),
        count: toInt(row?.count ?? row?.items ?? 0),
      };
    },
    [isStaffView, canStaffSeeExpenseFinance]
  );

  const callProfitOwnerOnly = useCallback(
    async (sid: string, fromISO: string, toISO: string): Promise<ProfitSummary> => {
      if (!isOwner) {
        return { net: 0, sales: null, expenses: null };
      }

      const { data, error } = await supabase.rpc("get_store_net_profit_v2", {
        p_store_id: sid,
        p_from: fromISO,
        p_to: toISO,
      } as any);
      if (error) throw error;

      const row = (Array.isArray(data) ? data[0] : data) as any;
      return {
        net: toNum(row?.net_profit ?? row?.net ?? 0),
        sales: row?.sales_total != null ? toNum(row?.sales_total) : null,
        expenses: row?.expenses_total != null ? toNum(row?.expenses_total) : null,
      };
    },
    [isOwner]
  );

  const callPaymentBreakdown = useCallback(
    async (fromISO: string, toISO: string, sidOrNull: string | null): Promise<PayBreakdown> => {
      if (!orgId) return { cash: 0, bank: 0, mobile: 0, credit: 0, other: 0, orders: 0 };

      const { data, error } = await supabase.rpc("get_sales_channel_summary_v3", {
        p_org_id: orgId,
        p_from: fromISO,
        p_to: toISO,
        p_store_id: sidOrNull,
      } as any);
      if (error) throw error;

      const rows = (Array.isArray(data) ? data : []) as any[];
      const out: PayBreakdown = { cash: 0, bank: 0, mobile: 0, credit: 0, other: 0, orders: 0 };

      for (const r of rows) {
        const ch = String(r?.channel ?? r?.payment_method ?? "").trim().toUpperCase();
        const rev = toNum(r?.revenue ?? r?.total ?? 0);
        const ord = toInt(r?.orders ?? 0);

        out.orders += ord;

        if (ch === "CASH") out.cash += rev;
        else if (ch === "BANK") out.bank += rev;
        else if (ch === "MOBILE") out.mobile += rev;
        else if (ch === "CREDIT") out.credit += rev;
        else out.other += rev;
      }

      return out;
    },
    [orgId]
  );

  const callCreditCollections = useCallback(
    async (fromISO: string, toISO: string, sidOrNull: string | null): Promise<CollectionBreakdown> => {
      if (!orgId) return { cash: 0, bank: 0, mobile: 0, other: 0, total: 0, payments: 0 };

      const fnCandidates = [
        "get_credit_collections_summary_v2",
        "get_credit_collections_channel_summary_v2",
        "get_credit_collections_channel_summary_v1",
        "get_credit_collections_channel_summary",
        "get_credit_payments_channel_summary_v1",
        "get_credit_payments_channel_summary",
      ];

      let lastErr: any = null;

      for (const fn of fnCandidates) {
        const { data, error } = await supabase.rpc(fn, {
          p_org_id: orgId,
          p_from: fromISO,
          p_to: toISO,
          p_store_id: sidOrNull,
        } as any);

        if (error) {
          lastErr = error;
          continue;
        }

        const rows = (Array.isArray(data) ? data : []) as any[];
        const out: CollectionBreakdown = {
          cash: 0,
          bank: 0,
          mobile: 0,
          other: 0,
          total: 0,
          payments: 0,
        };

        for (const r of rows) {
          const ch = String(r?.channel ?? r?.payment_method ?? r?.method ?? "").trim().toUpperCase();
          const amt = toNum(r?.amount ?? r?.revenue ?? r?.total ?? 0);
          const cnt = toInt(r?.payments ?? r?.count ?? 0);

          out.payments += cnt;

          if (ch === "CASH") out.cash += amt;
          else if (ch === "BANK") out.bank += amt;
          else if (ch === "MOBILE") out.mobile += amt;
          else out.other += amt;
        }

        out.total = out.cash + out.bank + out.mobile;
        return out;
      }

      const _ = lastErr;
      return { cash: 0, bank: 0, mobile: 0, other: 0, total: 0, payments: 0 };
    },
    [orgId]
  );

  const callExpenseBreakdown = useCallback(
    async (sid: string, fromYMD: string, toYMD: string): Promise<ExpenseChannelBreakdown> => {
      const { data, error } = await supabase.rpc("get_expense_channel_summary_v2", {
        p_store_id: sid,
        p_from: fromYMD,
        p_to: toYMD,
      } as any);
      if (error) throw error;

      const rows = (Array.isArray(data) ? data : []) as any[];

      const out: ExpenseChannelBreakdown = {
        cash: 0,
        bank: 0,
        mobile: 0,
      };

      for (const r of rows) {
        const ch = String(r?.channel ?? "").trim().toUpperCase();
        const amt = toNum(r?.amount ?? 0);

        if (ch === "CASH") out.cash += amt;
        else if (ch === "BANK") out.bank += amt;
        else if (ch === "MOBILE") out.mobile += amt;
      }

      return out;
    },
    []
  );

  const load = useCallback(
    async (opts?: { silent?: boolean }) => {
      const silent = !!opts?.silent;
      const rid = ++reqIdRef.current;

      if (!orgId) {
        setErr("No active organization selected");
        return;
      }
      if (!storeId) {
        setErr("No active store selected");
        return;
      }
      if (!silent && loadingRef.current) return;

      if (!silent) setLoading(true);
      setErr(null);

      // ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ reset preview state before each fresh load
      // this prevents stale profit/sales/expenses from a previous successful request
      setSalesRow({
        total: 0,
        orders: 0,
        currency: "TZS",
      });

      setExpRow({
        total: 0,
        count: 0,
      });

      setProfitRow({
        net: 0,
        sales: null,
        expenses: null,
      });

      setPay({
        cash: 0,
        bank: 0,
        mobile: 0,
        credit: 0,
        other: 0,
        orders: 0,
      });

      setCollections({
        cash: 0,
        bank: 0,
        mobile: 0,
        other: 0,
        total: 0,
        payments: 0,
      });

      setExpenseByChannel({
        cash: 0,
        bank: 0,
        mobile: 0,
      });

      try {
        const { from, to } = rangeToFromTo(range);
        const { from: fromYMD, to: toYMD } = rangeToDates(range);

        const [
          salesRes,
          expenseRes,
          profitRes,
          payRes,
          collectionsRes,
          expenseBreakdownRes,
        ] = await Promise.allSettled([
          callSalesForStore(storeId, from, to),
          callExpenseForStore(storeId, fromYMD, toYMD),
          callProfitOwnerOnly(storeId, from, to),
          callPaymentBreakdown(from, to, storeId),
          callCreditCollections(from, to, storeId),
          callExpenseBreakdown(storeId, fromYMD, toYMD),
        ]);

        if (rid !== reqIdRef.current) return;

        if (salesRes.status === "fulfilled") {
          setSalesRow(salesRes.value);setValuationScope(JSON.stringify([orgId,storeId]));
        } else {
          setSalesRow({
            total: 0,
            orders: 0,
            currency: "TZS",
          });
        }

        if (expenseRes.status === "fulfilled") {
          setExpRow(expenseRes.value);
        } else {
          setExpRow({
            total: 0,
            count: 0,
          });
        }

        if (profitRes.status === "fulfilled") {
          setProfitRow(profitRes.value);
        } else {
          setProfitRow({
            net: 0,
            sales: null,
            expenses: null,
          });
        }

        if (payRes.status === "fulfilled") {
          setPay(payRes.value);
        } else {
          setPay({
            cash: 0,
            bank: 0,
            mobile: 0,
            credit: 0,
            other: 0,
            orders: 0,
          });
        }

        if (collectionsRes.status === "fulfilled") {
          setCollections(collectionsRes.value);
        } else {
          setCollections({
            cash: 0,
            bank: 0,
            mobile: 0,
            other: 0,
            total: 0,
            payments: 0,
          });
        }

        if (expenseBreakdownRes.status === "fulfilled") {
          setExpenseByChannel(expenseBreakdownRes.value);
        } else {
          setExpenseByChannel({
            cash: 0,
            bank: 0,
            mobile: 0,
          });
        }

        const firstErr =
          (salesRes.status === "rejected" && salesRes.reason) ||
          (expenseRes.status === "rejected" && expenseRes.reason) ||
          (profitRes.status === "rejected" && profitRes.reason) ||
          (collectionsRes.status === "rejected" && collectionsRes.reason) ||
          (expenseBreakdownRes.status === "rejected" && expenseBreakdownRes.reason) ||
          null;

        if (firstErr) {
          const msg = firstErr?.message ?? "Failed to load some finance data";

          if (isStaffView && canStaffSeeExpenseFinance) {
            if (/owner\/admin only|no access|not allowed/i.test(String(msg))) {
              setErr(null);
            } else {
              setErr(msg);
            }
          } else {
            setErr(msg);
          }
        }
      } catch (e: any) {
        if (rid !== reqIdRef.current) return;
        setErr(e?.message ?? "Failed to load finance");
      } finally {
        if (!silent && rid === reqIdRef.current) setLoading(false);
      }
    },
    [
      orgId,
      storeId,
      range,
      callSalesForStore,
      callExpenseForStore,
      callProfitOwnerOnly,
      callPaymentBreakdown,
      callCreditCollections,
      callExpenseBreakdown,
    ]
  );

  useFocusEffect(
    useCallback(() => {
      if (isDesktopWeb) return;
      if (!orgId || !storeId) return;

      void load();
    }, [isDesktopWeb, orgId, storeId, load])
  );
  useAutoRefresh(() => {
    if (!orgId || !storeId) return;
    void load({ silent: true });
  }, !!orgId && !!storeId, AUTO_REFRESH_MS);

 const preferredMoney=usePreferredDisplayMoney(orgId,valuationScope===JSON.stringify([orgId,storeId])&&!loading);
  const fmtHomeMoney = useCallback(
    (n: number) =>
      preferredMoney(n, {
        currency: displayCurrency,
        locale: displayLocale,
      }).replace(/\s+/g, " "),
    [displayCurrency, displayLocale,preferredMoney]
  );

  const expenseBreakdownTotal =
    toNum(expenseByChannel.cash) +
    toNum(expenseByChannel.bank) +
    toNum(expenseByChannel.mobile);

  const effectiveExpenseTotal =
    isStaffView && canStaffSeeExpenseFinance
      ? Math.max(toNum(expRow.total), expenseBreakdownTotal)
      : toNum(expRow.total);

  const availableCashNum = subtractFloor(
    pay.cash + collections.cash,
    expenseByChannel.cash
  );

  const availableBankNum = subtractFloor(
    pay.bank + collections.bank,
    expenseByChannel.bank
  );

  const availableMobileNum = subtractFloor(
    pay.mobile + collections.mobile,
    expenseByChannel.mobile
  );

  const totalMoneyInNum =
    availableCashNum +
    availableBankNum +
    availableMobileNum;

  const openFinance = useCallback(() => {
    if (isStaffView && canStaffSeeExpenseFinance) {
      router.push("/(tabs)/sales/expenses" as any);
      return;
    }

    const dates = rangeToDates("today");

    router.push({
      pathname: "/finance/history",
      params: {
        mode: "SALES",
        scope: "STORE",
        range: "today",
        from: dates.from,
        to: dates.to,
      } as any,
    } as any);
  }, [router, isStaffView, canStaffSeeExpenseFinance]);

  const hubActions = useMemo(
    () => [
      {
        key: "credit",
        label: uiText("Credit"),
        hint: uiText("Customers"),
        icon: "people-outline",
        color: "#F97316",
        softColor: "#FFF7ED",
        borderColor: "rgba(249,115,22,0.20)",
        shadowColor: "#F97316",
        onPress: () => router.push("/(tabs)/credit" as any),
      },
    ],
    [router, uiText]
  );
  return (
    <View style={{ marginTop: 8 }}>
      <View
        style={{
          borderRadius: 24,
          borderWidth: 1,
          borderColor: "rgba(37,99,235,0.12)",
          backgroundColor: "#FFFFFF",
          paddingHorizontal: 12,
          paddingTop: 10,
          paddingBottom: 10,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            marginBottom: 4,
          }}
        >
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text
              style={{
                color: "#64748B",
                fontSize: 11,
                fontWeight: "900",
                letterSpacing: 0.8,
              }}
            >
              {uiText("BUSINESS HUB")}</Text>

            <Text
              style={{
                color: "#0F172A",
                fontSize: 14,
                fontWeight: "900",
                marginTop: 1,
              }}
              numberOfLines={1}
            >
              {(String((org.activeStoreName ?? uiText("Store"))).trim() || uiText("Store"))}
            </Text>
          </View>

          <View
            style={{
              paddingHorizontal: 8,
              paddingVertical: 4,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(16,185,129,0.20)",
              backgroundColor: "rgba(16,185,129,0.07)",
            }}
          >
            <Text
              style={{
                color: "#047857",
                fontWeight: "900",
                fontSize: 8,
                letterSpacing: 0.4,
              }}
            >
              {loading || staffExpenseLoading ? uiText("SYNCING") : uiText("LIVE")}
            </Text>
          </View>
        </View>

        <View
          style={{
            height: isNarrowHome ? 164 : 174,
            position: "relative",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <View
            pointerEvents="none"
            style={{
              position: "absolute",
              width: isNarrowHome ? 148 : 160,
              height: isNarrowHome ? 148 : 160,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(45,212,191,0.20)",
              backgroundColor: "rgba(240,253,250,0.72)",
            }}
          />

          <Pressable
            onPress={openFinance}
            hitSlop={8}
            style={({ pressed }) => ({
              width: isNarrowHome ? 120 : 130,
              height: isNarrowHome ? 120 : 130,
              borderRadius: 999,
              borderWidth: isNarrowHome ? 4 : 5,
              borderColor: "rgba(20,184,166,0.18)",
              backgroundColor: "#FFFFFF",
              alignItems: "center",
              justifyContent: "center",
              paddingHorizontal: 12,
              shadowColor: "#2563EB",
              shadowOpacity: 0.10,
              shadowRadius: 12,
              shadowOffset: { width: 0, height: 5 },
              elevation: 4,
              opacity: pressed ? 0.94 : 1,
              transform: [{ scale: pressed ? 0.985 : 1 }],
            })}
          >
            <Text
              style={{
                color: "#64748B",
                fontWeight: "900",
                fontSize: 10,
                letterSpacing: 0.8,
              }}
            >
              {uiText("TODAY'S SALES")}</Text>

            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: isNarrowHome ? 18 : 20,
                marginTop: 3,
                textAlign: "center",
              }}
              numberOfLines={2}
              adjustsFontSizeToFit
              minimumFontScale={0.58}
            >
              {loading ? "..." : fmtHomeMoney(salesRow.total)}
            </Text>

            <Text
              style={{
                color: "#64748B",
                fontWeight: "800",
                fontSize: 10,
                marginTop: 2,
              }}
            >
              {salesRow.orders ?? 0} {uiText("orders")}</Text>

            <View
              style={{
                marginTop: 4,
                paddingHorizontal: 8,
                paddingVertical: 3,
                borderRadius: 999,
                backgroundColor: "#EFF6FF",
              }}
            >
              <Text
                style={{
                  color: "#2563EB",
                  fontWeight: "900",
                  fontSize: 10,
                }}
              >
                {uiText("View Details")}</Text>
            </View>
          </Pressable>

          <View
            style={{
              position: "absolute",
              top: 1,
              left: 0,
              right: 0,
              flexDirection: "row",
              justifyContent: "space-between",
              paddingHorizontal: 2,
            }}
          >
            <CompactNotificationsHomeCard compactHub />

            {hubActions.slice(0, 1).map((action) => (
              <Pressable
                key={action.key}
                onPress={action.onPress}
                hitSlop={7}
                style={({ pressed }) => ({
                  width: 62,
                  alignItems: "center",
                  opacity: pressed ? 0.82 : 1,
                })}
              >
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 999,
                    borderWidth: 1,
                    borderColor: action.borderColor,
                    backgroundColor: action.softColor,
                    alignItems: "center",
                    justifyContent: "center",
                    shadowColor: action.shadowColor,
                    shadowOpacity: 0.16,
                    shadowRadius: 6,
                    shadowOffset: { width: 0, height: 2 },
                    elevation: 2,
                  }}
                >
                  <SafeIcon
                    name={
                      action.icon as React.ComponentProps<
                        typeof Ionicons
                      >["name"]
                    }
                    size={15}
                    color={action.color}
                  />
                </View>

                <Text
                  style={{
                    color: "#0F172A",
                    fontWeight: "900",
                    fontSize: 10,
                    marginTop: 2,
                  }}
                  numberOfLines={1}
                >
                  {action.label}
                </Text>

                <Text
                  style={{
                    color: "#94A3B8",
                    fontWeight: "800",
                    fontSize: 8,
                  }}
                  numberOfLines={1}
                >
                  {action.hint}
                </Text>
              </Pressable>
            ))}
          </View>


        </View>

        <View
          style={{
            flexDirection: "row",
            gap: 5,
            marginTop: 0,
          }}
        >
          <View
            style={{
              flex: 1,
              borderRadius: 10,
              backgroundColor: "#F8FAFC",
              paddingVertical: 5,
              paddingHorizontal: 6,
            }}
          >
            <Text
              style={{
                color: "#94A3B8",
                fontWeight: "900",
                fontSize: 8,
              }}
            >
              {uiText("MONEY IN")}</Text>

            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: 11,
                marginTop: 2,
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.62}
            >
              {fmtHomeMoney(totalMoneyInNum)}
            </Text>
          </View>

          <View
            style={{
              flex: 1,
              borderRadius: 10,
              backgroundColor: "#F8FAFC",
              paddingVertical: 5,
              paddingHorizontal: 6,
            }}
          >
            <Text
              style={{
                color: "#94A3B8",
                fontWeight: "900",
                fontSize: 8,
              }}
            >
              {uiText("EXPENSES")}</Text>

            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: 11,
                marginTop: 2,
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.62}
            >
              {isStaffView && !canStaffSeeExpenseFinance
                ? uiText("Restricted")
                : fmtHomeMoney(effectiveExpenseTotal)}
            </Text>
          </View>

          <View
            style={{
              flex: 1,
              borderRadius: 10,
              backgroundColor: "#F8FAFC",
              paddingVertical: 5,
              paddingHorizontal: 6,
            }}
          >
            <Text
              style={{
                color: "#94A3B8",
                fontWeight: "900",
                fontSize: 8,
              }}
              numberOfLines={1}
            >
              {isOwner ? uiText("NET PROFIT") : uiText("AVG / ORDER")}
            </Text>

            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: 11,
                marginTop: 2,
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.62}
            >
              {isOwner
                ? fmtHomeMoney(profitRow.net)
                : salesRow.orders > 0
                ? fmtHomeMoney(
                    salesRow.total / Math.max(1, salesRow.orders)
                  )
                : uiText("ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â")}
            </Text>
          </View>
        </View>

        {!!(!isStaffView ? err : null) ? (
          <View
            style={{
              marginTop: 6,
              borderRadius: 10,
              borderWidth: 1,
              borderColor: "rgba(239,68,68,0.18)",
              backgroundColor: "#FEF2F2",
              paddingHorizontal: 8,
              paddingVertical: 6,
            }}
          >
            <Text
              style={{
                color: "#B91C1C",
                fontWeight: "800",
                fontSize: 9,
              }}
              numberOfLines={2}
            >
              {!isStaffView ? systemText(err) : null}
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}

function CompactClubRevenueCardHomePreview({ onOpen }: { onOpen: () => void }) {
 const preferredMoney=usePreferredDisplayMoney();

 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const { width } = useWindowDimensions();
  const orgAny = useOrg() as any;
  const isDesktopWeb = isDesktopWebEnv(width);
  const isMobileWeb = isMobileWebEnv(width);

  if (isDesktopWeb) return null;

  const orgId: string = String(
    orgAny?.activeOrgId ??
      orgAny?.activeOrganizationId ??
      orgAny?.organizationId ??
      orgAny?.orgId ??
      orgAny?.activeOrg?.id ??
      orgAny?.activeOrg?.org_id ??
      ""
  ).trim();

  const money = useOrgMoneyPrefs(orgId);

  useFocusEffect(
    useCallback(() => {
      void money.refresh();
    }, [money])
  );const displayCurrency = money.currency || "TZS";
  const displayLocale = money.locale || "en-TZ";

  const storeId: string = String(
    orgAny?.activeStoreId ??
      orgAny?.activeStore?.id ??
      orgAny?.selectedStoreId ??
      orgAny?.selectedStore?.id ??
      ""
  ).trim();

  const storeName: string =
    String(orgAny?.activeStoreName ?? orgAny?.activeStore?.name ?? "Store").trim() || "Store";

  const range: RangeKey = "today";const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [row, setRow] = useState<DashRow | null>(null);

  const reqIdRef = useRef(0);

  const load = useCallback(async () => {
    const rid = ++reqIdRef.current;

    if (!storeId) {
      setErr("No active store selected");
      setRow(null);
      return;
    }

    setLoading(true);
    setErr(null);

    try {
      const { from, to } = rangeToFromTo(range);

      const { data: d1, error: e1 } = await supabase.rpc("get_club_revenue_dashboard_v4", {
        p_store_id: storeId,
        p_from: from,
        p_to: to,
      } as any);
      if (e1) throw e1;

      const raw = (Array.isArray(d1) ? d1[0] : d1) as any;

      if (rid !== reqIdRef.current) return;
      setRow(raw ? normalizeDash(raw, from, to, storeId) : null);
    } catch (e: any) {
      if (rid !== reqIdRef.current) return;
      setErr(e?.message ?? "Failed to load club revenue");
      setRow(null);
    } finally {if (rid === reqIdRef.current) setLoading(false);
    }
  }, [range, storeId]);

  useFocusEffect(
    useCallback(() => {
      if (isDesktopWeb) return;
      if (!storeId) return;

      void load();
    }, [isDesktopWeb, storeId, load])
  );

  useAutoRefresh(() => {
    if (!storeId) return;
    void load();
  }, !!storeId, AUTO_REFRESH_MS);

  const revenue = preferredMoney(toNum(row?.revenue), {
    currency: displayCurrency,
    locale: displayLocale,
  }).replace(/\s+/g, " ");
  const paid = preferredMoney(toNum(row?.paid_revenue), {
    currency: displayCurrency,
    locale: displayLocale,
  }).replace(/\s+/g, " ");

  return (
    <PremiumMetricCard
      title={uiText("Club Revenue")}
      subtitle={uiText("Store: {p0}", {p0: (storeName)})}
      iconName="pulse-outline"
      loading={loading}
      badgeText="LIVE"
      error={systemText(err)}
      ctaLabel="Open Club Revenue"
      mobileWebLite={isMobileWeb}
      tone="club"
      onPress={onOpen}
    >
      <View style={{ flexDirection: "row", gap: 12, paddingTop: 2 }}>
        <MiniStat label={uiText("Revenue")} value={revenue} />
        <MiniStat label={uiText("Paid")} value={paid} />
        <MiniStat label={uiText("Orders")} value={String(row?.delivered_orders ?? 0)} hint={uiText("delivered")} />
      </View>
    </PremiumMetricCard>
  );
}

function CompactStockValueCardHomePreview() {
 const preferredMoney=usePreferredDisplayMoney();

 const systemText = useSystemMessageText();
 const uiText = useCommonText();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const orgAny = useOrg() as any;
  const isDesktopWeb = isDesktopWebEnv(width);
  const isMobileWeb = isMobileWebEnv(width);

  if (isDesktopWeb) return null;

  const roleLower = String(orgAny?.activeRole ?? "").trim().toLowerCase();
  const canViewStockAction = roleLower === "owner";

  if (!canViewStockAction) return null;

  const orgId: string = String(
    orgAny?.activeOrgId ??
      orgAny?.activeOrganizationId ??
      orgAny?.organizationId ??
      orgAny?.orgId ??
      orgAny?.activeOrg?.id ??
      orgAny?.activeOrg?.org_id ??
      ""
  ).trim();

  const money = useOrgMoneyPrefs(orgId);

  useFocusEffect(
    useCallback(() => {
      void money.refresh();
    }, [money])
  );

  

  const displayCurrency = money.currency || "TZS";
  const displayLocale = money.locale || "en-TZ";

  const storeId: string = String(
    orgAny?.activeStoreId ??
      orgAny?.activeStore?.id ??
      orgAny?.selectedStoreId ??
      orgAny?.selectedStore?.id ??
      ""
  ).trim();

  const storeName: string =
    String(orgAny?.activeStoreName ?? orgAny?.activeStore?.name ?? "Store").trim() || "Store";

  const range: RangeKey = "today";

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [row, setRow] = useState<FinRow | null>(null);

  const STOCK_IN_VERSION_BADGE = "v2";

  const reqIdRef = useRef(0);

  const rpcTryScalar = useCallback(async (fnNames: string[], args: Record<string, any>) => {
    let lastErr: any = null;

    for (const fn of fnNames) {
      const { data, error } = await supabase.rpc(fn, args as any);
      if (error) {
        lastErr = error;
        continue;
      }
      const raw = (Array.isArray(data) ? data[0] : data) as any;
      return extractScalarValue(raw);
    }

    throw lastErr ?? new Error("RPC failed");
  }, []);

  const loadForStore = useCallback(
    async (sid: string, dateFrom: string, dateTo: string) => {
      const onVal = await rpcTryScalar(["get_stock_on_hand_value_v1"], {
        p_org_id: orgId,
        p_store_id: sid,
      });

      const inVal = await rpcTryScalar(["get_stock_in_value_v2", "get_stock_in_value_v1"], {
        p_org_id: orgId,
        p_store_id: sid,
        p_date_from: dateFrom,
        p_date_to: dateTo,
      });

      return {
        org_id: orgId,
        store_id: sid,
        date_from: dateFrom,
        date_to: dateTo,
        stock_on_hand_value:onVal,
        stock_in_value: inVal,
      } as FinRow;
    },
    [orgId, rpcTryScalar]
  );

  const load = useCallback(async () => {
    const rid = ++reqIdRef.current;

    if (!orgId) {
      setErr("No active organization selected");
      setRow(null);
      return;
    }
    if (!storeId) {
      setErr("No active store selected");
      setRow(null);
      return;
    }

    setLoading(true);
    setErr(null);

    try {
      const { from, to } = rangeToDates(range);

      const r = await loadForStore(storeId, from, to);
      if (rid !== reqIdRef.current) return;

      setRow({
        org_id: orgId,
        store_id: storeId,
        date_from: from,
        date_to: to,
        stock_on_hand_value: toNum(r.stock_on_hand_value),
        stock_in_value: toNum(r.stock_in_value),
      });
    } catch (e: any) {
      if (rid !== reqIdRef.current) return;
      setErr(e?.message ?? "Failed to load stock values");
      setRow(null);
    } finally {
      if (rid === reqIdRef.current) setLoading(false);
    }
  }, [orgId, storeId, range, loadForStore]);

  useFocusEffect(
    useCallback(() => {
      if (isDesktopWeb) return;
      if (!orgId || !storeId) return;

      void load();
    }, [isDesktopWeb, orgId, storeId, load])
  );

  useAutoRefresh(() => {
    if (!orgId || !storeId) return;
    void load();
  }, !!orgId && !!storeId, AUTO_REFRESH_MS);

  const onHand = preferredMoney(toNum(row?.stock_on_hand_value), {
    currency: displayCurrency,
    locale: displayLocale,
  }).replace(/\s+/g, " ");
  const stockIn = preferredMoney(toNum(row?.stock_in_value), {
    currency: displayCurrency,
    locale: displayLocale,
  }).replace(/\s+/g, " ");

  return (
    <PremiumMetricCard
      title={uiText("Stock Value")}
      subtitle={uiText("Store: {p0}", {p0: (storeName)})}
      iconName="cube-outline"
      loading={loading}
      badgeText="INVENTORY"
      error={systemText(err)}
      ctaLabel="Open Stock History"
      mobileWebLite={isMobileWeb}
      tone="stock"
      onPress={() => router.push("/stocks/history")}
      footerRight={
        <Text style={{ color: UI.faint, fontWeight: "900", fontSize: 12 }}>
          {loading ? "..." : STOCK_IN_VERSION_BADGE}
        </Text>
      }
    >
      <View style={{ flexDirection: "row", gap: 12, paddingTop: 2 }}>
        <MiniStat label={uiText("On Hand Value")} value={onHand} hint={uiText("current stock")} />
        <MiniStat label={uiText("Stock In Value")} value={stockIn} hint={uiText("received (+)")} />
      </View>
    </PremiumMetricCard>
  );
}

function MobileHomeActionTile({
  label,
  hint,
  icon,
  onPress,
  tone = "blue",
}: {
  label: string;
  hint: string;
  icon: React.ComponentProps<typeof Ionicons>["name"];
  onPress: () => void;
  tone?: "blue" | "red" | "amber" | "green" | "slate";
}) {
  const tones = {
    blue: {
      bg: "#EFF6FF",
      border: "rgba(37,99,235,0.14)",
      iconBg: "#DBEAFE",
      icon: "#2563EB",
    },
    red: {
      bg: "#FFF7F7",
      border: "rgba(239,68,68,0.14)",
      iconBg: "#FEE2E2",
      icon: "#DC2626",
    },
    amber: {
      bg: "#FFFBEB",
      border: "rgba(245,158,11,0.16)",
      iconBg: "#FEF3C7",
      icon: "#D97706",
    },
    green: {
      bg: "#ECFDF5",
      border: "rgba(16,185,129,0.16)",
      iconBg: "#D1FAE5",
      icon: "#059669",
    },
    slate: {
      bg: "#F8FAFC",
      border: "rgba(100,116,139,0.14)",
      iconBg: "#E2E8F0",
      icon: "#475569",
    },
  } as const;

  const palette = tones[tone];

  return (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={({ pressed }) => ({
        width: "48.5%",
        minHeight: 104,
        borderRadius: 22,
        borderWidth: 1,
        borderColor: palette.border,
        backgroundColor: palette.bg,
        padding: 14,
        opacity: pressed ? 0.84 : 1,
        transform: [{ scale: pressed ? 0.985 : 1 }],
      })}
    >
      <View
        style={{
          width: 38,
          height: 38,
          borderRadius: 13,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: palette.iconBg,
        }}
      >
        <SafeIcon name={icon} size={19} color={palette.icon} />
      </View>

      <Text
        style={{
          color: "#0F172A",
          fontWeight: "900",
          fontSize: 13,
          marginTop: 10,
        }}
        numberOfLines={1}
      >
        {label}
      </Text>

      <Text
        style={{
          color: "#64748B",
          fontWeight: "700",
          fontSize: 10,
          lineHeight: 14,
          marginTop: 3,
        }}
        numberOfLines={2}
      >
        {hint}
      </Text>
    </Pressable>
  );
}

// PREMIUM POLISH PASS 1 ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â TYPOGRAPHY
function MobileBusinessTools({
  isOwner,
  onOpenBusinessPosition,
  onOpenBusinessDebts,
  onOpenIncomingStock,
  onOpenStock,
}: {
  isOwner: boolean;
  onOpenBusinessPosition: () => void;
  onOpenBusinessDebts: () => void;
  onOpenIncomingStock: () => void;
  onOpenStock: () => void;
}) {
 const uiText = useCommonText();
  if (!isOwner) return null;

  const items = [
    {
      key: "position",
      label: uiText("Position"),
      icon: "analytics-outline" as const,
      color: "#0F766E",
      softColor: "#F0FDFA",
      borderColor: "rgba(15,118,110,0.13)",
      shadowColor: "#14B8A6",
      onPress: onOpenBusinessPosition,
    },
    {
      key: "debts",
      label: uiText("Debts"),
      icon: "wallet-outline" as const,
      color: "#C2410C",
      softColor: "#FFF7ED",
      borderColor: "rgba(194,65,12,0.13)",
      shadowColor: "#F97316",
      onPress: onOpenBusinessDebts,
    },
    {
      key: "incoming",
      label: uiText("Incoming"),
      icon: "boat-outline" as const,
      color: "#0369A1",
      softColor: "#F0F9FF",
      borderColor: "rgba(3,105,161,0.13)",
      shadowColor: "#38BDF8",
      onPress: onOpenIncomingStock,
    },
    {
      key: "stock-value",
      label: uiText("Stock Value"),
      icon: "cube-outline" as const,
      color: "#4F46E5",
      softColor: "#EEF2FF",
      borderColor: "rgba(79,70,229,0.13)",
      shadowColor: "#6366F1",
      onPress: onOpenStock,
    },
  ];

  return (
    <View
      style={{
        marginTop: 5,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: "rgba(148,163,184,0.14)",
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 8,
        paddingVertical: 5,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginBottom: 4,
        }}
      >
        <Text
          style={{
            flex: 1,
            color: "#0F172A",
            fontWeight: "900",
            fontSize: 12,
          }}
        >
          {uiText("Business Tools")}</Text>

        <Text
          style={{
            color: "#94A3B8",
            fontWeight: "900",
            fontSize: 9,
            letterSpacing: 0.4,
          }}
        >
          {uiText("OWNER")}</Text>
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        {items.map((item) => (
          <Pressable
            key={item.key}
            onPress={item.onPress}
            hitSlop={5}
            style={({ pressed }) => ({
              width: "24%",
              alignItems: "center",
              opacity: pressed ? 0.84 : 1,
              transform: [
                { scale: pressed ? 0.97 : 1 },
              ],
            })}
          >
            <View
              style={{
                width: 28,
                height: 28,
                borderRadius: 9,
                borderWidth: 1,
                borderColor: item.borderColor,
                backgroundColor: item.softColor,
                alignItems: "center",
                justifyContent: "center",
                shadowColor: item.shadowColor,
                shadowOpacity: 0.08,
                shadowRadius: 3,
                shadowOffset: { width: 0, height: 1 },
                elevation: 1,
              }}
            >
              <SafeIcon
                name={item.icon}
                size={13}
                color={item.color}
              />
            </View>

            <Text
              style={{
                color: "#475569",
                fontWeight: "900",
                fontSize: 8.5,
                lineHeight: 11,
                marginTop: 3,
                textAlign: "center",
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.80}
            >
              {item.label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
function MobileQuickAccess({
  onProducts,
  onCustomers,
  onExpenses,
  onReports,
  onStores,
  onCredit,
}: {
  onProducts: () => void;
  onCustomers: () => void;
  onExpenses: () => void;
  onReports: () => void;
  onStores: () => void;
  onCredit: () => void;
}) {
 const uiText = useCommonText();
  const primaryItems = [
    {
      key: "products",
      label: uiText("Products"),
      icon: "cube-outline" as const,
      color: "#2563EB",
      softColor: "#EFF6FF",
      borderColor: "rgba(37,99,235,0.12)",
      shadowColor: "#3B82F6",
      onPress: onProducts,
    },
    {
      key: "customers",
      label: "CRM",
      icon: "people-outline" as const,
      color: "#059669",
      softColor: "#ECFDF5",
      borderColor: "rgba(5,150,105,0.14)",
      shadowColor: "#10B981",
      onPress: onCustomers,
    },
    {
      key: "expenses",
      label: uiText("Expenses"),
      icon: "receipt-outline" as const,
      color: "#E11D48",
      softColor: "#FFF1F2",
      borderColor: "rgba(225,29,72,0.13)",
      shadowColor: "#FB7185",
      onPress: onExpenses,
    },
    {
      key: "reports",
      label: uiText("Reports"),
      icon: "bar-chart-outline" as const,
      color: "#D97706",
      softColor: "#FFFBEB",
      borderColor: "rgba(217,119,6,0.15)",
      shadowColor: "#F59E0B",
      onPress: onReports,
    },
  ];

  const secondaryItems = [
    {
      key: "stores",
      label: uiText("Stores"),
      icon: "storefront-outline" as const,
      onPress: onStores,
    },
    {
      key: "credit",
      label: uiText("Credit"),
      icon: "card-outline" as const,
      onPress: onCredit,
    },
  ];

  return (
    <View
      style={{
        marginTop: 5,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: "rgba(148,163,184,0.14)",
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 9,
        paddingVertical: 6,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginBottom: 4,
        }}
      >
        <Text
          style={{
            flex: 1,
            color: "#0F172A",
            fontWeight: "900",
            fontSize: 12,
          }}
        >
          {uiText("Quick Access")}</Text>

        <View style={{ flexDirection: "row", gap: 5 }}>
          {secondaryItems.map((item) => (
            <Pressable
              key={item.key}
              onPress={item.onPress}
              hitSlop={5}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                gap: 3,
                paddingHorizontal: 5,
                paddingVertical: 3,
                borderRadius: 999,
                backgroundColor: pressed
                  ? "#E2E8F0"
                  : "#F1F5F9",
                opacity: pressed ? 0.88 : 1,
                transform: [
                  { scale: pressed ? 0.97 : 1 },
                ],
              })}
            >
              <SafeIcon
                name={item.icon}
                size={10}
                color="#64748B"
              />

              <Text
                style={{
                  color: "#64748B",
                  fontWeight: "900",
                  fontSize: 8,
                }}
              >
                {item.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        {primaryItems.map((item) => (
          <Pressable
            key={item.key}
            onPress={item.onPress}
            hitSlop={5}
            style={({ pressed }) => ({
              width: "24%",
              alignItems: "center",
              opacity: pressed ? 0.84 : 1,
              transform: [
                { scale: pressed ? 0.97 : 1 },
              ],
            })}
          >
            <View
              style={{
                width: 32,
                height: 32,
                borderRadius: 10,
                borderWidth: 1,
                borderColor: item.borderColor,
                backgroundColor: item.softColor,
                alignItems: "center",
                justifyContent: "center",
                shadowColor: item.shadowColor,
                shadowOpacity: 0.10,
                shadowRadius: 4,
                shadowOffset: { width: 0, height: 2 },
                elevation: 1,
              }}
            >
              <SafeIcon
                name={item.icon}
                size={14}
                color={item.color}
              />
            </View>

            <Text
              style={{
                color: "#334155",
                fontWeight: "900",
                fontSize: 9,
                lineHeight: 12,
                marginTop: 3,
                textAlign: "center",
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
              minimumFontScale={0.82}
            >
              {item.label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
function ZetraAiCard({ onOpen }: { onOpen: () => void }) {
 const uiText = useCommonText();
  const { width } = useWindowDimensions();
  const isDesktopWeb = isDesktopWebEnv(width);
  const isMobileWeb = isMobileWebEnv(width);
  const isNarrowAi = width < 360;

  const tips = useMemo(
    () => [
      "Stock alert: cheki bidhaa zilizo chini ya kiwango.",
      "Sales insight: kuongeza bei kidogo kwa bidhaa hot inaweza kuongeza faida.",
      "Staff ops: weka staff kwenye store husika kwa urahisi.",
      "Club: boresha post zako + response kwa customers kwa haraka.",
    ],
    []
  );

  const [i, setI] = useState(0);
  const fade = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (Platform.OS === "web") return;

    let alive = true;
    let interval: any = null;

    const start = () => {
      if (!alive) return;
      if (interval) clearInterval(interval);
      interval = setInterval(() => {
        if (!alive) return;
        setI((x) => (x + 1) % tips.length);
      }, 4500);
    };

    const stop = () => {
      if (interval) clearInterval(interval);
      interval = null;
    };

    const sub = AppState.addEventListener("change", (state) => {
      if (!alive) return;
      if (state === "active") start();
      else stop();
    });

    start();

    return () => {
      alive = false;
      stop();
      try {
        // @ts-ignore
        sub?.remove?.();
      } catch {}
    };
  }, [isDesktopWeb, tips.length]);

  useEffect(() => {
    if (Platform.OS === "web") {
      fade.setValue(1);
      return;
    }

    fade.setValue(0);
    Animated.timing(fade, { toValue: 1, duration: 260, useNativeDriver: true }).start();
  }, [fade, i, isDesktopWeb]);

  const preview = tips[i];

  const CtaButton = ({
    title,
    kind,
    onPress,
  }: {
    title: string;
    kind: "primary" | "ghost";
    onPress: () => void;
  }) => {
    const primary = kind === "primary";

    return (
      <Pressable
        onPress={onPress}
        hitSlop={10}
        style={({ pressed }) => ({
          flex: 1,
          height: 42,
          borderRadius: 999,
          borderWidth: 1,
          borderColor: primary ? "rgba(79,140,255,0.34)" : "rgba(255,255,255,0.12)",
          backgroundColor: primary ? "rgba(79,140,255,0.14)" : "rgba(255,255,255,0.06)",
          alignItems: "center",
          justifyContent: "center",
          opacity: pressed ? 0.92 : 1,
          transform: pressed ? [{ scale: 0.995 }] : [{ scale: 1 }],
        })}
      >
        <Text style={{ color: UI.text, fontWeight: "900" }}>{title}</Text>
      </Pressable>
    );
  };

  return (
    <View style={{ paddingTop: 5 }}>
      <Pressable
        onPress={onOpen}
        hitSlop={8}
        style={({ pressed }) => ({
          minHeight: 78,
          borderRadius: 19,
          paddingHorizontal: 12,
          paddingVertical: 10,
          flexDirection: "row",
          alignItems: "center",
          gap: isNarrowAi ? 7 : 10,
          backgroundColor: "#0F766E",
          borderWidth: 1,
          borderColor: "rgba(167,243,208,0.30)",
          shadowColor: "#0F766E",
          shadowOpacity: 0.18,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: 6 },
          elevation: 4,
          opacity: pressed ? 0.96 : 1,
          transform: [
            { scale: pressed ? 0.992 : 1 },
          ],
        })}
      >
        <View
          style={{
            width: isNarrowAi ? 40 : 46,
            height: isNarrowAi ? 40 : 46,
            borderRadius: isNarrowAi ? 12 : 14,
            backgroundColor: "rgba(255,255,255,0.13)",
            borderWidth: 1,
            borderColor: "rgba(209,250,229,0.30)",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text
            style={{
              color: "#FFFFFF",
              fontWeight: "900",
              fontSize: 14,
            }}
          >
            AI
          </Text>
        </View>

        <View style={{ flex: 1, minWidth: 0 }}>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 5,
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                fontWeight: "900",
                fontSize: 14,
              }}
              numberOfLines={1}
            >
              ZETRA AI
            </Text>

            <View
              style={{
                paddingHorizontal: 7,
                paddingVertical: 2,
                borderRadius: 999,
                backgroundColor: "rgba(209,250,229,0.15)",
                borderWidth: 1,
                borderColor: "rgba(209,250,229,0.18)",
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
              }}
            >
              <View
                style={{
                  width: 5,
                  height: 5,
                  borderRadius: 999,
                  backgroundColor: "#A7F3D0",
                }}
              />

              <Text
                style={{
                  color: "#D1FAE5",
                  fontWeight: "900",
                  fontSize: 8,
                  letterSpacing: 0.35,
                }}
              >
                {isNarrowAi ? uiText("LIVE") : uiText("LIVE MONITORING")}
              </Text>
            </View>
          </View>

          <Animated.Text
            style={{
              opacity: fade,
              color: "rgba(255,255,255,0.86)",
              fontWeight: "700",
              fontSize: 10,
              lineHeight: 14,
              marginTop: 4,
            }}
            numberOfLines={2}
          >
            {preview}
          </Animated.Text>
        </View>

        <View
          style={{
            paddingHorizontal: 10,
            height: 32,
            borderRadius: 999,
            backgroundColor: "#FFFFFF",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "row",
            gap: 4,
            shadowColor: "#052E2B",
            shadowOpacity: 0.10,
            shadowRadius: 4,
            shadowOffset: { width: 0, height: 2 },
            elevation: 1,
          }}
        >
          <Text
            style={{
              color: "#0F766E",
              fontWeight: "900",
              fontSize: 10,
            }}
          >
            {uiText("Ask AI")}</Text>

          <SafeIcon
            name="arrow-forward"
            size={12}
            color="#0F766E"
          />
        </View>
      </Pressable>
    </View>
  );
}

function CashierQuickHome() {
 const systemText = useSystemMessageText();
 const uiText = useCommonText();
  const router = useRouter();
  const { refreshing, refresh, activeOrgName, activeRole, activeStoreName } = useOrg();

  const [handoffCount, setHandoffCount] = useState<number>(0);
  const [handoffLoading, setHandoffLoading] = useState(false);
  const [handoffError, setHandoffError] = useState<string | null>(null);

  const loadCashierQueue = useCallback(async () => {
    setHandoffLoading(true);
    setHandoffError(null);

    try {
      const { data, error } = await supabase.rpc("get_my_cashier_handoffs_v2", {
        p_status: "PENDING",
      } as any);

      if (error) throw error;

      const rows = Array.isArray(data) ? data : [];
      setHandoffCount(rows.length);
    } catch (e: any) {
      setHandoffCount(0);
      setHandoffError(e?.message ?? "Failed to load cashier queue");
    } finally {
      setHandoffLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadCashierQueue();
  }, [loadCashierQueue]);

  useAutoRefresh(() => {
    void loadCashierQueue();
  }, true, AUTO_REFRESH_MS);

  const onRefreshAll = useCallback(async () => {
    await refresh();
    await loadCashierQueue();
  }, [refresh, loadCashierQueue]);

  return (
    <Card style={{ gap: 12, marginTop: 14 }}>
      <Text style={{ color: UI.muted, fontWeight: "800" }}>
        {uiText("Cashier Workspace (depends on active org/workspace)")}</Text>

      <Text style={{ color: UI.faint, fontWeight: "800" }}>
        {uiText("Organization:")}<Text style={{ color: UI.text, fontWeight: "900" }}>{activeOrgName ?? uiText("ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â")}</Text>
      </Text>

      <Text style={{ color: UI.faint, fontWeight: "800" }}>
        {uiText("Role:")}<Text style={{ color: UI.text, fontWeight: "900" }}>{activeRole ?? uiText("ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â")}</Text>
      </Text>

      <Text style={{ color: UI.faint, fontWeight: "800" }}>
        {uiText("Active Store:")}<Text style={{ color: UI.text, fontWeight: "900" }}>{activeStoreName ?? uiText("ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â")}</Text>
      </Text>

      {!!handoffError && (
        <Card
          style={{
            borderColor: "rgba(201,74,74,0.35)",
            backgroundColor: "rgba(201,74,74,0.10)",
            borderRadius: 18,
            padding: 12,
          }}
        >
          <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(handoffError)}</Text>
        </Card>
      )}

      <Card
        style={{
          borderColor: UI.emeraldBorder,
          backgroundColor: UI.emeraldSoft,
          gap: 8,
        }}
      >
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 16 }}>
          {uiText("Pending Cashier Orders")}</Text>

        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 28 }}>
          {handoffLoading ? "..." : String(handoffCount)}
        </Text>

        <Text style={{ color: UI.muted, fontWeight: "800" }}>
          {uiText("Hizi ni order zilizotumwa kwenye cashier queue yako.")}</Text>
      </Card>

      <Pressable
        onPress={onRefreshAll}
        disabled={refreshing || handoffLoading}
        style={({ pressed }) => ({
          borderRadius: 18,
          borderWidth: 1,
          borderColor: UI.primaryBorder,
          backgroundColor: UI.primarySoft,
          paddingVertical: 15,
          paddingHorizontal: 16,
          alignItems: "center",
          justifyContent: "center",
          opacity: pressed || refreshing || handoffLoading ? 0.92 : 1,
        })}
      >
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 15 }}>
          {refreshing || handoffLoading ? uiText("Refreshing...") : uiText("Refresh Workspace")}
        </Text>
      </Pressable>

      <Pressable
        onPress={() => router.push("/(tabs)/sales")}
        style={({ pressed }) => ({
          borderRadius: 18,
          borderWidth: 1,
          borderColor: UI.primaryBorder,
          backgroundColor: UI.primarySoft,
          paddingVertical: 15,
          paddingHorizontal: 16,
          alignItems: "center",
          justifyContent: "center",
          opacity: pressed ? 0.92 : 1,
        })}
      >
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 15 }}>{uiText("Open Sales")}</Text>
      </Pressable>
    </Card>
  );
}

function WorkspaceCard({
  activeOrgName,
  activeRole,
  activeStoreName,
  activeStoreId,
  onOpen,
}: {
  activeOrgName?: string | null;
  activeRole?: string | null;
  activeStoreName?: string | null;
  activeStoreId?: string | null;
  onOpen: () => void;
}) {
 const uiText=useCommonText();
  const { width } = useWindowDimensions();
  const isMobileWeb = isMobileWebEnv(width);
  const roleLabel = String(activeRole ?? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â").trim() || "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â";
  const orgLabel = String(activeOrgName ?? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â").trim() || "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â";
  const storeLabel = String(activeStoreName ?? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â").trim() || "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â";

  return (
    <View style={{ marginTop: 14 }}>
      <View
        style={{
          gap: 10,
          borderRadius: 22,
          borderWidth: 1,
          borderColor: HOME_PALETTE.workspace.border,
          backgroundColor: HOME_PALETTE.workspace.bg,
          overflow: "hidden",
          padding: 14,
        }}
      >
        {!isMobileWeb ? (
          <View
            pointerEvents="none"
            style={{
              position: "absolute",
              top: -52,
              right: -42,
              width: 140,
              height: 140,
              borderRadius: 999,
              backgroundColor: "transparent",
            }}
          />
        ) : null}

        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <View
            style={{
              width: 42,
              height: 38,
              borderRadius: 14,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: "rgba(79,140,255,0.28)",
              backgroundColor: HOME_PALETTE.workspace.soft,
            }}
          >
            <SafeIcon name="business-outline" size={18} color={UI.primary} />
          </View>

          <View style={{ flex: 1, minWidth: 0 }}>
            <Text
              style={{
                color: HOME_CARD_FAINT,
                fontWeight: "900",
                fontSize: 10,
                letterSpacing: 0.8,
              }}
            >
              {uiText("CURRENT WORKSPACE")}</Text>

            <Text
              style={{ color: HOME_CARD_TEXT, fontWeight: "900", fontSize: 17, marginTop: 2 }}
              numberOfLines={1}
            >
              {(String((activeOrgName ?? "—")).trim() || "—")}
            </Text>
          </View>

          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(79,140,255,0.26)",
              backgroundColor: "rgba(79,140,255,0.10)",
            }}
          >
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 10 }}>
              {roleLabel.toUpperCase()}
            </Text>
          </View>
        </View>

        <HomeCardToneContext.Provider
          value={{ text: HOME_CARD_TEXT, muted: HOME_CARD_MUTED, faint: HOME_CARD_FAINT }}
        >
        <View style={{ flexDirection: "row", gap: 10 }}>
          <MiniStat label={uiText("Organization")} value={orgLabel} />
          <MiniStat label={uiText("Role")} value={roleLabel} />
          <MiniStat
            label={uiText("Active Store")}
            value={storeLabel}
            hint={activeStoreId ? uiText("live context") : uiText("not selected")}
          />
        </View>

        </HomeCardToneContext.Provider>

        {!activeStoreId ? (
          <Text style={{ color: UI.muted, fontWeight: "800" }}>
            {uiText("Hujachagua active store bado. Fungua workspace switcher uchague context sahihi ya kazi.")}</Text>
        ) : null}

        <Pressable
          onPress={onOpen}
          hitSlop={10}
          style={({ pressed }) => ({
            borderRadius: 16,
            borderWidth: 1,
            borderColor: "rgba(79,140,255,0.32)",
            backgroundColor: HOME_PALETTE.workspace.soft,
            paddingVertical: 13,
            paddingHorizontal: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            opacity: pressed ? 0.92 : 1,
          })}
        >
          <SafeIcon name="swap-horizontal" size={17} color={UI.text} />
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 14 }}>
            {uiText("Switch Org / Workspace")}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function WebSafeHomeActions({
  onOpenAI,
  onOpenOrgSwitcher,
  onOpenFinance,
  onOpenLive,
  onOpenStock,
  onOpenBusinessPosition,
  onOpenBusinessDebts,
  onOpenIncomingStock,
  width,
}: {
  onOpenAI: () => void;
  onOpenOrgSwitcher: () => void;
  onOpenFinance: () => void;
  onOpenLive: () => void;
  onOpenStock: () => void;
  onOpenBusinessPosition: () => void;
  onOpenBusinessDebts: () => void;
  onOpenIncomingStock: () => void;
  width: number;
}) {
 const uiText = useCommonText();
  const isWide = width >= 1100;
  const buttonWidth = isWide ? "48.8%" : "100%";

  const ActionButton = ({
    label,
    sublabel,
    onPress,
  }: {
    label: string;
    sublabel: string;
    onPress: () => void;
  }) => (
    <Pressable
      onPress={onPress}
      hitSlop={10}
      style={({ pressed }) => ({
        width: buttonWidth as any,
        minHeight: 92,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: "rgba(255,255,255,0.28)",
        backgroundColor: "rgba(255,255,255,0.16)",
        paddingVertical: 16,
        paddingHorizontal: 16,
        justifyContent: "center",
        opacity: pressed ? 0.92 : 1,
      })}
    >
      <Text style={{ color: "#071427", fontWeight: "900", fontSize: 17 }}>
        {label}
      </Text>
      <Text
        style={{
          color: "#FFFFFF",
          fontWeight: "900",
          fontSize: 12,
          marginTop: 6,
          lineHeight: 18,
        }}
        numberOfLines={2}
      >
        {sublabel}
      </Text>
    </Pressable>
  );

  return (
    <View style={{ paddingTop: 14 }}>
      <View
        style={{
          gap: 16,
          borderRadius: 24,
          borderWidth: 1,
          borderColor: DESKTOP_PANEL_BORDER,
          backgroundColor: DESKTOP_PANEL_BG,
          padding: 18,
          overflow: "hidden",
        }}
      >
        <View style={{ gap: 6 }}>
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 22 }}>
            {uiText("Quick Actions")}</Text>
          <Text
            style={{
              color: "#FFFFFF",
              fontWeight: "900",
              lineHeight: 22,
              fontSize: 13,
            }}
          >
            {uiText("Hatua za haraka za kila siku kwa desktop workflow.")}</Text>
        </View>

        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
            gap: 12,
          }}
        >
          <ActionButton label={uiText("Open AI")} sublabel="Assistant, ideas, and business guidance" onPress={onOpenAI} />
          <ActionButton label={uiText("Switch Org / Workspace")} sublabel="Badili organization au active context" onPress={onOpenOrgSwitcher} />
          <ActionButton label={uiText("Open Finance")} sublabel="Sales, expenses, and finance history" onPress={onOpenFinance} />
          <ActionButton label={uiText("Open Live")} sublabel="Real-time sales and money movement" onPress={onOpenLive} />
          <ActionButton label={uiText("Stock History")} sublabel="Inventory value and stock movement" onPress={onOpenStock} />
          <ActionButton label={uiText("Business Position")} sublabel="Loans, issued money, and business position" onPress={onOpenBusinessPosition} />
          <ActionButton label={uiText("Business Debts")} sublabel="Supplier, bank debts, and stock comparison" onPress={onOpenBusinessDebts} />
          <ActionButton label={uiText("Incoming Stock")} sublabel="Supplier orders and goods in transit" onPress={onOpenIncomingStock} />
        </View>
      </View>
    </View>
  );
}

function DesktopKpiStrip({
  sales,
  expenses,
  profit,
  orders,
  moneyIn,
  stockValue,
  isOwner,
  onOpenSales,
  onOpenExpenses,
  onOpenFinance,
  onOpenStock,
}: {
  sales: string;
  expenses: string;
  profit: string;
  orders: string;
  moneyIn: string;
  stockValue: string;
  isOwner: boolean;
  onOpenSales: () => void;
  onOpenExpenses: () => void;
  onOpenFinance: () => void;
  onOpenStock: () => void;
}) {
 const uiText=useCommonText();
  const Item = ({
    label,
    value,
    hint,
    onPress,
  }: {
    label: string;
    value: string;
    hint?: string;
    onPress?: () => void;
  }) => {
    return (
      <Pressable
        onPress={onPress}
        disabled={!onPress}
        hitSlop={10}
        style={({ pressed }) => ({
          flex: 1,
          minWidth: 160,
          gap: 6,
          borderRadius: 20,
          borderWidth: 1,
          borderColor: DESKTOP_PANEL_BORDER,
          backgroundColor: DESKTOP_PANEL_BG,
          padding: 14,
          opacity: pressed ? 0.95 : 1,
          transform: pressed ? [{ scale: 0.995 }] : [{ scale: 1 }],
        })}
      >
        <Text
          style={{
            color: DESKTOP_PANEL_MUTED,
            fontWeight: "800",
            fontSize: 12,
          }}
          numberOfLines={1}
        >
          {label}
        </Text>

        <Text
          style={{
            color: DESKTOP_PANEL_TEXT,
            fontWeight: "900",
            fontSize: 22,
          }}
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.62}
        >
          {value}
        </Text>

        {!!hint && (
          <Text
            style={{
              color: DESKTOP_PANEL_FAINT,
              fontWeight: "800",
              fontSize: 11,
            }}
            numberOfLines={1}
          >
            {hint}
          </Text>
        )}

        {!!onPress ? (
          <View
            style={{
              marginTop: 6,
              alignSelf: "flex-start",
              paddingHorizontal: 10,
              paddingVertical: 5,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(79,140,255,0.28)",
              backgroundColor: "rgba(79,140,255,0.10)",
            }}
          >
            <Text
              style={{
                color: DESKTOP_PANEL_TEXT,
                fontWeight: "900",
                fontSize: 10,
              }}
            >
              {uiText("OPEN")}</Text>
          </View>
        ) : null}
      </Pressable>
    );
  };

  return (
    <View
      style={{
        flexDirection: "row",
        flexWrap: "wrap",
        gap: 12,
        marginTop: 14,
      }}
    >
      <Item
        label={uiText("Sales Today")}
        value={sales}
        hint={uiText("store performance")}
        onPress={onOpenSales}
      />

      <Item
        label={uiText("Expenses")}
        value={expenses}
        hint={uiText("today")}
        onPress={onOpenExpenses}
      />

      <Item
        label={uiText("Orders")}
        value={orders}
        hint={uiText("completed")}
        onPress={onOpenSales}
      />

      <Item
        label={uiText("Money In")}
        value={moneyIn}
        hint={uiText("after expenses")}
        onPress={onOpenFinance}
      />

      <Item
        label={uiText("Stock Value")}
        value={stockValue}
        hint={uiText("on hand")}
        onPress={onOpenStock}
      />

      <Item
        label={uiText("Net Profit")}
        value={profit}
        hint={isOwner ? uiText("owner view") : uiText("owner-only")}
        onPress={onOpenFinance}
      />
    </View>
  );
}
function DesktopDashboardChart({
  sales,
  expenses,
  moneyIn,
  stockValue,
  profit,
  loading,
  formatValue,
}: {
  sales: number;
  expenses: number;
  moneyIn: number;
  stockValue: number;
  profit: number;
  loading: boolean;
  formatValue: (n: number) => string;
}) {
 const uiText = useCommonText();
const items = [
  {
    label: uiText("Sales"),
    value: sales,
    color: "rgba(16,185,129,0.95)",
    soft: "rgba(16,185,129,0.18)",
  },
  {
    label: uiText("Expenses"),
    value: expenses,
    color: "rgba(245,158,11,0.95)",
    soft: "rgba(245,158,11,0.18)",
  },
  {
    label: uiText("Money In"),
    value: moneyIn,
    color: "rgba(59,130,246,0.95)",
    soft: "rgba(59,130,246,0.18)",
  },
  {
    label: uiText("Stock"),
    value: stockValue,
    color: "rgba(255,255,255,0.95)",
    soft: "rgba(255,255,255,0.16)",
  },
  {
    label: uiText("Profit"),
    value: profit,
    color:
      profit < 0
        ? "rgba(239,68,68,0.98)"
        : "rgba(16,185,129,0.98)",
    soft:
      profit < 0
        ? "rgba(239,68,68,0.22)"
        : "rgba(16,185,129,0.20)",
  },
];

  const max = Math.max(1, ...items.map((x) => Math.abs(toNum(x.value))));
  const netAfterExpenses = sales - expenses;
  const insightText =
    netAfterExpenses >= 0
      ? `Business iko positive leo: sales zimezidi expenses kwa ${formatValue(netAfterExpenses)}.`
      : `Tahadhari: expenses zimezidi sales kwa ${formatValue(Math.abs(netAfterExpenses))}.`;

  return (
    <View
      style={{
        marginTop: 14,
        gap: 14,
        borderRadius: 22,
        borderWidth: 1,
        borderColor: DESKTOP_PANEL_BORDER,
        backgroundColor: DESKTOP_PANEL_BG,
        padding: 16,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Text style={{ color: DESKTOP_PANEL_TEXT, fontWeight: "900", fontSize: 20, flex: 1 }}>
          {uiText("Today Performance Chart")}</Text>

        <Text style={{ color: DESKTOP_PANEL_FAINT, fontWeight: "900", fontSize: 11 }}>
          {loading ? uiText("LOADING...") : uiText("LIVE")}
        </Text>
      </View>

      <View style={{ gap: 12 }}>
        {items.map((item) => {
          const pct = Math.max(4, Math.min(100, (Math.abs(toNum(item.value)) / max) * 100));

          return (
            <View key={item.label} style={{ gap: 6 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <Text
                  style={{
                    color: "rgba(255,255,255,0.92)",
                    fontWeight: "900",
                    width: 82,
                    fontSize: 12,
                  }}
                >
                  {item.label}
                </Text>

                <View
                  style={{
                    flex: 1,
                    height: 12,
                    borderRadius: 999,
                    backgroundColor: item.soft,
                    overflow: "hidden",
                  }}
                >
                  <View
                    style={{
                      width: `${pct}%`,
                      height: "100%",
                      borderRadius: 999,
                      backgroundColor: item.color,
                    }}
                  />
                </View>

                <Text
                  style={{
                    color: DESKTOP_PANEL_TEXT,
                    fontWeight: "900",
                    width: 138,
                    textAlign: "right",
                    fontSize: 12,
                  }}
                  numberOfLines={1}
                  adjustsFontSizeToFit
                  minimumFontScale={0.72}
                >
                  {formatValue(item.value)}
                </Text>
              </View>
            </View>
          );
        })}
      </View>

      <View
        style={{
          borderRadius: 18,
          borderWidth: 1,
       borderColor:
  netAfterExpenses < 0
    ? "rgba(239,68,68,0.42)"
    : "rgba(16,185,129,0.34)",

backgroundColor:
  netAfterExpenses < 0
    ? "rgba(239,68,68,0.18)"
    : "rgba(16,185,129,0.14)",
          padding: 12,
          gap: 4,
        }}
      >
      <Text
  style={{
    color:
      netAfterExpenses < 0
        ? "#FCA5A5"
        : "#A7F3D0",
    fontWeight: "900",
    fontSize: 13,
    letterSpacing: 0.3,
  }}
>
  {netAfterExpenses < 0 ? uiText("ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  RISK WARNING") : uiText("SMART READING")}
</Text>
        <Text style={{ color: DESKTOP_PANEL_MUTED, fontWeight: "800", lineHeight: 20 }}>
          {(netAfterExpenses >= 0 ? uiText("Business iko positive leo: sales zimezidi expenses kwa {p0}.", {p0: (formatValue(netAfterExpenses))}) : uiText("Tahadhari: expenses zimezidi sales kwa {p0}.", {p0: (formatValue(Math.abs(netAfterExpenses)))}))}
        </Text>
      </View>
    </View>
  );
}
function DesktopBusinessHealthCard({
  sales,
  expenses,
  moneyIn,
  stockValue,
  profit,
  isOwner,
  formatValue,
}: {
  sales: number;
  expenses: number;
  moneyIn: number;
  stockValue: number;
  profit: number;
  isOwner: boolean;
  formatValue: (n: number) => string;
}) {
 const uiText=useCommonText();
  const net = sales - expenses;

  const health = net < 0 ? "RISK" : net >= sales * 0.4 ? "HEALTHY" : "WATCH";

  const bg =
    health === "RISK" ? "#7F1D1D" : health === "WATCH" ? "#92400E" : "#0F766E";

  const border =
    health === "RISK"
      ? "rgba(248,113,113,0.70)"
      : health === "WATCH"
      ? "rgba(251,191,36,0.60)"
      : "rgba(52,211,153,0.60)";

  const actionText =
    health === "RISK"
      ? "Expenses zimezidi nguvu ya mauzo. Chukua hatua haraka kuongeza sales na kudhibiti matumizi."
      : health === "WATCH"
      ? "Biashara ipo kwenye tahadhari. Angalia matumizi, stock movement, na kuongeza mauzo."
      : "Business inaenda vizuri. Endelea kuongeza sales momentum na kulinda profit.";

  return (
    <HomeCardToneContext.Provider
      value={{ text: "#FFFFFF", muted: "rgba(255,255,255,0.88)", faint: "rgba(255,255,255,0.74)" }}
    >
      <View
        style={{
          marginTop: 14,
          gap: 14,
          borderRadius: 24,
          borderWidth: 1,
          borderColor: border,
          backgroundColor: bg,
          padding: 18,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 24, flex: 1 }}>
            {uiText("Business Health")}</Text>

          <View
            style={{
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.45)",
              backgroundColor: health === "RISK" ? "#EF4444" : "rgba(255,255,255,0.18)",
            }}
          >
            <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 12 }}>
              {uiText(health)}
            </Text>
          </View>
        </View>

        <View style={{ flexDirection: "row", gap: 12 }}>
          <MiniStat label={uiText("Sales")} value={formatValue(sales)} hint={uiText("today")} />
          <MiniStat label={uiText("Expenses")} value={formatValue(expenses)} hint={uiText("today")} />
          <MiniStat label={uiText("Money In")} value={formatValue(moneyIn)} hint={uiText("after expense")} />
        </View>

        <View style={{ flexDirection: "row", gap: 12 }}>
          <MiniStat label={uiText("Stock")} value={formatValue(stockValue)} hint={uiText("on hand")} multilineValue />
          <MiniStat
            label={uiText("Net Position")}
            value={net >= 0 ? `+ ${formatValue(net)}` : `- ${formatValue(Math.abs(net))}`}
            hint={net >= 0 ? uiText("positive") : uiText("negative")}
            multilineValue
          />
          <MiniStat
            label={uiText("Profit")}
            value={isOwner ? formatValue(profit) : uiText("OWNER")}
            hint={isOwner ? uiText("owner view") : uiText("restricted")}
            multilineValue
          />
        </View>

        <View
          style={{
            borderRadius: 18,
            borderWidth: 1,
            borderColor: "rgba(255,255,255,0.22)",
            backgroundColor: "rgba(255,255,255,0.15)",
            padding: 14,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 13, marginBottom: 6 }}>
            {uiText("NEXT ACTION")}</Text>
          <Text style={{ color: "#FFFFFF", fontWeight: "900", lineHeight: 22 }}>
            {(health === "RISK" ? uiText("Expenses zimezidi nguvu ya mauzo. Chukua hatua haraka kuongeza sales na kudhibiti matumizi.") : (health === "WATCH" ? uiText("Biashara ipo kwenye tahadhari. Angalia matumizi, stock movement, na kuongeza mauzo.") : uiText("Business inaenda vizuri. Endelea kuongeza sales momentum na kulinda profit.")))}
          </Text>
        </View>
      </View>
    </HomeCardToneContext.Provider>
  );
}
function DesktopCommandFocusCard({
  sales,
  expenses,
  moneyIn,
  stockValue,
  profit,
  formatValue,
  onOpenSales,
  onOpenExpenses,
  onOpenFinance,
  onOpenStock,
}: {
  sales: number;
  expenses: number;
  moneyIn: number;
  stockValue: number;
  profit: number;
  formatValue: (n: number) => string;
  onOpenSales: () => void;
  onOpenExpenses: () => void;
  onOpenFinance: () => void;
  onOpenStock: () => void;
}) {
 const uiText = useCommonText();
  const net = sales - expenses;
  const isRisk = net < 0;
  const isNoSales = sales <= 0;
  const stockPressure = stockValue > 0 && sales <= 0;

  const actions = [
    {
      title: isNoSales ? uiText("Push Sales Now") : uiText("Review Sales"),
      body: isNoSales
        ? "Hakuna mauzo yaliyoingia leo. Fungua sales history uangalie mwenendo na chukua hatua ya mauzo."
        : "Mauzo yameanza kuingia. Angalia sales history kuthibitisha bidhaa zinazotembea.",
      onPress: onOpenSales,
    },
    {
      title: isRisk ? uiText("Control Expenses") : uiText("Review Expenses"),
      body: isRisk
        ? "Expenses zimezidi sales. Kagua matumizi ya leo na punguza gharama zisizo za lazima."
        : "Angalia expenses kuhakikisha matumizi yanaendana na mauzo.",
      onPress: onOpenExpenses,
    },
    {
      title: uiText("Check Money In"),
      body: `Money In ya sasa ni ${formatValue(moneyIn)}. Hakikisha cash/bank/mobile zinalingana na taarifa.`,
      onPress: onOpenFinance,
    },
    {
      title: stockPressure ? uiText("Convert Stock to Sales") : uiText("Check Stock Value"),
      body: stockPressure
        ? `Stock value ipo ${formatValue(stockValue)} lakini sales ni ndogo. Sukuma bidhaa zenye mzunguko wa haraka.`
        : "Angalia stock value na movement ili kujua bidhaa zinazosimama au zinazotembea.",
      onPress: onOpenStock,
    },
  ];

  return (
    <View
      style={{
        marginTop: 14,
        gap: 14,
        borderRadius: 24,
        borderWidth: 1,
        borderColor: isRisk ? "rgba(248,113,113,0.55)" : "rgba(59,130,246,0.34)",
        backgroundColor: isRisk ? "#7F1D1D" : "#1E3A8A",
        padding: 18,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 22, flex: 1 }}>
          {uiText("Command Focus")}</Text>

        <View
          style={{
            paddingHorizontal: 12,
            paddingVertical: 7,
            borderRadius: 999,
            borderWidth: 1,
            borderColor: "rgba(255,255,255,0.34)",
            backgroundColor: isRisk ? "#EF4444" : "rgba(255,255,255,0.16)",
          }}
        >
          <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 11 }}>
            {isRisk ? uiText("URGENT") : uiText("TODAY")}
          </Text>
        </View>
      </View>

      <Text style={{ color: "rgba(255,255,255,0.88)", fontWeight: "900", lineHeight: 22 }}>
        {isRisk
          ? uiText("Dashboard inaonyesha tahadhari. Kipaumbele ni kuongeza mauzo, kudhibiti expenses, na kugeuza stock kuwa cash.")
          : uiText("Dashboard iko kwenye hali ya kufuatilia. Endelea kusukuma mauzo, stock movement, na money collection.")}
      </Text>

      <View style={{ gap: 10 }}>
        {actions.map((a) => (
          <Pressable
            key={a.title}
            onPress={a.onPress}
            hitSlop={10}
            style={({ pressed }) => ({
              borderRadius: 18,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.22)",
              backgroundColor: "rgba(255,255,255,0.14)",
              padding: 13,
              opacity: pressed ? 0.92 : 1,
            })}
          >
            <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 14 }}>
              {a.title}
            </Text>
            <Text
              style={{
                color: "rgba(255,255,255,0.86)",
                fontWeight: "800",
                lineHeight: 20,
                marginTop: 4,
              }}
            >
              {a.body}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
function DesktopSignalCard({
  title,
  body,
  badge,
  onPress,
}: {
  title: string;
  body: string;
  badge?: string;
  onPress?: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      hitSlop={10}
      style={({ pressed }) => ({
        opacity: pressed ? 0.94 : 1,
        transform: pressed ? [{ scale: 0.995 }] : [{ scale: 1 }],
      })}
    >
      <View
        style={{
          gap: 10,
          borderRadius: 20,
          borderWidth: 1,
          borderColor: DESKTOP_PANEL_BORDER,
          backgroundColor: DESKTOP_PANEL_ALT_BG,
          padding: 16,
        }}
      >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Text style={{ color: DESKTOP_PANEL_TEXT, fontWeight: "900", fontSize: 16, flex: 1 }}>{title}</Text>
        {!!badge ? (
          <View
            style={{
              paddingHorizontal: 9,
              paddingVertical: 5,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(79,140,255,0.26)",
              backgroundColor: "rgba(79,140,255,0.10)",
            }}
          >
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 11 }}>{badge}</Text>
          </View>
        ) : null}
      </View>

      <Text style={{ color: DESKTOP_PANEL_MUTED, fontWeight: "800", lineHeight: 21 }}>{body}</Text>
    </View>
    </Pressable>
  );
}

function CapitalRecoverySummaryCard({
  loading,
  error,
  summary,
  canSeeCapitalSecrets,
}: {
  loading: boolean;
  error: string | null;
  summary: CapitalRecoverySummaryRow;
  canSeeCapitalSecrets: boolean;
}) {
 const preferredMoney=usePreferredDisplayMoney();

 const systemText = useSystemMessageText();
 const uiText = useCommonText();
  const fmt = useCallback(
    (n: number) =>
      preferredMoney(n, {
        currency: "TZS",
        locale: "en-TZ",
      }).replace(/\s+/g, " "),
    [preferredMoney]
  );

  return (
    <Card
  style={{
    gap: 14,
    borderRadius: 26,
    borderColor: "rgba(147,197,253,0.55)",
    backgroundColor: "#FFFFFF",
    overflow: "hidden",
  }}
>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 20, flex: 1 }}>
          {uiText("Capital Recovery Summary")}</Text>
      </View>

      {!!error ? (
        <Card
          style={{
            borderColor: "rgba(201,74,74,0.35)",
            backgroundColor: "rgba(201,74,74,0.10)",
            borderRadius: 18,
            padding: 12,
          }}
        >
          <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(error)}</Text>
        </Card>
      ) : null}

      <View style={{ flexDirection: "row", gap: 12 }}>
        <MiniStat label={uiText("Income")} value={fmt(summary.total_income)} hint={uiText("all entries")} />
        <MiniStat label={uiText("Cost")} value={fmt(summary.total_cost)} hint={uiText("operating")} />
        {canSeeCapitalSecrets ? (
          <MiniStat label={uiText("Asset")} value={fmt(summary.total_asset)} hint={uiText("capital target")} />
        ) : null}
      </View>

      <View style={{ flexDirection: "row", gap: 12 }}>
        <MiniStat label={uiText("Remaining Cost")} value={fmt(summary.remaining_cost)} />
        {canSeeCapitalSecrets ? (
          <MiniStat label={uiText("Remaining Asset")} value={fmt(summary.remaining_asset)} />
        ) : null}
        {canSeeCapitalSecrets ? (
          <MiniStat label={uiText("Profit")} value={fmt(summary.realized_profit)} hint={uiText("after cost + asset")} />
        ) : null}
      </View>

      <View style={{ flexDirection: "row", gap: 12 }}>
        <MiniStat label={uiText("Entries")} value={String(summary.entries_count ?? 0)} />
        <MiniStat
          label={uiText("Last Entry")}
          value={summary.last_entry_at ? fmtLocal(summary.last_entry_at) : "—"}
          multilineValue
        />
      </View>
    </Card>
  );
}
function CapitalRecoveryActionHero({
  activeOrgName,
  activeStoreName,
}: {
  activeOrgName?: string | null;
  activeStoreName?: string | null;
}) {
 const uiText=useCommonText();
  return (
    <View style={{ marginTop: 14 }}>
      <Card
        style={{
          gap: 14,
          borderRadius: 24,
          borderColor: "rgba(79,140,255,0.28)",
          backgroundColor: UI.card,
          overflow: "hidden",
        }}
      >
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            top: -60,
            right: -40,
            width: 180,
            height: 180,
            borderRadius: 999,
            backgroundColor: "transparent",
          }}
        />

        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            left: -50,
            bottom: -90,
            width: 170,
            height: 170,
            borderRadius: 999,
            backgroundColor: "transparent",
          }}
        />

        <Text style={{ color: UI.faint, fontWeight: "900", fontSize: 11, letterSpacing: 0.8 }}>
          {uiText("CAPITAL RECOVERY MODE")}</Text>

        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 22 }}>
          {uiText("Recovery Command Zone")}</Text>

        <Text style={{ color: UI.muted, fontWeight: "800", lineHeight: 22 }}>
          {uiText("Hii ni mode maalum ya Capital Recovery. Focus kuu hapa ni Asset, Cost, Income, na ufuatiliaji wa kurejesha mtaji bila kuchanganya na maeneo yasiyo ya recovery.")}</Text>

        <View style={{ flexDirection: "row", gap: 12 }}>
          <MiniStat label={uiText("Organization")} value={String(activeOrgName ?? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â")} />
          <MiniStat label={uiText("Recovery Store")} value={String(activeStoreName ?? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â")} />
        </View>
      </Card>
    </View>
  );
}
function CapitalRecoveryHomeShell({
  activeOrgName,
  activeStoreName,
  activeStoreId,
  summary,
  summaryLoading,
  summaryError,
  canSeeCapitalSecrets,
}: {
  activeOrgName?: string | null;
  activeStoreName?: string | null;
  activeStoreId?: string | null;
  summary: CapitalRecoverySummaryRow;
  summaryLoading: boolean;
  summaryError: string | null;
  canSeeCapitalSecrets: boolean;
}) {
  return (
    <View style={{ marginTop: 14, gap: 14 }}>
      <CapitalRecoveryActionHero
        activeOrgName={activeOrgName}
        activeStoreName={activeStoreName}
      />

      <CapitalRecoverySummaryCard
        loading={summaryLoading}
        error={summaryError}
        summary={summary}
        canSeeCapitalSecrets={canSeeCapitalSecrets}
      />
    </View>
  );
}

function CapitalRecoveryBottomSwitcherCard({
  onOpenOrgSwitcher,
}: {
  onOpenOrgSwitcher: () => void;
}) {
 const uiText = useCommonText();
  return (
    <View style={{ marginTop: 14 }}>
     <Card
  style={{
    gap: 12,
    borderRadius: 26,
    borderColor: "rgba(20,184,166,0.35)",
    backgroundColor: "#ECFDF5",
    overflow: "hidden",
  }}
>
        <Text style={{ color: UI.text, fontWeight: "900", fontSize: 18 }}>
          {uiText("Switch Organization")}</Text>

        <Text style={{ color: UI.muted, fontWeight: "800", lineHeight: 22 }}>
          {uiText("Ukiwa bado kwenye dashboard hii unaweza kubadili organization au workspace na kuhamia biashara nyingine moja kwa moja.")}</Text>

        <Pressable
          onPress={onOpenOrgSwitcher}
          // @ts-ignore
          onClick={onOpenOrgSwitcher}
          hitSlop={10}
          style={({ pressed }) => ({
            borderRadius: 20,
            borderWidth: 1,
            borderColor: "rgba(16,185,129,0.38)",
            backgroundColor: "#D1FAE5",
            paddingVertical: 16,
            paddingHorizontal: 16,
            alignItems: "center",
            justifyContent: "center",
            opacity: pressed ? 0.92 : 1,
            transform: pressed ? [{ scale: 0.99 }] : [{ scale: 1 }],
          })}
        >
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 15 }}>
            {uiText("Switch Org / Workspace")}</Text>
        </Pressable>
      </Card>
    </View>
  );
}

function CapitalRecoveryReportsCard({
  activeStoreId,
  reloadKey = 0,
  canSeeCapitalSecrets,
}: {
  activeStoreId?: string | null;
  reloadKey?: number;
  canSeeCapitalSecrets: boolean;
}) {
 const preferredMoney=usePreferredDisplayMoney();

 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<CapitalRecoveryHistoryRow[]>([]);
 const [todayReport, setTodayReport] = useState<CapitalRecoveryTodayReport>({
  asset: 0,
  cost: 0,
  income: 0,
  net: 0,
});

  const storeId = String(activeStoreId ?? "").trim();

  const load = useCallback(async () => {
    if (!storeId) {
      setHistory([]);
      setTodayReport({
  asset: 0,
  cost: 0,
  income: 0,net: 0,
});
      setError("No active Capital Recovery store selected");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: hErr } = await supabase.rpc("get_capital_recovery_history_v2", {
        p_store_id: storeId,
        p_limit: 100,
      });

      if (hErr) throw hErr;

      const rows = (Array.isArray(data) ? data : []) as any[];

      const mappedRows: CapitalRecoveryHistoryRow[] = rows.map((r) => ({
        id: String(r?.id ?? ""),
        entry_type: String(r?.entry_type ?? "ASSET").toUpperCase() as
          | "ASSET"
          | "COST"
          | "INCOME",
        amount: toNum(r?.amount),
        note: clean(r?.note) || null,
        created_at: String(r?.created_at ?? ""),
        created_by: clean(r?.created_by) || null,
      }));

      setHistory(mappedRows);

      const today = toIsoDateLocal(new Date());

      let asset = 0;
      let cost = 0;
      let income = 0;

      for (const item of mappedRows) {
        const created = clean(item.created_at);
        if (!created) continue;

        const d = new Date(created);
        if (Number.isNaN(d.getTime())) continue;

        const itemDay = toIsoDateLocal(d);
        if (itemDay !== today) continue;

        if (item.entry_type === "ASSET") asset += toNum(item.amount);
        else if (item.entry_type === "COST") cost += toNum(item.amount);
        else if (item.entry_type === "INCOME") income += toNum(item.amount);
      }

      setTodayReport({
  asset,
  cost,
  income,
  net: income - cost,
});
    } catch (e: any) {
      setError(clean(e?.message) || "Failed to load Capital Recovery history");
      setHistory([]);
      setTodayReport({
  asset: 0,
  cost: 0,
  income: 0,
  net: 0,
});
    } finally {
      setLoading(false);
    }
  }, [storeId]);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load, reloadKey])
  );
  const fmt = useCallback(
    (n: number) =>
      preferredMoney(n, {
        currency: "TZS",
        locale: "en-TZ",
      }).replace(/\s+/g, " "),
    [preferredMoney]
  );

  const report = useMemo(() => {
    const base = {
      ASSET: { count: 0, amount: 0 },
      COST: { count: 0, amount: 0 },
      INCOME: { count: 0, amount: 0 },
    };

    for (const item of history) {
      base[item.entry_type].count += 1;
      base[item.entry_type].amount += toNum(item.amount);
    }

    return base;
  }, [history]);

  return (
    <View style={{ marginTop: 14 }}>
      <Card
        style={{
          gap: 14,
          borderRadius: 24,
          borderColor: "rgba(79,140,255,0.26)",
          backgroundColor: "rgba(255,255,255,0.055)",
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <Text style={{ color: UI.text, fontWeight: "900", fontSize: 18, flex: 1 }}>
            {uiText("Reports")}</Text>

          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: 999,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.10)",
              backgroundColor: "rgba(255,255,255,0.05)",
            }}
          >
            <Text style={{ color: UI.text, fontWeight: "900", fontSize: 11 }}>
              {loading ? "..." : history.length}
            </Text>
          </View>
        </View>

        {!!error ? (
          <Card
            style={{
              borderColor: "rgba(201,74,74,0.35)",
              backgroundColor: "rgba(201,74,74,0.10)",
              borderRadius: 18,
              padding: 12,
            }}
          >
            <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(error)}</Text>
          </Card>
        ) : null}

        <View style={{ flexDirection: "row", gap: 12 }}>
          {canSeeCapitalSecrets ? (
            <MiniStat
              label={uiText("Asset")}
              value={String(report.ASSET.count)}
              hint={fmt(report.ASSET.amount)}
            />
          ) : null}
          <MiniStat
            label={uiText("Cost")}value={String(report.COST.count)}
            hint={fmt(report.COST.amount)}
          />
          <MiniStat
  label={uiText("Income")}
  value={String(report.INCOME.count)}
  hint={fmt(report.INCOME.amount)}
/>
</View>

{/* ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â½ TODAY NET POSITION */}
<View
  style={{
    borderWidth: 1,
    borderColor:
      todayReport.income - todayReport.cost >= 0
        ? "rgba(16,185,129,0.32)"
        : "rgba(239,68,68,0.32)",
    backgroundColor:
      todayReport.income - todayReport.cost >= 0
        ? "rgba(79,140,255,0.10)"
        : "rgba(239,68,68,0.10)",
    borderRadius: 18,
    padding: 12,
    gap: 6,
  }}
>
  <Text style={{ color: UI.muted, fontWeight: "900", fontSize: 12 }}>
    {uiText("TODAY NET POSITION")}</Text>

  <Text
    style={{
      color: todayReport.income - todayReport.cost >= 0 ? UI.success : UI.danger,
      fontWeight: "900",
      fontSize: 18,
    }}
  >
    {todayReport.income - todayReport.cost >= 0
      ? `+ ${fmt(todayReport.income - todayReport.cost)}`
      : `- ${fmt(Math.abs(todayReport.income - todayReport.cost))}`}
  </Text>

  <Text style={{ color: UI.faint, fontWeight: "800", fontSize: 12 }}>
    {todayReport.income - todayReport.cost >= 0 ? uiText("Today profit") : uiText("Today loss")}
  </Text>
</View>

<View
  style={{
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
    backgroundColor: "rgba(255,255,255,0.04)",
    borderRadius: 18,
    padding: 12,
    gap: 10,
  }}
></View>
          <Text style={{ color: UI.muted, fontWeight: "900", fontSize: 12 }}>
            {uiText("TODAY REPORT")}</Text>

         <View style={{ flexDirection: "row", gap: 12 }}>
  {canSeeCapitalSecrets ? (
    <MiniStat label={uiText("Today Asset")} value={fmt(todayReport.asset)} hint={uiText("today")} />
  ) : null}
  <MiniStat label={uiText("Today Cost")} value={fmt(todayReport.cost)} hint={uiText("today")} />
  <MiniStat label={uiText("Today Income")} value={fmt(todayReport.income)} hint={uiText("today")} />
</View>

<View
  style={{
    marginTop: 10,
    borderWidth: 1,
    borderColor:
      todayReport.net < 0 ? "rgba(201,74,74,0.45)" : "rgba(16,185,129,0.35)",
    backgroundColor:
      todayReport.net < 0 ? "rgba(201,74,74,0.12)" : "rgba(79,140,255,0.10)",
    borderRadius: 16,
    padding: 12,
  }}
>
  <Text
    style={{
      color: todayReport.net < 0 ? UI.danger : UI.emerald,
      fontWeight: "900",
      fontSize: 12,
    }}
  >
    {uiText("TODAY NET POSITION")}</Text>

  <Text
    style={{
      color: todayReport.net < 0 ? UI.danger : UI.emerald,
      fontWeight: "900",
      fontSize: 20,
      marginTop: 6,
    }}
    numberOfLines={2}
    adjustsFontSizeToFit
    minimumFontScale={0.75}
  >
    {todayReport.net < 0 ? "-" : "+"}
    {fmt(Math.abs(todayReport.net))}
  </Text>

  <Text style={{ color: UI.muted, fontWeight: "800", marginTop: 4 }}>
    {todayReport.net < 0 ? uiText("Cost imezidi income ya leo") : uiText("Income imezidi cost ya leo")}
  </Text>
</View>
</Card>
    </View>
  );
}
     
     

function DesktopMasterHome({
  width,
  height,
  activeOrgName,
  activeStoreName,
  activeRole,
  organizationLogoUrl,
    financialStoreIds,
  organizationId,    salesPerformanceStoreId,
sales,
  expenses,
  moneyIn,
  profit,
  orders,
  stockValue,
  isOwner,
  loading,
  notificationUnread,
  notificationTotal,
  salesPerformanceMode,
  salesPerformanceCompare,
  salesPerformancePoints,
  salesPerformanceTotal,
  salesPerformancePreviousTotal,
  salesPerformanceLoading,
  salesPerformanceError,
  onChangeSalesPerformanceMode,
  onToggleSalesPerformanceCompare,
  formatValue,
  onOpenOrgSwitcher,
  onOpenBusinessProfile,
  onOpenNotifications,
  onOpenAI,
  onOpenSales,
  onOpenProducts,
  onOpenExpenses,
  onOpenStores,
  onOpenStock,
  onOpenCustomers,
  onOpenCredit,
  onOpenReports,
  onOpenBusinessStatement,
}: {
  width: number;
  height: number;
  activeOrgName?: string | null;
  activeStoreName?: string | null;
  activeRole?: string | null;
  organizationLogoUrl?: string | null;
    financialStoreIds: string[];
  organizationId?: string | null;
    salesPerformanceStoreId?: string | null;
sales: number;
  expenses: number;
  moneyIn: number;
  profit: number;
  orders: number;
  stockValue: number;
  isOwner: boolean;
  loading: boolean;
  notificationUnread: number;
  notificationTotal: number;

  salesPerformanceMode:
    | "Daily"
    | "Weekly"
    | "Monthly";

  salesPerformanceCompare: boolean;

  salesPerformancePoints: Array<{
    key: string;
    label: string;
    value: number;
    previousValue: number;
  }>;

  salesPerformanceTotal: number;
  salesPerformancePreviousTotal: number;
  salesPerformanceLoading: boolean;
  salesPerformanceError: string | null;

  onChangeSalesPerformanceMode: (
    mode: "Daily" | "Weekly" | "Monthly"
  ) => void;

  onToggleSalesPerformanceCompare: () => void;

  formatValue: (n: number) => string;
  onOpenOrgSwitcher: () => void;
  onOpenBusinessProfile: () => void;
  onOpenNotifications: () => void;
  onOpenAI: () => void;
  onOpenSales: () => void;
  onOpenProducts: () => void;
  onOpenExpenses: () => void;
  onOpenStores: () => void;
  onOpenStock: () => void;
  onOpenCustomers: () => void;
  onOpenCredit: () => void;
  onOpenReports: () => void;
  onOpenBusinessStatement: () => void;
}) {
 const uiText=useCommonText();
 const {language}=useLanguage();
  const desktopRouter = useRouter();

  const [desktopBusinessHour, setDesktopBusinessHour] =
    React.useState<number | null>(null);

  const loadDesktopServerTime = React.useCallback(async () => {
    try {
      const { data, error } = await supabase.rpc(
        "get_server_time_v1"
      );

      if (error) {
        console.warn(
          "Desktop server time failed:",
          error.message
        );
        return;
      }

      const row = Array.isArray(data)
        ? data[0]
        : data;

      const hour = Number(
        row?.business_hour
      );

      if (
        Number.isFinite(hour) &&
        hour >= 0 &&
        hour <= 23
      ) {
        setDesktopBusinessHour(
          Math.trunc(hour)
        );
      }
    } catch (error) {
      console.warn(
        "Desktop server time failed:",
        error
      );
    }
  }, []);

  React.useEffect(() => {
    void loadDesktopServerTime();

    const timer = setInterval(() => {
      void loadDesktopServerTime();
    }, 5 * 60 * 1000);

    return () => {
      clearInterval(timer);
    };
  }, [loadDesktopServerTime]);

  const desktopGreeting = React.useMemo(() => {
    const hour = desktopBusinessHour;

    if (hour === null) {
      return {
        text: "Welcome!",
        icon: "time-outline" as const,
        color: "#64748B",
      };
    }

    if (hour >= 5 && hour < 12) {
      return {
        text: "Good morning!",
        icon: "sunny" as const,
        color: "#FBBF24",
      };
    }

    if (hour >= 12 && hour < 17) {
      return {
        text: "Good afternoon!",
        icon: "partly-sunny" as const,
        color: "#F59E0B",
      };
    }

    if (hour >= 17 && hour < 21) {
      return {
        text: "Good evening!",
        icon: "partly-sunny-outline" as const,
        color: "#F97316",
      };
    }

    return {
      text: "Good night!",
      icon: "moon" as const,
      color: "#6366F1",
    };
  }, [desktopBusinessHour]);

  const orgLabel =
    String(activeOrgName ?? "").trim() || "Organization";

  const storeLabel =
    String(activeStoreName ?? "").trim() || "No active store";

  const roleLabel =
    String(activeRole ?? "").trim() || "User";

  // ==========================================================
  // DESKTOP GLOBAL SEARCH
  // Canonical live sources:
  // Products  -> get_products_manage / get_products
  // Customers -> customers
  // ==========================================================

  type DesktopGlobalSearchResult = {
    key: string;
    kind: "PRODUCT" | "CUSTOMER";
    id: string;
    title: string;
    subtitle: string;
    presentation?: import("@/src/i18n/presentation").SearchPresentation;
    meta?: string;
  };

  const [desktopSearchQuery, setDesktopSearchQuery] =
    useState("");

  const [desktopSearchResults, setDesktopSearchResults] =
    useState<DesktopGlobalSearchResult[]>([]);

  const [desktopSearchLoading, setDesktopSearchLoading] =
    useState(false);

  const [desktopSearchFocused, setDesktopSearchFocused] =
    useState(false);

  const desktopSearchRequestRef = useRef(0);

  useEffect(() => {
    const q = desktopSearchQuery.trim();

    if (q.length < 2) {
      desktopSearchRequestRef.current += 1;
      setDesktopSearchResults([]);
      setDesktopSearchLoading(false);
      return;
    }

    const requestId =
      ++desktopSearchRequestRef.current;

    const timer = setTimeout(() => {
      void (async () => {
        setDesktopSearchLoading(true);

        try {
          const normalizedQ =
            q.toLocaleLowerCase();

          const productRpc =
            isOwner
              ? "get_products_manage"
              : "get_products";

          const productPromise =
            organizationId &&
            salesPerformanceStoreId
              ? supabase.rpc(
                  productRpc,
                  {
                    p_org_id:
                      organizationId,
                    p_store_id:
                      salesPerformanceStoreId,
                  }
                )
              : Promise.resolve({
                  data: [],
                  error: null,
                } as any);

          const customerPromise =
            salesPerformanceStoreId
              ? supabase
                  .from("customers")
                  .select(
                    "id, full_name, phone, normalized_phone, total_orders, total_spent"
                  )
                  .eq(
                    "store_id",
                    salesPerformanceStoreId
                  )
                  .limit(200)
              : Promise.resolve({
                  data: [],
                  error: null,
                } as any);

          const [
            productResponse,
            customerResponse,
          ] = await Promise.all([
            productPromise,
            customerPromise,
          ]);

          if (
            requestId !==
            desktopSearchRequestRef.current
          ) {
            return;
          }

          const next:
            DesktopGlobalSearchResult[] = [];

          if (!productResponse?.error) {
            const products =
              Array.isArray(
                productResponse?.data
              )
                ? productResponse.data
                : [];

            products
              .filter((product: any) => {
                const haystack = [
                  product?.name,
                  product?.product_name,
                  product?.sku,
                  product?.category,
                  product?.barcode,
                ]
                  .filter(Boolean)
                  .join(" ")
                  .toLocaleLowerCase();

                return haystack.includes(
                  normalizedQ
                );
              })
              .slice(0, 6)
              .forEach((product: any) => {
                const productName =
                  String(
                    product?.name ??
                      product?.product_name ??
                      "Product"
                  ).trim();

                const sku =
                  String(
                    product?.sku ?? ""
                  ).trim();

                const category =
                  String(
                    product?.category ?? ""
                  ).trim();

                const stockCandidate =
                  product?.stock_qty ??
                  product?.qty_on_hand ??
                  product?.quantity ??
                  product?.stock ??
                  null;

                const stockNumber =
                  stockCandidate === null ||
                  stockCandidate === undefined
                    ? null
                    : Number(stockCandidate);

                const metaParts: string[] =
                  [];

                if (category) {
                  metaParts.push(category);
                }

                if (
                  stockNumber !== null &&
                  Number.isFinite(stockNumber)
                ) {
                  metaParts.push(
                    `Stock: ${stockNumber}`
                  );
                }

                const productId =
                  String(
                    product?.id ??
                      product?.product_id ??
                      ""
                  ).trim();

                next.push({
                  key: `PRODUCT:${
                    productId ||
                    `${productName}:${sku}`
                  }`,
                  kind: "PRODUCT",
                  id: productId,
                  presentation:{titleKey:product?.name==null&&product?.product_name==null?"Product":undefined,subtitleKey:sku?undefined:"Product",category,stock:Number.isFinite(stockNumber)?stockNumber:null},
                  title: productName,
                  subtitle:
                    sku
                      ? `SKU: ${sku}`
                      : uiText("Product"),
                  meta:
                    metaParts.join(" · ") ||
                    undefined,
                });
              });
          }

          if (!customerResponse?.error) {
            const customers =
              Array.isArray(
                customerResponse?.data
              )
                ? customerResponse.data
                : [];

            customers
              .filter((customer: any) => {
                const haystack = [
                  customer?.full_name,
                  customer?.phone,
                  customer?.normalized_phone,
                ]
                  .filter(Boolean)
                  .join(" ")
                  .toLocaleLowerCase();

                return haystack.includes(
                  normalizedQ
                );
              })
              .slice(0, 6)
              .forEach((customer: any) => {
                const customerId =
                  String(
                    customer?.id ?? ""
                  ).trim();

                const name =
                  String(
                    customer?.full_name ??
                      "Customer"
                  ).trim();

                const phone =
                  String(
                    customer?.phone ??
                      customer?.normalized_phone ??
                      ""
                  ).trim();

                const orders =
                  Number(
                    customer?.total_orders ?? 0
                  );

                next.push({
                  key: `CUSTOMER:${
                    customerId || name
                  }`,
                  kind: "CUSTOMER",
                  id: customerId,
                  presentation:{titleKey:customer?.full_name==null?"Customer":undefined,subtitleKey:phone?undefined:"Customer record",orders},
                  title: name,
                  subtitle:
                    phone ||
                    "Customer record",
                  meta:
                    orders > 0
                      ? `${orders} ${
                          orders === 1
                            ? "order"
                            : "orders"
                        }`
                      : undefined,
                });
              });
          }

          setDesktopSearchResults(next);
        } catch (error) {
          console.warn(
            "Desktop global search failed:",
            error
          );

          if (
            requestId ===
            desktopSearchRequestRef.current
          ) {
            setDesktopSearchResults([]);
          }
        } finally {
          if (
            requestId ===
            desktopSearchRequestRef.current
          ) {
            setDesktopSearchLoading(false);
          }
        }
      })();
    }, 350);

    return () => {
      clearTimeout(timer);
    };
  }, [
    desktopSearchQuery,
    organizationId,
    salesPerformanceStoreId,
    isOwner,
  ]);

  const openDesktopSearchResult =
    useCallback(
      (
        result:
          DesktopGlobalSearchResult
      ) => {
        setDesktopSearchFocused(false);

        if (
          result.kind === "CUSTOMER" &&
          result.id
        ) {
          desktopRouter.push({
            pathname: "/customers/[id]",
            params: {
              id: result.id,
              fromGlobalSearch: "1",
            },
          } as any);

          return;
        }

        if (result.kind === "CUSTOMER") {
          desktopRouter.push(
            "/customers" as any
          );
          return;
        }

        desktopRouter.push({
          pathname: "/(tabs)/products",
          params: {
            focusProductId: result.id,
            focusProductName: result.title,
          },
        } as any);
      },
      [desktopRouter]
    );


  const todayYmd = useMemo(() => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
  }, []);

  const [desktopSelectedDate, setDesktopSelectedDate] =
    useState(todayYmd);

  const desktopSelectedDateLabel = useMemo(() => {
    const [yearText, monthText, dayText] =
      desktopSelectedDate.split("-");

    const year = Number(yearText);
    const month = Number(monthText);
    const day = Number(dayText);

    const date = new Date(
      year,
      month - 1,
      day
    );

    if (Number.isNaN(date.getTime())) {
      return uiText("Today");
    }

    const formatted = date.toLocaleDateString(
      language==='en'?'en-GB':language,
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );

    return desktopSelectedDate === todayYmd
      ? uiText("Today • {p0}",{p0:formatted})
      : formatted;
  }, [desktopSelectedDate, todayYmd, language, uiText]);

  const [desktopCalendarOpen, setDesktopCalendarOpen] =
    useState(false);

  const [desktopCalendarMonth, setDesktopCalendarMonth] =
    useState(() => {
      const [yearText, monthText] = todayYmd.split("-");

      return new Date(
        Number(yearText),
        Number(monthText) - 1,
        1
      );
    });

  const openDesktopDatePicker = useCallback(() => {
    const [yearText, monthText] =
      desktopSelectedDate.split("-");

    setDesktopCalendarMonth(
      new Date(
        Number(yearText),
        Number(monthText) - 1,
        1
      )
    );

    setDesktopCalendarOpen((current) => !current);
  }, [desktopSelectedDate]);

  const desktopCalendarTitle = useMemo(
    () =>
      desktopCalendarMonth.toLocaleDateString(
        language==='en'?'en-GB':language,
        {
          month: "long",
          year: "numeric",
        }
      ),
    [desktopCalendarMonth, language]
  );

  const desktopCalendarDays = useMemo(() => {
    const year = desktopCalendarMonth.getFullYear();
    const month = desktopCalendarMonth.getMonth();

    const firstDay = new Date(year, month, 1);

    // Monday = 0 ... Sunday = 6
    const leadingDays =
      (firstDay.getDay() + 6) % 7;

    const daysInMonth =
      new Date(year, month + 1, 0).getDate();

    const cells: Array<{
      key: string;
      day: number | null;
      ymd: string | null;
    }> = [];

    for (let index = 0; index < leadingDays; index += 1) {
      cells.push({
        key: `empty-${index}`,
        day: null,
        ymd: null,
      });
    }

    for (let day = 1; day <= daysInMonth; day += 1) {
      const monthText =
        String(month + 1).padStart(2, "0");

      const dayText =
        String(day).padStart(2, "0");

      cells.push({
        key: `${year}-${monthText}-${dayText}`,
        day,
        ymd: `${year}-${monthText}-${dayText}`,
      });
    }

    while (cells.length % 7 !== 0) {
      cells.push({
        key: `tail-${cells.length}`,
        day: null,
        ymd: null,
      });
    }

    return cells;
  }, [desktopCalendarMonth]);

  const moveDesktopCalendarMonth = useCallback(
    (offset: number) => {
      setDesktopCalendarMonth((current) => {
        return new Date(
          current.getFullYear(),
          current.getMonth() + offset,
          1
        );
      });
    },
    []
  );

  const selectDesktopCalendarDate = useCallback(
    (ymd: string) => {
      setDesktopSelectedDate(ymd);
      setDesktopCalendarOpen(false);
    },
    []
  );

  const selectDesktopToday = useCallback(() => {
    setDesktopSelectedDate(todayYmd);

    const [yearText, monthText] =
      todayYmd.split("-");

    setDesktopCalendarMonth(
      new Date(
        Number(yearText),
        Number(monthText) - 1,
        1
      )
    );

    setDesktopCalendarOpen(false);
  }, [todayYmd]);

  const contentWide = width >= 1120;

  /*
   * Desktop-only viewport density.
   * Keeps the command center inside one laptop/desktop screen.
   */
  const desktopCompact = height < 760;
  const desktopTight = height < 850;

  const desktopOuterGap = desktopCompact ? 4 : desktopTight ? 5 : 7;
  const desktopSectionGap = desktopCompact ? 4 : desktopTight ? 5 : 7;

  const desktopTopBarHeight = desktopCompact ? 42 : desktopTight ? 46 : 50;
  const desktopGreetingHeight = desktopCompact ? 42 : desktopTight ? 48 : 54;

  const desktopKpiHeight = desktopCompact ? 62 : desktopTight ? 68 : 76;
  const desktopActionHeight = desktopCompact ? 44 : desktopTight ? 48 : 54;

  const desktopSalesHeight = desktopCompact ? 188 : desktopTight ? 210 : 236;
  const desktopChartHeight = desktopCompact ? 72 : desktopTight ? 86 : 100;

  const desktopBottomHeight = desktopCompact ? 88 : desktopTight ? 100 : 112;
  const desktopAiWidth = width < 1280 ? 220 : width < 1440 ? 260 : 320;

  const ActionCard = ({
    title,
    icon,
    color,
    soft,
    onPress,
  }: {
    title: string;
    icon: React.ComponentProps<typeof Ionicons>["name"];
    color: string;
    soft: string;
    onPress?: () => void;
  }) => (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => ({
        flex: 1,
        minWidth: 118,
        minHeight: desktopActionHeight,
        borderRadius: 13,
        borderWidth: 1,
        borderColor: "rgba(15,23,42,0.07)",
        backgroundColor: soft,
        paddingHorizontal: 12,
        paddingVertical: 11,
        justifyContent: "center",
        opacity: pressed ? 0.86 : 1,
      })}
    >
      <Ionicons name={icon} size={23} color={color} />

      <Text
        style={{
          color: "#0F172A",
          fontWeight: "900",
          fontSize: 12,
          marginTop: 8,
        }}
        numberOfLines={1}
      >
        {title}
      </Text>
    </Pressable>
  );

  const KpiCard = ({
    title,
    value,
    icon,
    soft,
    iconColor,
    onPress,
    hint,
    primaryAction = false,
    actionLabel,
  }: {
    title: string;
    value: string;
    icon: React.ComponentProps<typeof Ionicons>["name"];
    soft: string;
    iconColor: string;
    onPress?: () => void;
    hint?: string;
      primaryAction?: boolean;
    actionLabel?: string;
  }) => (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => ({
        flex: 1,
        minWidth: 135,
        minHeight: desktopKpiHeight,
        borderRadius: 12,
        borderWidth: primaryAction ? 1.5 : 1,
        borderColor: primaryAction
          ? pressed
            ? "rgba(22,163,74,0.46)"
            : "rgba(22,163,74,0.30)"
          : "rgba(15,23,42,0.07)",
        backgroundColor: primaryAction
          ? pressed
            ? "#ECFDF3"
            : "#F0FDF4"
          : soft,
        paddingHorizontal: 10,
        paddingVertical: 8,
        overflow: "hidden",
        shadowColor: primaryAction
          ? "#16A34A"
          : "#000000",
        shadowOpacity: primaryAction
          ? pressed
            ? 0.10
            : 0.06
          : 0,
        shadowRadius: primaryAction ? 8 : 0,
        shadowOffset: {
          width: 0,
          height: primaryAction ? 3 : 0,
        },
        elevation: primaryAction ? 2 : 0,
        opacity: pressed ? 0.94 : 1,
        transform: [
          {
            scale:
              pressed && primaryAction
                ? 0.992
                : 1,
          },
        ],
      })}
    >
      {primaryAction ? (
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            top: 0,
            left: 12,
            right: 12,
            height: 3,
            borderBottomLeftRadius: 999,
            borderBottomRightRadius: 999,
            backgroundColor: "#16A34A",
            opacity: 0.88,
          }}
        />
      ) : null}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 10,
        }}
      >
        <View
          style={{
            width: 34,
            height: 34,
            borderRadius: 10,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: primaryAction
              ? "#DCFCE7"
              : "#FFFFFF",
            borderWidth: primaryAction ? 1 : 0,
            borderColor: primaryAction
              ? "rgba(22,163,74,0.18)"
              : "transparent",
          }}
        >
          <Ionicons
            name={icon}
            size={19}
            color={iconColor}
          />
        </View>

        <View style={{ flex: 1, minWidth: 0 }}>
          <Text
            style={{
              color: "#334155",
              fontWeight: "900",
              fontSize: 11,
            }}
            numberOfLines={1}
          >
            {title}
          </Text>

          <Text
            style={{
              color: "#0F172A",
              fontWeight: "900",
              fontSize: desktopCompact ? 15 : desktopTight ? 16 : 17,
              marginTop: 2,
            }}
            numberOfLines={1}
            adjustsFontSizeToFit
            minimumFontScale={0.48}
          >
            {value}
          </Text>
        </View>
      </View>

      <View
        style={{
          marginTop: desktopCompact ? 4 : 6,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 6,
        }}
      >
        <Text
          style={{
            flex: 1,
            minWidth: 0,
            color: primaryAction
              ? "#475569"
              : "#64748B",
            fontWeight: "700",
            fontSize: 9,
          }}
          numberOfLines={1}
        >
          {hint || " "}
        </Text>

        {primaryAction && actionLabel ? (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 3,
              paddingHorizontal: 7,
              paddingVertical: 3,
              borderRadius: 999,
              backgroundColor: "#DCFCE7",
            }}
          >
            <Text
              style={{
                color: "#15803D",
                fontWeight: "900",
                fontSize: 8.5,
              }}
              numberOfLines={1}
            >
              {actionLabel}
            </Text>

            <Ionicons
              name="arrow-forward"
              size={10}
              color="#15803D"
            />
          </View>
        ) : null}
      </View>
    </Pressable>
  );

  const InsightRow = ({
    icon,
    iconColor,
    soft,
    title,
    subtitle,
    onPress,
  }: {
    icon: React.ComponentProps<typeof Ionicons>["name"];
    iconColor: string;
    soft: string;
    title: string;
    subtitle: string;
    onPress?: () => void;
  }) => (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        gap: 11,
        paddingVertical: 11,
        borderBottomWidth: 1,
        borderBottomColor: "#EEF2F7",
        opacity: pressed ? 0.8 : 1,
      })}
    >
      <View
        style={{
          width: 38,
          height: 38,
          borderRadius: 19,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: soft,
        }}
      >
        <Ionicons
          name={icon}
          size={19}
          color={iconColor}
        />
      </View>

      <View style={{ flex: 1, minWidth: 0 }}>
        <Text
          style={{
            color: "#0F172A",
            fontWeight: "900",
            fontSize: 11.5,
          }}
          numberOfLines={2}
        >
          {title}
        </Text>

        <Text
          style={{
            color: "#64748B",
            fontWeight: "700",
            fontSize: 9.5,
            marginTop: 3,
          }}
          numberOfLines={2}
        >
          {subtitle}
        </Text>
      </View>

      {onPress ? (
        <Ionicons
          name="chevron-forward"
          size={16}
          color="#64748B"
        />
      ) : null}
    </Pressable>
  );

  return (
    <View
      style={{
        width: "100%",
        maxWidth: 1600,
        minHeight: height,
        alignSelf: "center",
        gap: desktopOuterGap,
        overflow: "visible",
      }}
    >
      {/* MASTER REFERENCE TOP BAR */}
      <View
        style={{
          height: desktopTopBarHeight,
          minHeight: desktopTopBarHeight,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: "rgba(15,23,42,0.07)",
          backgroundColor: "#FFFFFF",
          paddingHorizontal: 12,
          paddingVertical: 8,
          flexDirection: "row",
          alignItems: "center",
          gap: 10,
          position: "relative",
          zIndex: 20000,
          overflow: "visible",
        }}
      >
        <Pressable
          onPress={onOpenOrgSwitcher}
          style={({ pressed }) => ({
            width: 220,
            minHeight: 40,
            flexDirection: "row",
            alignItems: "center",
            gap: 9,
            paddingHorizontal: 12,
            borderRadius: 11,
            borderWidth: 1,
            borderColor: "#DDE5EF",
            backgroundColor: pressed ? "#EFF6FF" : "#FFFFFF",
          })}
        >
          <Ionicons
            name="business"
            size={18}
            color="#2563EB"
          />

          <Text
            style={{
              color: "#0F172A",
              fontWeight: "900",
              fontSize: 11.5,
              flex: 1,
            }}
            numberOfLines={1}
          >
            {(String((activeOrgName ?? "")).trim() || uiText("Organization"))}
          </Text>

          <Ionicons
            name="chevron-down"
            size={14}
            color="#64748B"
          />
        </Pressable>

        <Pressable
          onPress={onOpenStores}
          style={({ pressed }) => ({
            width: 220,
            minHeight: 40,
            flexDirection: "row",
            alignItems: "center",
            gap: 9,
            paddingHorizontal: 12,
            borderRadius: 11,
            borderWidth: 1,
            borderColor: "#DDE5EF",
            backgroundColor: pressed ? "#F5F3FF" : "#FFFFFF",
          })}
        >
          <Ionicons
            name="storefront"
            size={18}
            color="#7C3AED"
          />

          <Text
            style={{
              color: "#0F172A",
              fontWeight: "900",
              fontSize: 11.5,
              flex: 1,
            }}
            numberOfLines={1}
          >
            {(String((activeStoreName ?? "")).trim() || uiText("No active store"))}
          </Text>

          <Ionicons
            name="chevron-down"
            size={14}
            color="#64748B"
          />
        </Pressable>

        <View
          style={{
            flex: 1,
            minWidth: 180,
            position: "relative",
            zIndex: 11000,
          }}
        >
          <View
            style={{
              minHeight: 40,
              borderRadius: 11,
              borderWidth: 1,
              borderColor:
                desktopSearchFocused
                  ? "#93C5FD"
                  : "#E2E8F0",
              backgroundColor: "#F8FAFC",
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 13,
              gap: 9,
            }}
          >
            <Ionicons
              name="search-outline"
              size={18}
              color={
                desktopSearchFocused
                  ? "#2563EB"
                  : "#475569"
              }
            />

            <TextInput
              value={desktopSearchQuery}
              onChangeText={
                setDesktopSearchQuery
              }
              onFocus={() =>
                setDesktopSearchFocused(true)
              }
              placeholder={uiText("Search products, customers...")}
              placeholderTextColor="#94A3B8"
              autoCorrect={false}
              autoCapitalize="none"
              returnKeyType="search"
              style={{
                flex: 1,
                minWidth: 0,
                paddingVertical: 0,
                color: "#0F172A",
                fontWeight: "700",
                fontSize: 11,
                outlineStyle: "none",
              } as any}
            />

            {desktopSearchLoading ? (
              <Text
                style={{
                  color: "#64748B",
                  fontWeight: "800",
                  fontSize: 9,
                }}
              >
                {uiText("Searching...")}</Text>
            ) : desktopSearchQuery.length >
              0 ? (
              <Pressable
                hitSlop={8}
                onPress={() => {
                  desktopSearchRequestRef.current +=
                    1;
                  setDesktopSearchQuery("");
                  setDesktopSearchResults([]);
                  setDesktopSearchLoading(false);
                }}
              >
                <Ionicons
                  name="close-circle"
                  size={17}
                  color="#94A3B8"
                />
              </Pressable>
            ) : (
              <Text
                style={{
                  color: "#94A3B8",
                  fontWeight: "800",
                  fontSize: 9,
                }}
              >
                {uiText("Products · Customers")}</Text>
            )}
          </View>

          {desktopSearchFocused &&
          desktopSearchQuery.trim().length >=
            2 ? (
            <View
              style={{
                position: "absolute",
                top: 46,
                left: 0,
                right: 0,
                maxHeight: 430,
                borderRadius: 14,
                borderWidth: 1,
                borderColor: "#DCE5EF",
                backgroundColor: "#FFFFFF",
                shadowColor: "#0F172A",
                shadowOpacity: 0.12,
                shadowRadius: 18,
                shadowOffset: {
                  width: 0,
                  height: 8,
                },
                elevation: 12,
                overflow: "hidden",
                zIndex: 12000,
              }}
            >
              <View
                style={{
                  minHeight: 32,
                  paddingHorizontal: 12,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent:
                    "space-between",
                  backgroundColor: "#F8FAFC",
                  borderBottomWidth: 1,
                  borderBottomColor: "#EEF2F7",
                }}
              >
                <Text
                  style={{
                    color: "#475569",
                    fontWeight: "900",
                    fontSize: 9.5,
                    letterSpacing: 0.3,
                  }}
                >
                  {uiText("GLOBAL SEARCH")}</Text>

                <Text
                  style={{
                    color: "#94A3B8",
                    fontWeight: "800",
                    fontSize: 9,
                  }}
                >
                  {uiText("Active store")}</Text>
              </View>

              {!desktopSearchLoading &&
              desktopSearchResults.length ===
                0 ? (
                <View
                  style={{
                    paddingHorizontal: 14,
                    paddingVertical: 18,
                    alignItems: "center",
                  }}
                >
                  <Ionicons
                    name="search-outline"
                    size={22}
                    color="#CBD5E1"
                  />

                  <Text
                    style={{
                      marginTop: 6,
                      color: "#64748B",
                      fontWeight: "800",
                      fontSize: 10.5,
                    }}
                  >
                    {uiText("No matching records")}</Text>
                </View>
              ) : (
                desktopSearchResults.map(
                  (result, index) => {
                    const displayResult=localizedSearchResult(language,result);
                    const isProduct =
                      result.kind ===
                      "PRODUCT";

                    return (
                      <Pressable
                        key={result.key}
                        onPress={() =>
                          openDesktopSearchResult(
                            result
                          )
                        }
                        style={({ pressed }) => ({
                          minHeight: 52,
                          paddingHorizontal: 12,
                          paddingVertical: 8,
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 10,
                          backgroundColor:
                            pressed
                              ? "#F8FAFC"
                              : "#FFFFFF",
                          borderBottomWidth:
                            index <
                            desktopSearchResults.length -
                              1
                              ? 1
                              : 0,
                          borderBottomColor:
                            "#F1F5F9",
                        })}
                      >
                        <View
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: 9,
                            alignItems: "center",
                            justifyContent:
                              "center",
                            backgroundColor:
                              isProduct
                                ? "#ECFDF5"
                                : "#EFF6FF",
                          }}
                        >
                          <Ionicons
                            name={
                              isProduct
                                ? "cube-outline"
                                : "person-outline"
                            }
                            size={16}
                            color={
                              isProduct
                                ? "#059669"
                                : "#2563EB"
                            }
                          />
                        </View>

                        <View
                          style={{
                            flex: 1,
                            minWidth: 0,
                          }}
                        >
                          <Text
                            numberOfLines={1}
                            style={{
                              color: "#0F172A",
                              fontWeight: "900",
                              fontSize: 10.5,
                            }}
                          >
                            {displayResult.title}
                          </Text>

                          <Text
                            numberOfLines={1}
                            style={{
                              color: "#64748B",
                              fontWeight: "700",
                              fontSize: 9,
                              marginTop: 2,
                            }}
                          >
                            {displayResult.subtitle}
                          </Text>
                        </View>

                        {result.meta ? (
                          <Text
                            numberOfLines={1}
                            style={{
                              maxWidth: 120,
                              color:
                                isProduct
                                  ? "#047857"
                                  : "#2563EB",
                              fontWeight: "800",
                              fontSize: 8.5,
                            }}
                          >
                            {displayResult.meta}
                          </Text>
                        ) : null}

                        <Ionicons
                          name="chevron-forward"
                          size={14}
                          color="#94A3B8"
                        />
                      </Pressable>
                    );
                  }
                )
              )}
            </View>
          ) : null}
        </View>
        <Pressable
          onPress={onOpenNotifications}
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons
            name="notifications-outline"
            size={21}
            color="#0F172A"
          />

          {notificationUnread > 0 ? (
            <View
              style={{
                position: "absolute",
                top: 1,
                right: 0,
                minWidth: 17,
                height: 17,
                borderRadius: 9,
                paddingHorizontal: 4,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "#DC2626",
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontWeight: "900",
                  fontSize: 8,
                }}
              >
                {notificationUnread > 99
                  ? "99+"
                  : notificationUnread}
              </Text>
            </View>
          ) : null}
        </Pressable>

        <View
          style={{
            width: 1,
            height: 28,
            backgroundColor: "#E2E8F0",
          }}
        />

        <Pressable
          onPress={onOpenBusinessProfile}
          style={({ pressed }) => ({
            minWidth: 150,
            flexDirection: "row",
            alignItems: "center",
            gap: 9,
            paddingHorizontal: 5,
            paddingVertical: 4,
            borderRadius: 11,
            backgroundColor: pressed
              ? "#F1F5F9"
              : "transparent",
          })}
        >
          <View
            style={{
              width: 60,
              height: 60,
              borderRadius: 30,
              backgroundColor: "#DBEAFE",
              alignItems: "center",
              justifyContent: "center",
              overflow: "hidden",
              borderWidth: 1,
              borderColor: "#BFDBFE",
            }}
          >
            {organizationLogoUrl ? (
              <Image
                source={{ uri: organizationLogoUrl }}
                resizeMode="cover"
                style={{
                  width: "100%",
                  height: "100%",
                }}
              />
            ) : (
              <Ionicons
                name="business"
                size={28}
                color="#2563EB"
              />
            )}
          </View>

          <View style={{ flex: 1, minWidth: 0 }}>
            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: 10.5,
              }}
              numberOfLines={1}
            >
              {(String((activeOrgName ?? "")).trim() || uiText("Organization"))}
            </Text>

            <Text
              style={{
                color: "#64748B",
                fontWeight: "700",
                fontSize: 9,
                marginTop: 1,
              }}
              numberOfLines={1}
            >
              {uiText(roleLabel.toUpperCase())}
            </Text>
          </View>

          <Ionicons
            name="chevron-down"
            size={14}
            color="#64748B"
          />
        </Pressable>
      </View>

      {/* GREETING / DATE */}
      <View
        style={{
          height: desktopGreetingHeight,
          paddingHorizontal: 2,
          paddingVertical: desktopCompact ? 2 : 4,
          flexDirection: "row",
          alignItems: "center",
          gap: 11,
          position: "relative",
          zIndex: 1,
          overflow: "visible",
        }}
      >
        <Ionicons
          name={desktopGreeting.icon}
          size={desktopCompact ? 27 : 32}
          color={desktopGreeting.color}
        />

        <View style={{ flex: 1, minWidth:0, flexDirection:"row", alignItems:"center", gap:12, flexWrap:"wrap" }}>
          <Text
            style={{
              color: "#0F172A",
              fontWeight: "900",
              fontSize: desktopCompact ? 24 : 26,
            }}
          >
            {desktopGreeting.text}
          </Text>
          <DashboardCurrency compact />
        </View>

        {/* DESKTOP SUBSCRIPTION STATUS */}
        <SubscriptionExpiryHomeStrip compact />

        <View
          style={{
            position: "relative",
            zIndex: 1000,
          }}
        >
          <Pressable
            onPress={openDesktopDatePicker}
            style={({ pressed }) => ({
              minWidth: 190,
              minHeight: 43,
              borderRadius: 12,
              borderWidth: 1,
              borderColor:
                desktopCalendarOpen || pressed
                  ? "#93C5FD"
                  : "#DDE5EF",
              backgroundColor:
                desktopCalendarOpen || pressed
                  ? "#EFF6FF"
                  : "#FFFFFF",
              paddingHorizontal: 14,
              flexDirection: "row",
              alignItems: "center",
              gap: 9,
            })}
          >
            <Ionicons
              name="calendar-outline"
              size={18}
              color="#334155"
            />

            <Text
              style={{
                color: "#0F172A",
                fontWeight: "900",
                fontSize: 11,
                flex: 1,
              }}
              numberOfLines={1}
            >
              {desktopSelectedDateLabel}
            </Text>

            <Ionicons
              name={
                desktopCalendarOpen
                  ? "chevron-up"
                  : "chevron-down"
              }
              size={14}
              color="#64748B"
            />
          </Pressable>

          {desktopCalendarOpen ? (
            <View
              style={{
                position: "absolute",
                top: 49,
                right: 0,
                width: 292,
                borderRadius: 16,
                borderWidth: 1,
                borderColor: "#DDE5EF",
                backgroundColor: "#FFFFFF",
                padding: 14,
                shadowColor: "#0F172A",
                shadowOpacity: 0.16,
                shadowRadius: 18,
                shadowOffset: {
                  width: 0,
                  height: 8,
                },
                elevation: 12,
                zIndex: 2000,
              }}
            >
              {/* MONTH HEADER */}
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 13,
                }}
              >
                <Pressable
                  onPress={() =>
                    moveDesktopCalendarMonth(-1)
                  }
                  style={({ pressed }) => ({
                    width: 32,
                    height: 32,
                    borderRadius: 9,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: pressed
                      ? "#F1F5F9"
                      : "#FFFFFF",
                  })}
                >
                  <Ionicons
                    name="chevron-back"
                    size={17}
                    color="#334155"
                  />
                </Pressable>

                <Text
                  style={{
                    flex: 1,
                    textAlign: "center",
                    color: "#0F172A",
                    fontSize: 13,
                    fontWeight: "900",
                  }}
                >
                  {desktopCalendarTitle}
                </Text>

                <Pressable
                  onPress={() =>
                    moveDesktopCalendarMonth(1)
                  }
                  style={({ pressed }) => ({
                    width: 32,
                    height: 32,
                    borderRadius: 9,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: pressed
                      ? "#F1F5F9"
                      : "#FFFFFF",
                  })}
                >
                  <Ionicons
                    name="chevron-forward"
                    size={17}
                    color="#334155"
                  />
                </Pressable>
              </View>

              {/* WEEK DAYS */}
              <View
                style={{
                  flexDirection: "row",
                  marginBottom: 5,
                }}
              >
                {[
                  "Mo",
                  "Tu",
                  "We",
                  "Th",
                  "Fr",
                  "Sa",
                  "Su",
                ].map((label) => (
                  <View
                    key={label}
                    style={{
                      width: `${100 / 7}%`,
                      alignItems: "center",
                    }}
                  >
                    <Text
                      style={{
                        color: "#94A3B8",
                        fontSize: 9,
                        fontWeight: "900",
                      }}
                    >
                      {label}
                    </Text>
                  </View>
                ))}
              </View>

              {/* DATE GRID */}
              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                }}
              >
                {desktopCalendarDays.map((cell) => {
                  const selected =
                    cell.ymd === desktopSelectedDate;

                  const isToday =
                    cell.ymd === todayYmd;

                  return (
                    <View
                      key={cell.key}
                      style={{
                        width: `${100 / 7}%`,
                        height: 34,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      {cell.day ? (
                        <Pressable
                          onPress={() =>
                            cell.ymd &&
                            selectDesktopCalendarDate(
                              cell.ymd
                            )
                          }
                          style={({ pressed }) => ({
                            width: 29,
                            height: 29,
                            borderRadius: 9,
                            alignItems: "center",
                            justifyContent: "center",
                            backgroundColor: selected
                              ? "#2563EB"
                              : pressed
                                ? "#EFF6FF"
                                : "transparent",
                            borderWidth:
                              !selected && isToday
                                ? 1
                                : 0,
                            borderColor: "#93C5FD",
                          })}
                        >
                          <Text
                            style={{
                              color: selected
                                ? "#FFFFFF"
                                : "#334155",
                              fontSize: 10.5,
                              fontWeight:
                                selected || isToday
                                  ? "900"
                                  : "700",
                            }}
                          >
                            {cell.day}
                          </Text>
                        </Pressable>
                      ) : null}
                    </View>
                  );
                })}
              </View>

              {/* FOOTER */}
              <View
                style={{
                  marginTop: 9,
                  paddingTop: 10,
                  borderTopWidth: 1,
                  borderTopColor: "#EEF2F7",
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <Text
                  style={{
                    color: "#64748B",
                    fontSize: 9.5,
                    fontWeight: "700",
                  }}
                >
                  {uiText("Select dashboard date")}</Text>

                <Pressable
                  onPress={selectDesktopToday}
                  style={({ pressed }) => ({
                    paddingHorizontal: 12,
                    height: 30,
                    borderRadius: 9,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: pressed
                      ? "#DBEAFE"
                      : "#EFF6FF",
                  })}
                >
                  <Text
                    style={{
                      color: "#2563EB",
                      fontSize: 10,
                      fontWeight: "900",
                    }}
                  >
                    {uiText("Today")}</Text>
                </Pressable>
              </View>
            </View>
          ) : null}
        </View>
      </View>

      {/* DESKTOP BODY */}
      <View
        style={{
          flexDirection: contentWide ? "row" : "column",
          alignItems: "stretch",
          gap: desktopSectionGap,
          overflow: "visible",

        }}
      >
        {/* MAIN COLUMN */}
        <View
          style={{
            flex: 1,
            minWidth: 0,
            width: contentWide ? undefined : "100%",

            gap: desktopSectionGap,
            overflow: "visible",
          }}
        >
          {/* KPI ROW */}
          <View
            style={{
              flexDirection: "row",
              flexWrap: "nowrap",
              gap: desktopCompact ? 5 : 7,
            }}
          >
            <KpiCard
              title={uiText("Today's Sales")}
              value={formatValue(sales)}
              icon="cart"
              soft="#ECFDF3"
              iconColor="#16A34A"
              onPress={onOpenSales}
              hint={uiText("{p0} completed orders", {p0: (orders)})}
              primaryAction
              actionLabel={uiText("Open POS")}
            />

            <KpiCard
              title={uiText("Money In")}
              value={formatValue(moneyIn)}
              icon="wallet"
              soft="#EFF6FF"
              iconColor="#2563EB"
              onPress={onOpenReports}
              hint={uiText("after expenses")}
            />

            <KpiCard
              title={uiText("Expenses")}
              value={formatValue(expenses)}
              icon="receipt"
              soft="#FFF1F2"
              iconColor="#E11D48"
              onPress={onOpenExpenses}
              hint={uiText("today")}
            />

            <KpiCard
              title={uiText("Net Profit")}
              value={
                isOwner
                  ? formatValue(profit)
                  : uiText("Owner only")
              }
              icon="bar-chart"
              soft="#F5F3FF"
              iconColor="#7C3AED"
              onPress={onOpenBusinessStatement}
              hint={isOwner ? uiText("owner view") : uiText("restricted")}
            />
          </View>

          {/* SALES PERFORMANCE V2 - DESKTOP BUSINESS PERFORMANCE WORKSPACE */}
          {salesPerformanceStoreId ? (
            <SalesPerformanceWorkspace
              storeId={salesPerformanceStoreId}
              organizationId={organizationId ?? null}
              formatValue={formatValue}
              onOpenCRM={onOpenCustomers}
            />
          ) : (
            <View
              style={{
                minHeight: 220,
                borderRadius: 16,
                borderWidth: 1,
                borderColor: "rgba(15,23,42,0.08)",
                backgroundColor: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
                padding: 24,
              }}
            >
              <Ionicons
                name="storefront-outline"
                size={26}
                color="#94A3B8"
              />

              <Text
                style={{
                  color: "#64748B",
                  fontWeight: "800",
                  fontSize: 11,
                  marginTop: 9,
                }}
              >
                {uiText("Select an active business and store to view Sales Performance.")}</Text>
            </View>
          )}
        </View>

        {/* RIGHT RAIL: ZETRA AI + FINANCIAL OVERVIEW */}
        <View
          style={{
            width: contentWide ? desktopAiWidth : "100%",
            minWidth: contentWide ? desktopAiWidth : 0,
            flexShrink: 0,
            gap: desktopSectionGap,
          }}
        >
        {/* ZETRA AI RAIL */}
        <View
          style={{
            width: "100%",
            borderRadius: 17,
            borderWidth: 1,
            borderColor: "rgba(16,185,129,0.22)",
            backgroundColor: "#ECFDF5",
            padding: 13,
            gap: 11,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 9,
            }}
          >
            <View
              style={{
                width: 42,
                height: 42,
                borderRadius: 14,
                backgroundColor: "#D1FAE5",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Ionicons
                name="sparkles"
                size={22}
                color="#059669"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: "#064E3B",
                  fontWeight: "900",
                  fontSize: 19,
                }}
              >
                ZETRA AI
              </Text>

              <Text
                style={{
                  color: "#047857",
                  fontWeight: "700",
                  fontSize: 9.5,
                  marginTop: 1,
                }}
              >
                {uiText("Your Business Assistant")}</Text>
            </View>

            <View
              style={{
                paddingHorizontal: 9,
                paddingVertical: 5,
                borderRadius: 999,
                backgroundColor: "#10B981",
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontWeight: "900",
                  fontSize: 8.5,
                }}
              >
                {uiText("LIVE")}</Text>
            </View>

            <Ionicons
              name="ellipsis-vertical"
              size={18}
              color="#047857"
            />
          </View>



          <Pressable
            onPress={onOpenAI}
            style={({ pressed }) => ({
              minHeight: desktopCompact ? 56 : 64,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: "rgba(37,99,235,0.16)",
              backgroundColor: pressed
                ? "#DBEAFE"
                : "#EFF6FF",
              padding: 13,
              flexDirection: "row",
              alignItems: "center",
              gap: 10,
            })}
          >
            <Ionicons
              name="chatbubble-ellipses-outline"
              size={22}
              color="#2563EB"
            />

            <View style={{ flex: 1 }}>
              <Text
                style={{
                  color: "#1D4ED8",
                  fontWeight: "900",
                  fontSize: 13,
                }}
              >
                {uiText("Ask ZETRA AI")}</Text>

              <Text
                style={{
                  color: "#475569",
                  fontWeight: "700",
                  fontSize: 9.5,
                  lineHeight: 14,
                  marginTop: 3,
                }}
              >
                {uiText("Ask about sales, stock, customers, profit and trends.")}</Text>
            </View>

            <Ionicons
              name="chevron-forward"
              size={18}
              color="#2563EB"
            />
          </Pressable>

          <View
            style={{
              flexDirection: "row",
              gap: 7,
            }}
          >
            {[
              {
                title: uiText("Summarize Today"),
                icon: "document-text-outline" as const,
                color: "#2563EB",
              },
              {
                title: uiText("Low Stock Alert"),
                icon: "cube-outline" as const,
                color: "#D97706",
              },
              {
                title: uiText("Top Products"),
                icon: "bar-chart-outline" as const,
                color: "#0F766E",
              },
            ].map((item) => (
              <Pressable
                key={item.title}
                onPress={onOpenAI}
                style={({ pressed }) => ({
                  flex: 1,
                  minHeight: desktopCompact ? 54 : 64,
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: "#DDE5EF",
                  backgroundColor: pressed
                    ? "#F8FAFC"
                    : "#FFFFFF",
                  paddingHorizontal: 7,
                  paddingVertical: 8,
                  alignItems: "center",
                  justifyContent: "center",
                })}
              >
                <Ionicons
                  name={item.icon}
                  size={20}
                  color={item.color}
                />

                <Text
                  style={{
                    color: "#0F172A",
                    fontWeight: "900",
                    fontSize: 9.5,
                    lineHeight: 12,
                    marginTop: 6,
                    textAlign: "center",
                    width: "100%",
                  }}
                  numberOfLines={2}
                >
                  {item.title}
                </Text>
              </Pressable>
            ))}
          </View>
</View>
      
          <BusinessFinancialOverview
            storeIds={financialStoreIds}
            enabled={isOwner}
          />
        </View>
</View>

      {loading ? (
        <Text
          style={{
            color: "#64748B",
            fontWeight: "800",
            fontSize: 9.5,
            textAlign: "right",
          }}
        >
          {uiText("Refreshing dashboard...")}</Text>
      ) : null}
    </View>
  );
}
function WebDesktopShell({
  width: _width,
  left,
  right,
}: {
  width: number;
  left: React.ReactNode;
  right: React.ReactNode;
}) {
 const desktopMax = _width >= 1600 ? 1520 : _width >= 1380 ? 1360 : 1240;
  const twoCols = _width >= 1180;

  if (!twoCols) {
    return (
      <View style={{ width: "100%", maxWidth: 980, alignSelf: "center" }}>
        {left}
        {right}
      </View>
    );
  }

  return (
    <View
      style={{
        width: "100%",
        maxWidth: desktopMax,
        alignSelf: "center",
        flexDirection: "row",
        alignItems: "flex-start",
        gap: 20,
      }}
    >
      <View style={{ flex: 1.35, minWidth: 0 }}>{left}</View>
      <View style={{ width: 360, minWidth: 360 }}>{right}</View>
    </View>
  );
}

export default function HomeScreen() {


 const systemText = useSystemMessageText();
 const uiText = useCommonText();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();

const {
  refreshing,
  error,
  refresh,
  activeOrgId,
  activeOrgName,
  activeRole,
  activeStoreName,
  activeStoreId,
  stores,
} = useOrg();

  const netInfo = useNetInfo();
  const isOnline = !!(netInfo.isConnected && netInfo.isInternetReachable !== false);

  const [dashTick, setDashTick] = useState(0);
  const [capitalRecoveryTick, setCapitalRecoveryTick] = useState(0);
  const [pulling, setPulling] = useState(false);


  const [organizationLogoUrl, setOrganizationLogoUrl] =
    useState<string | null>(null);
  useFocusEffect(
    useCallback(() => {
      let alive = true;

      async function loadOrganizationLogo() {
        const id = String(activeOrgId ?? "").trim();

        if (!id) {
          if (alive) setOrganizationLogoUrl(null);
          return;
        }

        try {
          const { data, error: logoError } = await supabase
            .from("organization_profiles")
            .select("logo_url")
            .eq("organization_id", id)
            .maybeSingle();

          if (logoError) throw logoError;
          if (!alive) return;

          setOrganizationLogoUrl(
            String(data?.logo_url ?? "").trim() || null
          );
        } catch (logoError) {
          console.warn(
            "Home organization logo load failed:",
            logoError
          );

          if (alive) {
            setOrganizationLogoUrl(null);
          }
        }
      }

      void loadOrganizationLogo();

      return () => {
        alive = false;
      };
    }, [activeOrgId])
  );
  type DesktopSalesPerformanceMode =
    | "Daily"
    | "Weekly"
    | "Monthly";

  type DesktopSalesPerformancePoint = {
    key: string;
    label: string;
    value: number;
    previousValue: number;
  };

  const [desktopSalesPerformanceMode, setDesktopSalesPerformanceMode] =
    useState<DesktopSalesPerformanceMode>("Daily");

  const [desktopSalesPerformanceCompare, setDesktopSalesPerformanceCompare] =
    useState(false);

  const [desktopSalesPerformancePoints, setDesktopSalesPerformancePoints] =
    useState<DesktopSalesPerformancePoint[]>([]);

  const [desktopSalesPerformanceTotal, setDesktopSalesPerformanceTotal] =
    useState(0);

  const [desktopSalesPerformancePreviousTotal, setDesktopSalesPerformancePreviousTotal] =
    useState(0);

  const [desktopSalesPerformanceLoading, setDesktopSalesPerformanceLoading] =
    useState(false);

  const [desktopSalesPerformanceError, setDesktopSalesPerformanceError] =
    useState<string | null>(null);

  const [desktopLoading, setDesktopLoading] = useState(false);const [desktopValuationScope,setDesktopValuationScope]=useState("");
  const [desktopFinanceErr, setDesktopFinanceErr] = useState<string | null>(null);
  const [desktopSales, setDesktopSales] = useState<SalesSummary>({
    total: 0,
    orders: 0,
    currency: "TZS",
  });
  const [desktopExpenses, setDesktopExpenses] = useState<ExpenseSummary>({
    total: 0,
    count: 0,
  });
  const [desktopProfit, setDesktopProfit] = useState<ProfitSummary>({
    net: 0,
    sales: null,
    expenses: null,
  });
  const [desktopPay, setDesktopPay] = useState<PayBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
    credit: 0,
    other: 0,
    orders: 0,
  });
  const [desktopCollections, setDesktopCollections] = useState<CollectionBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
    other: 0,
    total: 0,
    payments: 0,
  });
  const [desktopExpenseByChannel, setDesktopExpenseByChannel] = useState<ExpenseChannelBreakdown>({
    cash: 0,
    bank: 0,
    mobile: 0,
  });
  const [desktopStockValue, setDesktopStockValue] = useState(0);
const [desktopNotifUnread, setDesktopNotifUnread] = useState(0);
const [desktopNotifTotal, setDesktopNotifTotal] = useState(0);

  const [capitalSummaryLoading, setCapitalSummaryLoading] = useState(false);
  const [capitalSummaryError, setCapitalSummaryError] = useState<string | null>(null);
  const [capitalSummary, setCapitalSummary] = useState<CapitalRecoverySummaryRow>({
    total_asset: 0,
    total_cost: 0,
    total_income: 0,
    remaining_cost: 0,
    remaining_asset: 0,
    realized_profit: 0,
    entries_count: 0,
    last_entry_at: null,
  });

  const desktopLoadBusyRef = useRef(false);
  const desktopLoadSeqRef = useRef(0);
  const desktopNotifBusyRef = useRef(false);

  const goOrgSwitcher = useCallback(() => {
    router.push("/org-switcher");
  }, [router]);
  const goBusinessProfile = useCallback(() => {
    const orgId = clean(activeOrgId);

    if (!orgId) {
      Alert.alert(
        uiText("Missing organization"),
        uiText("Organization haijapatikana.")
      );
      return;
    }

    router.push({
      pathname: "/organization-profile",
      params: { orgId },
    } as any);
  }, [router, activeOrgId]);

  

  const goAI = useCallback(() => {
    router.push("/ai");
  }, [router]);

const goLive = useCallback(() => {
  router.push("/finance/live");
}, [router]);

const goBusinessPosition = useCallback(() => {
  router.push("/finance/business-position" as any);
}, [router]);

const goBusinessDebts = useCallback(() => {
  router.push("/finance/business-debts" as any);
}, [router]);

const goIncomingStock = useCallback(() => {
  router.push("/stocks/inbound" as any);
}, [router]);

  const goStockValue = useCallback(() => {
    router.push("/stocks/history" as any);
  }, [router]);

  const goSalesHistoryToday = useCallback(() => {
    router.push({
      pathname: "/(tabs)/sales/history",
      params: { range: "today" },
    } as any);
  }, [router]);

  const goExpenses = useCallback(() => {
    router.push("/(tabs)/sales/expenses" as any);
  }, [router]);

  const bottomPad = useMemo(() => Math.max(insets.bottom, 8) + 14, [insets.bottom]);
  const topPad = useMemo(() => Math.max(insets.top, 10) + 8, [insets.top]);

  const onPullRefresh = useCallback(async () => {
    setPulling(true);
    try {
      await Promise.resolve(refresh());

      if (activeStoreId && isOnline) {
        try {
          await syncSalesQueueOnce(String(activeStoreId));
        } catch {}
      }

      setDashTick((x) => x + 1);
      setCapitalRecoveryTick((x) => x + 1);
    } finally {
      setPulling(false);
    }
  }, [refresh, activeStoreId, isOnline]);

  const isCashier = String(activeRole ?? "").trim().toLowerCase() === "cashier";
  const isWeb = Platform.OS === "web";
  const isDesktopWeb = isDesktopWebEnv(width);
  const isMobileWeb = isWeb && !isDesktopWeb;

  // Web Lite ibaki kwa mobile browser tu.
  // Desktop browser itumie Command Center layout.
  const isWebLiteHome = isWeb && !isDesktopWeb;

  const activeStoreType = useMemo(() => {
    const row = (stores ?? []).find(
      (s: any) => String(s?.store_id ?? "") === String(activeStoreId ?? "")
    );
    const t = String((row as any)?.store_type ?? "STANDARD").trim().toUpperCase();
    return t === "CAPITAL_RECOVERY" ? "CAPITAL_RECOVERY" : "STANDARD";
  }, [stores, activeStoreId]);

  const isCapitalRecoveryStore = activeStoreType === "CAPITAL_RECOVERY";

  const orgId = String(activeOrgId ?? "").trim();
  const storeId = String(activeStoreId ?? "").trim();
  const roleLower = String(activeRole ?? "").trim().toLowerCase();
 const isOwner = roleLower === "owner";
const canSeeCapitalSecrets = isOwner;

// Owner pekee ndiye anaona Stock Action secrets.
// Admin, staff, cashier hawazioni kabisa.
const canViewStockAction = isOwner;

  const moneyPrefs = useOrgMoneyPrefs(orgId);
  const moneyRefreshRef = useRef<null | (() => Promise<any> | any)>(null);
  moneyRefreshRef.current = moneyPrefs.refresh;

 const preferredMoney=usePreferredDisplayMoney(orgId,desktopValuationScope===JSON.stringify([orgId,String(activeStoreId??'').trim()])&&!desktopLoading);
  const desktopFmtMoney = useCallback(
    (n: number) =>
      preferredMoney(n, {
        currency: moneyPrefs.currency || "TZS",
        locale: moneyPrefs.locale || "en-TZ",
      }).replace(/\s+/g, " "),
    [moneyPrefs.currency, moneyPrefs.locale,preferredMoney]
  );

  const loadCapitalRecoverySummary = useCallback(async () => {
    const sid = String(activeStoreId ?? "").trim();

    if (!sid) {
      setCapitalSummary({
        total_asset: 0,
        total_cost: 0,
        total_income: 0,
        remaining_cost: 0,
        remaining_asset: 0,
        realized_profit: 0,
        entries_count: 0,
        last_entry_at: null,
      });
      setCapitalSummaryError("No active Capital Recovery store selected");
      return;
    }

    setCapitalSummaryLoading(true);
    setCapitalSummaryError(null);

    try {
      const { data, error } = await supabase.rpc("get_capital_recovery_summary_v1", {
        p_store_id: sid,
      });

      if (error) throw error;

      const row = (Array.isArray(data) ? data[0] : data) as any;

      setCapitalSummary({
        total_asset: toNum(row?.total_asset),
        total_cost: toNum(row?.total_cost),
        total_income: toNum(row?.total_income),
        remaining_cost: toNum(row?.remaining_cost),
        remaining_asset: toNum(row?.remaining_asset),
        realized_profit: toNum(row?.realized_profit),
        entries_count: toInt(row?.entries_count),
        last_entry_at: clean(row?.last_entry_at) || null,
      });
    } catch (e: any) {
      setCapitalSummaryError(clean(e?.message) || "Failed to load Capital Recovery summary");
      setCapitalSummary({
        total_asset: 0,
        total_cost: 0,
        total_income: 0,
        remaining_cost: 0,
        remaining_asset: 0,
        realized_profit: 0,
        entries_count: 0,
        last_entry_at: null,
      });
    } finally {
      setCapitalSummaryLoading(false);
    }
  }, [activeStoreId]);

  const onCapitalRecoveryRefreshDone = useCallback(async () => {
    await Promise.resolve(refresh());

    if (activeStoreId && isOnline) {
      try {
        await syncSalesQueueOnce(String(activeStoreId));
      } catch {}
    }

    await loadCapitalRecoverySummary();
    setCapitalRecoveryTick((x) => x + 1);
  }, [refresh, activeStoreId, isOnline, loadCapitalRecoverySummary]);
const loadDesktopNotifications = useCallback(async () => {
  if (!isDesktopWeb) return;
  if (desktopNotifBusyRef.current) return;

  desktopNotifBusyRef.current = true;

  try {
    const { data, error } = await supabase.rpc("get_my_notifications", {
      p_store_id: null,
      p_limit: 80,
    } as any);

    if (error) throw error;

    const rows = Array.isArray(data) ? data : [];

    setDesktopNotifTotal(rows.length);
    setDesktopNotifUnread(
      rows.filter((r: any) => !r?.is_read).length
    );
  } catch {
    setDesktopNotifTotal(0);
    setDesktopNotifUnread(0);
  } finally {
    desktopNotifBusyRef.current = false;
  }
}, [isDesktopWeb]);
  const loadDesktopSalesPerformance = useCallback(async () => {
    if (!isDesktopWeb) return;
    if (isCapitalRecoveryStore) return;
    if (!storeId) return;

    setDesktopSalesPerformanceLoading(true);
    setDesktopSalesPerformanceError(null);

    try {
      const now = new Date();

      const startOfDay = (d: Date) =>
        new Date(
          d.getFullYear(),
          d.getMonth(),
          d.getDate(),
          0,
          0,
          0,
          0
        );

      const addDays = (d: Date, days: number) =>
        new Date(
          d.getFullYear(),
          d.getMonth(),
          d.getDate() + days,
          d.getHours(),
          d.getMinutes(),
          d.getSeconds(),
          d.getMilliseconds()
        );

      const toISO = (d: Date) => d.toISOString();

      const saleAmount = (row: any) =>
        toNum(
          row?.total_amount ??
            row?.total ??
            row?.amount ??
            row?.grand_total ??
            row?.paid_amount ??
            row?.revenue ??
            0
        );

      const saleDate = (row: any) => {
        const raw =
          row?.sold_at ??
          row?.created_at ??
          row?.sale_date ??
          row?.date ??
          null;

        if (!raw) return null;

        const parsed = new Date(raw);

        return Number.isNaN(parsed.getTime())
          ? null
          : parsed;
      };

      const isValidSale = (row: any) => {
        const status = String(row?.status ?? "")
          .trim()
          .toLowerCase();

        return !(
          status === "cancelled" ||
          status === "canceled" ||
          status === "void"
        );
      };

      let currentFrom: Date;
      let currentTo: Date;
      let previousFrom: Date;
      let previousTo: Date;

      if (desktopSalesPerformanceMode === "Daily") {
        currentFrom = startOfDay(now);
        currentTo = addDays(currentFrom, 1);

        previousFrom = addDays(currentFrom, -1);
        previousTo = currentFrom;
      }
      else if (desktopSalesPerformanceMode === "Weekly") {
        const jsDay = now.getDay();
        const mondayOffset =
          jsDay === 0
            ? -6
            : 1 - jsDay;

        currentFrom = startOfDay(
          addDays(now, mondayOffset)
        );

        currentTo = addDays(currentFrom, 7);

        previousFrom = addDays(currentFrom, -7);
        previousTo = currentFrom;
      }
      else {
        currentFrom = new Date(
          now.getFullYear(),
          now.getMonth(),
          1,
          0,
          0,
          0,
          0
        );

        currentTo = new Date(
          now.getFullYear(),
          now.getMonth() + 1,
          1,
          0,
          0,
          0,
          0
        );

        previousFrom = new Date(
          now.getFullYear(),
          now.getMonth() - 1,
          1,
          0,
          0,
          0,
          0
        );

        previousTo = currentFrom;
      }

      const [currentRes, previousRes] =
        await Promise.all([
          supabase.rpc("get_sales_v3", {
            p_store_id: storeId,
            p_from: toISO(currentFrom),
            p_to: toISO(currentTo),
          } as any),

          supabase.rpc("get_sales_v3", {
            p_store_id: storeId,
            p_from: toISO(previousFrom),
            p_to: toISO(previousTo),
          } as any),
        ]);

      if (currentRes.error) throw currentRes.error;
      if (previousRes.error) throw previousRes.error;

      const currentRows =
        (Array.isArray(currentRes.data)
          ? currentRes.data
          : []
        ).filter(isValidSale);

      const previousRows =
        (Array.isArray(previousRes.data)
          ? previousRes.data
          : []
        ).filter(isValidSale);

      const sumRows = (rows: any[]) =>
        rows.reduce(
          (total, row) =>
            total + saleAmount(row),
          0
        );

      let points: DesktopSalesPerformancePoint[] = [];

      if (desktopSalesPerformanceMode === "Daily") {
        const slots = [
          { key: "00", label: "12 AM", from: 0, to: 4 },
          { key: "04", label: "4 AM", from: 4, to: 8 },
          { key: "08", label: "8 AM", from: 8, to: 12 },
          { key: "12", label: "12 PM", from: 12, to: 16 },
          { key: "16", label: "4 PM", from: 16, to: 20 },
          { key: "20", label: "8 PM", from: 20, to: 24 },
        ];

        points = slots.map((slot) => {
          const currentValue = currentRows.reduce(
            (total: number, row: any) => {
              const d = saleDate(row);
              if (!d) return total;

              const hour = d.getHours();

              return hour >= slot.from &&
                hour < slot.to
                ? total + saleAmount(row)
                : total;
            },
            0
          );

          const previousValue = previousRows.reduce(
            (total: number, row: any) => {
              const d = saleDate(row);
              if (!d) return total;

              const hour = d.getHours();

              return hour >= slot.from &&
                hour < slot.to
                ? total + saleAmount(row)
                : total;
            },
            0
          );

          return {
            key: slot.key,
            label: slot.label,
            value: currentValue,
            previousValue,
          };
        });
      }
      else if (desktopSalesPerformanceMode === "Weekly") {
        const labels = [
          "Mon",
          "Tue",
          "Wed",
          "Thu",
          "Fri",
          "Sat",
          "Sun",
        ];

        points = labels.map((label, index) => {
          const currentDay = addDays(
            currentFrom,
            index
          );

          const previousDay = addDays(
            previousFrom,
            index
          );

          const currentKey =
            currentDay.toDateString();

          const previousKey =
            previousDay.toDateString();

          return {
            key: label,
            label,
            value: currentRows.reduce(
              (total: number, row: any) => {
                const d = saleDate(row);

                return d &&
                  d.toDateString() === currentKey
                  ? total + saleAmount(row)
                  : total;
              },
              0
            ),
            previousValue: previousRows.reduce(
              (total: number, row: any) => {
                const d = saleDate(row);

                return d &&
                  d.toDateString() === previousKey
                  ? total + saleAmount(row)
                  : total;
              },
              0
            ),
          };
        });
      }
      else {
        const monthEnd = new Date(
          currentTo.getTime() - 1
        );

        const daysInMonth =
          monthEnd.getDate();

        const weekCount =
          Math.ceil(daysInMonth / 7);

        points = Array.from(
          { length: weekCount },
          (_, index) => {
            const currentWeekFrom =
              addDays(
                currentFrom,
                index * 7
              );

            const currentWeekTo =
              addDays(
                currentWeekFrom,
                7
              );

            const previousWeekFrom =
              addDays(
                previousFrom,
                index * 7
              );

            const previousWeekTo =
              addDays(
                previousWeekFrom,
                7
              );

            const sumBetween = (
              rows: any[],
              fromDate: Date,
              toDate: Date
            ) =>
              rows.reduce(
                (total: number, row: any) => {
                  const d = saleDate(row);

                  return d &&
                    d >= fromDate &&
                    d < toDate
                    ? total + saleAmount(row)
                    : total;
                },
                0
              );

            return {
              key: `W${index + 1}`,
              label: `W${index + 1}`,
              value: sumBetween(
                currentRows,
                currentWeekFrom,
                currentWeekTo
              ),
              previousValue: sumBetween(
                previousRows,
                previousWeekFrom,
                previousWeekTo
              ),
            };
          }
        );
      }

      setDesktopSalesPerformancePoints(points);

      setDesktopSalesPerformanceTotal(
        sumRows(currentRows)
      );

      setDesktopSalesPerformancePreviousTotal(
        sumRows(previousRows)
      );
    }
    catch (error) {
      console.warn(
        "Desktop Sales Performance load failed:",
        error
      );

      setDesktopSalesPerformancePoints([]);
      setDesktopSalesPerformanceTotal(0);
      setDesktopSalesPerformancePreviousTotal(0);

      setDesktopSalesPerformanceError(
        "Sales Performance data unavailable."
      );
    }
    finally {
      setDesktopSalesPerformanceLoading(false);
    }
  }, [
    isDesktopWeb,
    isCapitalRecoveryStore,
    storeId,
    desktopSalesPerformanceMode,
  ]);

  // Sales Performance V2 owns current/previous get_sales_v3 requests.


  const desktopLoad = useCallback(async () => {
    // WEB SAFE MODE HOTFIX:
    // Desktop browser Home imekuwa ikipata freeze / page unresponsive.
    // Tunazima live heavy RPC loading kwenye Home ya web desktop kwa sasa.
    // Detailed pages (Finance / Stores / Products / Sales) bado zinafunguka kawaida.
    // Desktop web inaruhusiwa kutumia command center data.
    if (!isDesktopWeb) return;
    if (isCapitalRecoveryStore) return;
    if (!orgId || !storeId) return;
    if (desktopLoadBusyRef.current) return;const seq = ++desktopLoadSeqRef.current;
    desktopLoadBusyRef.current = true;

    setDesktopLoading(true);
    setDesktopFinanceErr(null);

    try {
      const { from, to } = rangeToFromTo("today");
      const { from: fromYMD, to: toYMD } = rangeToDates("today");

      const salesPromise = supabase.rpc("get_sales", {
        p_store_id: storeId,
        p_from: from,
        p_to: to,
      } as any);

      const expensePromise = supabase.rpc("get_expense_summary_v2", {
        p_store_id: storeId,
        p_from: fromYMD,
        p_to: toYMD,
      } as any);

      const profitPromise = isOwner
        ? supabase.rpc("get_store_net_profit_v2", {
            p_store_id: storeId,
            p_from: from,
            p_to: to,
          } as any)
        : Promise.resolve({ data: null, error: null } as any);

      const payPromise = supabase.rpc("get_sales_channel_summary_v3", {
        p_org_id: orgId,
        p_from: from,
        p_to: to,
        p_store_id: storeId,
      } as any);

      const collectionsPromise = supabase.rpc("get_credit_collections_summary_v2", {
        p_org_id: orgId,
        p_from: from,
        p_to: to,
        p_store_id: storeId,
      } as any);

      const expenseChannelPromise = supabase.rpc("get_expense_channel_summary_v1", {
        p_store_id: storeId,
        p_from: fromYMD,
        p_to: toYMD,
      } as any);

      const stockPromise = isOwner ? supabase.rpc("get_stock_on_hand_value_v1", {
        p_org_id: orgId,
        p_store_id: storeId,
      } as any) : Promise.resolve({data:null,error:null} as any);

      const [
        salesRes,
        expenseRes,
        profitRes,
        payRes,
        collectionsRes,
        expenseChannelRes,
        stockRes,
      ] = await Promise.all([
        salesPromise,
        expensePromise,
        profitPromise,
        payPromise,
        collectionsPromise,
        expenseChannelPromise,
        stockPromise,
      ]);

      if (salesRes.error) throw salesRes.error;
      if (expenseRes.error) throw expenseRes.error;
      if (profitRes?.error) throw profitRes.error;
      if (payRes.error) throw payRes.error;
      if (expenseChannelRes.error) throw expenseChannelRes.error;
      if (stockRes.error) throw stockRes.error;

      const salesRows = Array.isArray(salesRes.data) ? salesRes.data : [];
      const salesTotal = salesRows.reduce((acc: number, r: any) => {
        return (
          acc +
          toNum(
            r?.total_amount ??
              r?.total ??
              r?.amount ??
              r?.grand_total ??
              r?.paid_amount ??
              r?.revenue ??
              0
          )
        );
      }, 0);

      const salesOrders = salesRows.reduce((acc: number, r: any) => {
        const st = String(r?.status ?? "").toLowerCase().trim();
        if (st === "cancelled" || st === "canceled" || st === "void") return acc;
        return acc + 1;
      }, 0);

      if (seq !== desktopLoadSeqRef.current) return;

      setDesktopValuationScope(JSON.stringify([orgId,storeId]));setDesktopSales({
        total: salesTotal,
        orders: salesOrders,
        currency: "TZS",
      });

      const expenseRow = Array.isArray(expenseRes.data) ? expenseRes.data[0] : expenseRes.data;
      setDesktopExpenses({
        total: toNum(expenseRow?.total ?? expenseRow?.amount ?? expenseRow?.sum ?? 0),
        count: toInt(expenseRow?.count ?? expenseRow?.items ?? 0),
      });

      const profitRow = Array.isArray(profitRes?.data) ? profitRes.data[0] : profitRes?.data;
      setDesktopProfit({
        net: isOwner ? toNum(profitRow?.net_profit ?? profitRow?.net ?? 0) : 0,
        sales: profitRow?.sales_total != null ? toNum(profitRow?.sales_total) : null,
        expenses: profitRow?.expenses_total != null ? toNum(profitRow?.expenses_total) : null,
      });

      const payRows = Array.isArray(payRes.data) ? payRes.data : [];
      const payOut: PayBreakdown = {
        cash: 0,
        bank: 0,
        mobile: 0,
        credit: 0,
        other: 0,
        orders: 0,
      };

      for (const r of payRows) {
        const ch = String(r?.channel ?? r?.payment_method ?? "").trim().toUpperCase();
        const amt = toNum(r?.revenue ?? r?.total ?? 0);
        const ord = toInt(r?.orders ?? 0);
        payOut.orders += ord;

        if (ch === "CASH") payOut.cash += amt;
        else if (ch === "BANK") payOut.bank += amt;
        else if (ch === "MOBILE") payOut.mobile += amt;
        else if (ch === "CREDIT") payOut.credit += amt;
        else payOut.other += amt;
      }

      setDesktopPay(payOut);

      const collectionRows = Array.isArray(collectionsRes.data) ? collectionsRes.data : [];
      const collOut: CollectionBreakdown = {
        cash: 0,
        bank: 0,
        mobile: 0,
        other: 0,
        total: 0,
        payments: 0,
      };

      for (const r of collectionRows) {
        const ch = String(r?.channel ?? r?.payment_method ?? r?.method ?? "")
          .trim()
          .toUpperCase();
        const amt = toNum(r?.amount ?? r?.revenue ?? r?.total ?? 0);
        const cnt = toInt(r?.payments ?? r?.count ?? 0);

        collOut.payments += cnt;

        if (ch === "CASH") collOut.cash += amt;
        else if (ch === "BANK") collOut.bank += amt;
        else if (ch === "MOBILE") collOut.mobile += amt;
        else collOut.other += amt;
      }

      collOut.total = collOut.cash + collOut.bank + collOut.mobile;
      setDesktopCollections(collOut);

      const expenseChannelRows = Array.isArray(expenseChannelRes.data) ? expenseChannelRes.data : [];
      const expCh: ExpenseChannelBreakdown = { cash: 0, bank: 0, mobile: 0 };

      for (const r of expenseChannelRows) {
        const ch = String(r?.channel ?? "").trim().toUpperCase();
        const amt = toNum(r?.amount ?? 0);

        if (ch === "CASH") expCh.cash += amt;
        else if (ch === "BANK") expCh.bank += amt;
        else if (ch === "MOBILE") expCh.mobile += amt;
      }

      setDesktopExpenseByChannel(expCh);

      const stockRaw = Array.isArray(stockRes.data) ? stockRes.data[0] : stockRes.data;
      setDesktopStockValue(extractScalarValue(stockRaw));
    } catch (e: any) {
      if (seq === desktopLoadSeqRef.current) {
        setDesktopFinanceErr(e?.message ?? "Failed to load desktop dashboard");
      }
    } finally {
      if (seq === desktopLoadSeqRef.current) {
        setDesktopLoading(false);
      }
      desktopLoadBusyRef.current = false;
    }
  }, [isDesktopWeb, isCapitalRecoveryStore, orgId, storeId, isOwner]);

  useEffect(() => {
    if (!orgId) return;

    const run = async () => {
      try {
        await moneyRefreshRef.current?.();
      } catch {}
    };

    void run();
  }, [orgId]);

  useEffect(() => {
    if (isWebLiteHome) return;
    if (!isDesktopWeb) return;
    if (isCapitalRecoveryStore) return;
    if (!orgId || !storeId) return;

    void desktopLoad();
void loadDesktopNotifications();
  }, [isWebLiteHome, isDesktopWeb, isCapitalRecoveryStore, orgId, storeId, desktopLoad, loadDesktopNotifications]);


  useEffect(() => {
    if (!isDesktopWeb) return;
    if (isWebLiteHome) return;
    if (isCapitalRecoveryStore) return;
    if (!orgId || !storeId) return;

    let disposed = false;
    let refreshTimer: ReturnType<typeof setTimeout> | null = null;

    const scheduleDashboardRefresh = () => {
      if (disposed) return;

      if (refreshTimer) {
        clearTimeout(refreshTimer);
      }

      // One completed sale may produce several database changes.
      // Debounce them into one verified dashboard reload.
      refreshTimer = setTimeout(() => {
        refreshTimer = null;

        if (disposed) return;

        console.log(
          "[ZETRA HOME][REALTIME] debounce complete -> desktopLoad()"
        );

        void desktopLoad();
      }, 350);
    };

    const channel = supabase.channel(
      `desktop-home-live:${orgId}:${storeId}:${Date.now().toString(36)}:${Math.random().toString(36).slice(2, 8)}`
    );


    channel.on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "expenses",
      },
      (payload: any) => {
        const rowStoreId = String(
          payload?.new?.store_id ??
          payload?.old?.store_id ??
          ""
        ).trim();

        console.log(
          "[ZETRA HOME][EXPENSE REALTIME] event received",
          {
            eventType: payload?.eventType,
            rowStoreId,
            activeStoreId: storeId,
            newRow: payload?.new,
            oldRow: payload?.old,
          }
        );

        // Ignore expense changes belonging to another store.
        // DELETE may not expose store_id, so refresh safely when absent.
        if (rowStoreId && rowStoreId !== storeId) {
          console.log(
            "[ZETRA HOME][EXPENSE REALTIME] ignored - different store"
          );
          return;
        }

        console.log(
          "[ZETRA HOME][EXPENSE REALTIME] scheduling dashboard refresh"
        );

        scheduleDashboardRefresh();
      }
    );
    channel.on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "sales",
      },
      (payload: any) => {
        const rowStoreId = String(
          payload?.new?.store_id ??
          payload?.old?.store_id ??
          ""
        ).trim();

        // Some DELETE payloads may not expose store_id depending
        // on replica identity. Refresh safely in that case.
        if (rowStoreId && rowStoreId !== storeId) {
          return;
        }

        console.log(
          "[DESKTOP HOME REALTIME] SALES EVENT",
          payload?.eventType ?? "UNKNOWN",
          payload?.new?.store_id ?? payload?.old?.store_id ?? "NO_STORE_ID"
        );

        scheduleDashboardRefresh();
      }
    );

    channel.subscribe((status) => {
      console.log(
        "[DESKTOP HOME REALTIME] STATUS:",
        status,
        "ORG:",
        orgId,
        "STORE:",
        storeId
      );
    });

    return () => {
      disposed = true;

      if (refreshTimer) {
        clearTimeout(refreshTimer);
        refreshTimer = null;
      }

      try {
        supabase.removeChannel(channel);
      } catch {}
    };
  }, [
    isDesktopWeb,
    isWebLiteHome,
    isCapitalRecoveryStore,
    orgId,
    storeId,
    desktopLoad,
  ]);
  useFocusEffect(
    useCallback(() => {
      if (Platform.OS === "web") return;
      if (!activeStoreId || !isOnline) return;
      void syncSalesQueueOnce(String(activeStoreId));
    }, [activeStoreId, isOnline])
  );

  useFocusEffect(
    useCallback(() => {
      if (!isCapitalRecoveryStore) return;

      void loadCapitalRecoverySummary();
    }, [
      isCapitalRecoveryStore,
      loadCapitalRecoverySummary,
      capitalRecoveryTick,
    ])
  );

  useEffect(() => {
    // Browser should open fast. Offline sales sync is mobile-only here.
    if (Platform.OS === "web") return;
    if (!activeStoreId || !isOnline) return;

    void syncSalesQueueOnce(String(activeStoreId));

    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active" && activeStoreId && isOnline) {
        void syncSalesQueueOnce(String(activeStoreId));
      }
    });

    const timer = setInterval(() => {
      if (activeStoreId && isOnline) {
        void syncSalesQueueOnce(String(activeStoreId));
      }
    }, 15000);

    return () => {
      try {
        // @ts-ignore
        sub?.remove?.();
      } catch {}
      clearInterval(timer);
    };
  }, [activeStoreId, isOnline]);

  const homeRefreshControl =
    Platform.OS === "web"
      ? undefined
      : (
          <RefreshControl
            refreshing={pulling || refreshing}
            onRefresh={onPullRefresh}
            tintColor={UI.text}
          />
        );
  return (
    <Screen
      scroll={isDesktopWeb || isCashier || isCapitalRecoveryStore}
      refreshControl={homeRefreshControl as any}
      contentStyle={
        isDesktopWeb
          ? {
              minHeight: 0,
              paddingTop: Math.max(insets.top, 18) + 10,
              paddingHorizontal: 22,
              paddingBottom: bottomPad,
              overflow: "hidden",
            }
          : {
              paddingHorizontal: 16,
              flex: 1,
              minHeight: 0,
            }
      }
    >

      {!isDesktopWeb ? (
        <HeaderHero
          activeOrgName={activeOrgName}
          activeStoreName={
            isCapitalRecoveryStore
              ? `${activeStoreName ?? "Store"} ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ CAPITAL RECOVERY`
              : activeStoreName
          }
          isCashier={isCashier}
          onOpenOrgSwitcher={
            !isCashier && !isCapitalRecoveryStore
              ? goOrgSwitcher
              : undefined
          }
          organizationLogoUrl={
            !isCashier && !isCapitalRecoveryStore
              ? organizationLogoUrl
              : undefined
          }
          onOpenBusinessProfile={
            !isCashier && !isCapitalRecoveryStore
              ? goBusinessProfile
              : undefined
          }
        />
      ) : null}

<PreferredRateNote compact />

{!isCashier && !isDesktopWeb && !isCapitalRecoveryStore ? (
  <SubscriptionExpiryHomeStrip
    reloadKey={dashTick}
  />
) : null}

      {!!error && !String(error).toLowerCase().includes("not allowed") && (
        <Card
          style={{
            borderColor: "rgba(201,74,74,0.35)",
            backgroundColor: "rgba(201,74,74,0.10)",
            borderRadius: 18,
            padding: 12,
            marginTop: 14,
          }}
        >
          <Text style={{ color: UI.danger, fontWeight: "900" }}>{systemText(error)}</Text>
        </Card>
      )}

      {isCapitalRecoveryStore ? (
        <>
          <StoreGuard>
            <CapitalRecoveryHomeShell
              activeOrgName={activeOrgName}
              activeStoreName={activeStoreName}
              activeStoreId={activeStoreId}
              summaryLoading={capitalSummaryLoading}
              summaryError={capitalSummaryError}
              summary={capitalSummary}
              canSeeCapitalSecrets={canSeeCapitalSecrets}
            />

            <CapitalRecoveryReportsCard
              activeStoreId={activeStoreId}
              reloadKey={capitalRecoveryTick}
              canSeeCapitalSecrets={canSeeCapitalSecrets}
            />

            <CapitalRecoveryBottomSwitcherCard
              onOpenOrgSwitcher={goOrgSwitcher}
            />
          </StoreGuard>
        </>
      ) : isWebLiteHome ? (
        <StoreGuard>
          <View style={{ flex: 1, minHeight: 0 }}>
            <MobileWebFinanceShortcut />

          <MobileQuickAccess
            onProducts={() => router.push("/(tabs)/products" as any)}
            onCustomers={() => router.push("/customers" as any)}
            onExpenses={() => router.push("/(tabs)/expenses" as any)}
            onReports={() => {
              const dates = rangeToDates("today");

              router.push({
                pathname: "/finance/history",
                params: {
                  mode: "SALES",
                  scope: "STORE",
                  range: "today",
                  from: dates.from,
                  to: dates.to,
                } as any,
              } as any);
            }}
            onStores={() => router.push("/(tabs)/stores" as any)}
            onCredit={() => router.push("/(tabs)/credit" as any)}
          />

          <MobileBusinessTools
            isOwner={canViewStockAction}
            onOpenBusinessPosition={goBusinessPosition}
            onOpenBusinessDebts={goBusinessDebts}
            onOpenIncomingStock={goIncomingStock}
            onOpenStock={goStockValue}
          />

            <ZetraAiCard onOpen={goAI} />
          </View>
        </StoreGuard>
      ) : isCashier ? (
        <>
          <WorkspaceCard
            activeOrgName={activeOrgName}
            activeRole={activeRole}
            activeStoreName={activeStoreName}
            activeStoreId={activeStoreId}
            onOpen={goOrgSwitcher}
          />
          <CashierQuickHome />
        </>
      ) : isDesktopWeb ? (
        <DesktopMasterHome
          width={width}
          height={height}
          activeOrgName={activeOrgName}
          activeStoreName={activeStoreName}
          activeRole={activeRole}
          financialStoreIds={
            activeStoreId
              ? [String(activeStoreId)]
              : []
          }
          organizationId={
            activeOrgId
              ? String(activeOrgId)
              : null
          }
              salesPerformanceStoreId={storeId || null}
              organizationLogoUrl={organizationLogoUrl}
          sales={desktopSales.total}
          expenses={desktopExpenses.total}
          moneyIn={
            subtractFloor(desktopPay.cash + desktopCollections.cash, desktopExpenseByChannel.cash) +
            subtractFloor(desktopPay.bank + desktopCollections.bank, desktopExpenseByChannel.bank) +
            subtractFloor(desktopPay.mobile + desktopCollections.mobile, desktopExpenseByChannel.mobile)
          }
          profit={isOwner ? desktopProfit.net : 0}
          orders={desktopSales.orders}
          stockValue={desktopStockValue}
          isOwner={isOwner}
          loading={desktopLoading}
          notificationUnread={desktopNotifUnread}
          notificationTotal={desktopNotifTotal}

          salesPerformanceMode={
            desktopSalesPerformanceMode
          }
          salesPerformanceCompare={
            desktopSalesPerformanceCompare
          }
          salesPerformancePoints={
            desktopSalesPerformancePoints
          }
          salesPerformanceTotal={
            desktopSalesPerformanceTotal
          }
          salesPerformancePreviousTotal={
            desktopSalesPerformancePreviousTotal
          }
          salesPerformanceLoading={
            desktopSalesPerformanceLoading
          }
          salesPerformanceError={
            desktopSalesPerformanceError
          }

          onChangeSalesPerformanceMode={
            setDesktopSalesPerformanceMode
          }

          onToggleSalesPerformanceCompare={() =>
            setDesktopSalesPerformanceCompare(
              (current) => !current
            )
          }

          formatValue={desktopFmtMoney}
          onOpenOrgSwitcher={goOrgSwitcher}
          onOpenBusinessProfile={goBusinessProfile}
          onOpenNotifications={() =>
            router.push("/notifications" as any)
          }
          onOpenAI={goAI}
          onOpenSales={() =>
            router.push("/(tabs)/sales" as any)
          }
          onOpenProducts={() =>
            router.push("/(tabs)/products" as any)
          }
          onOpenExpenses={() =>
            router.push("/(tabs)/expenses" as any)
          }
          onOpenStores={() =>
            router.push("/(tabs)/stores" as any)
          }
          onOpenStock={goStockValue}
          onOpenCustomers={() =>
            router.push("/customers" as any)
          }
          onOpenCredit={() =>
            router.push("/(tabs)/credit" as any)
          }
          onOpenReports={() => {
            const dates = rangeToDates("today");

            router.push({
              pathname: "/finance/history",
              params: {
                mode: "SALES",
                scope: "STORE",
                range: "today",
                from: dates.from,
                to: dates.to,
              } as any,
            } as any);
          }}
          onOpenBusinessStatement={() =>
            router.push(
              "/settings/business-statement" as any
            )
          }
        />      ) : (
        <StoreGuard>
          <View style={{ flex: 1, minHeight: 0 }}>
            <CompactFinanceCardHomePreview />

          <MobileQuickAccess
            onProducts={() => router.push("/(tabs)/products" as any)}
            onCustomers={() => router.push("/customers" as any)}
            onExpenses={() => router.push("/(tabs)/expenses" as any)}
            onReports={() => {
              const dates = rangeToDates("today");

              router.push({
                pathname: "/finance/history",
                params: {
                  mode: "SALES",
                  scope: "STORE",
                  range: "today",
                  from: dates.from,
                  to: dates.to,
                } as any,
              } as any);
            }}
            onStores={() => router.push("/(tabs)/stores" as any)}
            onCredit={() => router.push("/(tabs)/credit" as any)}
          />

          <MobileBusinessTools
            isOwner={canViewStockAction}
            onOpenBusinessPosition={goBusinessPosition}
            onOpenBusinessDebts={goBusinessDebts}
            onOpenIncomingStock={goIncomingStock}
            onOpenStock={goStockValue}
          />

            <View style={{ flex: 1, minHeight: 0 }} />
            <ZetraAiCard onOpen={goAI} />
          </View>
        </StoreGuard>
      )}
    </Screen>
  );
}





























