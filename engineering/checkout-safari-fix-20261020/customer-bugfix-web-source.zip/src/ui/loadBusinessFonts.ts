// Web: loaded only after a verified session. Native: same existing font families.
import * as Font from 'expo-font';
import {Ionicons,MaterialIcons,MaterialCommunityIcons,Feather,FontAwesome,FontAwesome5,AntDesign,Entypo,EvilIcons,Foundation,Octicons,SimpleLineIcons,Zocial} from '@expo/vector-icons';
export function loadBusinessFonts(){return Font.loadAsync({...Ionicons.font,...MaterialIcons.font,...MaterialCommunityIcons.font,...Feather.font,...FontAwesome.font,...FontAwesome5.font,...AntDesign.font,...Entypo.font,...EvilIcons.font,...Foundation.font,...Octicons.font,...SimpleLineIcons.font,...Zocial.font})}
