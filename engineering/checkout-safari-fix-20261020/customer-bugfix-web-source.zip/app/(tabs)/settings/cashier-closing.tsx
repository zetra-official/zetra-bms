import {useDocumentText} from "@/src/i18n/useDocumentText";
import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
import {useCommonText} from "@/src/i18n/useCommonText";
import { Ionicons } from "@expo/vector-icons";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  Text,
  TextInput,
  View,
} from "react-native";

import { useNetInfo } from "@react-native-community/netinfo";

import { useOrg } from "@/src/context/OrgContext";
import { supabase } from "@/src/supabase/supabaseClient";
import { Button } from "@/src/ui/Button";
import { Card } from "@/src/ui/Card";
import { Screen } from "@/src/ui/Screen";
import { useOrgMoneyPrefs } from "@/src/ui/money";
import { theme, UI } from "@/src/ui/theme";

const CLOSE_SHIFT_RPC = "close_cashier_shift_v1";

type ClosingSaleRow = {
  sale_id?: string;
  sold_at?: string;
  status?: string | null;
  total_qty?: number | null;
  total_amount?: number | null;
  payment_method?: string | null;
  payment_channel?: string | null;
  paid_amount?: number | null;
  balance_amount?: number | null;
};

type PaymentSummary = {
  cash_total: number;
  mobile_total: number;
  bank_total: number;
  credit_collected_total: number;
  grand_paid_total: number;
  total_sales: number;
  total_balance: number;
};

const EMPTY_PAYMENT_SUMMARY: PaymentSummary = {
  cash_total: 0,
  mobile_total: 0,
  bank_total: 0,
  credit_collected_total: 0,
  grand_paid_total: 0,
  total_sales: 0,
  total_balance: 0,
};

type OpenShiftRow = {
  shift_id: string;
  organization_id: string;
  store_id: string;
  membership_id: string;
  opening_cash: number;
  drawer_count?: number | null;
  closing_note?: string | null;
  status: string;
  opened_at: string;
  closed_at?: string | null;
};

type AnyRow = Record<string, any>;
type RangeKey = "today" | "week" | "month" | "custom";

function startOfDayLocal(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function endOfDayLocal(d: Date) {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
}

function startOfWeekMondayLocal(d: Date) {
  const x = startOfDayLocal(d);
  const day = x.getDay();
  const diff = (day === 0 ? -6 : 1) - day;
  x.setDate(x.getDate() + diff);
  return x;
}

function startOfMonthLocal(d: Date) {
  const x = startOfDayLocal(d);
  x.setDate(1);
  return x;
}

function toDateInputValue(d: Date) {
  const year = d.getFullYear();
  const month = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDateInputStart(input: string) {
  const s = String(input ?? "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;

  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return null;

  const out = new Date(y, m - 1, d, 0, 0, 0, 0);
  return Number.isFinite(out.getTime()) ? out : null;
}

function parseDateInputEnd(input: string) {
  const s = String(input ?? "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;

  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return null;

  const out = new Date(y, m - 1, d, 23, 59, 59, 999);
  return Number.isFinite(out.getTime()) ? out : null;
}

function safeWhenLabel(iso?: string | null) {
  if (!iso) return "—";
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return "—";
  try {
    return new Date(t).toLocaleString();
  } catch {
    return iso;
  }
}

function toNum(v: any): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function normalizeMoneyInput(raw: string) {
  return String(raw ?? "").replace(/[^\d.-]/g, "");
}

function isShiftOverdue(openedAt?: string | null) {
  if (!openedAt) return false;
  const opened = new Date(openedAt);
  if (!Number.isFinite(opened.getTime())) return false;
  return opened.getTime() < startOfDayLocal(new Date()).getTime();
}

function buildShiftDayRange(openedAt: string) {
  const d = new Date(openedAt);
  return {
    from: startOfDayLocal(d).toISOString(),
    to: endOfDayLocal(d).toISOString(),
  };
}

function normalizeSaleRow(r: AnyRow): ClosingSaleRow {
  const saleId =
    (r.sale_id ?? r.id ?? r.saleId ?? r.saleID ?? r.sale) != null
      ? String(r.sale_id ?? r.id ?? r.saleId ?? r.saleID ?? r.sale)
      : undefined;

  const soldAt =
    (r.sold_at ?? r.created_at ?? r.inserted_at ?? r.createdAt) != null
      ? String(r.sold_at ?? r.created_at ?? r.inserted_at ?? r.createdAt)
      : undefined;

  const statusRaw = r.status ?? r.sale_status ?? r.saleStatus ?? null;
  const status = statusRaw != null ? String(statusRaw) : null;

  const qty =
    r.total_qty ?? r.totalQty ?? r.qty ?? r.sum_qty ?? r.sumQty ?? r.items_qty ?? r.itemsQty;

  const amount =
    r.total_amount ??
    r.totalAmount ??
    r.amount ??
    r.sum_amount ??
    r.sumAmount ??
    r.total ??
    r.total_price ??
    r.totalPrice;

  return {
    sale_id: saleId,
    sold_at: soldAt,
    status,
    total_qty: qty == null ? null : toNum(qty),
    total_amount: amount == null ? null : toNum(amount),
    payment_method: r.payment_method != null ? String(r.payment_method) : null,
    payment_channel: r.payment_channel != null ? String(r.payment_channel) : null,
    paid_amount: r.paid_amount == null ? null : toNum(r.paid_amount),
    balance_amount: r.balance_amount == null ? null : toNum(r.balance_amount),
  };
}

function normalizeOpenShiftRow(row: any): OpenShiftRow | null {
  if (!row?.shift_id) return null;

  return {
    shift_id: String(row.shift_id),
    organization_id: String(row.organization_id ?? ""),
    store_id: String(row.store_id ?? ""),
    membership_id: String(row.membership_id ?? ""),
    opening_cash: toNum(row.opening_cash ?? 0),
    drawer_count: row.drawer_count == null ? null : toNum(row.drawer_count),
    closing_note: row.closing_note != null ? String(row.closing_note) : null,
    status: String(row.status ?? "OPEN"),
    opened_at: String(row.opened_at ?? ""),
    closed_at: row.closed_at ?? null,
  };
}

function labelForRange(r: RangeKey) {
  if (r === "today") return "Today";
  if (r === "week") return "This Week";
  if (r === "month") return "This Month";
  return "Custom Range";
}

function InputLabel({ children }: { children: React.ReactNode }) {
  return (
    <Text style={{ color: theme.colors.muted, fontWeight: "900", marginBottom: 6 }}>
      {children}
    </Text>
  );
}

function InputBox(props: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  multiline?: boolean;
  editable?: boolean;
  keyboardType?: "default" | "numeric";
}) {
  return (
    <TextInput
      value={props.value}
      onChangeText={props.onChangeText}
      placeholder={props.placeholder}
      placeholderTextColor="rgba(255,255,255,0.35)"
      autoCapitalize="none"
      autoCorrect={false}
      multiline={props.multiline}
      editable={props.editable}
      keyboardType={props.keyboardType}
      style={{
        color: theme.colors.text,
        fontWeight: "800",
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor:
          props.editable === false ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)",
        borderRadius: 16,
        paddingHorizontal: 12,
        paddingVertical: props.multiline ? 12 : 10,
        minHeight: props.multiline ? 96 : undefined,
        textAlignVertical: props.multiline ? "top" : "center",
        opacity: props.editable === false ? 0.7 : 1,
      }}
    />
  );
}

function MetricCard({
  title,
  amount,
  subtitle,
}: {
  title: string;
  amount: string;
  subtitle?: string;
}) {
  return (
    <Card style={{ flex: 1, gap: 6 }}>
      <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{title}</Text>
      <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 18 }}>
        {amount}
      </Text>
      {!!subtitle && (
        <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12 }}>
          {subtitle}
        </Text>
      )}
    </Card>
  );
}

function escapeHtml(input: any) {
  return String(input ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export default function CashierClosingScreen() {
 const {documentText, documentLocale} = useDocumentText();
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const { activeOrgId, activeOrgName, activeStoreId, activeStoreName, activeRole } =
    useOrg() as any;

  const money = useOrgMoneyPrefs(activeOrgId);
  const fmtMoney = useCallback((n: number) => money.fmt(Number(n || 0)), [money]);

  const netInfo = useNetInfo();
  const isOnline = !!(netInfo.isConnected && netInfo.isInternetReachable !== false);
  const isOffline = !isOnline;

  const [range, setRange] = useState<RangeKey>("today");

  const now = useMemo(() => new Date(), []);
  const [customFrom, setCustomFrom] = useState<string>(() =>
    toDateInputValue(startOfMonthLocal(now))
  );
  const [customTo, setCustomTo] = useState<string>(() => toDateInputValue(endOfDayLocal(now)));

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [sharingBusy, setSharingBusy] = useState(false);
  const [submitBusy, setSubmitBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [rows, setRows] = useState<ClosingSaleRow[]>([]);
  const [paymentSummary, setPaymentSummary] = useState<PaymentSummary>(EMPTY_PAYMENT_SUMMARY);

  const [openShift, setOpenShift] = useState<OpenShiftRow | null>(null);
  const [latestShift, setLatestShift] = useState<OpenShiftRow | null>(null);

  const [closingNote, setClosingNote] = useState("");
  const [reviewed, setReviewed] = useState(false);

  const [drawerCountDraft, setDrawerCountDraft] = useState("");
  const [closingSubmitted, setClosingSubmitted] = useState(false);
  const [submittedAt, setSubmittedAt] = useState<string | null>(null);

  const [cashierEmail, setCashierEmail] = useState<string>("—");

  const isCashier = String(activeRole ?? "").toLowerCase() === "cashier";
  const canView = useMemo(() => {
    const r = String(activeRole ?? "").toLowerCase();
    return r === "owner" || r === "admin" || r === "staff" || r === "cashier";
  }, [activeRole]);

  const ranges = useMemo(() => {
    const n = new Date();
    return {
      today: {
        from: startOfDayLocal(n).toISOString(),
        to: endOfDayLocal(n).toISOString(),
      },
      week: {
        from: startOfWeekMondayLocal(n).toISOString(),
        to: endOfDayLocal(n).toISOString(),
      },
      month: {
        from: startOfMonthLocal(n).toISOString(),
        to: endOfDayLocal(n).toISOString(),
      },
    };
  }, []);

  const resolvedRange = useMemo(() => {
    if (range !== "custom") return ranges[range];

    const fromDate = parseDateInputStart(customFrom);
    const toDate = parseDateInputEnd(customTo);

    if (!fromDate || !toDate) return null;
    if (fromDate.getTime() > toDate.getTime()) return null;

    return {
      from: fromDate.toISOString(),
      to: toDate.toISOString(),
    };
  }, [customFrom, customTo, range, ranges]);

  const customRangeError = useMemo(() => {
    if (range !== "custom") return null;

    const fromDate = parseDateInputStart(customFrom);
    const toDate = parseDateInputEnd(customTo);

    if (!fromDate || !toDate) return "Tumia format ya tarehe: YYYY-MM-DD";
    if (fromDate.getTime() > toDate.getTime()) {
      return "From Date haiwezi kuwa kubwa kuliko To Date";
    }
    return null;
  }, [customFrom, customTo, range]);

  const overdueShift = useMemo(() => {
    if (!openShift?.shift_id) return null;
    return isShiftOverdue(openShift.opened_at) ? openShift : null;
  }, [openShift]);

  const effectiveRange = useMemo(() => {
    if (overdueShift?.opened_at) {
      return buildShiftDayRange(overdueShift.opened_at);
    }
    return resolvedRange;
  }, [overdueShift?.opened_at, resolvedRange]);

  const effectiveRangeLabel = useMemo(() => {
    if (overdueShift?.opened_at) {
      const d = new Date(overdueShift.opened_at);
      return `Overdue Shift Day (${toDateInputValue(d)})`;
    }
    return labelForRange(range);
  }, [overdueShift?.opened_at, range]);

  const loadCurrentUserEmail = useCallback(async () => {
    try {
      const { data, error } = await supabase.auth.getUser();
      if (error) throw error;

      const email = String(data?.user?.email ?? "").trim();
      setCashierEmail(email || "—");
    } catch {
      setCashierEmail("—");
    }
  }, []);

  const load = useCallback(
    async (mode: "boot" | "refresh") => {
      setErr(null);
      if (mode === "boot") setLoading(true);
      if (mode === "refresh") setRefreshing(true);

      try {
        if (!activeStoreId) throw new Error("No active store selected.");
        if (!canView) throw new Error("No permission.");

        const access = await supabase.rpc("ensure_my_store_access", {
          p_store_id: activeStoreId,
        });
        if (access.error) throw access.error;

        let shiftRowNormalized: OpenShiftRow | null = null;
        let latestShiftNormalized: OpenShiftRow | null = null;

        if (isCashier) {
          const [openShiftRes, latestShiftRes] = await Promise.all([
            supabase.rpc("get_my_open_cashier_shift_v1", {
              p_store_id: activeStoreId,
            } as any),
            supabase.rpc("get_my_latest_cashier_shift_v1", {
              p_store_id: activeStoreId,
            } as any),
          ]);

          if (openShiftRes.error) throw openShiftRes.error;
          if (latestShiftRes.error) throw latestShiftRes.error;

          const openShiftRow = Array.isArray(openShiftRes.data)
            ? openShiftRes.data[0]
            : openShiftRes.data;

          const latestShiftRow = Array.isArray(latestShiftRes.data)
            ? latestShiftRes.data[0]
            : latestShiftRes.data;

          shiftRowNormalized = normalizeOpenShiftRow(openShiftRow);
          latestShiftNormalized = normalizeOpenShiftRow(latestShiftRow);

          setOpenShift(shiftRowNormalized);
          setLatestShift(latestShiftNormalized);

          if (shiftRowNormalized?.status === "OPEN") {
            setClosingSubmitted(false);
            setReviewed(false);
          } else if (latestShiftNormalized?.status === "CLOSED") {
            setClosingSubmitted(true);
            setReviewed(true);
          } else {
            setClosingSubmitted(false);
          }
        } else {
          setOpenShift(null);
          setLatestShift(null);
        }

        const shiftContext = shiftRowNormalized ?? latestShiftNormalized;

        const finalRange =
          shiftRowNormalized?.opened_at && isShiftOverdue(shiftRowNormalized.opened_at)
            ? buildShiftDayRange(shiftRowNormalized.opened_at)
            : resolvedRange;

        if (!finalRange) throw new Error("Invalid custom date range.");

        const useCashierScopedRpc = isCashier && !!shiftContext?.shift_id;

        const salesRes = useCashierScopedRpc
          ? await supabase.rpc("get_my_cashier_closing_sales_v1", {
              p_shift_id: shiftContext!.shift_id,
              p_from: finalRange.from,
              p_to: finalRange.to,
            } as any)
          : await supabase.rpc("get_sales_v2", {
              p_store_id: activeStoreId,
              p_from: finalRange.from,
              p_to: finalRange.to,
            } as any);

        if (salesRes.error) throw salesRes.error;

        const payRes = useCashierScopedRpc
          ? await supabase.rpc("get_my_cashier_closing_payment_summary_v1", {
              p_shift_id: shiftContext!.shift_id,
              p_from: finalRange.from,
              p_to: finalRange.to,
            } as any)
          : await supabase.rpc("get_sales_payment_summary_v1", {
              p_store_id: activeStoreId,
              p_from: finalRange.from,
              p_to: finalRange.to,
            } as any);

        if (payRes.error) throw payRes.error;

        const raw = (salesRes.data ?? []) as AnyRow[];
        const list = raw.map(normalizeSaleRow);

        list.sort((a, b) => {
          const ta = a.sold_at ? Date.parse(a.sold_at) : 0;
          const tb = b.sold_at ? Date.parse(b.sold_at) : 0;
          return tb - ta;
        });

        const payRow = Array.isArray(payRes.data) ? (payRes.data[0] ?? null) : payRes.data;

        setRows(list);
        setPaymentSummary({
          cash_total: toNum(payRow?.v_cash_total ?? payRow?.cash_total ?? 0),
          mobile_total: toNum(payRow?.v_mobile_total ?? payRow?.mobile_total ?? 0),
          bank_total: toNum(payRow?.v_bank_total ?? payRow?.bank_total ?? 0),
          credit_collected_total: toNum(
            payRow?.v_credit_collected_total ?? payRow?.credit_collected_total ?? 0
          ),
          grand_paid_total: toNum(payRow?.v_grand_paid_total ?? payRow?.grand_paid_total ?? 0),
          total_sales: toNum(payRow?.v_total_sales ?? payRow?.total_sales ?? 0),
          total_balance: toNum(payRow?.v_total_balance ?? payRow?.total_balance ?? 0),
        });

        if (!submittedAt && latestShiftNormalized?.closed_at) {
          setSubmittedAt(String(latestShiftNormalized.closed_at));
        }
      } catch (e: any) {
        setRows([]);
        setPaymentSummary(EMPTY_PAYMENT_SUMMARY);
        setErr(e?.message ?? "Failed to load cashier closing");
      } finally {
        if (mode === "boot") setLoading(false);
        if (mode === "refresh") setRefreshing(false);
      }
    },
    [activeStoreId, canView, isCashier, resolvedRange, submittedAt]
  );

  useEffect(() => {
    void loadCurrentUserEmail();
  }, [loadCurrentUserEmail]);

  useEffect(() => {
    void load("boot");
  }, [load]);

  useFocusEffect(
    useCallback(() => {
      void loadCurrentUserEmail();
      void load("refresh");
      return () => {};
    }, [load, loadCurrentUserEmail])
  );

  useEffect(() => {
    if (range === "custom") return;
    void load("refresh");
  }, [range, load]);

  const applyCustomRange = useCallback(() => {
    if (overdueShift?.shift_id) return;

    const fromDate = parseDateInputStart(customFrom);
    const toDate = parseDateInputEnd(customTo);

    if (!fromDate || !toDate) {
      setErr("Tumia format ya tarehe: YYYY-MM-DD");
      return;
    }

    if (fromDate.getTime() > toDate.getTime()) {
      setErr("From Date haiwezi kuwa kubwa kuliko To Date");
      return;
    }

    setErr(null);
    setRange("custom");
    void load("refresh");
  }, [customFrom, customTo, load, overdueShift?.shift_id]);

  const openReceipt = useCallback(
    (row: ClosingSaleRow) => {
      const saleId = String(row.sale_id ?? "").trim();
      if (!saleId) return;

      router.push({
        pathname: "/(tabs)/sales/receipt",
        params: { saleId },
      } as any);
    },
    [router]
  );

  const saleCount = rows.length;

  const totalQty = useMemo(() => rows.reduce((a, r) => a + toNum(r.total_qty ?? 0), 0), [rows]);

  const avgSale = useMemo(() => {
    if (saleCount <= 0) return 0;
    return paymentSummary.total_sales / saleCount;
  }, [paymentSummary.total_sales, saleCount]);

  const shiftContext = openShift ?? latestShift;

  const openingCash = useMemo(
    () => toNum(shiftContext?.opening_cash ?? 0),
    [shiftContext?.opening_cash]
  );

  const expectedDrawer = useMemo(() => {
    return openingCash + paymentSummary.cash_total;
  }, [openingCash, paymentSummary.cash_total]);

  const collectedNonCash = useMemo(() => {
    return paymentSummary.mobile_total + paymentSummary.bank_total;
  }, [paymentSummary.mobile_total, paymentSummary.bank_total]);

  const drawerCount = useMemo(() => {
    const raw = String(drawerCountDraft ?? "").trim();
    if (raw) return toNum(raw);
    return toNum(shiftContext?.drawer_count ?? 0);
  }, [drawerCountDraft, shiftContext?.drawer_count]);

  const drawerDifference = useMemo(() => {
    return drawerCount - expectedDrawer;
  }, [drawerCount, expectedDrawer]);

  const drawerDifferenceLabel = useMemo(() => {
    if (drawerDifference === 0) return "BALANCED";
    if (drawerDifference > 0) return "OVER";
    return "SHORT";
  }, [drawerDifference]);

  const closingStatusLabel = useMemo(() => {
    if (closingSubmitted) return "SUBMITTED";
    if (!openShift?.shift_id && latestShift?.status === "CLOSED") return "SUBMITTED";
    if (reviewed) return "REVIEWED";
    if (overdueShift?.shift_id) return "OVERDUE";
    return "OPEN";
  }, [closingSubmitted, latestShift?.status, openShift?.shift_id, overdueShift?.shift_id, reviewed]);

  const canSubmitClosing = useMemo(() => {
    if (loading || submitBusy) return false;
    if (!isCashier) return false;
    if (!openShift?.shift_id) return false;
    if (closingSubmitted) return false;
    if (drawerCountDraft.trim() === "") return false;
    return true;
  }, [closingSubmitted, drawerCountDraft, isCashier, loading, openShift?.shift_id, submitBusy]);

  const effectiveClosingNote = useMemo(() => {
    const draft = String(closingNote ?? "").trim();
    if (draft) return draft;
    return String(shiftContext?.closing_note ?? "").trim();
  }, [closingNote, shiftContext?.closing_note]);

  const rangeTextForPdf = useMemo(() => {
    if (overdueShift?.opened_at) {
      const r = buildShiftDayRange(overdueShift.opened_at);
      return `Overdue Shift Day (${safeWhenLabel(r.from)} → ${safeWhenLabel(r.to)})`;
    }

    if (range === "custom") {
      return `${customFrom || "—"} → ${customTo || "—"}`;
    }

    const label = labelForRange(range);
    const resolved = effectiveRange;
    if (!resolved) return label;
    return `${label} (${safeWhenLabel(resolved.from)} → ${safeWhenLabel(resolved.to)})`;
  }, [customFrom, customTo, effectiveRange, overdueShift?.opened_at, range]);

  const buildClosingHtml = useCallback(() => {
    const salesRowsHtml = rows
      .map((item, idx) => {
        const saleId = escapeHtml(String(item.sale_id ?? "").trim());
        const when = escapeHtml(safeWhenLabel(item.sold_at));
        const qty = escapeHtml(String(toNum(item.total_qty ?? 0)));
        const amount = escapeHtml(fmtMoney(toNum(item.total_amount ?? 0)));
        const method = escapeHtml(String(item.payment_method ?? "—").toUpperCase().trim() || "—");
        const channel = escapeHtml(String(item.payment_channel ?? "").trim());
        const paidIn = escapeHtml(fmtMoney(toNum(item.paid_amount ?? 0)));
        const balance = escapeHtml(fmtMoney(toNum(item.balance_amount ?? 0)));
        const status = escapeHtml(String(item.status ?? "COMPLETED").toUpperCase());

        return `
          <tr>
            <td>${idx + 1}</td>
            <td>${saleId || "—"}</td>
            <td>${when}</td>
            <td>${qty}</td>
            <td>${amount}</td>
            <td>${method}${channel ? ` • ${channel}` : ""}</td>
            <td>${paidIn}</td>
            <td>${balance}</td>
            <td>${status}</td>
          </tr>
        `;
      })
      .join("");

    return `
      <!DOCTYPE html>
      <html lang="${documentLocale().language}" dir="${documentLocale().direction}">
        <head>
          <meta charset="utf-8" />
          <title>${documentText("Cashier Closing")}</title>
          <style>
            body {
              font-family: Arial, Helvetica, sans-serif;
              padding: 24px;
              color: #111827;
            }
            h1 {
              margin: 0 0 4px 0;
              font-size: 26px;
            }
            .sub {
              color: #4b5563;
              font-size: 12px;
              margin-bottom: 20px;
            }
            .section-title {
              margin-top: 22px;
              margin-bottom: 10px;
              font-size: 16px;
              font-weight: 700;
            }
            .grid {
              width: 100%;
              border-collapse: collapse;
              margin-top: 8px;
            }
            .grid td, .grid th {
              border: 1px solid #d1d5db;
              padding: 8px;
              font-size: 12px;
              vertical-align: top;
            }
            .grid th {
              background: #f3f4f6;
              text-align: left;
            }
            .pill {
              display: inline-block;
              padding: 6px 10px;
              border-radius: 999px;
              background: #ecfdf5;
              border: 1px solid #10b981;
              color: #065f46;
              font-size: 12px;
              font-weight: 700;
            }
            .note-box {
              border: 1px solid #d1d5db;
              background: #f9fafb;
              border-radius: 12px;
              padding: 12px;
              font-size: 12px;
              white-space: pre-wrap;
              line-height: 1.5;
            }
            .two-col {
              width: 100%;
              border-collapse: separate;
              border-spacing: 10px 10px;
            }
            .metric {
              border: 1px solid #d1d5db;
              border-radius: 12px;
              padding: 12px;
            }
            .metric-title {
              font-size: 11px;
              color: #6b7280;
              margin-bottom: 6px;
            }
            .metric-value {
              font-size: 18px;
              font-weight: 700;
              color: #111827;
            }
            .metric-sub {
              font-size: 11px;
              color: #6b7280;
              margin-top: 6px;
            }
            .footer {
              margin-top: 22px;
              font-size: 11px;
              color: #6b7280;
            }
          </style>
        </head>
        <body>
          <h1>${documentText("Cashier Closing Summary")}</h1>
          <div class="sub">
            ${escapeHtml(activeOrgName ?? "—")} • ${escapeHtml(activeStoreName ?? "—")} • ${escapeHtml(activeRole ?? "—")}
          </div>

          <table class="grid">
            <tr>
              <th style="width: 180px;">${documentText("Organization")}</th>
              <td>${escapeHtml(activeOrgName ?? "—")}</td>
            </tr>
            <tr>
              <th>${documentText("Store")}</th>
              <td>${escapeHtml(activeStoreName ?? "—")}</td>
            </tr>
            <tr>
              <th>${documentText("Role")}</th>
              <td>${escapeHtml(activeRole ?? "—")}</td>
            </tr>
            <tr>
              <th>${documentText("Cashier Email")}</th>
              <td>${escapeHtml(cashierEmail)}</td>
            </tr>
            <tr>
              <th>${documentText("Report Generated By")}</th>
              <td>${escapeHtml(cashierEmail)}</td>
            </tr>
            <tr>
              <th>${documentText("Status")}</th>
              <td><span class="pill">${escapeHtml(closingStatusLabel)}</span></td>
            </tr>
            <tr>
              <th>${documentText("Range")}</th>
              <td>${escapeHtml(rangeTextForPdf)}</td>
            </tr>
            <tr>
              <th>${documentText("Shift Opened At")}</th>
              <td>${escapeHtml(shiftContext?.opened_at ? safeWhenLabel(shiftContext.opened_at) : "—")}</td>
            </tr>
            <tr>
              <th>${documentText("Opening Cash")}</th>
              <td>${escapeHtml(fmtMoney(openingCash))}</td>
            </tr>
            <tr>
              <th>${documentText("Drawer Count")}</th>
              <td>${escapeHtml(fmtMoney(drawerCount))}</td>
            </tr>
            <tr>
              <th>${documentText("Difference")}</th>
              <td>${escapeHtml(fmtMoney(drawerDifference))} (${escapeHtml(drawerDifferenceLabel)})</td>
            </tr>
            <tr>
              <th>${documentText("Submitted At")}</th>
              <td>${escapeHtml(submittedAt ? safeWhenLabel(submittedAt) : "—")}</td>
            </tr>
            <tr>
              <th>${documentText("Generated At")}</th>
              <td>${escapeHtml(new Date().toLocaleString())}</td>
            </tr>
          </table>

          <div class="section-title">${documentText("Closing Summary")}</div>
          <table class="two-col">
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Sales Count")}</div>
                <div class="metric-value">${escapeHtml(String(saleCount))}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Total Qty")}</div>
                <div class="metric-value">${escapeHtml(String(totalQty))}</div>
              </td>
            </tr>
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Total Sales")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.total_sales))}</div>
                <div class="metric-sub">${documentText("Mauzo yote ya range hii")}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Avg Sale")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(avgSale))}</div>
                <div class="metric-sub">${documentText("Wastani kwa sale")}</div>
              </td>
            </tr>
          </table>

          <div class="section-title">${documentText("Payment Breakdown")}</div>
          <table class="two-col">
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Cash Sales")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.cash_total))}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Mobile")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.mobile_total))}</div>
              </td>
            </tr>
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Bank")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.bank_total))}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Credit Collected")}</div>
                <div class="metric-value">${escapeHtml(
                  fmtMoney(paymentSummary.credit_collected_total)
                )}</div>
              </td>
            </tr>
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Grand Paid In")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.grand_paid_total))}</div>
                <div class="metric-sub">${documentText("Pesa iliyoingia kweli")}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Outstanding")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.total_balance))}</div>
                <div class="metric-sub">${documentText("Balance / mikopo")}</div>
              </td>
            </tr>
          </table>

          <div class="section-title">${documentText("Closing Review")}</div>
          <table class="two-col">
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Opening Cash")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(openingCash))}</div>
                <div class="metric-sub">${documentText("Cash ya kuanzia shift")}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Expected Cash Drawer")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(expectedDrawer))}</div>
                <div class="metric-sub">${documentText("Opening Cash + Cash Sales")}</div>
              </td>
            </tr>
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Drawer Count")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(drawerCount))}</div>
                <div class="metric-sub">${documentText("Cash halisi iliyohesabiwa")}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Difference")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(drawerDifference))}</div>
                <div class="metric-sub">${escapeHtml(drawerDifferenceLabel)}</div>
              </td>
            </tr>
            <tr>
              <td class="metric">
                <div class="metric-title">${documentText("Cash Sales Only")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(paymentSummary.cash_total))}</div>
                <div class="metric-sub">${documentText("Fedha ya cash kutoka mauzo tu")}</div>
              </td>
              <td class="metric">
                <div class="metric-title">${documentText("Non-Cash Collected")}</div>
                <div class="metric-value">${escapeHtml(fmtMoney(collectedNonCash))}</div>
                <div class="metric-sub">${documentText("Mobile + Bank")}</div>
              </td>
            </tr>
          </table>

          <div class="section-title">${documentText("Closing Note")}</div>
          <div class="note-box">${escapeHtml(effectiveClosingNote || "No closing note.")}</div>

          <div class="section-title">${documentText("Sales Included in This Closing")}</div>
          <table class="grid">
            <thead>
              <tr>
                <th>#</th>
                <th>${documentText("Sale ID")}</th>
                <th>${documentText("When")}</th>
                <th>${documentText("Qty")}</th>
                <th>${documentText("Amount")}</th>
                <th>${documentText("Method")}</th>
                <th>${documentText("Paid In")}</th>
                <th>${documentText("Balance")}</th>
                <th>${documentText("Status")}</th>
              </tr>
            </thead>
            <tbody>
              ${salesRowsHtml || `<tr><td colspan="9">${documentText("No sales found for this range.")}</td></tr>`}
            </tbody>
          </table>

          <div class="footer">
            ${documentText("ZETRA Cashier Closing • Drawer Count + Difference + Submit Closing • Cashier:")} ${escapeHtml(
              cashierEmail
            )}
          </div>
        </body>
      </html>
    `;
  }, [
    activeOrgName,
    activeRole,
    activeStoreName,
    avgSale,
    cashierEmail,
    closingStatusLabel,
    effectiveClosingNote,
    collectedNonCash,
    drawerCount,
    drawerDifference,
    drawerDifferenceLabel,
    expectedDrawer,
    fmtMoney,
    openingCash,
    shiftContext?.opened_at,
    paymentSummary.cash_total,
    paymentSummary.mobile_total,
    paymentSummary.bank_total,
    paymentSummary.credit_collected_total,
    paymentSummary.grand_paid_total,
    paymentSummary.total_balance,
    paymentSummary.total_sales,
    rangeTextForPdf,
    rows,
    saleCount,
    submittedAt,
    totalQty,
  ]);

  const handleShareClosingPdf = useCallback(async () => {
    if (sharingBusy) return;

    try {
      setSharingBusy(true);

      const available = await Sharing.isAvailableAsync();
      if (!available) {
        Alert.alert(uiText("Unavailable"), uiText("Sharing haipatikani kwenye kifaa hiki."));
        return;
      }

      const html = buildClosingHtml();

      const file = await Print.printToFileAsync({
        html,
        base64: false,
      });

      if (!file?.uri) {
        throw new Error("PDF URI not returned");
      }

      await Sharing.shareAsync(file.uri, {
        mimeType: "application/pdf",
        dialogTitle: "Share Cashier Closing PDF",
        UTI: "com.adobe.pdf",
      });
    } catch (e: any) {
      Alert.alert(uiText("Share failed"), e?.message ?? uiText("Imeshindikana kutengeneza au kushare PDF."));
    } finally {
      setSharingBusy(false);
    }
  }, [buildClosingHtml, sharingBusy]);

  const closeShiftInDb = useCallback(async () => {
    if (!openShift?.shift_id) {
      throw new Error("No open shift found.");
    }

    const payload = {
      p_shift_id: openShift.shift_id,
      p_drawer_count: drawerCount,
      p_closing_note: String(closingNote ?? "").trim() || null,
    };

    const { error } = await supabase.rpc(CLOSE_SHIFT_RPC, payload as any);
    if (error) throw error;
  }, [closingNote, drawerCount, openShift?.shift_id]);

  const handleSubmitClosing = useCallback(() => {
    if (!canSubmitClosing) return;

    const diff = drawerDifference;
    const diffAbs = Math.abs(diff);
    const diffLabel = diff === 0 ? "BALANCED" : diff > 0 ? "OVER" : "SHORT";

    Alert.alert(
      uiText("Submit Closing"),
      uiText("Expected Drawer: {p0}\nDrawer Count: {p1}\nDifference: {p2} ({p3})\n\nUna uhakika unataka kufunga closing hii?", {p0: (fmtMoney(expectedDrawer)), p1: (fmtMoney(
        drawerCount
      )), p2: (fmtMoney(diff)), p3: (diffLabel)}),
      [
        { text: uiText("Cancel"), style: "cancel" },
        {
          text: uiText("Submit"),
          onPress: async () => {
            try {
              setSubmitBusy(true);

              await closeShiftInDb();

              const nowIso = new Date().toISOString();

              if (openShift) {
                setLatestShift({
                  ...openShift,
                  status: "CLOSED",
                  closed_at: nowIso,
                  drawer_count: drawerCount,
                  closing_note: String(closingNote ?? "").trim() || null,
                });
              }

              setOpenShift(null);
              setClosingSubmitted(true);
              setReviewed(true);
              setSubmittedAt(nowIso);

              setDrawerCountDraft("");
              setClosingNote("");

              await load("refresh");

              if (diffAbs > 0) {
                Alert.alert(
                  uiText("Closing Submitted ✅"),
                  uiText("Closing imefungwa vizuri.\n\nDifference: {p0} ({p1})", {p0: (fmtMoney(diff)), p1: (diffLabel)})
                );
              } else {
                Alert.alert(
                  uiText("Closing Submitted ✅"),
                  uiText("Closing imefungwa vizuri na shift iliyofungwa imeondolewa kwenye open state.")
                );
              }
            } catch (e: any) {
              Alert.alert(
                uiText("Closing Failed"),
                e?.message ??
                  uiText("Imeshindikana kufunga shift. Hakikisha RPC \"{p0}\" ipo sahihi kwenye DB.", {p0: (CLOSE_SHIFT_RPC)})
              );
            } finally {
              setSubmitBusy(false);
            }
          },
        },
      ]
    );
  }, [
    canSubmitClosing,
    closeShiftInDb,
    drawerCount,
    drawerDifference,
    expectedDrawer,
    fmtMoney,
    load,
  ]);

  const SegButton = useCallback(
    ({ k, label }: { k: RangeKey; label: string }) => {
      const active = range === k;
      const disabled = closingSubmitted || !!overdueShift?.shift_id;

      return (
        <Pressable
          onPress={() => setRange(k)}
          disabled={disabled}
          style={{
            flex: 1,
            paddingVertical: 10,
            borderRadius: 999,
            alignItems: "center",
            justifyContent: "center",
            borderWidth: 1,
            borderColor: active ? theme.colors.emeraldBorder : theme.colors.border,
            backgroundColor: active ? theme.colors.emeraldSoft : "rgba(255,255,255,0.06)",
            opacity: disabled ? 0.65 : 1,
          }}
        >
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{label}</Text>
        </Pressable>
      );
    },
    [closingSubmitted, overdueShift?.shift_id, range]
  );

  const Header = useMemo(() => {
    return (
      <View style={{ gap: 14, paddingBottom: 10 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <Pressable
            onPress={() => router.back()}
            style={{
              width: 44,
              height: 44,
              borderRadius: 999,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: theme.colors.border,
              backgroundColor: "rgba(255,255,255,0.06)",
            }}
          >
            <Ionicons name="chevron-back" size={22} color={theme.colors.text} />
          </Pressable>

          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 26, fontWeight: "900", color: theme.colors.text }}>
              {uiText("Cashier Closing")}</Text>
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {activeOrgName ?? "—"} • {activeStoreName ?? uiText("No store")} • {activeRole ?? "—"}
            </Text>
            <Text style={{ color: theme.colors.muted, fontWeight: "800", fontSize: 12 }}>
              {cashierEmail !== "—" ? uiText("Cashier Email: {p0}", {p0: (cashierEmail)}) : uiText("Cashier Email: —")}
            </Text>
            <Text style={{ color: theme.colors.muted, fontWeight: "800", fontSize: 12 }}>
              {isOffline ? uiText("OFFLINE") : uiText("ONLINE")}
            </Text>
          </View>

          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              borderRadius: 999,
              borderWidth: 1,
              borderColor:
                closingSubmitted || reviewed || overdueShift?.shift_id
                  ? theme.colors.emeraldBorder
                  : theme.colors.border,
              backgroundColor:
                closingSubmitted || reviewed || overdueShift?.shift_id
                  ? theme.colors.emeraldSoft
                  : "rgba(255,255,255,0.06)",
            }}
          >
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
              {closingStatusLabel}
            </Text>
          </View>
        </View>

        {!!overdueShift?.shift_id && (
          <Card
            style={{
              gap: 8,
              borderColor: "rgba(245,158,11,0.35)",
              backgroundColor: "rgba(245,158,11,0.08)",
            }}
          >
            <Text style={{ color: "#f59e0b", fontWeight: "900", fontSize: 16 }}>
              {uiText("OVERDUE SHIFT ENFORCEMENT")}</Text>
            <Text style={{ color: theme.colors.text, fontWeight: "800" }}>
              {uiText("Shift ya zamani bado OPEN, kwa hiyo mfumo ume-lock range na unasoma mauzo ya siku ile shift ilipoanza.")}</Text>
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {uiText("Shift Opened At:")}{safeWhenLabel(overdueShift.opened_at)}
            </Text>
          </Card>
        )}

        <Card style={{ gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Range")}</Text>

          <View style={{ flexDirection: "row", gap: 10 }}>
            <SegButton k="today" label={uiText("Today")} />
            <SegButton k="week" label={uiText("Week")} />
            <SegButton k="month" label={uiText("Month")} />
            <SegButton k="custom" label={uiText("Custom")} />
          </View>

          {!!overdueShift?.shift_id && (
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {uiText("Range imefungwa kwa siku ya overdue shift mpaka shift hiyo ifungiwe closing.")}</Text>
          )}

          {range === "custom" && !overdueShift?.shift_id && (
            <View style={{ gap: 10 }}>
              <View>
                <InputLabel>{uiText("From Date")}</InputLabel>
                <InputBox
                  value={customFrom}
                  onChangeText={setCustomFrom}
                  placeholder="YYYY-MM-DD"
                  editable={!closingSubmitted}
                />
              </View>

              <View>
                <InputLabel>{uiText("To Date")}</InputLabel>
                <InputBox
                  value={customTo}
                  onChangeText={setCustomTo}
                  placeholder="YYYY-MM-DD"
                  editable={!closingSubmitted}
                />
              </View>

              {!!customRangeError && (
                <Text style={{ color: theme.colors.danger, fontWeight: "800" }}>
                  {customRangeError}
                </Text>
              )}

              <Button
                title={uiText("Apply Custom Range")}
                onPress={applyCustomRange}
                disabled={!!customRangeError || closingSubmitted}
                variant="secondary"
              />
            </View>
          )}

          <Button
            title={refreshing ? uiText("Refreshing...") : uiText("Refresh")}
            onPress={() => load("refresh")}
            disabled={refreshing || (range === "custom" && !!customRangeError)}
            variant="primary"
          />

          {!!err && <Text style={{ color: theme.colors.danger, fontWeight: "800" }}>{systemText(err)}</Text>}
        </Card>

        <Text style={{ fontWeight: "900", fontSize: 16, color: theme.colors.text }}>{uiText("Closing Summary ({p0})", {p0: (effectiveRangeLabel)})}</Text>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard title={uiText("Sales Count")} amount={String(saleCount)} />
          <MetricCard title={uiText("Total Qty")} amount={String(totalQty)} />
        </View>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard
            title={uiText("TOTAL SALES")}
            amount={fmtMoney(paymentSummary.total_sales)}
            subtitle={uiText("Mauzo yote ya range hii")}
          />
          <MetricCard title={uiText("AVG SALE")} amount={fmtMoney(avgSale)} subtitle={uiText("Wastani kwa sale")} />
        </View>

        <Text style={{ fontWeight: "900", fontSize: 16, color: theme.colors.text }}>
          {uiText("Payment Breakdown")}</Text>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard title={uiText("Cash Sales")} amount={fmtMoney(paymentSummary.cash_total)} />
          <MetricCard title={uiText("Mobile")} amount={fmtMoney(paymentSummary.mobile_total)} />
        </View>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard title={uiText("Bank")} amount={fmtMoney(paymentSummary.bank_total)} />
          <MetricCard
            title={uiText("Credit Collected")}
            amount={fmtMoney(paymentSummary.credit_collected_total)}
          />
        </View>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard
            title={uiText("Grand Paid In")}
            amount={fmtMoney(paymentSummary.grand_paid_total)}
            subtitle={uiText("Pesa iliyoingia kweli")}
          />
          <MetricCard
            title={uiText("Outstanding")}
            amount={fmtMoney(paymentSummary.total_balance)}
            subtitle={uiText("Balance / mikopo")}
          />
        </View>

        <Text style={{ fontWeight: "900", fontSize: 16, color: theme.colors.text }}>
          {uiText("Closing Review")}</Text>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard
            title={uiText("Opening Cash")}
            amount={fmtMoney(openingCash)}
            subtitle={uiText("Cash ya kuanzia shift")}
          />
          <MetricCard
            title={uiText("Expected Cash Drawer")}
            amount={fmtMoney(expectedDrawer)}
            subtitle={uiText("Opening Cash + Cash Sales")}
          />
        </View>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <MetricCard
            title={uiText("Cash Sales Only")}
            amount={fmtMoney(paymentSummary.cash_total)}
            subtitle={uiText("Fedha ya cash kutoka mauzo tu")}
          />
          <MetricCard
            title={uiText("Non-Cash Collected")}
            amount={fmtMoney(collectedNonCash)}
            subtitle={uiText("Mobile + Bank")}
          />
        </View>

        {!!shiftContext?.opened_at && (
          <Card style={{ gap: 8 }}>
            <Text style={{ color: UI.text, fontWeight: "900" }}>
              {shiftContext?.status === "OPEN" ? uiText("Active Shift") : uiText("Latest Shift")}
            </Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Shift Opened At:")}{safeWhenLabel(shiftContext.opened_at)}
            </Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Shift Closed At:")}{shiftContext.closed_at ? safeWhenLabel(shiftContext.closed_at) : "—"}
            </Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Opening Cash iliyotumika kwenye hesabu hii:")}{fmtMoney(openingCash)}
            </Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Drawer Count ya shift:")}{fmtMoney(toNum(shiftContext.drawer_count ?? 0))}
            </Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Cashier Email:")}{cashierEmail}
            </Text>
          </Card>
        )}

        <Card style={{ gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
            {uiText("Drawer Count & Difference")}</Text>

          <View>
            <InputLabel>{uiText("Drawer Count (cash halisi uliyohesabu)")}</InputLabel>
            <InputBox
              value={drawerCountDraft}
              onChangeText={(t) => setDrawerCountDraft(normalizeMoneyInput(t))}
              placeholder={uiText("mf: 125000")}
              editable={!closingSubmitted}
              keyboardType="numeric"
            />
          </View>

          <View style={{ flexDirection: "row", gap: 10 }}>
            <MetricCard
              title={uiText("DRAWER COUNT")}
              amount={fmtMoney(drawerCount)}
              subtitle={uiText("Cash halisi kwenye drawer")}
            />
            <MetricCard
              title={uiText("DIFFERENCE")}
              amount={fmtMoney(drawerDifference)}
              subtitle={drawerDifferenceLabel}
            />
          </View>

          <Text
            style={{
              color:
                drawerDifference === 0
                  ? UI.emerald
                  : drawerDifference > 0
                    ? "#f59e0b"
                    : "#ef4444",
              fontWeight: "900",
              fontSize: 12,
            }}
          >
            {drawerDifference === 0
              ? uiText("Drawer ime-balance vizuri.")
              : drawerDifference > 0
                ? uiText("Drawer ina excess cash kuliko ilivyotarajiwa.")
                : uiText("Drawer ina upungufu wa cash kuliko ilivyotarajiwa.")}
          </Text>
        </Card>

        <Card style={{ gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Closing Note")}</Text>

          <InputBox
            value={closingNote}
            onChangeText={setClosingNote}
            placeholder={uiText("andika maelezo ya closing hapa...")}
            multiline
            editable={!closingSubmitted}
          />

          <View style={{ flexDirection: "row", gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Button
                title={reviewed ? uiText("Reviewed ✅") : uiText("Mark as Reviewed")}
                onPress={() => {
                  if (reviewed) {
                    Alert.alert(uiText("Already reviewed"), uiText("Closing hii tayari imewekewa reviewed."));
                    return;
                  }
                  setReviewed(true);
                  Alert.alert(uiText("Reviewed ✅"), uiText("Cashier Closing imewekwa reviewed kwa UI ya sasa."));
                }}
                disabled={reviewed || closingSubmitted}
                variant="primary"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Button
                title={sharingBusy ? uiText("Preparing PDF...") : uiText("Share Closing PDF")}
                onPress={() => {
                  void handleShareClosingPdf();
                }}
                disabled={sharingBusy || loading}
                variant="secondary"
              />
            </View>
          </View>

          <Button
            title={
              submitBusy
                ? uiText("Submitting...")
                : closingSubmitted
                  ? uiText("Closing Submitted ✅")
                  : overdueShift?.shift_id
                    ? uiText("Submit Overdue Closing")
                    : uiText("Submit Closing")
            }
            onPress={handleSubmitClosing}
            disabled={!canSubmitClosing}
            variant="primary"
          />

          {!!submittedAt && (
            <Text style={{ color: theme.colors.muted, fontWeight: "800", fontSize: 12 }}>
              {uiText("Submitted At:")}{safeWhenLabel(submittedAt)}
            </Text>
          )}

          <Text style={{ color: theme.colors.muted, fontWeight: "800", fontSize: 12 }}>
            {uiText("Cashier Email:")}{cashierEmail}
          </Text>

          <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12 }}>
            {uiText("Hii hatua imefunga enterprise control ya UI: Drawer Count + Difference + Submit Closing.")}</Text>
        </Card>

        {!isCashier && (
          <Card style={{ gap: 8, borderColor: "rgba(245,158,11,0.30)" }}>
            <Text style={{ color: UI.text, fontWeight: "900" }}>{uiText("Note")}</Text>
            <Text style={{ color: UI.muted, fontWeight: "800" }}>
              {uiText("Hii screen imewekwa ndani ya Cashier Closing, lakini kwa sasa opening cash itapatikana kwa cashier aliyefungua shift kwenye store hii. Kwa owner/admin ambaye si cashier, metric ya opening cash inaweza kuwa 0 kama hakuna shift yake mwenyewe wazi.")}</Text>
          </Card>
        )}

        <Text style={{ fontWeight: "900", fontSize: 16, color: theme.colors.text }}>
          {uiText("Sales Included in This Closing")}</Text>

        <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
          {uiText("Hizi ni sale records zilizoingia kwenye closing summary ya juu.")}</Text>

        {loading && (
          <View style={{ paddingTop: 10, alignItems: "center" }}>
            <ActivityIndicator />
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {uiText("Loading closing data...")}</Text>
          </View>
        )}
      </View>
    );
  }, [SegButton, activeOrgName, activeRole, activeStoreName, applyCustomRange, avgSale, canSubmitClosing, cashierEmail, closingStatusLabel, effectiveClosingNote, closingSubmitted, collectedNonCash, customFrom, customRangeError, customTo, drawerCount, drawerDifference, drawerDifferenceLabel, effectiveRangeLabel, err, expectedDrawer, fmtMoney, handleShareClosingPdf, handleSubmitClosing, isCashier, isOffline, load, loading, openingCash, overdueShift?.shift_id, shiftContext?.opened_at, shiftContext?.closed_at, shiftContext?.drawer_count, shiftContext?.status, paymentSummary.bank_total, paymentSummary.cash_total, paymentSummary.credit_collected_total, paymentSummary.grand_paid_total, paymentSummary.mobile_total, paymentSummary.total_balance, paymentSummary.total_sales, range, refreshing, reviewed, router, saleCount, sharingBusy, submitBusy, submittedAt, totalQty, uiText, systemText]);

  return (
    <Screen scroll={false}>
      <FlatList
        style={{ flex: 1 }}
        data={loading ? [] : rows}
        keyExtractor={(item, idx) => String(item.sale_id ?? idx)}
        refreshing={refreshing}
        onRefresh={() => load("refresh")}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={Header}
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => {
          const saleId = String(item.sale_id ?? "").trim();
          const when = safeWhenLabel(item.sold_at);
          const qty = toNum(item.total_qty ?? 0);
          const amount = toNum(item.total_amount ?? 0);
          const status = String(item.status ?? "COMPLETED").toUpperCase();
          const method = String(item.payment_method ?? "").toUpperCase().trim();
          const channel = String(item.payment_channel ?? "").trim();
          const paidAmount = toNum(item.paid_amount ?? 0);
          const balanceAmount = toNum(item.balance_amount ?? 0);

          return (
            <Pressable onPress={() => openReceipt(item)}>
              <Card style={{ marginBottom: 12, gap: 10 }}>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 10,
                  }}
                >
                  <Text
                    style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16, flex: 1 }}
                    numberOfLines={1}
                  >
                    {uiText("Sale")}{saleId ? saleId.slice(0, 8) : "—"}
                  </Text>

                  <View
                    style={{
                      paddingHorizontal: 10,
                      paddingVertical: 6,
                      borderRadius: 999,
                      borderWidth: 1,
                      borderColor: theme.colors.emeraldBorder,
                      backgroundColor: theme.colors.emeraldSoft,
                    }}
                  >
                    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText(status)}</Text>
                  </View>
                </View>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("When:")}<Text style={{ color: theme.colors.text }}>{when}</Text>
                </Text>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Qty:")}<Text style={{ color: theme.colors.text }}>{qty}</Text>
                  {"   "}•{"   "}
                  {uiText("Amount:")}<Text style={{ color: theme.colors.text }}>{fmtMoney(amount)}</Text>
                </Text>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Method:")}<Text style={{ color: theme.colors.text }}>{method || "—"}</Text>
                  {channel ? <Text style={{ color: theme.colors.text }}> • {channel}</Text> : null}
                </Text>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Paid In:")}<Text style={{ color: theme.colors.text }}>{fmtMoney(paidAmount)}</Text>
                  {"   "}•{"   "}
                  {uiText("Balance:")}{" "}
                  <Text style={{ color: theme.colors.text }}>{fmtMoney(balanceAmount)}</Text>
                </Text>

                <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
                  {uiText("Cashier Email:")}<Text style={{ color: theme.colors.text }}>{cashierEmail}</Text>
                </Text>

                <Text
                  style={{
                    color: theme.colors.muted,
                    fontWeight: "800",
                    textDecorationLine: "underline",
                  }}
                >
                  {uiText("Open Receipt")}</Text>
              </Card>
            </Pressable>
          );
        }}
        ListEmptyComponent={
          !loading ? (
            <View style={{ paddingTop: 16, alignItems: "center" }}>
              <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("No sales ({p0}).", {p0: (effectiveRangeLabel)})}</Text>
            </View>
          ) : null
        }
      />
    </Screen>
  );
}