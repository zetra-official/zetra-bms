import React from 'react';
import { Platform } from 'react-native';
import { usePathname, useSegments } from 'expo-router';
import Head from 'expo-router/head';

/** Search presentation only; authorization remains in AuthGate and backend RLS. */
export function WebSearchMetadata() {
  const pathname = usePathname();
  const segments = useSegments() as string[];
  if (Platform.OS !== 'web') return null;
  const publicLogin = pathname === '/login' || (pathname === '/' && segments.length === 0);
  return <Head>
    <title>{publicLogin ? 'ZETRA BMS | Business Management System' : 'ZETRA BMS'}</title>
    <meta name="robots" content={publicLogin ? 'index, follow' : 'noindex, nofollow'} />
    {publicLogin ? <meta name="description" content="Sign in to ZETRA BMS to manage your business, sales, inventory, customers and financial reports in one secure workspace." /> : null}
    {publicLogin ? <link rel="canonical" href="https://app.zetra.tz/login" /> : null}
  </Head>;
}

