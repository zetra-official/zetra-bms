// Public entry renders the canonical login immediately. Root AuthGate alone restores
// sessions and routes verified users using OrgProvider's canonical organization state.
export {default} from './(auth)/login';
