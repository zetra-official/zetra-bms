import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import type { Ionicons as ExpoIonicons } from '@expo/vector-icons';
import SafeIcon from './SafeIcon';
import glyphs from '@expo/vector-icons/build/vendor/react-native-vector-icons/glyphmaps/Ionicons.json';

type Props = React.ComponentProps<typeof ExpoIonicons>;
const family = 'ZetraBusinessIonicons';
const source = require('@expo/vector-icons/build/vendor/react-native-vector-icons/Fonts/Ionicons.ttf');
let face: FontFace | undefined;
let pending: Promise<void> | undefined;
let loaded = false;

function load(): Promise<void> {
  if (loaded) return Promise.resolve();
  if (pending) return pending;
  // Use the browser's actual font load, not Expo's six-second observer race.
  // The identical bundled glyphs/asset are retained; no network request to an API.
  pending = (async () => {
    const uri = typeof source === 'string' ? source : source.default ?? source.uri;
    if (!uri || typeof FontFace === 'undefined') throw new Error('Browser font loading unavailable');
    face = new FontFace(family, `url(${JSON.stringify(uri)})`);
    await face.load();
    // React Native's bundled DOM declaration omits FontFaceSet's standard add().
    const fonts = document.fonts as FontFaceSet & { add(font: FontFace): FontFaceSet };
    fonts.add(face);
    loaded = true;
  })().finally(() => { pending = undefined; });
  return pending;
}

export default function BusinessIonicons({ name, size = 24, color, style, ...props }: Props) {
  const [ready, setReady] = useState(loaded);
  useEffect(() => {
    let active = true;
    const start = () => {
      void load().then(() => { if (active) setReady(true); }).catch(error => {
        // A real failed download has an SVG fallback and can recover on reconnect.
        // Keep the failure observable; never turn it into an uncaught mount promise.
        console.warn('Business icon font unavailable; SVG fallback active', error);
        if (active) setReady(false);
      });
    };
    start();
    window.addEventListener('online', start);
    return () => { active = false; window.removeEventListener('online', start); };
  }, []);

  if (!ready) {
    return <View {...props as any} style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
      <SafeIcon name={name} size={size} color={typeof color === 'string' ? color : undefined} />
    </View>;
  }
  return <Text {...props} style={[{ fontSize: size, color, fontFamily: family, fontWeight: 'normal', fontStyle: 'normal' }, style]}>
    {String.fromCodePoint(glyphs[name])}
  </Text>;
}
