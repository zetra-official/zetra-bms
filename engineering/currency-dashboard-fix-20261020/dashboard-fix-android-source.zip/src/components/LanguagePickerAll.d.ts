import type {ComponentType} from 'react';
export declare const LanguagePickerAll:ComponentType<{value:string|null;onChange:(locale:string)=>void;title?:string;disabled?:boolean;hint?:string}>;
