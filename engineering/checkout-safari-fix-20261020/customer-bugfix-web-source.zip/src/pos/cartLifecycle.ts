/** Device cart lifecycle only. Never financial state or a source of product prices. */
export type CartScope={organizationId:string;storeId:string;actorId:string};
export type CartStorage={getItem(k:string):Promise<string|null>;setItem(k:string,v:string):Promise<void>};
export function scopedCartKey(s:CartScope){if(!s.organizationId||!s.storeId||!s.actorId)throw Error('CART_SCOPE_REQUIRED');return `sales_cart_v2_${s.actorId}_${s.organizationId}_${s.storeId}`}
const pending=new Map<string,Promise<void>>();
export function writeCart(storage:CartStorage,key:string,items:readonly unknown[]){
 const value=JSON.stringify(items),previous=pending.get(key)??Promise.resolve();
 const next=previous.catch(()=>{}).then(()=>storage.setItem(key,value));pending.set(key,next);
 void next.finally(()=>{if(pending.get(key)===next)pending.delete(key)}).catch(()=>{});return next;
}
export async function readCart(storage:CartStorage,key:string){await pending.get(key)?.catch(()=>{});const raw=await storage.getItem(key);if(raw===null)return [];const value=JSON.parse(raw);if(!Array.isArray(value))throw Error('INVALID_CART_STORAGE');return value}
export function consumeUnchangedCart(storage:CartStorage,key:string,signature:(items:any[])=>string,expected:string){
 let cleared=false;const previous=pending.get(key)??Promise.resolve();
 const next=previous.catch(()=>{}).then(async()=>{const raw=await storage.getItem(key),items=raw?JSON.parse(raw):[];if(Array.isArray(items)&&signature(items)===expected){await storage.setItem(key,'[]');cleared=true}});
 pending.set(key,next);void next.finally(()=>{if(pending.get(key)===next)pending.delete(key)}).catch(()=>{});return next.then(()=>cleared);
}
export class CartLifecycle<T>{
 key='';items:T[]=[];private version=0;private generation=0;
 activate(key:string){if(key!==this.key){this.key=key;this.items=[];this.version++;this.generation++}return this.items}
 invalidate(){this.generation++}
 update(change:T[]|((previous:T[])=>T[])){this.version++;this.items=typeof change==='function'?change(this.items):change;return this.items}
 async restore(load:()=>Promise<T[]>){const v=this.version,g=++this.generation;const rows=await load();if(g!==this.generation||v!==this.version)return false;this.items=rows;return true}
}
/** Full-array validation: do not silently drop rows or change quantities/prices. */
export function parseCheckoutCart(raw:unknown){
 if(typeof raw!=='string'||!raw)return [];
 let source=raw,value:unknown;
 for(let n=0;n<3;n++){try{value=JSON.parse(source);break}catch{try{const next=decodeURIComponent(source);if(next===source)break;source=next}catch{break}}}
 if(!Array.isArray(value))return [];
 if(value.some(x=>!x||typeof x.product_id!=='string'||!x.product_id||!Number.isFinite(Number(x.qty))||Number(x.qty)<=0||!Number.isFinite(Number(x.unit_price))||Number(x.unit_price)<=0||!Number.isFinite(Number(x.extra_per_qty??0))||Number(x.unit_price)+Number(x.extra_per_qty??0)<=0))return [];
 return value.map(x=>({...x,qty:Number(x.qty),unit_price:Number(x.unit_price),extra_per_qty:Number(x.extra_per_qty??0),line_total:(Number(x.unit_price)+Number(x.extra_per_qty??0))*Number(x.qty)}));
}
