/* Public asset delivery only. No authentication, storage, API or financial calls. */
(() => {
  'use strict';
  const config = __ZETRA_BUNDLE_CONFIG__;
  function start() {
    const source = new URL(config.url, location.href);
    if (source.origin !== location.origin || !/^\/_expo\/static\/js\/web\/entry-[a-f0-9]+\.js$/.test(source.pathname)) return;
    let running = false, executed = false, failedExecution = false;
    const retainedParts = new Map();
    const panel = document.createElement('section');
    panel.setAttribute('role', 'status');
    panel.setAttribute('aria-live', 'polite');
    panel.dataset.zetraBootstrap = 'downloading';
    panel.style.cssText = 'position:fixed;z-index:2147483647;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;padding:28px;background:#071523;color:#e5f1fc;font:16px/1.6 system-ui;text-align:center;box-sizing:border-box';
    const message = document.createElement('p');
    const retry = document.createElement('button');
    retry.textContent = 'Retry loading / Jaribu tena';
    retry.style.cssText = 'min-height:48px;padding:12px 24px;border:0;border-radius:12px;background:#20d39b;color:#04251c;font:700 16px system-ui;cursor:pointer';
    retry.hidden = true;
    panel.append(message, retry);
    document.body.append(panel);
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    async function download() {
      if (running || executed) return;
      running = true;
      retry.hidden = true;
      panel.dataset.zetraBootstrap = 'downloading';
      message.textContent = 'Loading application… 0% / Inapakia…';
      const controllers = new Set();
      let stopped = false;
      const budget = setTimeout(() => {stopped = true; for (const controller of controllers) controller.abort();}, 240000);
      try {
        if (!globalThis.crypto?.subtle) throw Error('SECURE_INTEGRITY_UNAVAILABLE');
        let full;
        // Preserve the browser's normal compressed/cacheable download on healthy connections.
        if (!retainedParts.size) {
          const controller = new AbortController();controllers.add(controller);
          const timer = setTimeout(() => controller.abort(), 30000);
          try {
            const response = await fetch(source.href, {credentials: 'omit', signal: controller.signal});
            if (response.status !== 200) throw Error('FULL_ASSET_UNAVAILABLE');
            full = new Uint8Array(await response.arrayBuffer());
            if (full.length !== config.bytes) throw Error('INCOMPLETE_FULL_ASSET');
          } catch (error) {full = undefined; if (stopped) throw error;}
          finally {clearTimeout(timer);controllers.delete(controller);}
        }
        const chunkSize = 262144, count = Math.ceil(config.bytes / chunkSize);
        const parts = new Array(count);
        let cursor = 0, completed = 0;
        for (const [index, bytes] of retainedParts) {parts[index] = bytes; completed += bytes.length;}
        async function part(index) {
          if (parts[index]) return;
          const first = index * chunkSize, last = Math.min(config.bytes - 1, first + chunkSize - 1);
          let failure;
          for (let attempt = 0; attempt < 3 && !stopped; attempt++) {
            const controller = new AbortController();
            controllers.add(controller);
            const timer = setTimeout(() => controller.abort(), 60000);
            try {
              const response = await fetch(source.href, {headers: {Range: `bytes=${first}-${last}`}, credentials: 'omit', signal: controller.signal});
              if (response.status !== 206 || response.headers.get('Content-Range') !== `bytes ${first}-${last}/${config.bytes}`) throw Error('INCOMPLETE_ASSET_RANGE');
              const bytes = new Uint8Array(await response.arrayBuffer());
              if (bytes.length !== last - first + 1) throw Error('INCOMPLETE_ASSET_BYTES');
              parts[index] = bytes;retainedParts.set(index, bytes);
              completed += bytes.length;
              message.textContent = `Loading application… ${Math.floor(completed * 100 / config.bytes)}% / Inapakia…`;
              return;
            } catch (error) {
              failure = error;
              if (attempt < 2 && !stopped) await wait(250 * (attempt + 1));
            } finally {
              clearTimeout(timer);
              controllers.delete(controller);
            }
          }
          throw failure || Error('ASSET_DOWNLOAD_STOPPED');
        }
        let downloadError;
        if (!full) await Promise.all(Array.from({length: Math.min(4, count)}, async () => {
          try {
            while (!stopped && cursor < count) await part(cursor++);
          } catch (error) {
            downloadError ||= error;
            stopped = true;
            for (const controller of controllers) controller.abort();
          }
        }));
        if (downloadError) throw downloadError;
        const bytes = full || new Uint8Array(config.bytes);
        if (!full) parts.forEach((part, index) => bytes.set(part, index * chunkSize));
        const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(b => b.toString(16).padStart(2, '0')).join('');
        if (digest !== config.sha256) {retainedParts.clear();throw Error('ASSET_INTEGRITY_FAILED');}
        retainedParts.clear();
        panel.dataset.zetraBootstrap = 'verified';
        message.textContent = 'Opening your workspace… / Inafungua sehemu yako ya kazi…';
        executed = true;
        const blobUrl = URL.createObjectURL(new Blob([bytes], {type: 'application/javascript'}));
        const script = document.createElement('script');
        script.src = blobUrl;
        const executionFailed = () => {
          failedExecution = true;
          URL.revokeObjectURL(blobUrl);
          panel.dataset.zetraBootstrap = 'execution-failed';
          message.textContent = 'Application could not start. Reload this page. / Pakia ukurasa upya.';
          retry.textContent = 'Reload page / Pakia upya';
          retry.hidden = false;
        };
        const runtimeError = event => {if (event.filename === blobUrl) executionFailed();};
        window.addEventListener('error', runtimeError);
        script.onload = () => {window.removeEventListener('error', runtimeError); URL.revokeObjectURL(blobUrl); if (!failedExecution) panel.remove();};
        script.onerror = () => {window.removeEventListener('error', runtimeError); executionFailed();};
        document.head.append(script);
      } catch (error) {
        panel.dataset.zetraBootstrap = 'download-failed';
        message.textContent = 'Application download did not finish. Your session is preserved. Check your connection and retry. / Upakuaji haujakamilika. Jaribu tena.';
        retry.hidden = false;
      } finally {
        clearTimeout(budget);
        running = false;
      }
    }
    retry.addEventListener('click', () => failedExecution ? location.reload() : void download());
    void download();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();
