// Verified Production custom domain. Device/browser origin is never Auth authority.
export const CANONICAL_WEB_ORIGIN = 'https://app.zetra.tz';

export function authLinkHasError(url: string): boolean {
  try {
    const parsed = new URL(url);
    const fragment = new URLSearchParams(parsed.hash.slice(1));
    return ['error', 'error_code', 'error_description'].some(key =>
      !!(parsed.searchParams.get(key) || fragment.get(key)));
  } catch { return false; }
}

export function emailRedirect(kind: 'signup' | 'resend' | 'recovery', platform: string): string {
  const path = kind === 'recovery' ? 'reset-password' : 'login';
  // Preserve existing native resend/recovery deep links. Signup email remains
  // usable from any email browser, including a second device.
  if (platform !== 'web' && kind !== 'signup') return `zetrabmsclean://${path}`;
  return `${CANONICAL_WEB_ORIGIN}/${path}`;
}
