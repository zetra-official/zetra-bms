import {useDocumentText} from "@/src/i18n/useDocumentText";
import type { ViewStyle } from "react-native";
import {useSystemMessageText} from "@/src/i18n/useSystemMessageText";
﻿import {useCommonText} from "@/src/i18n/useCommonText";
// app/notifications/index.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  ScrollView,
  Share,
  Text,
  TextInput,
  View,
  Platform,
  useWindowDimensions,
} from "react-native";
import { useRouter } from "expo-router";
import { Ionicons as VectorIonicons } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Screen } from "@/src/ui/Screen";
import { Card } from "@/src/ui/Card";
import { theme } from "@/src/ui/theme";
import { supabase } from "@/src/supabase/supabaseClient";
import { useOrg } from "@/src/context/OrgContext";

type NotifRow = {
  id: string;
  organization_id: string;
  store_id: string;
  source_store_id: string | null;
  event_type: string;
  title: string;
  body: any;
  items: any;
  total_units: number;
  total_skus: number;
  actor_user_id: string;
  actor_name: string | null;
  ref_movement_id: string | null;
  event_id: string;
  created_by: string;
  created_at: string;
  is_read: boolean;
  read_at: string | null;
};

type Receipt = {
  key: string; // movement_id preferred, fallback to notification id
  movement_id: string | null;
  organization_id: string;
  store_id: string;
  source_store_id: string | null;
  event_type: string;
  title: string;

  actor_user_id: string;
  actor_name: string | null;

  created_at: string; // newest timestamp among group
  total_units: number;
  total_skus: number;

  is_read: boolean;

  // raw rows inside this receipt
  rows: NotifRow[];

  // merged items
  items: any[];
};

function Ionicons({
  name,
  size = 18,
  color = theme.colors.text,
}: {
  name: string;
  size?: number;
  color?: string;
}) {
  if (Platform.OS !== "web") {
    return <VectorIonicons name={name as any} size={size} color={color} />;
  }

  const glyph =
    name === "chevron-back" ? "‹" :
    name === "receipt-outline" ? "▤" :
    name === "arrow-forward" ? "→" :
    name === "search" ? "⌕" :
    name === "close" ? "×" :
    "•";

  return (
    <Text style={{ color, fontSize: size, fontWeight: "900", lineHeight: size + 4 }}>
      {glyph}
    </Text>
  );
}

function fmtLocal(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  try {
    return d.toLocaleString();
  } catch {
    return iso;
  }
}

function fmtEAT(iso: string) {
  try {
    return new Date(iso).toLocaleString("en-GB", {
      timeZone: "Africa/Nairobi",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
function escHtml(v: any) {
  return String(v ?? "—")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
function shortId(id: string) {
  if (!id) return "—";
  return `${id.slice(0, 6)}…${id.slice(-4)}`;
}

function clean(s: any) {
  return String(s ?? "").trim();
}

function clampInt(n: any, fallback = 0) {
  const x = Number(n);
  if (!Number.isFinite(x)) return fallback;
  return Math.floor(x);
}

/** Parse "YYYY-MM-DD" to Date at local midnight */
function parseYMD(s: string) {
  const t = clean(s);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const [yy, mm, dd] = t.split("-").map((v) => Number(v));
  if (!yy || !mm || !dd) return null;
  const d = new Date(yy, mm - 1, dd, 0, 0, 0, 0);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
}

function endOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
}

function looksLikeEmail(s: string) {
  const t = clean(s).toLowerCase();
  return t.includes("@") && t.includes(".");
}

function firstNonEmpty(...vals: any[]) {
  for (const v of vals) {
    const s = clean(v);
    if (s) return s;
  }
  return "";
}

function formatItemMoney(v: any) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "";
  return String(n);
}

function sameId(a: any, b: any) {
  return clean(a) !== "" && clean(a) === clean(b);
}

function itemMetaLine(it: any) {
  const sku = firstNonEmpty(it?.sku, it?.product_sku);
  const barcode = firstNonEmpty(it?.barcode, it?.product_barcode);
  const category = firstNonEmpty(it?.category, it?.product_category);
  const unit = firstNonEmpty(it?.unit, it?.product_unit);
  const sellingPrice = firstNonEmpty(it?.selling_price, it?.unit_price, it?.price);

  const meta: string[] = [];
  if (sku) meta.push(`SKU ${sku}`);
  if (barcode) meta.push(`Barcode ${barcode}`);
  if (category) meta.push(`Category ${category}`);
  if (unit) meta.push(`Unit ${unit}`);
  if (sellingPrice) meta.push(`Sell ${formatItemMoney(sellingPrice)}`);

  return meta;
}
function notificationItemsOf(row: any) {
  const body = row?.body ?? {};

  const arr =
    Array.isArray(row?.items) ? row.items :
    Array.isArray(body?.items) ? body.items :
    Array.isArray(body?.products) ? body.products :
    Array.isArray(body?.stock_items) ? body.stock_items :
    [];

  return arr;
}
function hasRealProductName(it: any) {
  const name = firstNonEmpty(
    it?.product_name,
    it?.name,
    it?.item_name,
    it?.product?.name
  );

  if (!name) return false;

  const normalized = name.toLowerCase();

  return normalized !== "unknown product" && normalized !== "product";
}
function itemQtyOf(it: any) {
  return clampInt(
    it?.qty ??
      it?.quantity ??
      it?.amount ??
      it?.qty_change ??
      it?.delta ??
      it?.total_units ??
      0,
    0
  );
}
function totalQtyOfItems(items: any[], fallback = 0) {
  const sum = (items ?? []).reduce((a, it) => a + itemQtyOf(it), 0);
  return sum > 0 ? sum : clampInt(fallback, 0);
}
function prettyTypeLabel(v: any) {
  const t = clean(v).toUpperCase();
  if (!t) return "—";
  if (t === "STOCK_IN") return "Stock In";
  if (t === "TRANSFER_IN") return "Transfer In";
  if (t === "TRANSFER") return "Transfer";
  return t.replace(/_/g, " ");
}

function prettyDateTimeEAT(iso: string) {
  try {
    return new Date(iso).toLocaleString("en-GB", {
      timeZone: "Africa/Nairobi",
      weekday: "short",
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
function receiptActionLabel(r: Receipt) {
  const t = clean(r.event_type).toUpperCase();
  const title = clean(r.title).toUpperCase();

  if (t.includes("STOCK_OUT") || title.includes("REDUCED")) return "Stock Reduced";
  if (t.includes("STOCK_IN") || title.includes("NEW STOCK")) return "New Stock Received";
  if (t.includes("TRANSFER")) return "Store Transfer";

  return prettyTypeLabel(r.event_type);
}

function productNamesSummary(items: any[]) {
  const names = (items ?? [])
    .map((it: any) => firstNonEmpty(it?.product_name, it?.name))
    .filter(Boolean);

  if (names.length === 0) return "Product details";
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} + ${names[1]}`;

  return `${names[0]} +${names.length - 1} more`;
}
function compactReceiptSummary(r: Receipt, items: any[]) {
  const first = items?.[0];
  const firstName =
    firstNonEmpty(first?.product_name, first?.name) ||
    (clean(first?.product_id) ? shortId(clean(first?.product_id)) : "Item");

  const more = Math.max(0, (items?.length ?? 0) - 1);
  const units = clampInt(r.total_units, 0);

  if ((items?.length ?? 0) <= 0) {
    return `${units} units`;
  }

  if (more <= 0) {
    return `${firstName} • ${units} pcs`;
  }

  return `${firstName} +${more} more • ${units} pcs`;
}

export default function NotificationsCenter() {
 const {documentText, documentLocale} = useDocumentText();
 const systemText = useSystemMessageText();
 const uiText=useCommonText();
  const router = useRouter();
  const { activeStoreId, activeStoreName, stores } = useOrg();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [rows, setRows] = useState<NotifRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  const mode: "ALL" = "ALL";

  // ✅ filters
  const [q, setQ] = useState("");
  const [dateFrom, setDateFrom] = useState<string>(""); // YYYY-MM-DD
  const [dateTo, setDateTo] = useState<string>(""); // YYYY-MM-DD
  const [preset, setPreset] = useState<"ALL" | "TODAY" | "7D" | "30D">("ALL");

  // ✅ current user (for showing YOUR email instead of UUID)
  const [myUserId, setMyUserId] = useState<string>("");
  const [myEmail, setMyEmail] = useState<string>("");

  // ✅ actor display cache (for other users => profiles.display_name)
  const [actorDisplay, setActorDisplay] = useState<Record<string, string>>({});

  // ✅ fallback product metadata cache for old notifications
  const [productMeta, setProductMeta] = useState<
    Record<
      string,
      {
        name?: string;
        sku?: string;
        barcode?: string;
        category?: string;
        unit?: string;
        selling_price?: number | string | null;
      }
    >
  >({});
const [movementItemsById, setMovementItemsById] = useState<Record<string, any[]>>({});
  // ✅ receipt modal
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState<Receipt | null>(null);

  // Desktop presentation only.
  // Android and smaller web screens keep the existing layout.
  const { width: viewportWidth } = useWindowDimensions();

  const isDesktop =
    Platform.OS === "web" &&
    viewportWidth >= 1100;

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { data } = await supabase.auth.getUser();
        const uid = String(data?.user?.id ?? "");
        const em = String(data?.user?.email ?? "");
        if (!alive) return;
        setMyUserId(uid);
        setMyEmail(em);
      } catch {
        // ignore
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const storeNameById = useMemo(() => {
    const map: Record<string, string> = {};
    for (const s of stores ?? []) {
      map[String((s as any).store_id)] = String((s as any).store_name ?? "Store");
    }
    return map;
  }, [stores]);

 const pStoreId = useMemo(() => null, []);

  const load = useCallback(async () => {
    setError(null);

    try {
      const { data, error: e } = await supabase.rpc("get_my_notifications_v3", {
        p_store_id: pStoreId,
        p_limit: 200,
      });
      if (e) throw e;

      setRows((data ?? []) as NotifRow[]);
    } catch (err: any) {
      setRows([]);
      setError(err?.message ?? "Failed to load notifications");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [pStoreId]);

  useEffect(() => {
    setLoading(true);
    void load();
  }, [load]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await load();
  }, [load]);

  const markRead = useCallback(async (id: string) => {
    try {
      await supabase.rpc("mark_notification_read", { p_notification_id: id });
    } catch {
      // non-blocking
    }
  }, []);

  /** ✅ Prefetch profiles.display_name for actors (best-effort) */
  useEffect(() => {
    let alive = true;

    const ids = Array.from(new Set((rows ?? []).map((r) => clean(r.actor_user_id)).filter(Boolean)));
    const missing = ids.filter((id) => !actorDisplay[id]);
    if (missing.length === 0) return;

    (async () => {
      try {
        const { data, error: e } = await supabase
          .from("profiles")
          .select("id, display_name")
          .in("id", missing)
          .limit(200);

        if (e) return;
        if (!alive) return;

        const next: Record<string, string> = {};
        for (const row of (data ?? []) as any[]) {
          const id = clean(row?.id);
          const dn = clean(row?.display_name);
          if (id && dn) next[id] = dn;
        }

        if (Object.keys(next).length > 0) {
          setActorDisplay((prev) => ({ ...prev, ...next }));
        }
      } catch {
        // ignore
      }
    })();

    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows]);

  useEffect(() => {
    let alive = true;

    const ids = Array.from(
      new Set(
        (rows ?? [])
          .flatMap((r) => notificationItemsOf(r))
          .map((it: any) => clean(it?.product_id))
          .filter(Boolean)
      )
    );

    const missing = ids.filter((id) => !productMeta[id]);
    if (missing.length === 0) return;

    (async () => {
      try {
        const { data, error: e } = await supabase
          .from("products")
          .select("id, name, sku, barcode, category, unit, selling_price, price")
          .in("id", missing)
          .limit(500);

        if (e) return;
        if (!alive) return;

        const next: Record<
          string,
          {
            name?: string;
            sku?: string;
            barcode?: string;
            category?: string;
            unit?: string;
            selling_price?: number | string | null;
          }
        > = {};

        for (const row of (data ?? []) as any[]) {
          const id = clean(row?.id);
          if (!id) continue;

          next[id] = {
            name: clean(row?.name),
            sku: clean(row?.sku),
            barcode: clean(row?.barcode),
            category: clean(row?.category),
            unit: clean(row?.unit),
            selling_price: row?.selling_price ?? row?.price ?? null,
          };
        }

        if (Object.keys(next).length > 0) {
          setProductMeta((prev) => ({ ...prev, ...next }));
        }
      } catch {
        // ignore
      }
    })();

    return () => {
      alive = false;
    };
  }, [rows]);
useEffect(() => {
  let alive = true;

  // ✅ Only ask movement RPC for old/incomplete notifications.
  // Notifications ambazo tayari zina product name hazihitaji fallback query.
  const movementIds = Array.from(
    new Set(
      (rows ?? [])
        .filter((r) => {
          const movementId = clean(r.ref_movement_id);
          if (!movementId) return false;

          const items = notificationItemsOf(r);

          if (items.length === 0) return true;

          return !items.some((it: any) => hasRealProductName(it));
        })
        .map((r) => clean(r.ref_movement_id))
        .filter(Boolean)
    )
  );

  const missing = movementIds.filter(
    (id) => !Object.prototype.hasOwnProperty.call(movementItemsById, id)
  );

  if (missing.length === 0) {
    return () => {
      alive = false;
    };
  }

  (async () => {
    try {
      const { data, error } = await supabase.rpc(
        "get_notification_movement_items_v1",
        {
          p_movement_ids: missing,
        } as any
      );

      if (error) throw error;

      const next: Record<string, any[]> = {};

      // ✅ Cache even movements that return zero rows.
      // This prevents requesting the same movement repeatedly.
      for (const mid of missing) {
        next[mid] = [];
      }

      for (const row of (data ?? []) as any[]) {
        const mid = clean(row?.movement_id);
        if (!mid) continue;

        const item = {
          product_id: clean(row?.product_id),
          product_name: clean(row?.product_name) || "Unknown Product",
          name: clean(row?.product_name) || "Unknown Product",
          sku: clean(row?.sku),
          barcode: clean(row?.barcode),
          category: clean(row?.category),
          unit: clean(row?.unit),
          selling_price: row?.selling_price ?? null,
          qty: Math.abs(Number(row?.qty ?? 0)),
          source: "stock_movements_rpc",
          mode: clean(row?.mode),
        };

        // ✅ Do not overwrite another product from the same movement.
        next[mid].push(item);
      }

      if (!alive) return;

      setMovementItemsById((prev) => ({
        ...prev,
        ...next,
      }));
    } catch {
      // fallback is supplementary; notification screen must remain usable
    }
  })();

  return () => {
    alive = false;
  };
}, [rows]);
  /** ✅ Group notifications into one "receipt" per movement_id */
  const receipts: Receipt[] = useMemo(() => {
    const map = new Map<string, Receipt>();

    for (const n of rows ?? []) {
      const key = n.event_id ? `ev:${n.event_id}` : n.ref_movement_id ? `mv:${n.ref_movement_id}` : `n:${n.id}`;
      const itemsArr = notificationItemsOf(n);

      const existing = map.get(key);
      if (!existing) {
        map.set(key, {
          key,
          movement_id: n.ref_movement_id ?? null,
          organization_id: n.organization_id,
          store_id: n.store_id,
          source_store_id: n.source_store_id ?? null,
          event_type: n.event_type,
          title: n.title,
          actor_user_id: n.actor_user_id,
          actor_name: n.actor_name ?? null,
          created_at: n.created_at,
          total_units: clampInt(n.total_units, 0),
          total_skus: clampInt(n.total_skus, 0),
          is_read: !!n.is_read,
          rows: [n],
          items: [...itemsArr],
        });
        continue;
      }

      existing.rows.push(n);

      if (new Date(n.created_at).getTime() > new Date(existing.created_at).getTime()) {
        existing.created_at = n.created_at;
      }

      existing.total_units += clampInt(n.total_units, 0);

      if (itemsArr.length > 0) {
        existing.items.push(...itemsArr);
      }

      existing.is_read = existing.is_read && !!n.is_read;
    }

    const out = Array.from(map.values()).map((r) => {
      const uniq = new Set<string>();
      for (const it of r.items ?? []) {
        const pid = clean(it?.product_id);
        if (pid) uniq.add(pid);
      }
      const computedSkus = uniq.size;
      return {
        ...r,
        total_skus: computedSkus > 0 ? computedSkus : clampInt(r.total_skus, 0),
      };
    });

    out.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return out;
  }, [rows]);

  /** Presets: TODAY / 7D / 30D set dateFrom/dateTo automatically */
  useEffect(() => {
    if (preset === "ALL") return;

    const now = new Date();
    const to = startOfDay(now);
    let from = startOfDay(now);

    if (preset === "TODAY") {
      from = startOfDay(now);
    } else if (preset === "7D") {
      from = startOfDay(new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000));
    } else if (preset === "30D") {
      from = startOfDay(new Date(now.getTime() - 29 * 24 * 60 * 60 * 1000));
    }

    const fmt = (d: Date) => {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      return `${y}-${m}-${dd}`;
    };

    setDateFrom(fmt(from));
    setDateTo(fmt(to));
  }, [preset]);

  const filtered: Receipt[] = useMemo(() => {
    const qq = clean(q).toLowerCase();

    const df = dateFrom ? parseYMD(dateFrom) : null;
    const dt = dateTo ? parseYMD(dateTo) : null;

    const fromD = df ? startOfDay(df) : null;
    const toD = dt ? endOfDay(dt) : null;

    return (receipts ?? []).filter((r) => {
      if (fromD || toD) {
        const t = new Date(r.created_at);
        const okFrom = fromD ? t.getTime() >= fromD.getTime() : true;
        const okTo = toD ? t.getTime() <= toD.getTime() : true;
        if (!okFrom || !okTo) return false;
      }

      if (!qq) return true;

      const storeName = (storeNameById[String(r.store_id)] ?? "Store").toLowerCase();
      const sourceStoreName = (r.source_store_id
        ? storeNameById[String(r.source_store_id)] ?? ""
        : ""
      ).toLowerCase();

      const actorRaw = clean(r.actor_name).toLowerCase();
      const actorResolved = clean(actorDisplay[clean(r.actor_user_id)]).toLowerCase();
      const title = clean(r.title).toLowerCase();
      const type = clean(r.event_type).toLowerCase();
      const move = clean(r.movement_id).toLowerCase();

      const itemsText = (r.items ?? [])
        .map((it: any) => {
          const pid = clean(it?.product_id);
          const nm = clean(it?.product_name || it?.name);
          const sku = clean(it?.sku || it?.product_sku);
          return `${pid} ${nm} ${sku}`;
        })
        .join(" ")
        .toLowerCase();

      return (
        title.includes(qq) ||
        type.includes(qq) ||
        storeName.includes(qq) ||
        sourceStoreName.includes(qq) ||
        actorRaw.includes(qq) ||
        actorResolved.includes(qq) ||
        move.includes(qq) ||
        itemsText.includes(qq)
      );
    });
  }, [receipts, q, dateFrom, dateTo, storeNameById, actorDisplay]);

  const groupedReceipts = useMemo(() => {
    const currentStoreId = clean(activeStoreId);

    if (!currentStoreId) {
      return {
        currentStore: [] as Receipt[],
        otherStores: filtered,
      };
    }

    const currentStore: Receipt[] = [];
    const otherStores: Receipt[] = [];

    for (const r of filtered) {
      if (clean(r.store_id) === currentStoreId) currentStore.push(r);
      else otherStores.push(r);
    }

    return { currentStore, otherStores };
  }, [filtered, activeStoreId]);

  const clearFilters = useCallback(() => {
    setQ("");
    setPreset("ALL");
    setDateFrom("");
    setDateTo("");
  }, []);

  const markReceiptRead = useCallback(
    async (r: Receipt) => {
      const ids = (r.rows ?? []).map((x) => x.id).filter(Boolean);
      for (const id of ids) {
        // eslint-disable-next-line no-await-in-loop
        await markRead(id);
      }
    },
    [markRead]
  );

  const actorLabel = useCallback(
    (r: Receipt) => {
      const body0 = r.rows?.[0]?.body ?? {};
      const item0 = Array.isArray(r.items) && r.items.length > 0 ? r.items[0] : {};

      const explicit =
        firstNonEmpty(
          r.actor_name,
          body0?.actor_email,
          body0?.created_by_email,
          body0?.user_email,
          body0?.actor_name,
          body0?.created_by_name,
          item0?.actor_email,
          item0?.created_by_email,
          item0?.actor_name
        );

      if (explicit) return explicit;

      const uid = clean(r.actor_user_id);

      if (uid && myUserId && uid === myUserId && myEmail) return myEmail;

      const dn = clean(actorDisplay[uid]);
      if (dn) return dn;

      return shortId(uid);
    },
    [actorDisplay, myEmail, myUserId]
  );

  const sourceLabel = useCallback(
    (r: Receipt) => {
      const sid = clean(r.source_store_id);
      const tid = clean(r.store_id);
      const eventType = clean(r.event_type).toUpperCase();
      const title = clean(r.title).toUpperCase();
      const body0 = r.rows?.[0]?.body ?? {};
      const firstItem = Array.isArray(r.items) && r.items.length > 0 ? r.items[0] : null;

      const explicitSource =
        firstNonEmpty(
          body0?.source_type,
          body0?.source,
          body0?.entry_type,
          body0?.notification_type,
          firstItem?.source_type,
          firstItem?.source
        ).toUpperCase();

      const isSameStoreSource = sameId(sid, tid);
      const hasRealMovementSource = sid && !isSameStoreSource;

      if (hasRealMovementSource) {
        const nm = storeNameById[sid] ?? shortId(sid);
        return `Store Movement from ${nm}`;
      }

      if (explicitSource.includes("NEW_STOCK")) return "New Stock Received";
      if (explicitSource.includes("PURCHASE")) return "New Stock Received";
      if (explicitSource.includes("MANUAL")) return "New Stock Received";
      if (explicitSource.includes("TRANSFER")) return "Store Movement";
      if (title.includes("NEW STOCK")) return "New Stock Received";
      if (title.includes("STOCK AVAILABLE")) return "New Stock Received";
      if (eventType.includes("TRANSFER")) return "Store Movement";
      if (eventType.includes("STOCK_IN")) return "New Stock Received";

      return "Stock Received";
    },
    [storeNameById]
  );

  const routeLabel = useCallback(
    (r: Receipt) => {
      const tid = clean(r.store_id);
      const toNm = storeNameById[tid] ?? shortId(tid);
      const sid = clean(r.source_store_id);

      if (sid && !sameId(sid, tid)) {
        const fromNm = storeNameById[sid] ?? shortId(sid);
        return { from: fromNm, to: toNm };
      }

      return { from: "New Stock Entry", to: toNm };
    },
    [storeNameById]
  );

const mergedItemsForReceipt = useCallback(
  (r: Receipt) => {
    const m = new Map<string, any>();
    const movementId = clean(r.movement_id);

    const notifItems = [
      ...(Array.isArray(r.items) ? r.items : []),
      ...((r.rows ?? []).flatMap((row) => notificationItemsOf(row))),
    ];

    const notifHasRealName = notifItems.some((it: any) => {
      const nm = firstNonEmpty(it?.product_name, it?.name, it?.item_name, it?.product?.name);
      return nm && nm.toLowerCase() !== "unknown product" && nm.toLowerCase() !== "product";
    });

    const movementFallback =
      movementId && Array.isArray(movementItemsById[movementId])
        ? movementItemsById[movementId]
        : [];

    const rawItems =
      movementFallback.length > 0 && !notifHasRealName
        ? movementFallback
        : notifItems.length > 0
        ? notifItems
        : movementFallback;

    for (const it of rawItems) {
      const pid = clean(it?.product_id);
      const meta = pid ? productMeta[pid] ?? {} : {};

      const name = firstNonEmpty(
        it?.product_name,
        it?.name,
        it?.item_name,
        it?.product?.name,
        meta?.name
      );

      const finalName =
        name && name.toLowerCase() !== "unknown product" && name.toLowerCase() !== "product"
          ? name
          : firstNonEmpty(meta?.name) || "Unknown Product";

      const key = pid || `name:${finalName}`;
      const prev = m.get(key);
      const qty = itemQtyOf(it);

      const normalized = {
        ...it,
        product_id: pid,
        product_name: finalName,
        name: finalName,
        sku: firstNonEmpty(it?.sku, it?.product_sku, meta?.sku),
        product_sku: firstNonEmpty(it?.product_sku, it?.sku, meta?.sku),
        barcode: firstNonEmpty(it?.barcode, it?.product_barcode, meta?.barcode),
        product_barcode: firstNonEmpty(it?.product_barcode, it?.barcode, meta?.barcode),
        category: firstNonEmpty(it?.category, it?.product_category, meta?.category),
        product_category: firstNonEmpty(it?.product_category, it?.category, meta?.category),
        unit: firstNonEmpty(it?.unit, it?.product_unit, meta?.unit),
        product_unit: firstNonEmpty(it?.product_unit, it?.unit, meta?.unit),
        selling_price:
          it?.selling_price ?? it?.unit_price ?? it?.price ?? meta?.selling_price ?? null,
        unit_price:
          it?.unit_price ?? it?.selling_price ?? it?.price ?? meta?.selling_price ?? null,
        price:
          it?.price ?? it?.selling_price ?? it?.unit_price ?? meta?.selling_price ?? null,
        qty,
      };

      if (!prev) {
        m.set(key, normalized);
      } else {
        m.set(key, {
          ...prev,
          ...normalized,
          qty: clampInt(prev.qty, 0) + qty,
        });
      }
    }

    return Array.from(m.values()).filter((x) => clean(x?.product_name || x?.name));
  },
  [movementItemsById, productMeta]
);

      

  const buildReceiptText = useCallback(
    (r: Receipt) => {
      const { from, to } = routeLabel(r);
      const actor = actorLabel(r);
      const src = sourceLabel(r);

      const items = mergedItemsForReceipt(r);
      const movementId = r.movement_id ? r.movement_id : r.key;

      const lines: string[] = [];
      lines.push(uiText("ZETRA BMS • Stock Movement Receipt"));
      lines.push("----------------------------------");
      lines.push(uiText("Date/Time (EAT): {p0}", {p0: (fmtEAT(r.created_at))}));
      lines.push(uiText("Type: {p0}", {p0: (clean(r.event_type) || "—")}));
      lines.push(uiText("From: {p0}", {p0: (from)}));
      lines.push(uiText("To: {p0}", {p0: (to)}));
      lines.push(uiText("Source: {p0}", {p0: (src)}));
      lines.push(uiText("Receipt: {p0}", {p0: (shortId(movementId))}));
      lines.push(uiText("Processed by: {p0}", {p0: (actor)}));
      lines.push("");
      lines.push(uiText("Items: {p0} | Total Units: {p1}", {p0: (items.length), p1: (totalQtyOfItems(items, r.total_units))}));
      lines.push("");
      lines.push("Items:");
      for (const it of items) {
        const name =
          firstNonEmpty(it?.product_name, it?.name) ||
          (clean(it?.product_id) ? shortId(clean(it?.product_id)) : "Item");

        const sku = firstNonEmpty(it?.sku, it?.product_sku);
        const barcode = firstNonEmpty(it?.barcode, it?.product_barcode);
        const category = firstNonEmpty(it?.category, it?.product_category);
        const unit = firstNonEmpty(it?.unit, it?.product_unit);
        const qty = clampInt(it?.qty, 0);

        const sellingPrice = firstNonEmpty(it?.selling_price, it?.unit_price, it?.price);

        const extras: string[] = [];
        if (sku) extras.push(`SKU ${sku}`);
        if (barcode) extras.push(`Barcode ${barcode}`);
        if (category) extras.push(`Category ${category}`);
        if (unit) extras.push(`Unit ${unit}`);
        if (sellingPrice) extras.push(`Sell ${formatItemMoney(sellingPrice)}`);

        const extraText = extras.length ? ` • ${extras.join(" • ")}` : "";
        lines.push(uiText("- {p0}{p1} • Qty {p2}", {p0: (name), p1: (extraText), p2: (qty)}));
      }

      lines.push("");
      lines.push(uiText("Receipt Ref: {p0}", {p0: (shortId(movementId))}));

      return lines.join("\n");
    },
    [actorLabel, mergedItemsForReceipt, routeLabel, sourceLabel]
  );

  const shareSelected = useCallback(async () => {
    if (!selected) return;
    try {
      await Share.share({ message: buildReceiptText(selected) });
    } catch {
      // ignore
    }
  }, [buildReceiptText, selected]);

  const copySelected = useCallback(async () => {
    if (!selected) return;
    try {
      await Clipboard.setStringAsync(buildReceiptText(selected));
      Alert.alert(uiText("Copied ✅"), uiText("Receipt ime-copy (unaweza ku-paste WhatsApp/Email)."));
    } catch {
      Alert.alert(uiText("Failed"), uiText("Imeshindikana ku-copy receipt."));
    }
  }, [buildReceiptText, selected]);
const shareSelectedPdf = useCallback(async () => {
  if (!selected) return;

  const { from, to } = routeLabel(selected);
  const actor = actorLabel(selected);
  const src = sourceLabel(selected);
  const movementId = selected.movement_id ? selected.movement_id : selected.key;
  const items = mergedItemsForReceipt(selected);

  const itemsHtml = items
    .map((it: any) => {
      const name =
        firstNonEmpty(it?.product_name, it?.name) ||
        (clean(it?.product_id) ? shortId(clean(it?.product_id)) : "Item");

      const sku = firstNonEmpty(it?.sku, it?.product_sku);
      const barcode = firstNonEmpty(it?.barcode, it?.product_barcode);
      const category = firstNonEmpty(it?.category, it?.product_category);
      const unit = firstNonEmpty(it?.unit, it?.product_unit);
      const qty = clampInt(it?.qty, 0);

      return `
        <tr>
          <td>
            <strong>${escHtml(name)}</strong>
            ${sku ? `<br/><span>SKU: ${escHtml(sku)}</span>` : ""}
            ${barcode ? `<br/><span>${documentText("Barcode:")} ${escHtml(barcode)}</span>` : ""}
            ${category ? `<br/><span>${documentText("Category:")} ${escHtml(category)}</span>` : ""}
            ${unit ? `<br/><span>${documentText("Unit:")} ${escHtml(unit)}</span>` : ""}
          </td>
          <td>${escHtml(qty)}</td>
        </tr>
      `;
    })
    .join("");

  const html = `
    <html lang="${documentLocale().language}" dir="${documentLocale().direction}">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>
          @page { size: A4; margin: 14mm; }
          body {
            margin: 0;
            padding: 0;
            background: #ffffff;
            color: #0F172A;
            font-family: Arial, sans-serif;
          }
          .top {
            border-bottom: 2px solid #10B981;
            padding-bottom: 14px;
            margin-bottom: 18px;
          }
          h1 {
            margin: 0;
            color: #059669;
            font-size: 28px;
            font-weight: 900;
          }
          .sub {
            margin-top: 6px;
            color: #64748B;
            font-weight: 800;
          }
          .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 16px;
          }
          .box {
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            padding: 10px;
            background: #F8FAFC;
          }
          .label {
            color: #64748B;
            font-size: 12px;
            font-weight: 800;
          }
          .value {
            margin-top: 4px;
            color: #0F172A;
            font-weight: 900;
            word-break: break-word;
          }
          .blue { color: #2563EB; }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
          }
          th {
            text-align: left;
            background: #F1F5F9;
            padding: 10px;
            font-size: 12px;
            color: #475569;
          }
          td {
            border-bottom: 1px solid #E5E7EB;
            padding: 10px;
            vertical-align: top;
            font-weight: 800;
          }
          td:nth-child(2), th:nth-child(2) {
            width: 90px;
            text-align: center;
          }
          span {
            color: #64748B;
            font-size: 12px;
            font-weight: 700;
          }
          .summary {
            margin-top: 18px;
            border: 1px solid #10B981;
            background: #ECFDF5;
            border-radius: 14px;
            padding: 14px;
            font-weight: 900;
          }
          .footer {
            margin-top: 24px;
            color: #64748B;
            font-size: 12px;
            font-weight: 700;
          }
        </style>
      </head>
      <body>
        <div class="top">
          <h1>${documentText("Stock Movement Receipt")}</h1>
          <div class="sub">${documentText("Generated by ZETRA BMS")}</div>
        </div>

        <div class="grid">
          <div class="box"><div class="label">${documentText("Date / Time (EAT)")}</div><div class="value blue">${escHtml(fmtEAT(selected.created_at))}</div></div>
          <div class="box"><div class="label">${documentText("Type")}</div><div class="value">${escHtml(prettyTypeLabel(selected.event_type))}</div></div>
          <div class="box"><div class="label">${documentText("From")}</div><div class="value blue">${escHtml(from)}</div></div>
          <div class="box"><div class="label">${documentText("To")}</div><div class="value blue">${escHtml(to)}</div></div>
          <div class="box"><div class="label">${documentText("Source")}</div><div class="value">${escHtml(src)}</div></div>
          <div class="box"><div class="label">${documentText("Processed By")}</div><div class="value">${escHtml(actor)}</div></div>
          <div class="box"><div class="label">${documentText("Receipt")}</div><div class="value blue">${escHtml(shortId(movementId))}</div></div>
          <div class="box"><div class="label">${documentText("Reference")}</div><div class="value">${escHtml(shortId(movementId))}</div></div>
        </div>

        <div class="summary">
          ${documentText("Products:")} ${escHtml(items.length)} &nbsp;&nbsp; • &nbsp;&nbsp; Total Units: ${escHtml(totalQtyOfItems(items, selected.total_units))}
        </div>

        <table>
          <thead>
            <tr>
              <th>${documentText("Item Details")}</th>
              <th>${documentText("Qty")}</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml || `<tr><td colspan="2">${documentText("No items found.")}</td></tr>`}
          </tbody>
        </table>

        <div class="footer">${documentText("This receipt is system generated by ZETRA BMS.")}</div>
      </body>
    </html>
  `;

  try {
    const file = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(file.uri, {
      mimeType: "application/pdf",
      dialogTitle: "Share Notification Receipt PDF",
    });
  } catch (e: any) {
    Alert.alert(uiText("PDF failed"), e?.message ?? uiText("Failed to create PDF receipt."));
  }
}, [actorLabel, mergedItemsForReceipt, routeLabel, selected, sourceLabel]);
  const openReceipt = useCallback(
    async (r: Receipt) => {
      // Mark read first (stability: keep DB state correct)
      if (!r.is_read) {
        await markReceiptRead(r);
        // local optimistic update
        setRows((prev) =>
          (prev ?? []).map((n) => {
            if ((r.rows ?? []).some((x) => x.id === n.id)) {
              return { ...n, is_read: true, read_at: new Date().toISOString() } as any;
            }
            return n;
          })
        );
      }

      const bulk=(r.rows??[]).find(n=>n.body?.source==='incoming_m3'&&n.body?.event_id);
      if(bulk){router.push({pathname:'/stocks/receiving-receipt' as any,params:{eventId:String(bulk.body.event_id)}});return;}
      setSelected(r);

      // Desktop uses a persistent master-detail workspace.
      // Android and mobile browser keep the existing receipt modal.
      if (!isDesktop) {
        setModalOpen(true);
      }
    },
    [isDesktop, markReceiptRead]
  );

  return (
    <Screen scroll>
      <View
        style={{
          width: "100%",
          maxWidth: isDesktop ? 1440 : undefined,
          alignSelf: "center",
          paddingHorizontal: isDesktop ? 24 : 0,
          paddingTop: isDesktop ? 8 : 0,
        }}
      >
      {/* Receipt modal */}
      <Modal
        visible={modalOpen}
        transparent
        animationType="fade"
        statusBarTranslucent
        hardwareAccelerated
        onRequestClose={() => setModalOpen(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(15,23,42,0.35)",
            padding: 18,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Pressable
            onPress={() => setModalOpen(false)}
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
            }}
          />

          <View
            style={{
              width: "100%",
              maxWidth: 560,
              alignSelf: "stretch",
              borderRadius: 28,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "rgba(148,163,184,0.22)",
              padding: 0,
              maxHeight: "84%",
              minHeight: 260,
              elevation: 30,
              overflow: "hidden",
            }}
          >
            <ScrollView
              style={{ flexGrow: 0 }}
              contentContainerStyle={{ padding: 16, paddingBottom: 28 }}
              showsVerticalScrollIndicator
              nestedScrollEnabled
              keyboardShouldPersistTaps="handled"
              bounces={false}
              alwaysBounceVertical={false}
            >
              <View
                style={{
                  borderBottomWidth: 1,
                  borderBottomColor: "rgba(15,23,42,0.10)",
                  paddingBottom: 14,
                  marginBottom: 14,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <View
                    style={{
                      width: 48,
                      height: 48,
                      borderRadius: 16,
                      alignItems: "center",
                      justifyContent: "center",
                      borderWidth: 1,
                      borderColor: "rgba(16,185,129,0.28)",
                      backgroundColor: "rgba(16,185,129,0.12)",
                    }}
                  >
                    <Ionicons name="receipt-outline" size={22} color={theme.colors.text} />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 22 }}>
                      {uiText("Receipt")}</Text>
                    <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 2 }}>
                      {uiText("Stock movement / stock entry summary")}</Text>
                  </View>
                </View>
              </View>

              {selected ? (
                <>
                  {(() => {
                    const { from, to } = routeLabel(selected);
                    const actor = actorLabel(selected);
                    const src = sourceLabel(selected);
                    const movementId = selected.movement_id ? selected.movement_id : selected.key;
                    const items = mergedItemsForReceipt(selected);
                    const actorKind = looksLikeEmail(actor) ? "Email" : "User";

                    return (
                      <>
                        <View
                          style={{
                            borderWidth: 1,
                            borderColor: "rgba(255,255,255,0.08)",
                            backgroundColor: "#FFFFFF",
                            borderRadius: 20,
                            padding: 14,
                            gap: 12,
                          }}
                        >
                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "center",
                              justifyContent: "space-between",
                              gap: 10,
                            }}
                          >
                            <View style={{ flex: 1 }}>
                              <Text style={{ color: theme.colors.muted, fontWeight: "800", fontSize: 12 }}>
                                {uiText("DATE / TIME (EAT)")}</Text>
                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  fontSize: 18,
                                  marginTop: 4,
                                }}
                              >
                                {prettyDateTimeEAT(selected.created_at)}
                              </Text>
                            </View>

                            <View
                              style={{
                                paddingHorizontal: 12,
                                paddingVertical: 7,
                                borderRadius: 999,
                                borderWidth: 1,
                                borderColor: "rgba(16,185,129,0.24)",
                                backgroundColor: "rgba(16,185,129,0.10)",
                              }}
                            >
                              <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 12 }}>
                                {prettyTypeLabel(selected.event_type)}
                              </Text>
                            </View>
                          </View>

                          <View
                            style={{
                              borderWidth: 1,
                              borderColor: "rgba(16,185,129,0.14)",
                              backgroundColor: "rgba(16,185,129,0.06)",
                              borderRadius: 18,
                              padding: 12,
                              gap: 10,
                            }}
                          >
                            <Text style={{ color: theme.colors.muted, fontWeight: "900", fontSize: 12 }}>
                              {uiText("ROUTE")}</Text>

                            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                              <View style={{ flex: 1 }}>
                                <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12 }}>
                                  {uiText("FROM")}</Text>
                                <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 17 }}>
                                  {from}
                                </Text>
                              </View>

                              <Ionicons name="arrow-forward" size={18} color={theme.colors.muted} />

                              <View style={{ flex: 1 }}>
                                <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 12 }}>
                                  {uiText("TO")}</Text>
                                <Text
                                  style={{
                                    color: theme.colors.text,
                                    fontWeight: "900",
                                    fontSize: 17,
                                    textAlign: "right",
                                  }}
                                >
                                  {to}
                                </Text>
                              </View>
                            </View>
                          </View>

                          <View style={{ flexDirection: "row", gap: 10 }}>
                            <View
                              style={{
                                flex: 1,
                                borderWidth: 1,
                                borderColor: "rgba(255,255,255,0.08)",
                                backgroundColor: "rgba(255,255,255,0.025)",
                                borderRadius: 16,
                                padding: 12,
                              }}
                            >
                              <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                                {uiText("SOURCE")}</Text>
                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  fontSize: 14,
                                  marginTop: 5,
                                }}
                              >
                                {src}
                              </Text>
                            </View>

                            <View
                              style={{
                                flex: 1,
                                borderWidth: 1,
                                borderColor: "rgba(255,255,255,0.08)",
                                backgroundColor: "rgba(255,255,255,0.025)",
                                borderRadius: 16,
                                padding: 12,
                              }}
                            >
                              <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                                {uiText("PROCESSED BY")}</Text>
                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  fontSize: 14,
                                  marginTop: 5,
                                }}
                                numberOfLines={2}
                              >
                                {actor}
                              </Text>
                              <Text
                                style={{
                                  color: theme.colors.muted,
                                  fontWeight: "800",
                                  fontSize: 11,
                                  marginTop: 4,
                                }}
                              >
                                {(looksLikeEmail(actor) ? uiText("Email") : uiText("User"))}
                              </Text>
                            </View>
                          </View>

                          <View
                            style={{
                              borderWidth: 1,
                              borderColor: "rgba(255,255,255,0.08)",
                              backgroundColor: "rgba(255,255,255,0.025)",
                              borderRadius: 16,
                              padding: 12,
                              gap: 8,
                            }}
                          >
                            <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                              {uiText("RECEIPT SUMMARY")}</Text>

                            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 18 }}>
                              {shortId(movementId)}
                            </Text>

                            <View style={{ flexDirection: "row", gap: 12 }}>
                              <View style={{ flex: 1 }}>
                                <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                                  {uiText("PRODUCTS")}</Text>
                                <Text
                                  style={{
                                    color: theme.colors.text,
                                    fontWeight: "900",
                                    fontSize: 17,
                                    marginTop: 2,
                                  }}
                                >
                                  {items.length}
                                </Text>
                              </View>

                              <View style={{ flex: 1 }}>
                                <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                                  {uiText("TOTAL UNITS")}</Text>
                                <Text
                                  style={{
                                    color: theme.colors.text,
                                    fontWeight: "900",
                                    fontSize: 17,
                                    marginTop: 2,
                                  }}
                                >
                                  {totalQtyOfItems(items, selected.total_units)}
                                </Text>
                              </View>
                            </View>
                          </View>
                        </View>

                        <View style={{ marginTop: 16 }}>
                          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}>
                            {uiText("Items")}</Text>
                        <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 4 }}>
  {uiText("Majina ya bidhaa, idadi na taarifa muhimu za kila product.")}</Text>
                        </View>

                        <View style={{ marginTop: 10, gap: 10 }}>
                          {items.length === 0 ? (
  <View
    style={{
      borderWidth: 1,
      borderColor: "rgba(239,68,68,0.20)",
      backgroundColor: "rgba(239,68,68,0.06)",
      borderRadius: 18,
      padding: 14,
    }}
  >
    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
      {uiText("Hakuna product details zilizopatikana kwenye notification hii.")}</Text>
    <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 6 }}>
      {uiText("Hii inaonyesha notification ya zamani au RPC haikutuma items/body.items.")}</Text>
  </View>
) : items.map((it: any, idx: number) => {
                            const name =
                              firstNonEmpty(it?.product_name, it?.name) ||
                              (clean(it?.product_id) ? shortId(clean(it?.product_id)) : "Item");

                            const qty = clampInt(it?.qty, 0);
                            const meta = itemMetaLine(it);

                            return (
                              <View
                                key={`${idx}`}
                                style={{
                                  borderWidth: 1,
                                  borderColor: "rgba(255,255,255,0.08)",
                                  backgroundColor: "rgba(255,255,255,0.03)",
                                  borderRadius: 18,
                                  padding: 14,
                                  gap: 10,
                                }}
                              >
                                <View
                                  style={{
                                    flexDirection: "row",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    gap: 10,
                                  }}
                                >
                                  <Text
                                    style={{
                                      flex: 1,
                                      color: theme.colors.text,
                                      fontWeight: "900",
                                      fontSize: 17,
                                    }}
                                  >
                                    {name}
                                  </Text>

                                  <View
                                    style={{
                                      paddingHorizontal: 12,
                                      paddingVertical: 6,
                                      borderRadius: 999,
                                      borderWidth: 1,
                                      borderColor: "rgba(16,185,129,0.24)",
                                      backgroundColor: "rgba(16,185,129,0.10)",
                                    }}
                                  >
                                    <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 12 }}>
                                      {uiText("Qty")}{qty}
                                    </Text>
                                  </View>
                                </View>

                                {meta.length ? (
                                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                                    {meta.map((x, i) => (
                                      <View
                                        key={`${idx}-${i}`}
                                        style={{
                                          paddingHorizontal: 10,
                                          paddingVertical: 6,
                                          borderRadius: 999,
                                          borderWidth: 1,
                                          borderColor: "rgba(255,255,255,0.08)",
                                          backgroundColor: "rgba(255,255,255,0.04)",
                                        }}
                                      >
                                        <Text style={{ color: theme.colors.text, fontWeight: "800", fontSize: 12 }}>
                                          {x}
                                        </Text>
                                      </View>
                                    ))}
                                  </View>
                                ) : null}
                              </View>
                            );
                          })}
                        </View>

<View
                          style={{
                            marginTop: 16,
                            borderWidth: 1,
                            borderColor: "rgba(16,185,129,0.18)",
                            backgroundColor: "rgba(16,185,129,0.07)",
                            borderRadius: 18,
                            padding: 14,
                          }}
                        >
                          <Text style={{ color: theme.colors.faint, fontWeight: "800", fontSize: 11 }}>
                            {uiText("RECEIPT REF")}</Text>
                          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16, marginTop: 4 }}>
                            {shortId(movementId)}
                          </Text>
                        </View>
<View style={{ flexDirection: "row", gap: 10, marginTop: 18 }}>
  <View style={{ flex: 1 }}>
    <Pressable
      onPress={shareSelected}
      style={({ pressed }) => ({
        paddingVertical: 14,
        borderRadius: 999,
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: "#FFFFFF",
        opacity: pressed ? 0.92 : 1,
        alignItems: "center",
      })}
    >
      <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
        {uiText("Share Text")}</Text>
    </Pressable>
  </View>

  <View style={{ flex: 1 }}>
    <Pressable
      onPress={shareSelectedPdf}
      style={({ pressed }) => ({
        paddingVertical: 14,
        borderRadius: 999,
        borderWidth: 1,
        borderColor: "#0B63CE",
        backgroundColor: "#0B63CE",
        opacity: pressed ? 0.92 : 1,
        alignItems: "center",
      })}
    >
      <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 15 }}>
        {uiText("Share PDF")}</Text>
    </Pressable>
  </View>
</View>

<View style={{ marginTop: 10 }}>
  <Pressable
    onPress={copySelected}
    style={({ pressed }) => ({
      paddingVertical: 14,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: theme.colors.border,
      backgroundColor: "#FFFFFF",
      opacity: pressed ? 0.92 : 1,
      alignItems: "center",
    })}
  >
    <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
      {uiText("Copy Text")}</Text>
  </Pressable>
</View>

<View style={{ marginTop: 10 }}>
  <Pressable
    onPress={() => setModalOpen(false)}
    style={({ pressed }) => ({
      paddingVertical: 14,
      borderRadius: 999,
      borderWidth: 1,
      borderColor: theme.colors.border,
      backgroundColor: "#FFFFFF",
      opacity: pressed ? 0.92 : 1,
      alignItems: "center",
    })}
  >
    <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
      {uiText("Close")}</Text>
  </Pressable>
</View>
                      </>
                    );
                  })()}
                </>
              ) : (
                <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 8 }}>
                  {uiText("No receipt loaded.")}</Text>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Header */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [{ opacity: pressed ? 0.8 : 1, paddingVertical: 6 }]}
        >
          <Ionicons name="chevron-back" size={22} color={theme.colors.text} />
        </Pressable>

        <Text style={{ fontSize: isDesktop ? 28 : 22, fontWeight: "900", color: theme.colors.text }}>
          {uiText("Notifications")}</Text>
      </View>

      <View
        style={{
          flexDirection: isDesktop ? "row" : "column",
          alignItems: isDesktop ? "flex-start" : "stretch",
          gap: isDesktop ? 16 : 0,
          marginTop: 12,
        }}
      >
        <View
          style={{
            width: isDesktop ? "34%" : "100%",
            minWidth: 0,
          }}
        >
          <Card style={{ marginTop: 0, gap: 10 }}>
            <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Notification Scope")}</Text>

        <View
          style={{
            borderWidth: 1,
            borderColor: theme.colors.emeraldBorder,
            backgroundColor: "rgba(16,185,129,0.06)",
            borderRadius: theme.radius.lg,
            paddingHorizontal: 12,
            paddingVertical: 12,
          }}
        >
          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
            {uiText("Assigned Stores")}</Text>
          <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 6 }}>
            {uiText("Active Store:")}<Text style={{ color: theme.colors.text }}>{activeStoreName ?? "—"}</Text>
          </Text>
          <Text style={{ color: theme.colors.faint, fontWeight: "800", marginTop: 6 }}>
            {uiText("User ataona notifications zote za stores alizoassigniwa, hata kama hajaziswitch kwa sasa.")}</Text>
        </View>
          </Card>
        </View>

        <View
          style={{
            flex: isDesktop ? 1 : undefined,
            width: isDesktop ? undefined : "100%",
            minWidth: 0,
          }}
        >
          {/* Search + Date filter */}
          <Card style={{ marginTop: isDesktop ? 0 : 12, gap: 10 }}>
        <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Search & Date")}</Text>

        <View
          style={{
            borderWidth: 1,
            borderColor: theme.colors.border,
            backgroundColor: theme.colors.surface2,
            borderRadius: theme.radius.lg,
            paddingHorizontal: 12,
            paddingVertical: 10,
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Ionicons name="search" size={16} color={theme.colors.muted} />
          <TextInput
            value={q}
            onChangeText={setQ}
            placeholder={uiText("Search: store, type, movement id, sku, product...")}
            placeholderTextColor={theme.colors.muted}
            style={{
              flex: 1,
              color: theme.colors.text,
              fontWeight: "800",
              paddingVertical: 0,
            }}
            autoCorrect={false}
            autoCapitalize="none"
          />
          {q ? (
            <Pressable onPress={() => setQ("")} style={{ padding: 6 }}>
              <Ionicons name="close" size={18} color={theme.colors.muted} />
            </Pressable>
          ) : null}
        </View>

        {/* Presets */}
        <View style={{ flexDirection: "row", gap: 10 }}>
          {(["ALL", "TODAY", "7D", "30D"] as const).map((k) => {
            const active = preset === k;
            const label = k === "ALL" ? "All Time" : k === "TODAY" ? "Today" : k;
            return (
              <Pressable
                key={k}
                onPress={() => setPreset(k)}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 10,
                    borderRadius: theme.radius.lg,
                    borderWidth: 1,
                    borderColor: active ? theme.colors.emeraldBorder : theme.colors.border,
                    backgroundColor: active ? theme.colors.emeraldSoft : theme.colors.card,
                    opacity: pressed ? 0.92 : 1,
                    alignItems: "center",
                  },
                ]}
              >
                <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{k === "7D" ? uiText("{p0} DAYS", {p0: 7}) : k === "30D" ? uiText("{p0} DAYS", {p0: 30}) : (k === "ALL" ? uiText("All Time") : (k === "TODAY" ? uiText("Today") : k))}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Custom date range */}
        <View style={{ flexDirection: "row", gap: 10 }}>
          <View style={{ flex: 1, gap: 6 }}>
            <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("From")}</Text>
            <TextInput
              value={dateFrom}
              onChangeText={(v) => {
                setPreset("ALL");
                setDateFrom(v);
              }}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={theme.colors.muted}
              style={{
                borderWidth: 1,
                borderColor: theme.colors.border,
                backgroundColor: theme.colors.surface2,
                borderRadius: theme.radius.lg,
                paddingHorizontal: 12,
                paddingVertical: 10,
                color: theme.colors.text,
                fontWeight: "800",
              }}
              autoCorrect={false}
              autoCapitalize="none"
            />
          </View>

          <View style={{ flex: 1, gap: 6 }}>
            <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("To")}</Text>
            <TextInput
              value={dateTo}
              onChangeText={(v) => {
                setPreset("ALL");
                setDateTo(v);
              }}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={theme.colors.muted}
              style={{
                borderWidth: 1,
                borderColor: theme.colors.border,
                backgroundColor: theme.colors.surface2,
                borderRadius: theme.radius.lg,
                paddingHorizontal: 12,
                paddingVertical: 10,
                color: theme.colors.text,
                fontWeight: "800",
              }}
              autoCorrect={false}
              autoCapitalize="none"
            />
          </View>
        </View>

        <View style={{ flexDirection: "row", gap: 10 }}>
          <Pressable
            onPress={clearFilters}
            style={({ pressed }) => [
              {
                flex: 1,
                paddingVertical: 10,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: theme.colors.border,
                backgroundColor: theme.colors.card,
                opacity: pressed ? 0.92 : 1,
                alignItems: "center",
              },
            ]}
          >
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{uiText("Clear Filters")}</Text>
          </Pressable>

          <Pressable
            onPress={onRefresh}
            style={({ pressed }) => [
              {
                flex: 1,
                paddingVertical: 10,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: theme.colors.border,
                backgroundColor: "rgba(255,255,255,0.04)",
                opacity: pressed ? 0.92 : 1,
                alignItems: "center",
              },
            ]}
          >
            <Text style={{ color: theme.colors.text, fontWeight: "900" }}>
              {refreshing ? uiText("Refreshing...") : uiText("Refresh")}
            </Text>
          </Pressable>
        </View>
          </Card>
        </View>
      </View>

      {/* Loading / Error */}
      {loading ? (
        <View style={{ paddingVertical: 24, alignItems: "center" }}>
          <ActivityIndicator />
        </View>
      ) : error ? (
        <Card
          style={{
            marginTop: 12,
            borderColor: theme.colors.dangerBorder,
            backgroundColor: theme.colors.dangerSoft,
          }}
        >
          <Text style={{ color: theme.colors.danger, fontWeight: "900" }}>{systemText(error)}</Text>
        </Card>
      ) : null}

      {/* DESKTOP MASTER DETAIL WORKSPACE V2 */}
      <View
        style={{
          flexDirection: isDesktop ? "row" : "column",
          alignItems: "flex-start",
          gap: isDesktop ? 18 : 0,
          width: "100%",
          height: isDesktop ? ("calc(100vh - 32px)" as ViewStyle["height"]) : undefined,
          minHeight: isDesktop ? 620 : undefined,
          overflow: isDesktop ? "hidden" : "visible",
        }}
      >
        <View
          style={{
            width: isDesktop ? "40%" : "100%",
            minWidth: 0,
            height: isDesktop ? "100%" : undefined,
            overflow: isDesktop ? "hidden" : "visible",
          }}
        >
          {/* List */}
      <View
        style={{
          marginTop: isDesktop ? 22 : 14,
          marginBottom: isDesktop ? 10 : 6,
          paddingTop: isDesktop ? 18 : 0,
          borderTopWidth: isDesktop ? 1 : 0,
          borderTopColor: theme.colors.border,
        }}
      >
        <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}>{uiText("Receipts ({p0})", {p0: (filtered.length)})}</Text>

        <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 4 }}>
          {uiText("Notifications za stores zote ulizoassigniwa zinaonekana hapa, zikiwa zimegawanywa vizuri.")}</Text>
      </View>

      <ScrollView
        style={{
          flex: isDesktop ? 1 : undefined,
          maxHeight: isDesktop ? ("calc(100vh - 170px)" as ViewStyle["maxHeight"]) : undefined,
        }}
        contentContainerStyle={{
          gap: 12,
          paddingRight: isDesktop ? 6 : 0,
          paddingBottom: isDesktop ? 24 : 0,
        }}
        showsVerticalScrollIndicator={isDesktop}
        nestedScrollEnabled
      >
        {groupedReceipts.currentStore.length > 0 ? (
          <View style={{ gap: 10 }}>
            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>{uiText("Active Store ({p0})", {p0: (groupedReceipts.currentStore.length)})}</Text>

            {groupedReceipts.currentStore.map((r) => {
              const targetStore = storeNameById[String(r.store_id)] ?? "Store";
              const isUnread = !r.is_read;
              const mvLabel = r.movement_id ? shortId(r.movement_id) : shortId(r.key);
              const mergedItems = mergedItemsForReceipt(r);
              const action = receiptActionLabel(r);
              const summary = productNamesSummary(mergedItems);

              return (
                <Pressable
                  key={r.key}
                  onPress={() => openReceipt(r)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.95 : 1 }]}
                >
                  <Card
                    style={{
                      borderColor: isUnread ? theme.colors.emeraldBorder : theme.colors.border,
                      backgroundColor: isUnread ? "rgba(16,185,129,0.07)" : theme.colors.card,
                      borderRadius: 18,
                      padding: 14,
                      gap: 8,
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 10 }}>
                      <View style={{ flex: 1, minWidth: 0 }}>
                        <Text
                          style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}
                          numberOfLines={1}
                        >
                          {action}
                        </Text>

                        <Text
                          style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 4 }}
                          numberOfLines={1}
                        >
                          {(storeNameById[String(r.store_id)] ?? uiText("Store"))}
                        </Text>

                        <Text
                          style={{ color: theme.colors.faint, fontWeight: "800", marginTop: 4, fontSize: 12 }}
                          numberOfLines={1}
                        >
                          {prettyTypeLabel(r.event_type)} • {fmtLocal(r.created_at)}
                        </Text>

                        <Text
                          style={{ color: theme.colors.text, fontWeight: "900", marginTop: 8 }}
                          numberOfLines={1}
                        >
                          {summary}
                        </Text>

                        <Text
                          style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 6 }}
                          numberOfLines={1}
                        >{uiText("{p0} products • {p1} pcs", {p0: (mergedItems.length), p1: (clampInt(r.total_units, 0))})}</Text>

                     

                        <Text
                          style={{ color: theme.colors.faint, fontWeight: "800", marginTop: 6, fontSize: 12 }}
                          numberOfLines={1}
                        >
                          {uiText("Receipt:")}{mvLabel}
                        </Text>
                      </View>

                      {isUnread ? (
                        <View
                          style={{
                            alignSelf: "flex-start",
                            paddingHorizontal: 10,
                            paddingVertical: 5,
                            borderRadius: 999,
                            borderWidth: 1,
                            borderColor: theme.colors.emeraldBorder,
                            backgroundColor: theme.colors.emeraldSoft,
                          }}
                        >
                          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 11 }}>
                            {uiText("NEW")}</Text>
                        </View>
                      ) : null}
                    </View>
                  </Card>
                </Pressable>
              );
            })}
          </View>
        ) : null}

        {groupedReceipts.otherStores.length > 0 ? (
          <View style={{ gap: 10 }}>
            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>{uiText("Other Assigned Stores ({p0})", {p0: (groupedReceipts.otherStores.length)})}</Text>

            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>
              {uiText("Hizi ni notifications za stores nyingine ulizoassigniwa ndani ya organization hii.")}</Text>

            {groupedReceipts.otherStores.map((r) => {
              const targetStore = storeNameById[String(r.store_id)] ?? "Store";
              const isUnread = !r.is_read;
              const mvLabel = r.movement_id ? shortId(r.movement_id) : shortId(r.key);
              const mergedItems = mergedItemsForReceipt(r);
              const action = receiptActionLabel(r);
              const summary = productNamesSummary(mergedItems);

              return (
                <Pressable
                  key={r.key}
                  onPress={() => openReceipt(r)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.95 : 1 }]}
                >
                  <Card
                    style={{
                      borderColor: isUnread ? theme.colors.emeraldBorder : theme.colors.border,
                      backgroundColor: isUnread ? "rgba(16,185,129,0.07)" : theme.colors.card,
                      borderRadius: 18,
                      padding: 14,
                      gap: 8,
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "flex-start", gap: 10 }}>
                      <View style={{ flex: 1, minWidth: 0 }}>
                        <Text
                          style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}
                          numberOfLines={1}
                        >
                          {action}
                        </Text>

                        <Text
                          style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 4 }}
                          numberOfLines={1}
                        >
                          {(storeNameById[String(r.store_id)] ?? uiText("Store"))}
                        </Text>

                        <Text
                          style={{ color: theme.colors.faint, fontWeight: "800", marginTop: 4, fontSize: 12 }}
                          numberOfLines={1}
                        >
                          {prettyTypeLabel(r.event_type)} • {fmtLocal(r.created_at)}
                        </Text>

                        <Text
                          style={{ color: theme.colors.text, fontWeight: "900", marginTop: 8 }}
                          numberOfLines={1}
                        >
                          {summary}
                        </Text>

                        <Text
                          style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 6 }}
                          numberOfLines={1}
                        >{uiText("{p0} products • {p1} pcs", {p0: (mergedItems.length), p1: (clampInt(r.total_units, 0))})}</Text>

                        <Text
                          style={{ color: theme.colors.faint, fontWeight: "800", marginTop: 6, fontSize: 12 }}
                          numberOfLines={1}
                        >
                          {uiText("Receipt:")}{mvLabel}
                        </Text>
                      </View>

                      {isUnread ? (
                        <View
                          style={{
                            alignSelf: "flex-start",
                            paddingHorizontal: 10,
                            paddingVertical: 5,
                            borderRadius: 999,
                            borderWidth: 1,
                            borderColor: theme.colors.emeraldBorder,
                            backgroundColor: theme.colors.emeraldSoft,
                          }}
                        >
                          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 11 }}>
                            {uiText("NEW")}</Text>
                        </View>
                      ) : null}
                    </View>
                  </Card>
                </Pressable>
              );
            })}
          </View>
        ) : null}

        {groupedReceipts.currentStore.length === 0 && groupedReceipts.otherStores.length === 0 ? (
          <Card
            style={{
              borderColor: theme.colors.border,
              backgroundColor: theme.colors.card,
            }}
          >
            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 15 }}>
              {uiText("No notifications found")}</Text>
            <Text style={{ color: theme.colors.muted, fontWeight: "800", marginTop: 6 }}>
              {uiText("Hakuna notifications kwa stores ulizoassigniwa kwa sasa.")}</Text>
          </Card>
        ) : null}
      </ScrollView>

              </View>

        {isDesktop ? (
          <View
            style={{
              flex: 1,
              minWidth: 0,
              height: "100%",
              overflow: "hidden",
            }}
          >
            <View
              style={{
                borderWidth: 1,
                borderColor: theme.colors.border,
                backgroundColor: theme.colors.card,
                borderRadius: 20,
                padding: 18,
                minHeight: 460,
                height: "100%",
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 12,
                  paddingBottom: 14,
                  borderBottomWidth: 1,
                  borderBottomColor: theme.colors.border,
                }}
              >
                <View style={{ flex: 1, minWidth: 0 }}>
                  <Text
                    style={{
                      color: theme.colors.text,
                      fontWeight: "900",
                      fontSize: 20,
                    }}
                  >
                    {uiText("Receipt Details")}</Text>

                  <Text
                    style={{
                      color: theme.colors.muted,
                      fontWeight: "800",
                      marginTop: 4,
                    }}
                  >
                    {uiText("Full details for the selected business event.")}</Text>
                </View>

                <View
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 14,
                    alignItems: "center",
                    justifyContent: "center",
                    borderWidth: 1,
                    borderColor: theme.colors.emeraldBorder,
                    backgroundColor: theme.colors.emeraldSoft,
                  }}
                >
                  <Ionicons
                    name="receipt-outline"
                    size={20}
                    color={theme.colors.text}
                  />
                </View>
              </View>

              {selected ? (
                <ScrollView
                  style={{
                    flex: 1,
                    marginTop: 16,
                  }}
                  contentContainerStyle={{
                    gap: 12,
                    paddingRight: 6,
                    paddingBottom: 24,
                  }}
                  showsVerticalScrollIndicator
                  nestedScrollEnabled
                >
                  {(() => {
                    const { from, to } = routeLabel(selected);
                    const actor = actorLabel(selected);
                    const src = sourceLabel(selected);
                    const items = mergedItemsForReceipt(selected);
                    const movementId =
                      selected.movement_id
                        ? selected.movement_id
                        : selected.key;

                    return (
                      <>
                        <View
                          style={{
                            borderWidth: 1,
                            borderColor: theme.colors.emeraldBorder,
                            backgroundColor: theme.colors.emeraldSoft,
                            borderRadius: 18,
                            padding: 16,
                          }}
                        >
                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "flex-start",
                              justifyContent: "space-between",
                              gap: 12,
                            }}
                          >
                            <View style={{ flex: 1, minWidth: 0 }}>
                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  fontSize: 20,
                                }}
                              >
                                {receiptActionLabel(selected)}
                              </Text>

                              <Text
                                style={{
                                  color: theme.colors.muted,
                                  fontWeight: "800",
                                  marginTop: 5,
                                }}
                              >
                                {prettyDateTimeEAT(selected.created_at)}
                              </Text>
                            </View>

                            <View
                              style={{
                                paddingHorizontal: 10,
                                paddingVertical: 6,
                                borderRadius: 999,
                                borderWidth: 1,
                                borderColor: theme.colors.emeraldBorder,
                                backgroundColor: theme.colors.card,
                              }}
                            >
                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  fontSize: 11,
                                }}
                              >
                                {prettyTypeLabel(selected.event_type)}
                              </Text>
                            </View>
                          </View>
                        </View>

                        <View
                          style={{
                            flexDirection: "row",
                            gap: 10,
                          }}
                        >
                          <View
                            style={{
                              flex: 1,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              borderRadius: 16,
                              padding: 14,
                              backgroundColor: theme.colors.surface2,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.faint,
                                fontWeight: "900",
                                fontSize: 11,
                              }}
                            >
                              {uiText("PRODUCTS")}</Text>

                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                                fontSize: 22,
                                marginTop: 5,
                              }}
                            >
                              {items.length}
                            </Text>
                          </View>

                          <View
                            style={{
                              flex: 1,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              borderRadius: 16,
                              padding: 14,
                              backgroundColor: theme.colors.surface2,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.faint,
                                fontWeight: "900",
                                fontSize: 11,
                              }}
                            >
                              {uiText("TOTAL UNITS")}</Text>

                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                                fontSize: 22,
                                marginTop: 5,
                              }}
                            >
                              {totalQtyOfItems(
                                items,
                                selected.total_units
                              )}
                            </Text>
                          </View>
                        </View>

                        <View
                          style={{
                            borderWidth: 1,
                            borderColor: theme.colors.border,
                            borderRadius: 18,
                            padding: 14,
                            gap: 12,
                          }}
                        >
                          <Text
                            style={{
                              color: theme.colors.faint,
                              fontWeight: "900",
                              fontSize: 11,
                            }}
                          >
                            {uiText("ROUTE")}</Text>

                          <View
                            style={{
                              flexDirection: "row",
                              alignItems: "center",
                              gap: 12,
                            }}
                          >
                            <View style={{ flex: 1, minWidth: 0 }}>
                              <Text
                                style={{
                                  color: theme.colors.faint,
                                  fontWeight: "800",
                                  fontSize: 11,
                                }}
                              >
                                {uiText("FROM")}</Text>

                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  marginTop: 4,
                                }}
                                numberOfLines={2}
                              >
                                {from}
                              </Text>
                            </View>

                            <Ionicons
                              name="arrow-forward"
                              size={18}
                              color={theme.colors.muted}
                            />

                            <View style={{ flex: 1, minWidth: 0 }}>
                              <Text
                                style={{
                                  color: theme.colors.faint,
                                  fontWeight: "800",
                                  fontSize: 11,
                                  textAlign: "right",
                                }}
                              >
                                {uiText("TO")}</Text>

                              <Text
                                style={{
                                  color: theme.colors.text,
                                  fontWeight: "900",
                                  marginTop: 4,
                                  textAlign: "right",
                                }}
                                numberOfLines={2}
                              >
                                {to}
                              </Text>
                            </View>
                          </View>
                        </View>

                        <View
                          style={{
                            flexDirection: "row",
                            gap: 10,
                          }}
                        >
                          <View
                            style={{
                              flex: 1,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              borderRadius: 16,
                              padding: 14,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.faint,
                                fontWeight: "900",
                                fontSize: 11,
                              }}
                            >
                              {uiText("SOURCE")}</Text>

                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                                marginTop: 5,
                              }}
                              numberOfLines={2}
                            >
                              {src}
                            </Text>
                          </View>

                          <View
                            style={{
                              flex: 1,
                              borderWidth: 1,
                              borderColor: theme.colors.border,
                              borderRadius: 16,
                              padding: 14,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.faint,
                                fontWeight: "900",
                                fontSize: 11,
                              }}
                            >
                              {uiText("PROCESSED BY")}</Text>

                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                                marginTop: 5,
                              }}
                              numberOfLines={2}
                            >
                              {actor}
                            </Text>
                          </View>
                        </View>

                        <View
                          style={{
                            borderWidth: 1,
                            borderColor: theme.colors.border,
                            borderRadius: 16,
                            padding: 14,
                          }}
                        >
                          <Text
                            style={{
                              color: theme.colors.faint,
                              fontWeight: "900",
                              fontSize: 11,
                            }}
                          >
                            {uiText("RECEIPT REF")}</Text>

                          <Text
                            style={{
                              color: theme.colors.text,
                              fontWeight: "900",
                              fontSize: 15,
                              marginTop: 5,
                            }}
                          >
                            {shortId(movementId)}
                          </Text>
                        </View>

                        <View
                          style={{
                            borderWidth: 1,
                            borderColor: theme.colors.border,
                            borderRadius: 18,
                            overflow: "hidden",
                          }}
                        >
                          <View
                            style={{
                              paddingHorizontal: 14,
                              paddingVertical: 12,
                              backgroundColor: theme.colors.surface2,
                              borderBottomWidth: 1,
                              borderBottomColor: theme.colors.border,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.text,
                                fontWeight: "900",
                                fontSize: 14,
                              }}
                            >{uiText("Products ({p0})", {p0: (items.length)})}</Text>
                          </View>

                          {items.length > 0 ? (
                            items.slice(0, 12).map((it: any, idx: number) => {
                              const productName =
                                firstNonEmpty(
                                  it?.product_name,
                                  it?.name,
                                  it?.item_name,
                                  it?.product?.name
                                ) || "Product";

                              const qty = itemQtyOf(it);

                              return (
                                <View
                                  key={`${productName}-${idx}`}
                                  style={{
                                    flexDirection: "row",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    gap: 12,
                                    paddingHorizontal: 14,
                                    paddingVertical: 11,
                                    borderBottomWidth:
                                      idx < Math.min(items.length, 12) - 1
                                        ? 1
                                        : 0,
                                    borderBottomColor: theme.colors.border,
                                  }}
                                >
                                  <Text
                                    style={{
                                      flex: 1,
                                      minWidth: 0,
                                      color: theme.colors.text,
                                      fontWeight: "800",
                                    }}
                                    numberOfLines={2}
                                  >
                                    {(firstNonEmpty(
                                  it?.product_name,
                                  it?.name,
                                  it?.item_name,
                                  it?.product?.name
                                ) || uiText("Product"))}
                                  </Text>

                                  <Text
                                    style={{
                                      color: theme.colors.text,
                                      fontWeight: "900",
                                    }}
                                  >
                                    {qty} {uiText("pcs")}</Text>
                                </View>
                              );
                            })
                          ) : (
                            <View style={{ padding: 14 }}>
                              <Text
                                style={{
                                  color: theme.colors.muted,
                                  fontWeight: "800",
                                }}
                              >
                                {uiText("No product details available.")}</Text>
                            </View>
                          )}

                          {items.length > 12 ? (
                            <View
                              style={{
                                paddingHorizontal: 14,
                                paddingVertical: 11,
                                borderTopWidth: 1,
                                borderTopColor: theme.colors.border,
                              }}
                            >
                              <Text
                                style={{
                                  color: theme.colors.muted,
                                  fontWeight: "900",
                                  textAlign: "center",
                                }}
                              >
                                +{items.length - 12} {uiText("more products")}</Text>
                            </View>
                          ) : null}
                        </View>
                      </>
                    );
                  })()}
                </ScrollView>
              ) : (
                <View
                  style={{
                    minHeight: 330,
                    alignItems: "center",
                    justifyContent: "center",
                    paddingHorizontal: 30,
                  }}
                >
                  <View
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: 20,
                      alignItems: "center",
                      justifyContent: "center",
                      borderWidth: 1,
                      borderColor: theme.colors.border,
                      backgroundColor: theme.colors.surface2,
                    }}
                  >
                    <Ionicons
                      name="notifications-outline"
                      size={28}
                      color={theme.colors.muted}
                    />
                  </View>

                  <Text
                    style={{
                      color: theme.colors.text,
                      fontWeight: "900",
                      fontSize: 17,
                      marginTop: 16,
                      textAlign: "center",
                    }}
                  >
                    {uiText("Select a notification")}</Text>

                  <Text
                    style={{
                      color: theme.colors.muted,
                      fontWeight: "800",
                      marginTop: 7,
                      textAlign: "center",
                      lineHeight: 20,
                    }}
                  >
                    {uiText("Click a notification on the left to view its receipt details here.")}</Text>
                </View>
              )}
            </View>
          </View>
        ) : null}
      </View>
<View style={{ height: 40 }} />
      </View>
    </Screen>
  );
}
