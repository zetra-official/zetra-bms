import {useCommonText} from "@/src/i18n/useCommonText";
import { useOrg } from "@/src/context/OrgContext";
import { useOrgMoneyPrefs } from "@/src/ui/money";
import { supabase } from "@/src/supabase/supabaseClient";
import { Button } from "@/src/ui/Button";
import { Card } from "@/src/ui/Card";
import { Screen } from "@/src/ui/Screen";
import { theme } from "@/src/ui/theme";
import SafeIcon from "@/src/ui/SafeIcon";
import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";
import AddPaymentSheet from "@/src/components/credit/AddPaymentSheet";
import PaymentRow, { Payment } from "@/src/components/credit/PaymentRow";

type AccountRow = {
  account_id: string;
  customer_name: string | null;
  phone?: string | null;
  balance: number | null;
};

type Txn = {
  id: string;
  kind: "SALE" | "PAYMENT" | string;
  amount: number;
  created_at: string | null;
  note: string | null;
  reference: string | null;
  method: string | null;
  sale_id?: string | null;
};

type TxnWithRunning = Txn & {
  running_after: number;
  signed_delta: number;
};

function looksLikeUuid(s: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    s
  );
}
function cryptoRandomFallback() {
  return `${Date.now()}_${Math.floor(Math.random() * 1e9)}`;
}
function extractSaleId(t: { sale_id?: string | null; reference?: string | null; note?: string | null }) {
  const direct = String(t.sale_id ?? "").trim();
  if (looksLikeUuid(direct)) return direct;

  const ref = String(t.reference ?? "").trim();
  if (looksLikeUuid(ref)) return ref;

  const note = String(t.note ?? "").trim();
  if (looksLikeUuid(note)) return note;

  const blob = `${ref} ${note}`.trim();
  const m = blob.match(
    /([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})/i
  );
  return m?.[1] ?? null;
}

export default function CreditDetailScreen() {
 const uiText=useCommonText();
  const router = useRouter();
  const params = useLocalSearchParams<{ creditId: string }>();
  const accountId = String(params.creditId || "");

  const { activeRole, activeStoreId, activeOrgId } = useOrg();

  // ✅ single source of truth for money formatting
  const money = useOrgMoneyPrefs(String(activeOrgId ?? ""));

  const isOwnerAdmin = useMemo(
    () => activeRole === "owner" || activeRole === "admin",
    [activeRole]
  );

  // ✅ NEW: switch-aware permission (staff allowed only when store switch ON)
  const [canManageCredit, setCanManageCredit] = useState(false);

  const [account, setAccount] = useState<AccountRow | null>(null);
  const [txns, setTxns] = useState<Txn[]>([]);
  const [loading, setLoading] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  const balance = useMemo(() => Number(account?.balance ?? 0), [account]);

  // 🔒 Freeze rule (UX only): balance = 0
  const isCleared = useMemo(() => Number(balance) <= 0, [balance]);

  const payments: Payment[] = useMemo(() => {
    return txns
      .filter((t) => String(t.kind).toUpperCase() === "PAYMENT")
      .map((t) => ({
        id: String(t.id),
        amount: Number(t.amount ?? 0),
        payment_date: t.created_at ?? null,
        note: t.note ?? null,
        method: t.method ?? null,
        reference: t.reference ?? null,
      }));
  }, [txns]);

  const openReceipt = useCallback(
    (saleId: string) => {
      const s = String(saleId ?? "").trim();
      if (!s) return;
      router.push({ pathname: "/(tabs)/sales/receipt", params: { saleId: s } } as any);
    },
    [router]
  );
  const openPaymentReceipt = useCallback(
    (paymentId: string) => {
      const pid = String(paymentId ?? "").trim();
      if (!pid || !accountId) return;

      router.push({
        pathname: "/(tabs)/credit/payment-receipt",
        params: {
          creditId: accountId,
          paymentId: pid,
        },
      } as any);
    },
    [router, accountId]
  );
  const loadAccess = useCallback(async () => {
    try {
      if (!activeStoreId) {
        setCanManageCredit(false);
        return;
      }
      if (isOwnerAdmin) {
        setCanManageCredit(true);
        return;
      }

      const { data, error } = await supabase.rpc("can_manage_credit_for_store", {
        p_store_id: activeStoreId,
      } as any);

      if (error) throw error;
      setCanManageCredit(!!data);
    } catch {
      setCanManageCredit(false);
    }
  }, [activeStoreId, isOwnerAdmin]);

  const openPaymentSheet = useCallback(() => {
    if (isCleared) return;
    if (!canManageCredit) return;
    setSheetOpen(true);
  }, [isCleared, canManageCredit]);

  const load = useCallback(async () => {
    if (!accountId) return;

    try {
      setErrMsg(null);
      setLoading(true);

      if (!activeStoreId) {
        setAccount(null);
        setTxns([]);
        setErrMsg("Missing activeStoreId. Chagua store kwanza.");
        return;
      }

      const { data: list, error: le } = await supabase.rpc(
        "get_store_credit_accounts_v2",
        { p_store_id: activeStoreId, p_status: "ALL" } as any
      );
      if (le) throw le;

      const row = ((list ?? []) as any[]).find((x) => {
        const id = x.account_id ?? x.credit_account_id ?? x.id;
        return String(id) === String(accountId);
      });

      setAccount(
        row
          ? {
              account_id: String(row.account_id ?? row.credit_account_id ?? row.id),
              customer_name: row.customer_name ?? row.full_name ?? row.name ?? null,
              phone: row.phone ?? row.normalized_phone ?? null,
              balance: Number(row.balance ?? row.balance_amount ?? 0),
            }
          : { account_id: accountId, customer_name: "Customer", phone: null, balance: 0 }
      );

      const { data: t, error: te } = await supabase.rpc(
        "get_credit_account_transactions_v2",
        { p_credit_account_id: accountId, p_limit: 200 } as any
      );
      if (te) throw te;

      const mapped: Txn[] = ((t ?? []) as any[]).map((x) => {
        const id = x.id ?? x.txn_id ?? x.transaction_id ?? cryptoRandomFallback();

        const kind =
          String(x.entry_type ?? x.kind ?? x.type ?? x.txn_type ?? x.entry_kind ?? "")
            .toUpperCase()
            .trim() || "TXN";

        const amountRaw = x.amount ?? x.delta ?? x.delta_amount ?? 0;
        const created_at =
          x.created_at ?? x.txn_date ?? x.transaction_date ?? x.inserted_at ?? null;

        const note = x.note ?? x.description ?? null;
        const reference = x.reference ?? x.ref ?? null;
        const method = x.payment_method ?? x.method ?? null;

        const saleId =
          x.sale_id ??
          x.saleId ??
          x.saleID ??
          x.related_sale_id ??
          x.related_sale ??
          x.sale ??
          null;

        return {
          id: String(id),
          kind,
          amount: Number(amountRaw ?? 0),
          created_at,
          note,
          reference,
          method,
          sale_id: saleId != null ? String(saleId) : null,
        };
      });

      const saleIdsToCheck = Array.from(
        new Set(
          mapped
            .filter((x) => String(x.kind).toUpperCase() === "SALE")
            .map((x) => extractSaleId(x))
            .filter((x): x is string => !!x)
        )
      );

      let existingSaleIds = new Set<string>();

      if (saleIdsToCheck.length > 0) {
        const { data: existingSales } = await supabase
          .from("sales")
          .select("id")
          .in("id", saleIdsToCheck);

        existingSaleIds = new Set(
          ((existingSales ?? []) as any[]).map((x) => String(x.id))
        );
      }

      const cleanMapped = mapped.filter((x) => {
        const kind = String(x.kind).toUpperCase();
        if (kind !== "SALE") return true;

        const sid = extractSaleId(x);

        // Kama ni SALE lakini receipt/sale imefutwa, isiendelee kuonekana kwenye credit detail.
        if (sid && !existingSaleIds.has(sid)) return false;

        return true;
      });

      cleanMapped.sort((a, b) => {
        const ta = a.created_at ? new Date(a.created_at).getTime() : 0;
        const tb = b.created_at ? new Date(b.created_at).getTime() : 0;
        return tb - ta;
      });

      setTxns(cleanMapped);
    } catch (e: any) {
      setAccount(null);
      setTxns([]);
      setErrMsg(e?.message ?? "Failed to load credit detail.");
    } finally {
      setLoading(false);
    }
  }, [accountId, activeStoreId]);

  useFocusEffect(
    useCallback(() => {
      loadAccess();
      load();
    }, [loadAccess, load])
  );

  const txnsWithRunning: TxnWithRunning[] = useMemo(() => {
    if (!txns || txns.length === 0) return [];

    const chronological = [...txns].sort((a, b) => {
      const ta = a.created_at ? new Date(a.created_at).getTime() : 0;
      const tb = b.created_at ? new Date(b.created_at).getTime() : 0;
      return ta - tb;
    });

    let run = 0;
    const computedChrono: TxnWithRunning[] = chronological.map((t) => {
      const k = String(t.kind).toUpperCase();
      const amt = Math.abs(Number(t.amount ?? 0));
      const signed = k === "PAYMENT" ? -amt : k === "SALE" ? +amt : +Number(t.amount ?? 0);
      run = run + signed;

      return { ...t, signed_delta: signed, running_after: run };
    });

    computedChrono.sort((a, b) => {
      const ta = a.created_at ? new Date(a.created_at).getTime() : 0;
      const tb = b.created_at ? new Date(b.created_at).getTime() : 0;
      return tb - ta;
    });

    return computedChrono;
  }, [txns]);

  if (loading) {
    return (
      <Screen>
        <View style={{ paddingVertical: 18 }}>
          <ActivityIndicator />
        </View>
      </Screen>
    );
  }

  const custName = account?.customer_name ?? "Customer";
  const custPhone = account?.phone ?? null;

  return (
    <Screen scroll bottomPad={220}>
      <View style={{ flex: 1, gap: 14 }}>
        <View style={{ paddingTop: 6, paddingBottom: 10 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 14 }}>
            <Pressable
              onPress={() => router.back()}
              hitSlop={10}
              style={{
                width: 44,
                height: 44,
                borderRadius: 999,
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: "rgba(148,163,184,0.22)",
                backgroundColor: "#FFFFFF",
              }}
            >
              <SafeIcon name="chevron-left" size={22} color={theme.colors.text} />
            </Pressable>

            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: "900" }}>
                {uiText("Credit Detail")}</Text>
              <Text style={{ color: theme.colors.muted, marginTop: 4 }}>
                {uiText("Transactions + taarifa za mteja.")}</Text>
            </View>
          </View>
        </View>

        {errMsg ? (
          <Card>
            <Text style={{ color: theme.colors.danger, fontWeight: "900" }}>{errMsg}</Text>
          </Card>
        ) : null}

        <Card
          style={{
            gap: 12,
            padding: 18,
            backgroundColor: "#FFFFFF",
            borderColor: "rgba(148,163,184,0.22)",
            shadowColor: "#0F172A",
            shadowOpacity: 0.08,
            shadowRadius: 14,
            shadowOffset: { width: 0, height: 8 },
            elevation: 3,
          }}
        >
          <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("Summary")}</Text>

          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 18 }}>
            {(account?.customer_name ?? uiText("Customer"))}
          </Text>

          {custPhone ? (
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{custPhone}</Text>
          ) : (
            <Text style={{ color: theme.colors.muted, fontWeight: "800" }}>{uiText("No phone")}</Text>
          )}

          <View
            style={{
              marginTop: 4,
              paddingVertical: 10,
              paddingHorizontal: 12,
              borderRadius: 18,
              borderWidth: 1,
              borderColor: "rgba(16,185,129,0.26)",
              backgroundColor: "rgba(16,185,129,0.08)",
            }}
          >
            <Text style={{ color: theme.colors.muted, fontWeight: "900" }}>{uiText("Balance")}</Text>
            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 18 }}>
              {money.fmt(balance)}
            </Text>
          </View>

          <View style={{ height: 6 }} />

          {isCleared ? (
            <View
              style={{
                borderWidth: 1,
                borderColor: theme.colors.emeraldBorder,
                backgroundColor: theme.colors.emeraldSoft,
                paddingVertical: 12,
                paddingHorizontal: 14,
                borderRadius: theme.radius.xl,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ color: theme.colors.emerald, fontWeight: "900", fontSize: 16 }}>
                {uiText("Account Cleared 🔒")}</Text>
              <Text style={{ color: theme.colors.muted, marginTop: 6, textAlign: "center" }}>
                {uiText("Balance ni 0. Malipo mapya hayaruhusiwi kwenye account hii.")}</Text>
            </View>
          ) : null}

          <Pressable
            onPress={openPaymentSheet}
            disabled={!accountId || !canManageCredit || isCleared}
            style={({ pressed }) => ({
              minHeight: 56,
              borderRadius: 18,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor:
                !accountId || !canManageCredit || isCleared
                  ? "rgba(16,185,129,0.35)"
                  : "#059669",
              opacity: pressed ? 0.9 : 1,
              shadowColor: "#059669",
              shadowOpacity: 0.18,
              shadowRadius: 12,
              shadowOffset: { width: 0, height: 8 },
              elevation: 3,
            })}
          >
            <Text style={{ color: "#FFFFFF", fontWeight: "900", fontSize: 16 }}>
              {isCleared ? uiText("Account Cleared 🔒") : uiText("Add Payment")}
            </Text>
          </Pressable>

          <Text style={{ color: theme.colors.faint, fontSize: 12 }}>
            {canManageCredit ? uiText("Staff (Allowed) / Owner/Admin") : uiText("Staff")} {uiText("• Credit v2 • Transactions")}</Text>
        </Card>

        <Card
          style={{
            gap: 12,
            padding: 18,
            backgroundColor: "#FFFFFF",
            borderColor: "rgba(148,163,184,0.22)",
            shadowColor: "#0F172A",
            shadowOpacity: 0.08,
            shadowRadius: 14,
            shadowOffset: { width: 0, height: 8 },
            elevation: 3,
          }}
        >
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}>
              {uiText("Recent Transactions")}</Text>
            <Pressable onPress={load} style={{ paddingVertical: 6, paddingHorizontal: 10 }}>
              <Text style={{ color: theme.colors.emerald, fontWeight: "900" }}>{uiText("Refresh")}</Text>
            </Pressable>
          </View>

          {txnsWithRunning.length === 0 ? (
            <Text style={{ color: theme.colors.muted }}>{uiText("No transactions yet.")}</Text>
          ) : (
            txnsWithRunning.map((t) => {
              const kind = String(t.kind).toUpperCase();
              const amtAbs = Math.abs(Number(t.amount ?? 0));
              const isPayment = kind === "PAYMENT";
              const isSale = kind === "SALE";

              const amountColor = isPayment ? theme.colors.text : theme.colors.emerald;
              const deltaLabel = isPayment ? `-${money.fmt(amtAbs)}` : `+${money.fmt(amtAbs)}`;
              const when = t.created_at ? new Date(t.created_at).toLocaleString() : "—";

              const saleIdForReceipt = isSale ? extractSaleId(t) : null;
              const canOpenReceipt = isSale && !!saleIdForReceipt;
              const canOpenPaymentReceipt = isPayment && !!t.id;

              return (
                <View
                  key={t.id}
                  style={{
                    paddingTop: 10,
                    borderTopWidth: 1,
                    borderTopColor: "rgba(148,163,184,0.18)",
                  }}
                >
                  <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 10 }}>
                    <Text style={{ color: theme.colors.text, fontWeight: "900" }}>{kind}</Text>
                    <Text style={{ color: amountColor, fontWeight: "900" }}>{deltaLabel}</Text>
                  </View>

                  <Text style={{ color: theme.colors.muted, marginTop: 4, fontWeight: "900" }}>
                    {uiText("Running:")}{" "}
                    <Text style={{ color: theme.colors.text }}>{money.fmt(t.running_after)}</Text>
                  </Text>

                  {!!t.method && isPayment ? (
                    <Text style={{ color: theme.colors.muted, marginTop: 4, fontWeight: "800" }}>
                      {String(t.method).toUpperCase()}
                      {t.reference ? ` • ${t.reference}` : ""}
                    </Text>
                  ) : null}

                  {!!t.note ? (
                    <Text style={{ color: theme.colors.muted, marginTop: 4 }}>{t.note}</Text>
                  ) : null}

                  <Text style={{ color: theme.colors.faint, marginTop: 6, fontSize: 12 }}>
                    {when}
                  </Text>

                  {canOpenReceipt ? (
                    <Pressable
                      onPress={() => openReceipt(String(saleIdForReceipt))}
                      hitSlop={10}
                      style={{ marginTop: 8, alignSelf: "flex-start" }}
                    >
                      <Text
                        style={{
                          color: theme.colors.emerald,
                          fontWeight: "900",
                          textDecorationLine: "underline",
                        }}
                      >
                        {uiText("Open Receipt →")}</Text>
                    </Pressable>
                  ) : null}

                  {canOpenPaymentReceipt ? (
                    <Pressable
                      onPress={() => openPaymentReceipt(t.id)}
                      hitSlop={10}
                      style={{ marginTop: 8, alignSelf: "flex-start" }}
                    >
                      <Text
                        style={{
                          color: theme.colors.emerald,
                          fontWeight: "900",
                          textDecorationLine: "underline",
                        }}
                      >
                        {uiText("Open Payment Receipt →")}</Text>
                    </Pressable>
                  ) : null}
                </View>
              );
            })
          )}
        </Card>

        <Card
          style={{
            gap: 12,
            padding: 18,
            backgroundColor: "#FFFFFF",
            borderColor: "rgba(148,163,184,0.22)",
            shadowColor: "#0F172A",
            shadowOpacity: 0.08,
            shadowRadius: 14,
            shadowOffset: { width: 0, height: 8 },
            elevation: 3,
          }}
        >
          <Text style={{ color: theme.colors.text, fontWeight: "900", fontSize: 16 }}>
            {uiText("Payments")}</Text>

          {payments.length === 0 ? (
            <Text style={{ color: theme.colors.muted }}>{uiText("No payments yet.")}</Text>
          ) : (
            payments.map((p) => (
              <Pressable
                key={p.id}
                onPress={() => openPaymentReceipt(p.id)}
                hitSlop={10}
                style={({ pressed }) => ({
                  opacity: pressed ? 0.88 : 1,
                })}
              >
                <PaymentRow payment={p} />
              </Pressable>
            ))
          )}
        </Card>

        <AddPaymentSheet
          visible={sheetOpen}
          creditId={accountId}
          canManageCredit={canManageCredit}
          onClose={() => setSheetOpen(false)}
          onSuccess={(paymentId) => {
            loadAccess();
            load();

            const pid = String(paymentId ?? "").trim();
            if (pid) {
              router.push({
                pathname: "/(tabs)/credit/payment-receipt",
                params: {
                  creditId: accountId,
                  paymentId: pid,
                },
              } as any);
            }
          }}
        />
      </View>
    </Screen>
  );
}
